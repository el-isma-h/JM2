"use server";

import { redirect } from "next/navigation";
import { and, eq } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import {
  checkUserTotp,
  consumeToken,
  createSession,
  destroySession,
  elevateSession,
  enableTotp,
  generateTotpSecret,
  getCurrentUser,
  hashPassword,
  issueToken,
  peekToken,
  requireUser,
  totpUri,
  validatePasswordStrength,
  verifyPassword,
} from "@/server/auth";
import { layoutMail, sendMail } from "@/server/mail";
import { audit } from "@/server/audit";
import { appUrl, requireEmailVerification } from "@/lib/env";
import { safeNextPath, slugify } from "@/lib/utils";
import { TERMS_VERSION } from "@/lib/legal";
import { clientIp, hit, RATE_LIMITS, resetHits, tooManyMessage } from "@/server/rate-limit";
import { bootstrapOrgDefaults } from "@/server/org-defaults";

export type ActionState = { error?: string; ok?: boolean; message?: string; data?: Record<string, string> };

const signupSchema = z.object({
  firstName: z.string().trim().min(1, "Prénom requis").max(80),
  lastName: z.string().trim().min(1, "Nom requis").max(80),
  email: z.string().trim().toLowerCase().email("Adresse e-mail invalide"),
  password: z.string(),
  orgName: z.string().trim().min(2, "Nom de l'entreprise ou du cabinet requis").max(120),
  orgKind: z.enum(["of", "cfa", "of_cfa"]),
  consent: z.literal("on", { message: "Vous devez accepter les conditions." }),
});

export async function signupAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const parsed = signupSchema.safeParse(Object.fromEntries(formData));
  if (!parsed.success) return { error: parsed.error.issues[0]?.message ?? "Formulaire invalide" };
  const d = parsed.data;
  const rl = await hit("signup:ip", await clientIp(), RATE_LIMITS.signupIp);
  if (!rl.ok) return { error: tooManyMessage(rl) };
  const pwErr = validatePasswordStrength(d.password);
  if (pwErr) return { error: `Mot de passe : ${pwErr}` };

  const [existing] = await db.select({ id: schema.users.id }).from(schema.users).where(eq(schema.users.email, d.email)).limit(1);
  if (existing) return { error: "Un compte existe déjà avec cette adresse. Connectez-vous ou réinitialisez votre mot de passe." };

  const verificationRequired = requireEmailVerification();
  const userId = await db.transaction(async (tx) => {
    let slug = slugify(d.orgName) || "organisation";
    const [clash] = await tx.select({ id: schema.tenants.id }).from(schema.tenants).where(eq(schema.tenants.slug, slug)).limit(1);
    if (clash) slug = `${slug}-${Math.random().toString(36).slice(2, 6)}`;
    const [tenant] = await tx.insert(schema.tenants).values({ name: d.orgName, kind: "organisme", slug }).returning();
    const [user] = await tx
      .insert(schema.users)
      .values({
        email: d.email,
        passwordHash: await hashPassword(d.password),
        firstName: d.firstName,
        lastName: d.lastName,
        tenantId: tenant.id,
        termsAcceptedAt: new Date(),
        termsVersion: TERMS_VERSION,
        // Vérification non exigée (pas de service e-mail ou REQUIRE_EMAIL_VERIFICATION=false) : compte valide d'emblée.
        emailVerifiedAt: verificationRequired ? null : new Date(),
      })
      .returning();
    const [org] = await tx
      .insert(schema.organismes)
      .values({ tenantId: tenant.id, legalName: d.orgName, kind: d.orgKind, ownerUserId: user.id, onboardingStep: "identite" })
      .returning();
    await tx.insert(schema.memberships).values({ orgId: org.id, userId: user.id, roles: ["direction"] });
    await bootstrapOrgDefaults(tx, org.id);
    return user.id;
  });

  if (verificationRequired) {
    const token = await issueToken("verify_email", { userId, email: d.email, ttlMinutes: 60 * 24 });
    await sendMail({
      to: d.email,
      subject: "Vérifiez votre adresse e-mail",
      html: layoutMail("Bienvenue sur Next Formation", `<p>Bonjour ${d.firstName},</p><p>Confirmez votre adresse e-mail pour activer votre espace.</p>`, {
        label: "Vérifier mon adresse",
        url: `${appUrl()}/verification?token=${token}`,
      }),
    });
  }
  await audit({ action: "auth.signup", userId, after: { emailVerification: verificationRequired ? "required" : "not_required" } });
  await createSession(userId);
  redirect(verificationRequired ? "/verification" : "/app");
}

export async function loginAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  const password = String(formData.get("password") ?? "");
  const code = String(formData.get("code") ?? "").trim();
  if (!email || !password) return { error: "E-mail et mot de passe requis." };
  const ip = await clientIp();
  const [byIp, byEmail] = [await hit("login:ip", ip, RATE_LIMITS.loginIp), await hit("login:email", email, RATE_LIMITS.loginEmail)];
  if (!byIp.ok || !byEmail.ok) {
    await audit({ action: "auth.login_throttled", after: { email, ip } });
    return { error: tooManyMessage(byIp.ok ? byEmail : byIp) };
  }
  const [user] = await db.select().from(schema.users).where(eq(schema.users.email, email)).limit(1);
  // Délai constant : pas d'indication si le compte existe.
  const ok = user ? await verifyPassword(password, user.passwordHash) : await verifyPassword(password, "$2a$12$abcdefghijklmnopqrstuuWqkV5l7Xb3Q7h7n9zq2Yq5wWnI7cmF1a");
  if (!user || !ok || user.disabledAt) {
    await audit({ action: "auth.login_failed", after: { email } });
    return { error: "Identifiants incorrects." };
  }
  if (user.totpEnabledAt) {
    if (!code) return { data: { needCode: "1" }, error: undefined };
    if (!(await checkUserTotp(user.id, code))) return { data: { needCode: "1" }, error: "Code de vérification incorrect." };
  }
  await resetHits("login:email", email);
  await createSession(user.id);
  await audit({ action: "auth.login", userId: user.id });
  redirect(safeNextPath(formData.get("next")));
}

export async function logoutAction() {
  const u = await getCurrentUser();
  await destroySession();
  if (u) await audit({ action: "auth.logout", userId: u.id });
  redirect("/connexion");
}

export async function resendVerificationAction(): Promise<ActionState> {
  const user = await requireUser();
  if (user.emailVerified) return { ok: true, message: "Adresse déjà vérifiée." };
  if (!requireEmailVerification()) return { ok: true, message: "La vérification de l'adresse n'est pas requise sur cette installation : vous pouvez accéder à votre espace." };
  const rl = await hit("verify:user", user.id, RATE_LIMITS.resendVerification);
  if (!rl.ok) return { error: tooManyMessage(rl) };
  const token = await issueToken("verify_email", { userId: user.id, email: user.email, ttlMinutes: 60 * 24 });
  const res = await sendMail({
    to: user.email,
    subject: "Vérifiez votre adresse e-mail",
    html: layoutMail("Vérification de votre adresse", `<p>Cliquez pour confirmer votre adresse e-mail.</p>`, {
      label: "Vérifier mon adresse",
      url: `${appUrl()}/verification?token=${token}`,
    }),
  });
  return {
    ok: true,
    message:
      res.status === "sent"
        ? "E-mail envoyé."
        : "E-mail journalisé dans la boîte d'envoi (service e-mail non configuré) : un administrateur peut récupérer le lien dans Admin → Boîte d'envoi.",
  };
}

export async function verifyEmailAction(token: string): Promise<ActionState> {
  const row = await consumeToken("verify_email", token);
  if (!row?.userId) return { error: "Lien invalide ou expiré." };
  await db.update(schema.users).set({ emailVerifiedAt: new Date() }).where(eq(schema.users.id, row.userId));
  await audit({ action: "auth.email_verified", userId: row.userId });
  return { ok: true };
}

export async function forgotPasswordAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  if (!email) return { error: "Adresse requise." };
  const byIp = await hit("reset:ip", await clientIp(), RATE_LIMITS.resetIp);
  if (!byIp.ok) return { error: tooManyMessage(byIp) };
  // Au-delà du plafond par adresse, on répond comme d'habitude sans renvoyer d'e-mail (pas d'indication d'existence).
  const byEmail = await hit("reset:email", email, RATE_LIMITS.resetEmail);
  if (!byEmail.ok) return { ok: true, message: "Si un compte existe pour cette adresse, un e-mail de réinitialisation a été envoyé." };
  const [user] = await db.select().from(schema.users).where(eq(schema.users.email, email)).limit(1);
  if (user) {
    const token = await issueToken("reset_password", { userId: user.id, email, ttlMinutes: 30 });
    await sendMail({
      to: email,
      subject: "Réinitialisation de votre mot de passe",
      html: layoutMail("Réinitialiser votre mot de passe", `<p>Ce lien est valable 30 minutes. Si vous n'êtes pas à l'origine de cette demande, ignorez cet e-mail.</p>`, {
        label: "Choisir un nouveau mot de passe",
        url: `${appUrl()}/reinitialiser?token=${token}`,
      }),
    });
    await audit({ action: "auth.reset_requested", userId: user.id });
  }
  return { ok: true, message: "Si un compte existe pour cette adresse, un e-mail de réinitialisation a été envoyé." };
}

export async function resetPasswordAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const token = String(formData.get("token") ?? "");
  const password = String(formData.get("password") ?? "");
  const confirm = String(formData.get("confirm") ?? "");
  if (password !== confirm) return { error: "Les deux mots de passe diffèrent." };
  const pwErr = validatePasswordStrength(password);
  if (pwErr) return { error: `Mot de passe : ${pwErr}` };
  const row = await consumeToken("reset_password", token);
  if (!row?.userId) return { error: "Lien invalide ou expiré." };
  await db.update(schema.users).set({ passwordHash: await hashPassword(password) }).where(eq(schema.users.id, row.userId));
  await db.delete(schema.sessions).where(eq(schema.sessions.userId, row.userId));
  await audit({ action: "auth.password_reset", userId: row.userId });
  return { ok: true, message: "Mot de passe modifié. Vous pouvez vous connecter." };
}

// ---------- TOTP ----------

export async function startTotpSetupAction(): Promise<ActionState> {
  const user = await requireUser();
  const secret = generateTotpSecret();
  return { ok: true, data: { secret, uri: totpUri(user.email, secret) } };
}

export async function confirmTotpSetupAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const user = await requireUser();
  const secret = String(formData.get("secret") ?? "");
  const code = String(formData.get("code") ?? "");
  const ok = await enableTotp(user.id, secret, code);
  if (!ok) return { error: "Code incorrect. Vérifiez l'heure de votre téléphone et réessayez." };
  await elevateSession(user.sessionId);
  await audit({ action: "auth.totp_enabled", userId: user.id });
  const [u] = await db.select({ codes: schema.users.recoveryCodesHash }).from(schema.users).where(eq(schema.users.id, user.id));
  void u;
  return { ok: true, message: "Authentification renforcée activée." };
}

/** Vérification renforcée pour un accès sensible (RIB, exports, clôture). */
export async function elevateAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const user = await requireUser();
  const rl = await hit("elevate:user", user.id, RATE_LIMITS.elevate);
  if (!rl.ok) return { error: tooManyMessage(rl) };
  const code = String(formData.get("code") ?? "");
  const password = String(formData.get("password") ?? "");
  if (user.totpEnabled) {
    if (!(await checkUserTotp(user.id, code))) return { error: "Code incorrect." };
  } else {
    const [u] = await db.select().from(schema.users).where(eq(schema.users.id, user.id)).limit(1);
    if (!u || !(await verifyPassword(password, u.passwordHash))) return { error: "Mot de passe incorrect." };
  }
  await elevateSession(user.sessionId);
  await audit({ action: "auth.elevated", userId: user.id });
  const next = safeNextPath(formData.get("next"), "");
  if (next) redirect(next);
  return { ok: true };
}

// ---------- Invitations ----------

export async function acceptInvitationAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const token = String(formData.get("token") ?? "");
  const rl = await hit("invite:ip", await clientIp(), RATE_LIMITS.invitationIp);
  if (!rl.ok) return { error: tooManyMessage(rl) };
  const inv = await peekToken("invite", token);
  if (!inv) return { error: "Invitation invalide ou expirée." };
  const payload = inv.payload as { invitationId: string };
  const [invitation] = await db.select().from(schema.invitations).where(eq(schema.invitations.id, payload.invitationId)).limit(1);
  if (!invitation || invitation.status !== "pending") return { error: "Invitation déjà utilisée ou révoquée." };

  const current = await getCurrentUser();
  let userId = current?.id;
  if (!userId) {
    const firstName = String(formData.get("firstName") ?? "").trim();
    const lastName = String(formData.get("lastName") ?? "").trim();
    const password = String(formData.get("password") ?? "");
    if (!firstName || !lastName) return { error: "Prénom et nom requis." };
    const pwErr = validatePasswordStrength(password);
    if (pwErr) return { error: `Mot de passe : ${pwErr}` };
    const [existing] = await db.select().from(schema.users).where(eq(schema.users.email, invitation.email)).limit(1);
    if (existing) {
      if (!(await verifyPassword(password, existing.passwordHash))) return { error: "Un compte existe pour cette adresse : saisissez son mot de passe." };
      userId = existing.id;
    } else {
      const [u] = await db
        .insert(schema.users)
        .values({
          email: invitation.email,
          passwordHash: await hashPassword(password),
          firstName,
          lastName,
          tenantId: invitation.tenantId,
          emailVerifiedAt: new Date(),
          termsAcceptedAt: new Date(),
          termsVersion: TERMS_VERSION,
        })
        .returning();
      userId = u.id;
    }
  } else if (current && current.email !== invitation.email) {
    return { error: `Cette invitation est destinée à ${invitation.email}. Déconnectez-vous pour l'accepter.` };
  }

  await db.transaction(async (tx) => {
    if (invitation.orgId) {
      const [m] = await tx
        .select()
        .from(schema.memberships)
        .where(and(eq(schema.memberships.orgId, invitation.orgId), eq(schema.memberships.userId, userId!)))
        .limit(1);
      const roles = Array.isArray(invitation.roles) ? invitation.roles : [];
      if (!m) {
        await tx.insert(schema.memberships).values({
          orgId: invitation.orgId,
          userId: userId!,
          roles,
          personId: invitation.personId ?? null,
          trainerId: invitation.trainerId ?? null,
          companyId: invitation.companyId ?? null,
        });
      } else {
        const merged = [...new Set([...(Array.isArray(m.roles) ? (m.roles as string[]) : []), ...(roles as string[])])];
        await tx.update(schema.memberships).set({ roles: merged, active: true }).where(eq(schema.memberships.id, m.id));
      }
      // Propriétaire désigné à la création de l'organisme (script de mise en service) : la propriété est prise à l'acceptation.
      const [o] = await tx.select({ ownerUserId: schema.organismes.ownerUserId, settings: schema.organismes.settings }).from(schema.organismes).where(eq(schema.organismes.id, invitation.orgId)).limit(1);
      const st = (o?.settings ?? {}) as Record<string, unknown>;
      if (o && !o.ownerUserId && typeof st.pendingOwnerEmail === "string" && st.pendingOwnerEmail.toLowerCase() === invitation.email.toLowerCase()) {
        const { pendingOwnerEmail: _drop, ...rest } = st;
        void _drop;
        await tx.update(schema.organismes).set({ ownerUserId: userId!, settings: rest }).where(eq(schema.organismes.id, invitation.orgId));
      }
      if (invitation.personId) await tx.update(schema.persons).set({ userId: userId! }).where(eq(schema.persons.id, invitation.personId));
      if (invitation.trainerId) await tx.update(schema.trainers).set({ userId: userId! }).where(eq(schema.trainers.id, invitation.trainerId));
      if (invitation.companyId && !invitation.personId && !invitation.trainerId) {
        await tx.update(schema.contacts).set({ userId: userId! }).where(and(eq(schema.contacts.companyId, invitation.companyId), eq(schema.contacts.email, invitation.email)));
      }
    }
    await tx.update(schema.invitations).set({ status: "accepted", acceptedAt: new Date() }).where(eq(schema.invitations.id, invitation.id));
  });
  await consumeToken("invite", token);
  await audit({ action: "auth.invitation_accepted", userId, orgId: invitation.orgId, tenantId: invitation.tenantId });
  if (!current) await createSession(userId!);
  redirect("/app");
}
