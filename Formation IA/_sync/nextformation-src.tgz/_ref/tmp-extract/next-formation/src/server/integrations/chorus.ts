import "server-only";
import { and, asc, eq, isNotNull, notInArray, or, isNull } from "drizzle-orm";
import { db, schema } from "@/db";
import { audit } from "@/server/audit";
import { readDocument } from "@/server/documents/store";
import { registerJobHandler } from "@/server/jobs/registry";
import { getIntegration, readSecrets, upsertIntegration, type IntegrationRow } from "./store";
import { CHORUS_FINAL_STATUSES, chorusStatusMeta } from "./chorus-status";

/**
 * Connecteur Chorus Pro (BÊTA : à valider en qualification avant tout usage en production).
 *
 * Accès par la plateforme PISTE (piste.gouv.fr) :
 * - jeton OAuth2 « client credentials » (client_id / client_secret de l'application PISTE, scope openid) ;
 * - en-tête `cpro-account` : Base64 de « login:mot de passe » du compte technique Chorus Pro rattaché à la structure ;
 * - environnements : qualification (sandbox-oauth / sandbox-api.piste.gouv.fr) ou production (oauth / api.piste.gouv.fr).
 *
 * Dépôt d'une facture émise (`deposerFlux`) :
 * - si le PDF archivé est un Factur-X (fichier factur-x.xml embarqué) : POST /cpro/factures/v1/deposer/flux,
 *   syntaxe IN_DP_E2_CII_FACTURX, puis suivi par /cpro/transverses/v1/consulterCR ;
 * - sinon (cas du PDF généré par Next Formation, qui n'est pas un Factur-X) : mode « saisie API »,
 *   PDF ajouté par /cpro/transverses/v1/ajouter/fichier puis facture soumise par /cpro/factures/v1/soumettre avec ses
 *   métadonnées (destinataire SIRET + code service, références, lignes, totaux).
 * Suivi : /cpro/factures/v1/consulter/fournisseur (statut de la facture) ; job récurrent `chorus:status`.
 *
 * Tous les appels sont protégés par un délai maximal et renvoient des erreurs explicites en français.
 * Chaque dépôt (réussi ou non) est audité. Les secrets restent chiffrés (org_integrations.secrets_enc).
 */

export type ChorusEnv = "qualification" | "production";
export type ChorusConfig = { env?: ChorusEnv; supplierSiret?: string | null; supplierStructureId?: number | null; supplierName?: string | null; lastTestAt?: string | null };
export type ChorusSecrets = { clientId?: string; clientSecret?: string; techLogin?: string; techPassword?: string };

export const CHORUS_ENDPOINTS: Record<ChorusEnv, { oauth: string; api: string; label: string }> = {
  qualification: { oauth: "https://sandbox-oauth.piste.gouv.fr/api/oauth/token", api: "https://sandbox-api.piste.gouv.fr", label: "Qualification (bac à sable PISTE)" },
  production: { oauth: "https://oauth.piste.gouv.fr/api/oauth/token", api: "https://api.piste.gouv.fr", label: "Production" },
};

const TIMEOUT_MS = 20_000;

export class ChorusError extends Error {
  constructor(message: string, public readonly detail?: Record<string, unknown>) {
    super(message);
    this.name = "ChorusError";
  }
}

/* ---------- Configuration ---------- */

export type ChorusState = { row: IntegrationRow | null; config: ChorusConfig; env: ChorusEnv; configured: boolean; disabled: boolean; missing: string[] };

export async function getChorusState(orgId: string): Promise<ChorusState> {
  const row = await getIntegration(orgId, "chorus");
  const config = ((row?.config ?? {}) as ChorusConfig) ?? {};
  const secrets = readSecrets<ChorusSecrets>(row) ?? {};
  const missing: string[] = [];
  if (!row) missing.push("connecteur Chorus Pro non configuré (page Intégrations)");
  else {
    if (!secrets.clientId) missing.push("client_id PISTE");
    if (!secrets.clientSecret) missing.push("client_secret PISTE");
    if (!secrets.techLogin) missing.push("login du compte technique Chorus Pro");
    if (!secrets.techPassword) missing.push("mot de passe du compte technique Chorus Pro");
  }
  const disabled = row?.status === "desactivee";
  if (disabled) missing.push("connecteur Chorus Pro désactivé (page Intégrations)");
  return { row, config, env: config.env === "production" ? "production" : "qualification", configured: missing.length === 0, disabled, missing };
}

/* ---------- Appels réseau ---------- */

async function fetchWithTimeout(url: string, init: RequestInit, what: string): Promise<Response> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
  try {
    return await fetch(url, { ...init, signal: ctrl.signal, cache: "no-store" });
  } catch (e) {
    if (e instanceof Error && e.name === "AbortError") throw new ChorusError(`${what} : Chorus Pro (PISTE) n'a pas répondu en ${TIMEOUT_MS / 1000} s. Réessayez plus tard.`);
    throw new ChorusError(`${what} : connexion à PISTE impossible (${e instanceof Error ? e.message : "erreur réseau"}).`);
  } finally {
    clearTimeout(timer);
  }
}

const g = globalThis as unknown as { __nfChorusTokens?: Map<string, { token: string; exp: number }> };
const tokens = (g.__nfChorusTokens ??= new Map());

/** Jeton OAuth2 PISTE (client credentials, scope openid), mis en cache jusqu'à une minute avant expiration. */
export async function getPisteToken(env: ChorusEnv, secrets: ChorusSecrets): Promise<string> {
  if (!secrets.clientId || !secrets.clientSecret) throw new ChorusError("Identifiants PISTE manquants (client_id / client_secret).");
  const key = `${env}:${secrets.clientId}`;
  const cached = tokens.get(key);
  if (cached && cached.exp > Date.now()) return cached.token;
  const body = new URLSearchParams({ grant_type: "client_credentials", client_id: secrets.clientId, client_secret: secrets.clientSecret, scope: "openid" });
  const res = await fetchWithTimeout(CHORUS_ENDPOINTS[env].oauth, { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded", Accept: "application/json" }, body: body.toString() }, "Jeton PISTE");
  const json = (await res.json().catch(() => null)) as { access_token?: string; expires_in?: number; error?: string; error_description?: string } | null;
  if (!res.ok || !json?.access_token) {
    const reason = json?.error_description || json?.error || `réponse HTTP ${res.status}`;
    throw new ChorusError(`Jeton PISTE refusé (${reason}). Vérifiez le client_id / client_secret de l'application PISTE et l'environnement (${CHORUS_ENDPOINTS[env].label}).`);
  }
  tokens.set(key, { token: json.access_token, exp: Date.now() + Math.max(60, (json.expires_in ?? 3600) - 60) * 1000 });
  return json.access_token;
}

type CproResponse = { codeRetour?: number | string; libelle?: string } & Record<string, unknown>;

/** Appel JSON d'un service Chorus Pro (POST), avec jeton PISTE et compte technique. */
async function cpro<T extends CproResponse>(env: ChorusEnv, secrets: ChorusSecrets, path: string, payload: Record<string, unknown>, what: string): Promise<T> {
  if (!secrets.techLogin || !secrets.techPassword) throw new ChorusError("Compte technique Chorus Pro manquant (login / mot de passe).");
  const token = await getPisteToken(env, secrets);
  const account = Buffer.from(`${secrets.techLogin}:${secrets.techPassword}`, "utf8").toString("base64");
  const res = await fetchWithTimeout(
    `${CHORUS_ENDPOINTS[env].api}${path}`,
    { method: "POST", headers: { Authorization: `Bearer ${token}`, "cpro-account": account, "Content-Type": "application/json;charset=utf-8", Accept: "application/json;charset=utf-8" }, body: JSON.stringify(payload) },
    what,
  );
  const text = await res.text();
  let json: T | null = null;
  try {
    json = text ? (JSON.parse(text) as T) : null;
  } catch {
    json = null;
  }
  if (res.status === 401) {
    tokens.delete(`${env}:${secrets.clientId}`);
    throw new ChorusError(`${what} : accès refusé par PISTE (HTTP 401). Le jeton a expiré ou l'application PISTE n'est pas abonnée à l'API Chorus Pro.`);
  }
  if (res.status === 403) throw new ChorusError(`${what} : compte technique refusé (HTTP 403). Vérifiez le login / mot de passe du compte technique et qu'il est rattaché à la structure, avec les droits API activés.`);
  if (!res.ok) throw new ChorusError(`${what} : Chorus Pro a répondu HTTP ${res.status}${json?.libelle ? ` (${json.libelle})` : ""}.`, { status: res.status, body: text.slice(0, 500) });
  if (!json) throw new ChorusError(`${what} : réponse illisible de Chorus Pro (HTTP ${res.status}).`, { body: text.slice(0, 500) });
  if (json.codeRetour !== undefined && Number(json.codeRetour) !== 0) throw new ChorusError(`${what} : ${json.libelle || `code retour ${json.codeRetour}`}.`, { codeRetour: json.codeRetour });
  return json;
}

/* ---------- Services Chorus Pro ---------- */

/** Identifiant technique (idStructureCPP) d'une structure à partir de son SIRET. */
export async function rechercherStructure(env: ChorusEnv, secrets: ChorusSecrets, siret: string): Promise<{ id: number; name: string | null }> {
  const r = await cpro<CproResponse & { listeStructures?: { idStructureCPP?: number; designationStructure?: string }[] }>(env, secrets, "/cpro/structures/v1/rechercher", { structure: { identifiantStructure: siret, typeIdentifiantStructure: "SIRET" }, restreindreStructuresPrivees: false }, "Recherche de la structure");
  const s = r.listeStructures?.[0];
  if (!s?.idStructureCPP) throw new ChorusError(`Aucune structure Chorus Pro ne correspond au SIRET ${siret}. Créez ou rattachez la structure sur Chorus Pro (${CHORUS_ENDPOINTS[env].label}).`);
  return { id: Number(s.idStructureCPP), name: s.designationStructure ?? null };
}

/** Dépôt d'un flux (Factur-X) : renvoie le numéro de flux. */
export async function deposerFluxFichier(env: ChorusEnv, secrets: ChorusSecrets, input: { file: Buffer; fileName: string; syntaxe?: string }) {
  const r = await cpro<CproResponse & { numeroFluxDepot?: string; dateDepot?: string }>(env, secrets, "/cpro/factures/v1/deposer/flux", { fichierFlux: input.file.toString("base64"), nomFichier: input.fileName, syntaxeFlux: input.syntaxe ?? "IN_DP_E2_CII_FACTURX", avecSignature: false }, "Dépôt du flux");
  if (!r.numeroFluxDepot) throw new ChorusError("Dépôt du flux : Chorus Pro n'a pas renvoyé de numéro de flux.");
  return { numeroFluxDepot: String(r.numeroFluxDepot), dateDepot: r.dateDepot ?? null };
}

export async function consulterCR(env: ChorusEnv, secrets: ChorusSecrets, numeroFluxDepot: string) {
  const r = await cpro<CproResponse & { etatCourantFlux?: string }>(env, secrets, "/cpro/transverses/v1/consulterCR", { numeroFluxDepot }, "Compte rendu du flux");
  return { etat: r.etatCourantFlux ?? null };
}

export async function ajouterFichier(env: ChorusEnv, secrets: ChorusSecrets, input: { file: Buffer; fileName: string }) {
  const r = await cpro<CproResponse & { pieceJointeId?: number }>(env, secrets, "/cpro/transverses/v1/ajouter/fichier", { pieceJointeFichier: input.file.toString("base64"), pieceJointeNom: input.fileName, pieceJointeTypeMime: "application/pdf", pieceJointeExtension: "PDF" }, "Ajout du PDF");
  if (!r.pieceJointeId) throw new ChorusError("Ajout du PDF : Chorus Pro n'a pas renvoyé d'identifiant de pièce jointe.");
  return Number(r.pieceJointeId);
}

export async function soumettreFacture(env: ChorusEnv, secrets: ChorusSecrets, payload: Record<string, unknown>) {
  const r = await cpro<CproResponse & { identifiantFactureCPP?: number; numeroFacture?: string; statutFacture?: string; dateDepot?: string }>(env, secrets, "/cpro/factures/v1/soumettre", payload, "Soumission de la facture");
  if (!r.identifiantFactureCPP) throw new ChorusError("Soumission de la facture : Chorus Pro n'a pas renvoyé d'identifiant de facture.");
  return { id: Number(r.identifiantFactureCPP), statut: r.statutFacture ?? "DEPOSEE", dateDepot: r.dateDepot ?? null };
}

export async function consulterFactureFournisseur(env: ChorusEnv, secrets: ChorusSecrets, identifiantFactureCPP: number) {
  const r = await cpro<CproResponse & { facture?: { statutFacture?: string; statut?: string } }>(env, secrets, "/cpro/factures/v1/consulter/fournisseur", { identifiantFactureCPP }, "Consultation de la facture");
  return { statut: r.facture?.statutFacture ?? r.facture?.statut ?? null };
}

export async function rechercherFactureParFlux(env: ChorusEnv, secrets: ChorusSecrets, numeroFluxDepot: string) {
  const r = await cpro<CproResponse & { listeFactures?: { identifiantFactureCPP?: number; statut?: string }[] }>(env, secrets, "/cpro/factures/v1/rechercher/fournisseur", { numeroFluxDepot }, "Recherche de la facture du flux");
  const f = r.listeFactures?.[0];
  return f?.identifiantFactureCPP ? { id: Number(f.identifiantFactureCPP), statut: f.statut ?? null } : null;
}

/* ---------- Règles de dépôt ---------- */

type Invoice = typeof schema.invoices.$inferSelect;

/** Ce qui empêche le dépôt de cette facture (liste vide = dépôt possible). */
export function chorusBlockers(state: Pick<ChorusState, "missing">, inv: Pick<Invoice, "status" | "kind" | "documentId" | "buyerSiret" | "serviceCode" | "chorusStatus" | "chorusRef" | "number">): string[] {
  const out = [...state.missing];
  if (inv.status === "brouillon" || !inv.number) out.push("facture à émettre (un brouillon ne se dépose pas)");
  if (inv.status === "annulee") out.push("facture annulée");
  if (inv.kind === "proforma") out.push("une pro forma ne se dépose pas sur Chorus Pro");
  if (!inv.documentId) out.push("PDF archivé de la facture");
  if (!inv.buyerSiret?.trim()) out.push("SIRET de l'acheteur public");
  if (!inv.serviceCode?.trim()) out.push("code service");
  if (inv.chorusRef && !chorusStatusMeta(inv.chorusStatus).redeposit) out.push(`déjà déposée (${chorusStatusMeta(inv.chorusStatus).label})`);
  return out;
}

/** Un PDF Factur-X embarque un fichier « factur-x.xml » (CII). */
export function isFacturX(pdf: Buffer): boolean {
  const s = pdf.toString("latin1");
  return /factur-x\.xml/i.test(s) && /CrossIndustryInvoice/.test(s);
}

const euros = (cents: number) => Math.round(cents) / 100;

/** Corps de la soumission « saisie API » à partir de la facture émise et de ses lignes figées. */
export function buildSoumettrePayload(input: { invoice: Invoice; lines: (typeof schema.invoiceLines.$inferSelect)[]; supplierStructureId: number; pieceJointeId: number; fileName: string; originalNumber: string | null }) {
  const { invoice: inv, lines } = input;
  const byRate = new Map<number, { base: number; vat: number }>();
  for (const l of lines) {
    const rate = inv.vatExempt ? 0 : l.vatRateBp;
    const cur = byRate.get(rate) ?? { base: 0, vat: 0 };
    cur.base += l.totalHtCents;
    cur.vat += inv.vatExempt ? 0 : Math.round((l.totalHtCents * l.vatRateBp) / 10000);
    byRate.set(rate, cur);
  }
  // Le numéro d'engagement juridique prime (rapprochement côté acheteur) ; sinon le bon de commande.
  const numeroBonCommande = inv.legalCommitment?.trim() || inv.purchaseOrderNumber?.trim() || undefined;
  const commentaire = [inv.purchaseOrderNumber ? `Bon de commande ${inv.purchaseOrderNumber}` : null, inv.legalCommitment ? `Engagement juridique ${inv.legalCommitment}` : null].filter(Boolean).join(" ; ");
  return {
    modeDepot: "SAISIE_API",
    numeroFactureSaisi: inv.number,
    dateFacture: inv.issueDate,
    cadreDeFacturation: { codeCadreFacturation: "A1_FACTURE_FOURNISSEUR" },
    destinataire: { codeDestinataire: inv.buyerSiret, codeServiceExecutant: inv.serviceCode },
    fournisseur: { idFournisseur: input.supplierStructureId },
    references: {
      deviseFacture: "EUR",
      typeFacture: inv.kind === "avoir" ? "AVOIR" : "FACTURE",
      typeTva: inv.vatExempt ? "EXONERATION" : "TVA_SUR_ENCAISSEMENT",
      ...(inv.vatExempt && inv.vatMention ? { motifExonerationTva: inv.vatMention.slice(0, 200) } : {}),
      modePaiement: "VIREMENT",
      ...(numeroBonCommande ? { numeroBonCommande } : {}),
      ...(inv.kind === "avoir" && input.originalNumber ? { numeroFactureOrigine: input.originalNumber } : {}),
    },
    lignePoste: lines.map((l, i) => ({
      lignePosteNumero: i + 1,
      lignePosteReference: `L${i + 1}`,
      lignePosteDenomination: l.label.slice(0, 512),
      lignePosteQuantite: l.quantity / 1000,
      lignePosteUnite: l.unit,
      lignePosteMontantUnitaireHT: euros(l.unitCents),
      lignePosteTauxTvaManuel: inv.vatExempt ? 0 : l.vatRateBp / 100,
    })),
    ligneTva: [...byRate.entries()].map(([rate, v]) => ({ ligneTvaTauxManuel: rate / 100, ligneTvaMontantBaseHtParTaux: euros(v.base), ligneTvaMontantTvaParTaux: euros(v.vat) })),
    montantTotal: { montantHtTotal: euros(inv.totalHtCents), montantTVA: euros(inv.vatCents), montantTtcTotal: euros(inv.totalTtcCents), montantAPayer: euros(inv.totalTtcCents - inv.paidCents) },
    pieceJointePrincipale: [{ pieceJointePrincipaleDesignation: input.fileName, pieceJointePrincipaleId: input.pieceJointeId }],
    ...(commentaire ? { commentaire } : {}),
  };
}

/* ---------- Opérations métier ---------- */

async function loadInvoice(orgId: string, invoiceId: string) {
  const [inv] = await db.select().from(schema.invoices).where(and(eq(schema.invoices.id, invoiceId), eq(schema.invoices.orgId, orgId))).limit(1);
  if (!inv) throw new ChorusError("Facture introuvable dans cet organisme.");
  return inv;
}

/** Test de connexion : jeton PISTE puis recherche de la structure de l'organisme (SIRET), mémorisée pour les dépôts. */
export async function testChorusConnection(orgId: string): Promise<{ structureId: number; name: string | null; env: ChorusEnv }> {
  const state = await getChorusState(orgId);
  if (!state.row) throw new ChorusError("Connecteur Chorus Pro non configuré.");
  const secrets = readSecrets<ChorusSecrets>(state.row) ?? {};
  const [org] = await db.select({ siret: schema.organismes.siret, isDemo: schema.organismes.isDemo }).from(schema.organismes).where(eq(schema.organismes.id, orgId)).limit(1);
  if (org?.isDemo) throw new ChorusError("Démonstration : aucun appel Chorus Pro réel.");
  const siret = state.config.supplierSiret?.trim() || org?.siret?.trim();
  if (!siret) throw new ChorusError("SIRET de l'organisme absent : renseignez-le dans Paramètres ou sur la carte Chorus Pro.");
  try {
    const s = await rechercherStructure(state.env, secrets, siret);
    await upsertIntegration(orgId, "chorus", { status: "connectee", lastError: null, lastSyncAt: new Date(), config: { supplierStructureId: s.id, supplierName: s.name, lastTestAt: new Date().toISOString() } });
    return { structureId: s.id, name: s.name, env: state.env };
  } catch (e) {
    await upsertIntegration(orgId, "chorus", { status: "erreur", lastError: e instanceof Error ? e.message.slice(0, 500) : "erreur" });
    throw e;
  }
}

/**
 * Dépôt de la facture émise sur Chorus Pro (Factur-X par flux, sinon PDF + métadonnées en saisie API).
 * Met à jour chorusStatus / chorusRef / chorusSubmittedAt et audite le dépôt, qu'il réussisse ou non.
 */
export async function deposerFlux(input: { orgId: string; invoiceId: string; userId: string }): Promise<{ mode: "flux" | "saisie_api"; ref: string; status: string; env: ChorusEnv }> {
  const { orgId, invoiceId, userId } = input;
  const state = await getChorusState(orgId);
  const inv = await loadInvoice(orgId, invoiceId);
  const blockers = chorusBlockers(state, inv);
  if (blockers.length) throw new ChorusError(`Dépôt impossible, il manque : ${blockers.join(", ")}.`);
  const [org] = await db.select().from(schema.organismes).where(eq(schema.organismes.id, orgId)).limit(1);
  if (!org) throw new ChorusError("Organisme introuvable.");
  if (org.isDemo || inv.isDemo) throw new ChorusError("Démonstration : aucun dépôt réel sur Chorus Pro.");
  const secrets = readSecrets<ChorusSecrets>(state.row) ?? {};
  const file = await readDocument(inv.documentId!);
  if (!file || file.doc.orgId !== orgId) throw new ChorusError("PDF archivé de la facture introuvable.");
  const fileName = file.doc.fileName || `${inv.number}.pdf`;
  let mode: "flux" | "saisie_api" = "saisie_api";
  try {
    let ref: string;
    let status: string;
    if (isFacturX(file.data)) {
      mode = "flux";
      const r = await deposerFluxFichier(state.env, secrets, { file: file.data, fileName });
      ref = `flux:${r.numeroFluxDepot}`;
      status = "IN_RECU";
    } else {
      let supplierStructureId = state.config.supplierStructureId ?? null;
      if (!supplierStructureId) {
        const siret = state.config.supplierSiret?.trim() || org.siret?.trim();
        if (!siret) throw new ChorusError("SIRET de l'organisme absent : impossible d'identifier le fournisseur sur Chorus Pro.");
        const s = await rechercherStructure(state.env, secrets, siret);
        supplierStructureId = s.id;
        await upsertIntegration(orgId, "chorus", { config: { supplierStructureId: s.id, supplierName: s.name } });
      }
      const lines = await db.select().from(schema.invoiceLines).where(eq(schema.invoiceLines.invoiceId, inv.id)).orderBy(asc(schema.invoiceLines.position));
      const original = inv.creditOfInvoiceId ? (await db.select({ number: schema.invoices.number }).from(schema.invoices).where(and(eq(schema.invoices.id, inv.creditOfInvoiceId), eq(schema.invoices.orgId, orgId))).limit(1))[0]?.number ?? null : null;
      const pieceJointeId = await ajouterFichier(state.env, secrets, { file: file.data, fileName });
      const r = await soumettreFacture(state.env, secrets, buildSoumettrePayload({ invoice: inv, lines, supplierStructureId, pieceJointeId, fileName, originalNumber: original }));
      ref = `facture:${r.id}`;
      status = r.statut;
    }
    await db.update(schema.invoices).set({ chorusRef: ref, chorusStatus: status, chorusSubmittedAt: new Date() }).where(and(eq(schema.invoices.id, inv.id), eq(schema.invoices.orgId, orgId)));
    await upsertIntegration(orgId, "chorus", { status: "connectee", lastError: null, lastSyncAt: new Date() });
    await audit({ action: "invoice.chorus.deposit", userId, orgId, entityType: "invoice", entityId: inv.id, before: { chorusRef: inv.chorusRef, chorusStatus: inv.chorusStatus }, after: { mode, ref, status, env: state.env, buyerSiret: inv.buyerSiret, serviceCode: inv.serviceCode, purchaseOrderNumber: inv.purchaseOrderNumber, legalCommitment: inv.legalCommitment } });
    return { mode, ref, status, env: state.env };
  } catch (e) {
    const message = e instanceof Error ? e.message : "Erreur inconnue";
    await db.update(schema.invoices).set({ chorusStatus: "echec_depot" }).where(and(eq(schema.invoices.id, inv.id), eq(schema.invoices.orgId, orgId)));
    await upsertIntegration(orgId, "chorus", { status: "erreur", lastError: message.slice(0, 500) });
    await audit({ action: "invoice.chorus.deposit_failed", userId, orgId, entityType: "invoice", entityId: inv.id, after: { mode, env: state.env, error: message.slice(0, 500) } });
    throw e instanceof ChorusError ? e : new ChorusError(`Dépôt Chorus Pro : ${message}`);
  }
}

/** Met à jour le statut Chorus Pro d'une facture déposée (flux puis facture). */
export async function refreshChorusStatus(input: { orgId: string; invoiceId: string; userId: string | null }): Promise<{ status: string | null; changed: boolean }> {
  const { orgId, invoiceId, userId } = input;
  const inv = await loadInvoice(orgId, invoiceId);
  if (!inv.chorusRef) throw new ChorusError("Facture non déposée sur Chorus Pro.");
  const state = await getChorusState(orgId);
  if (!state.configured) throw new ChorusError(`Suivi impossible, il manque : ${state.missing.join(", ")}.`);
  const secrets = readSecrets<ChorusSecrets>(state.row) ?? {};
  let ref = inv.chorusRef;
  let status: string | null = inv.chorusStatus;
  const [kind, value] = ref.split(":", 2);
  if (kind === "flux") {
    const cr = await consulterCR(state.env, secrets, value);
    status = cr.etat ?? status;
    if (cr.etat === "IN_INTEGRE" || cr.etat === "IN_INTEGRE_PARTIEL") {
      const f = await rechercherFactureParFlux(state.env, secrets, value).catch(() => null);
      if (f) {
        ref = `facture:${f.id}`;
        status = f.statut ?? status;
      }
    }
  } else if (kind === "facture" && /^\d+$/.test(value)) {
    const r = await consulterFactureFournisseur(state.env, secrets, Number(value));
    status = r.statut ?? status;
  } else {
    throw new ChorusError(`Référence Chorus Pro illisible : ${ref}.`);
  }
  const changed = status !== inv.chorusStatus || ref !== inv.chorusRef;
  if (changed) {
    await db.update(schema.invoices).set({ chorusStatus: status, chorusRef: ref }).where(and(eq(schema.invoices.id, inv.id), eq(schema.invoices.orgId, orgId)));
    await audit({ action: "invoice.chorus.status", userId, orgId, entityType: "invoice", entityId: inv.id, before: { chorusStatus: inv.chorusStatus, chorusRef: inv.chorusRef }, after: { chorusStatus: status, chorusRef: ref } });
  }
  await upsertIntegration(orgId, "chorus", { lastSyncAt: new Date(), lastError: null });
  return { status, changed };
}

/* ---------- Tâche récurrente ---------- */

// chorus:status : suivi des factures déposées dont le statut n'est pas final (hors démonstration).
registerJobHandler("chorus:status", async (job) => {
  const rows = await db
    .select({ id: schema.invoices.id, orgId: schema.invoices.orgId })
    .from(schema.invoices)
    .where(
      and(
        isNotNull(schema.invoices.chorusRef),
        eq(schema.invoices.isDemo, false),
        or(isNull(schema.invoices.chorusStatus), notInArray(schema.invoices.chorusStatus, CHORUS_FINAL_STATUSES)),
        job.orgId ? eq(schema.invoices.orgId, job.orgId) : undefined,
      ),
    )
    .limit(200);
  let checked = 0;
  let changed = 0;
  const errors: string[] = [];
  for (const r of rows) {
    try {
      const res = await refreshChorusStatus({ orgId: r.orgId, invoiceId: r.id, userId: null });
      checked++;
      if (res.changed) changed++;
    } catch (e) {
      errors.push(`${r.id} : ${e instanceof Error ? e.message : "erreur"}`.slice(0, 300));
    }
  }
  return { candidates: rows.length, checked, changed, errors: errors.slice(0, 20) };
});
