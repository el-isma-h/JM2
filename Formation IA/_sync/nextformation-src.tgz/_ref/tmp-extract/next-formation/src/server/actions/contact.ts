"use server";

import { z } from "zod";
import { layoutMail, sendMail } from "@/server/mail";
import { clientIp, hit, tooManyMessage } from "@/server/rate-limit";
import type { ActionState } from "./auth";

/** Formulaire de contact public : 5 messages par heure et par adresse IP. */
const CONTACT_RULE = { limit: 5, windowSeconds: 60 * 60 };

const schema = z.object({
  name: z.string().trim().min(2, "Indiquez votre nom.").max(120),
  email: z.string().trim().email("Adresse e-mail invalide.").max(200),
  organisation: z.string().trim().max(160).optional().default(""),
  subject: z.enum(["demo", "tarifs", "reprise", "securite", "autre"], { message: "Choisissez un sujet." }),
  message: z.string().trim().min(10, "Votre message est trop court (10 caractères minimum).").max(4000, "Votre message est trop long (4 000 caractères maximum)."),
  /** Champ piège invisible : un robot le remplit, un humain non. */
  website: z.string().optional().default(""),
});

const SUBJECTS: Record<z.infer<typeof schema>["subject"], string> = {
  demo: "Demande de démonstration accompagnée",
  tarifs: "Question sur les tarifs",
  reprise: "Reprise de données depuis un autre outil",
  securite: "Question sécurité ou conformité",
  autre: "Autre demande",
};

const esc = (s: string) => s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c] ?? c);

/**
 * Enregistre le message dans la boîte d'envoi (mail_outbox) à destination de LEGAL_CONTACT_EMAIL.
 * Sans adresse configurée ou sans service e-mail, le message reste journalisé dans la boîte d'envoi (statut « non configuré »)
 * et visible par l'administrateur plateforme.
 */
export async function contactAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const parsed = schema.safeParse({
    name: formData.get("name"),
    email: formData.get("email"),
    organisation: formData.get("organisation") ?? "",
    subject: formData.get("subject"),
    message: formData.get("message"),
    website: formData.get("website") ?? "",
  });
  if (!parsed.success) {
    const first = parsed.error.issues[0];
    return { error: first?.message ?? "Vérifiez les champs du formulaire." };
  }
  // Robot détecté : réponse neutre, rien n'est enregistré.
  if (parsed.data.website) return { ok: true, message: "Message reçu." };
  const rl = await hit("contact:ip", await clientIp(), CONTACT_RULE);
  if (!rl.ok) return { error: tooManyMessage(rl) };

  const d = parsed.data;
  const to = process.env.LEGAL_CONTACT_EMAIL?.trim() || "contact-non-configure@nextformation.local";
  const subject = `[Contact] ${SUBJECTS[d.subject]} : ${d.name}`;
  const body = `<p><strong>${esc(d.name)}</strong>${d.organisation ? ` (${esc(d.organisation)})` : ""}<br />${esc(d.email)}</p><p>${esc(d.message).replace(/\n/g, "<br />")}</p>`;
  try {
    const res = await sendMail({ to, subject, html: layoutMail(SUBJECTS[d.subject], body), text: `${d.name} (${d.organisation}) <${d.email}>\n\n${d.message}` });
    if (res.status === "failed") return { error: "Le message n'a pas pu être envoyé. Réessayez dans un instant ou écrivez-nous directement." };
  } catch (e) {
    console.error("contact.send", e);
    return { error: "Le message n'a pas pu être enregistré. Réessayez dans un instant." };
  }
  return { ok: true, message: "Nous vous répondons sous un jour ouvré à l'adresse indiquée." };
}
