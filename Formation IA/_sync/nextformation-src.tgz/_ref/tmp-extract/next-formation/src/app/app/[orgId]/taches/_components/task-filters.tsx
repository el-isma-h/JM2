import { Button } from "@/components/ui/button";
import { Checkbox, Field, Input, Select } from "@/components/ui/field";
import { TASK_FAMILIES, TASK_PRIORITIES, taskFamilyLabels, taskPriorityLabels, taskStatusLabels, TASK_STATUSES, entityTypeLabels } from "@/server/tasks/rules";
import type { TaskFilters } from "@/server/tasks/queries";

/** Filtres conservés dans l'URL (F16). */
export function TaskFiltersForm({ f, extra }: { f: TaskFilters; extra?: React.ReactNode }) {
  return (
    <form method="get" className="flex flex-wrap items-end gap-3 border-b border-line px-5 py-3">
      <Field label="Recherche" htmlFor="tf-q" className="w-full max-w-[220px]">
        <Input id="tf-q" name="q" defaultValue={f.q} placeholder="Objet ou dossier" />
      </Field>
      <Field label="Statut" htmlFor="tf-status" className="w-44">
        <Select id="tf-status" name="status" defaultValue={f.status ?? "ouvertes"}>
          <option value="ouvertes">Ouvertes</option>
          {TASK_STATUSES.map((s) => (
            <option key={s} value={s}>
              {taskStatusLabels[s]}
            </option>
          ))}
          <option value="toutes">Toutes</option>
        </Select>
      </Field>
      <Field label="Famille" htmlFor="tf-family" className="w-44">
        <Select id="tf-family" name="family" defaultValue={f.family ?? ""}>
          <option value="">Toutes</option>
          {TASK_FAMILIES.map((s) => (
            <option key={s} value={s}>
              {taskFamilyLabels[s]}
            </option>
          ))}
        </Select>
      </Field>
      <Field label="Priorité" htmlFor="tf-priority" className="w-36">
        <Select id="tf-priority" name="priority" defaultValue={f.priority ?? ""}>
          <option value="">Toutes</option>
          {TASK_PRIORITIES.map((s) => (
            <option key={s} value={s}>
              {taskPriorityLabels[s]}
            </option>
          ))}
        </Select>
      </Field>
      <Field label="Dossier" htmlFor="tf-entity" className="w-40">
        <Select id="tf-entity" name="entityType" defaultValue={f.entityType ?? ""}>
          <option value="">Tous</option>
          {Object.entries(entityTypeLabels).map(([k, v]) => (
            <option key={k} value={k}>
              {v}
            </option>
          ))}
        </Select>
      </Field>
      {f.entityId ? <input type="hidden" name="entityId" value={f.entityId} /> : null}
      {extra}
      <Checkbox name="late" value="1" defaultChecked={f.late} label="En retard seulement" className="mb-2" />
      <Button type="submit" variant="secondary">
        Filtrer
      </Button>
    </form>
  );
}
