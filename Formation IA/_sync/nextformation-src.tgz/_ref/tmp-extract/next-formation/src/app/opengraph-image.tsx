import { ImageResponse } from "next/og";

export const alt = "Next Formation : logiciel de gestion pour organismes de formation et CFA, tout le métier dans un seul dossier";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

/** Image de partage (LinkedIn, X, Slack, WhatsApp) : identité encre et signal violet. */
export default function OpengraphImage() {
  return new ImageResponse(
    (
      <div style={{ width: "100%", height: "100%", display: "flex", flexDirection: "column", justifyContent: "space-between", background: "#0A0B0D", color: "#F3F0E8", padding: "72px 80px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 18 }}>
          <svg width="44" height="44" viewBox="0 0 32 32">
            <path d="M6 28V4l20 24V4" fill="none" stroke="#F3F0E8" strokeWidth="2.2" strokeLinecap="square" />
            <rect x="23" y="4" width="3" height="3" fill="#C9B8F0" />
          </svg>
          <div style={{ display: "flex", fontSize: 28, letterSpacing: 6 }}>
            <span style={{ fontWeight: 700 }}>NEXT</span>
            <span style={{ marginLeft: 10, opacity: 0.6 }}>FORMATION</span>
          </div>
        </div>
        <div style={{ display: "flex", flexDirection: "column" }}>
          <div style={{ display: "flex", fontSize: 20, letterSpacing: 6, opacity: 0.5 }}>ORGANISMES DE FORMATION · CFA</div>
          <div style={{ display: "flex", flexDirection: "column", fontSize: 84, lineHeight: 1.02, marginTop: 28, letterSpacing: 1 }}>
            <span>TOUT LE MÉTIER,</span>
            <span style={{ color: "#C9B8F0" }}>UN SEUL DOSSIER.</span>
          </div>
          <div style={{ display: "flex", fontSize: 28, marginTop: 32, opacity: 0.72, maxWidth: 980 }}>
            Émargement par demi-journée, documents, financements, Qualiopi explicable. À 90 % du prix de référence.
          </div>
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          {["#4B2A7F", "#C9B8F0", "#8E8B83", "#5C5B61"].map((c, i) => (
            <div key={i} style={{ width: 56, height: 3, background: c }} />
          ))}
        </div>
      </div>
    ),
    size,
  );
}
