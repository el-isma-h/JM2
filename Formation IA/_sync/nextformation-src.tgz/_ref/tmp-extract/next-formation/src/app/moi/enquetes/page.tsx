import { guardLearner } from "@/server/extranet/guard";
import { listSurveys } from "@/server/extranet/queries";
import { openSurveyAction } from "@/server/actions/self";
import { NoAttachment } from "@/components/extranet/shell";
import { ActionButton } from "@/components/admin/action-form";
import { Badge } from "@/components/ui/badge";
import { EmptyState, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { fmtDate } from "@/lib/dates";

export const dynamic = "force-dynamic";

const kindLabels: Record<string, string> = {
  positionnement: "Positionnement",
  satisfaction_chaud: "Satisfaction à chaud",
  satisfaction_froid: "Satisfaction à froid",
  employeur: "Employeur",
  formateur: "Formateur",
  financeur: "Financeur",
  competences: "Compétences",
  besoins: "Besoins",
};

/** Enquêtes qui me sont adressées : en attente (ouverture via un lien personnel) ou déjà répondues. */
export default async function LearnerSurveys() {
  const ctx = await guardLearner("/moi/enquetes");
  if (!ctx) return <NoAttachment kind="learner" />;
  const rows = await listSurveys(ctx.org.id, { enrollmentIds: ctx.enrollmentIds });
  const pending = rows.filter((r) => !r.response.submittedAt && r.survey.status === "active");
  const done = rows.filter((r) => Boolean(r.response.submittedAt));
  return (
    <>
      <PageHeader title="Enquêtes" description="Vos réponses alimentent l'amélioration continue de l'organisme (Qualiopi). Elles ne modifient jamais votre dossier." />
      <div className="space-y-6">
        <Panel>
          <PanelHeader title="À répondre" />
          {pending.length ? (
            <Table>
              <thead>
                <tr>
                  <Th>Enquête</Th>
                  <Th>Type</Th>
                  <Th>Envoyée le</Th>
                  <Th className="text-right">Action</Th>
                </tr>
              </thead>
              <tbody>
                {pending.map((r) => (
                  <tr key={r.response.id}>
                    <Td className="font-medium text-ink">{r.survey.title}</Td>
                    <Td>{kindLabels[r.survey.kind] ?? r.survey.kind}</Td>
                    <Td className="num">{r.response.sentAt ? fmtDate(r.response.sentAt) : "-"}</Td>
                    <Td className="text-right">
                      <ActionButton action={openSurveyAction} fields={{ responseId: r.response.id }} label="Répondre" variant="primary" />
                    </Td>
                  </tr>
                ))}
              </tbody>
            </Table>
          ) : (
            <EmptyState title="Aucune enquête en attente" description="Vous serez invité à répondre aux enquêtes de satisfaction en fin de formation." />
          )}
        </Panel>
        <Panel>
          <PanelHeader title="Répondues" />
          {done.length ? (
            <Table>
              <thead>
                <tr>
                  <Th>Enquête</Th>
                  <Th>Type</Th>
                  <Th>Répondue le</Th>
                  <Th>État</Th>
                </tr>
              </thead>
              <tbody>
                {done.map((r) => (
                  <tr key={r.response.id}>
                    <Td className="font-medium text-ink">{r.survey.title}</Td>
                    <Td>{kindLabels[r.survey.kind] ?? r.survey.kind}</Td>
                    <Td className="num">{fmtDate(r.response.submittedAt)}</Td>
                    <Td>
                      <Badge tone="ok">Merci pour votre réponse</Badge>
                    </Td>
                  </tr>
                ))}
              </tbody>
            </Table>
          ) : (
            <EmptyState title="Aucune réponse enregistrée" />
          )}
        </Panel>
      </div>
    </>
  );
}
