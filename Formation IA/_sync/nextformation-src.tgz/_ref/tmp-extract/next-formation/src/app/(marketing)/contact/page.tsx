import type { Metadata } from "next";
import Link from "next/link";
import { PageHero } from "@/components/marketing/site";
import { publisher } from "@/lib/legal";
import { breadcrumbJsonLd, jsonLdScript, pageMeta } from "@/lib/seo";
import { ContactForm } from "./contact-form";

export const metadata: Metadata = pageMeta("/contact", "Contact", "Écrivez à l'équipe Next Formation : démonstration accompagnée, tarifs, reprise de données depuis Digiforma, Galaxy ou Excel, questions de sécurité. Réponse sous un jour ouvré.");
export const dynamic = "force-dynamic";

export default function ContactPage() {
  const p = publisher();
  return (
    <article>
      <script type="application/ld+json" dangerouslySetInnerHTML={jsonLdScript(breadcrumbJsonLd([{ name: "Accueil", path: "/" }, { name: "Contact", path: "/contact" }]))} />
      <PageHero crumbs={[{ label: "Accueil", href: "/" }, { label: "Contact" }]} eyebrow="Contact" title="Écrivez-nous." description="Réponse sous un jour ouvré. Pour voir le produit tout de suite, la démonstration s'ouvre sans compte." />
      <section className="conteneur grid gap-12 py-16 lg:grid-cols-[0.7fr_1.3fr] lg:py-24">
        <div>
          <h2 className="text-[24px]">Avant d&apos;écrire</h2>
          <ul className="mt-6 flex flex-col divide-y divide-line border-t border-line-strong text-[14px]">
            <li className="py-3">
              <Link href="/demo" className="text-accent underline-offset-4 hover:underline">Démonstration instantanée</Link>
              <span className="text-ink-2"> : organisme fictif complet, huit profils, sans compte.</span>
            </li>
            <li className="py-3">
              <Link href="/tarifs" className="text-accent underline-offset-4 hover:underline">Tarifs et calculateur</Link>
              <span className="text-ink-2"> : plan, options, comparaison avec la référence publique.</span>
            </li>
            <li className="py-3">
              <Link href="/securite-conformite" className="text-accent underline-offset-4 hover:underline">Sécurité et conformité</Link>
              <span className="text-ink-2"> : hébergement, RGPD, droits par rôle, sauvegardes.</span>
            </li>
          </ul>
          <dl className="mt-10 grid gap-y-2 text-[13.5px]">
            <dt className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">E-mail</dt>
            <dd>{p.email ? <a href={`mailto:${p.email}`} className="text-accent hover:underline">{p.email}</a> : <span className="bg-warn-soft px-1 text-warn-ink">[À compléter : adresse de contact]</span>}</dd>
            <dt className="mt-3 font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">Éditeur</dt>
            <dd>{p.name || <span className="bg-warn-soft px-1 text-warn-ink">[À compléter : raison sociale]</span>}</dd>
          </dl>
        </div>
        <div className="relative border border-line-strong bg-bg-elev p-6 sm:p-8">
          <ContactForm />
        </div>
      </section>
    </article>
  );
}
