import { NextResponse, type NextRequest } from "next/server";
import { and, asc, eq, ilike, or, sql, type SQL } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireOrg, trainerSessionIds } from "@/server/authz";
import { audit } from "@/server/audit";
import { AuthError } from "@/server/auth";
import { toCsv } from "@/server/imports/kinds";

export const dynamic = "force-dynamic";

/** Export CSV des apprenants (permission renforcée `exports.run`), même périmètre que la liste. */
export async function GET(req: NextRequest, { params }: { params: Promise<{ orgId: string }> }) {
  const { orgId } = await params;
  let ctx;
  try {
    ctx = await requireOrg(orgId, "enrollments.view", "exports.run");
  } catch (e) {
    if (e instanceof AuthError && e.code === "elevation_required") return NextResponse.redirect(new URL(`/securite?next=${encodeURIComponent(`/app/${orgId}/apprenants`)}`, req.url));
    if (e instanceof AuthError && e.code === "unauthenticated") return NextResponse.redirect(new URL(`/connexion?next=${encodeURIComponent(`/app/${orgId}/apprenants`)}`, req.url));
    return new NextResponse("Accès refusé", { status: 403 });
  }
  if (ctx.trainerOnly) return new NextResponse("Accès refusé", { status: 403 });
  const q = req.nextUrl.searchParams.get("q")?.trim();
  const status = req.nextUrl.searchParams.get("statut")?.trim();
  const scope = await trainerSessionIds(ctx);
  const scopeSql = scope ? (scope.length ? sql`and e.session_id in (${sql.join(scope.map((id) => sql`${id}`), sql`, `)})` : sql`and false`) : sql``;
  const conds: SQL[] = [eq(schema.persons.orgId, orgId), sql`exists (select 1 from ${schema.enrollments} e where e.person_id = ${schema.persons.id} ${scopeSql})`];
  if (q) conds.push(or(ilike(schema.persons.lastName, `%${q}%`), ilike(schema.persons.firstName, `%${q}%`), ilike(schema.persons.email, `%${q}%`))!);
  if (status && (schema.personStatusEnum.enumValues as readonly string[]).includes(status)) conds.push(eq(schema.persons.status, status as "apprenant"));
  const rows = await db
    .select({ p: schema.persons, companyName: schema.companies.name, enrollments: sql<number>`(select count(*)::int from ${schema.enrollments} e where e.person_id = ${schema.persons.id})` })
    .from(schema.persons)
    .leftJoin(schema.companies, eq(schema.companies.id, schema.persons.companyId))
    .where(and(...conds))
    .orderBy(asc(schema.persons.lastName), asc(schema.persons.firstName))
    .limit(20000);
  const csv = toCsv(
    ["Nom", "Prénom", "Civilité", "Date de naissance", "E-mail", "Téléphone", "Adresse", "Code postal", "Ville", "Statut", "Employeur", "Nombre d'inscriptions", "Identifiant"],
    rows.map(({ p, companyName, enrollments }) => [p.lastName, p.firstName, p.civility, p.birthDate, p.email, p.phone, p.addressLine1, p.postalCode, p.city, p.status, companyName, enrollments, p.id]),
  );
  await audit({ action: "export.run", userId: ctx.user.id, orgId, entityType: "export", after: { kind: "apprenants", rows: rows.length, q: q ?? null, status: status ?? null } });
  return new NextResponse(csv, { headers: { "content-type": "text/csv; charset=utf-8", "content-disposition": `attachment; filename="apprenants-${new Date().toISOString().slice(0, 10)}.csv"` } });
}
