import { Fragment } from "react";
import Link from "next/link";
import { notFound } from "next/navigation";
import { and, desc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { duplicateQuoteAction, generateQuotePdfAction, sendQuoteAction, setQuoteStatusAction, updateQuoteAction } from "@/server/actions/quotes";
import { quoteFormOptions } from "@/server/crm/quote-options";
import { isOverdue } from "@/server/crm/queries";
import { computeTotals, vatRateLabel, type QuoteLine } from "@/server/crm/quote-math";
import { todayParis } from "@/lib/time";
import { fmtDate, fmtDateTime } from "@/lib/dates";
import { formatCents } from "@/lib/money";
import { integrations } from "@/lib/env";
import { StatusBadge } from "@/components/ui/badge";
import { Field, Input, Textarea } from "@/components/ui/field";
import { KeyValue, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { ActionButton } from "@/components/admin/action-form";
import { FormDialog } from "@/components/admin/form-dialog";
import { QuoteForm } from "@/components/crm/quote-form";
import { DocumentList } from "@/components/crm/documents";
import { FadeIn } from "@/components/ui/motion";

export const dynamic = "force-dynamic";

export default async function QuotePage({ params }: { params: Promise<{ orgId: string; quoteId: string }> }) {
  const { orgId, quoteId } = await params;
  const base = `/app/${orgId}`;
  const ctx = await guardOrg(orgId, `${base}/devis/${quoteId}`, "crm.view");
  if (!/^[0-9a-f-]{36}$/i.test(quoteId)) notFound();
  const [quote] = await db.select().from(schema.quotes).where(and(eq(schema.quotes.id, quoteId), eq(schema.quotes.orgId, ctx.org.id))).limit(1);
  if (!quote) notFound();
  const canManage = ctx.permissions.has("crm.manage");
  const canGenerate = ctx.permissions.has("documents.generate");
  const today = todayParis();
  const lines = (Array.isArray(quote.lines) ? quote.lines : []) as QuoteLine[];
  const totals = computeTotals(lines);

  const [company, contact, person, need, docs, options] = await Promise.all([
    quote.companyId ? db.select().from(schema.companies).where(and(eq(schema.companies.id, quote.companyId), eq(schema.companies.orgId, ctx.org.id))).limit(1).then((r) => r[0] ?? null) : null,
    quote.contactId ? db.select().from(schema.contacts).where(and(eq(schema.contacts.id, quote.contactId), eq(schema.contacts.orgId, ctx.org.id))).limit(1).then((r) => r[0] ?? null) : null,
    quote.personId ? db.select().from(schema.persons).where(and(eq(schema.persons.id, quote.personId), eq(schema.persons.orgId, ctx.org.id))).limit(1).then((r) => r[0] ?? null) : null,
    quote.needId ? db.select().from(schema.needs).where(and(eq(schema.needs.id, quote.needId), eq(schema.needs.orgId, ctx.org.id))).limit(1).then((r) => r[0] ?? null) : null,
    db.select().from(schema.documents).where(and(eq(schema.documents.orgId, ctx.org.id), eq(schema.documents.sourceType, "quote"), eq(schema.documents.sourceId, quote.id))).orderBy(desc(schema.documents.version)),
    quoteFormOptions(ctx.org.id),
  ]);
  const recipientEmail = contact?.email ?? company?.email ?? person?.email ?? null;
  const late = quote.status === "envoye" && isOverdue(quote.validUntil, today);
  const nextLabel = quote.status === "brouillon" ? "Devis à envoyer au client" : quote.status === "envoye" ? (late ? "Validité dépassée : relancer le client ou marquer expiré" : "En attente de la réponse du client") : quote.status === "accepte" ? "Accepté : créer l'inscription si ce n'est pas fait" : quote.status === "refuse" ? "Refusé : dupliquer pour une nouvelle proposition" : "Expiré : dupliquer pour une nouvelle proposition";
  const fields = { orgId: ctx.org.id, quoteId: quote.id };

  return (
    <FadeIn>
      <PageHeader
        breadcrumb={[{ label: "Commercial" }, { label: "Devis", href: `${base}/devis` }, { label: quote.number }]}
        title={<span className="num">{quote.number}</span>}
        description={`${quote.title} · ${company ? company.name : person ? `${person.firstName} ${person.lastName}` : "destinataire à définir"}`}
        actions={
          <>
            <StatusBadge status={quote.status} />
            {canManage && canGenerate ? <ActionButton action={generateQuotePdfAction} fields={fields} label={quote.documentId ? "Régénérer le PDF" : "Générer le PDF"} size="md" /> : null}
            {canManage && canGenerate && quote.status !== "accepte" && quote.status !== "refuse" ? (
              <FormDialog action={sendQuoteAction} trigger={quote.status === "envoye" ? "Renvoyer" : "Envoyer au contact"} title="Envoyer le devis" description={`Le PDF est régénéré puis envoyé par e-mail.${integrations.mail() ? "" : " Service e-mail non configuré : l'e-mail sera journalisé dans la boîte d'envoi."}`} submitLabel="Envoyer">
                <input type="hidden" name="orgId" value={ctx.org.id} />
                <input type="hidden" name="quoteId" value={quote.id} />
                <Field label="Destinataire" required htmlFor="send-to">
                  <Input id="send-to" name="to" type="email" required defaultValue={recipientEmail ?? ""} />
                </Field>
                <Field label="Message d'accompagnement" htmlFor="send-msg">
                  <Textarea id="send-msg" name="message" rows={3} />
                </Field>
              </FormDialog>
            ) : null}
            {canManage && quote.status === "envoye" ? (
              <>
                <ActionButton action={setQuoteStatusAction} fields={{ ...fields, status: "accepte" }} label="Accepté" variant="accent" size="md" confirm={{ title: "Enregistrer l'acceptation", description: need ? `Le besoin « ${need.title} » passera en « gagné ».` : "Le devis sera marqué accepté.", confirmLabel: "Confirmer l'acceptation" }} />
                <ActionButton action={setQuoteStatusAction} fields={{ ...fields, status: "refuse" }} label="Refusé" variant="danger" size="md" confirm={{ title: "Enregistrer le refus", confirmLabel: "Confirmer le refus", danger: true, input: { name: "reason", label: "Motif (facultatif)" } }} />
                <ActionButton action={setQuoteStatusAction} fields={{ ...fields, status: "expire" }} label="Expiré" size="md" confirm={{ title: "Marquer le devis expiré", confirmLabel: "Confirmer" }} />
                <ActionButton action={setQuoteStatusAction} fields={{ ...fields, status: "brouillon" }} label="Repasser en brouillon" size="md" confirm={{ title: "Repasser en brouillon", description: "Le devis redevient modifiable ; le PDF transmis reste conservé en version antérieure.", confirmLabel: "Confirmer" }} />
              </>
            ) : null}
            {canManage && quote.status !== "brouillon" ? <ActionButton action={duplicateQuoteAction} fields={fields} label="Dupliquer" size="md" /> : null}
          </>
        }
      />
      <Notice tone={late ? "danger" : quote.status === "accepte" ? "ok" : "info"} title="Prochaine action" className="mb-6">
        {nextLabel}
        {quote.validUntil ? (
          <>
            {" "}· validité : <span className="num">{fmtDate(quote.validUntil)}</span>
          </>
        ) : null}
      </Notice>

      {quote.status === "brouillon" && canManage ? (
        <Panel className="p-5">
          <QuoteForm action={updateQuoteAction} orgId={ctx.org.id} quote={quote} companies={options.companies} contacts={options.contacts} persons={options.persons} needs={options.needs} today={today} submitLabel="Enregistrer le brouillon" />
        </Panel>
      ) : (
        <div className="grid gap-6 lg:grid-cols-[minmax(0,2fr)_minmax(0,1fr)]">
          <Panel>
            <PanelHeader title="Lignes" />
            <Table>
              <thead>
                <tr>
                  <Th>Désignation</Th>
                  <Th num>Qté</Th>
                  <Th num>P.U. HT</Th>
                  <Th num>TVA</Th>
                  <Th num>Total HT</Th>
                </tr>
              </thead>
              <tbody>
                {lines.map((l, i) => (
                  <tr key={i}>
                    <Td>
                      <span className="font-medium text-ink">{l.label}</span>
                      {l.description ? <span className="block text-[12px] text-ink-3">{l.description}</span> : null}
                    </Td>
                    <Td num>{l.qty.toLocaleString("fr-FR")}</Td>
                    <Td num>{formatCents(l.unitCents)}</Td>
                    <Td num>{vatRateLabel(l.vatRateBp)}</Td>
                    <Td num>{formatCents(Math.round(l.qty * l.unitCents))}</Td>
                  </tr>
                ))}
              </tbody>
            </Table>
            <dl className="ml-auto grid max-w-sm grid-cols-[1fr_auto] gap-x-6 gap-y-1.5 px-5 py-4 text-[13.5px]">
              <dt className="text-ink-2">Total HT</dt>
              <dd className="num text-right">{formatCents(totals.totalHtCents)}</dd>
              {totals.byRate
                .filter((r) => r.rateBp > 0)
                .map((r) => (
                  <Fragment key={r.rateBp}>
                    <dt className="text-ink-2">TVA {vatRateLabel(r.rateBp)}</dt>
                    <dd className="num text-right">{formatCents(r.vatCents)}</dd>
                  </Fragment>
                ))}
              <dt className="border-t border-line pt-2 font-medium">Total TTC</dt>
              <dd className="num border-t border-line pt-2 text-right font-medium">{formatCents(quote.totalTtcCents)}</dd>
            </dl>
            {quote.notes ? <p className="whitespace-pre-line border-t border-line px-5 py-4 text-[13.5px] text-ink-2">{quote.notes}</p> : null}
          </Panel>
          <Panel className="self-start">
            <PanelHeader title="Rattachements" />
            <div className="p-5">
              <KeyValue
                items={[
                  { k: "Entreprise", v: company ? <Link href={`${base}/entreprises/${company.id}`} className="hover:underline">{company.name}</Link> : null },
                  { k: "Contact", v: contact ? `${contact.firstName} ${contact.lastName}${contact.email ? ` (${contact.email})` : ""}` : null },
                  { k: "Personne", v: person ? <Link href={`${base}/candidats/${person.id}`} className="hover:underline">{person.firstName} {person.lastName}</Link> : null },
                  { k: "Besoin", v: need ? <Link href={`${base}/besoins/${need.id}`} className="hover:underline">{need.title}</Link> : null },
                  { k: "Émis le", v: <span className="num">{fmtDate(quote.issueDate)}</span> },
                  { k: "Envoyé le", v: quote.sentAt ? <span className="num">{fmtDateTime(quote.sentAt)}</span> : null },
                  { k: "Accepté le", v: quote.acceptedAt ? <span className="num">{fmtDateTime(quote.acceptedAt)}</span> : null },
                ]}
              />
            </div>
          </Panel>
        </div>
      )}

      <Panel className="mt-6">
        <PanelHeader title="Versions PDF" description="Chaque génération crée une nouvelle version ; aucune version transmise n'est remplacée." />
        <DocumentList orgId={ctx.org.id} docs={docs} emptyTitle="Aucun PDF généré" emptyDescription="Générez le PDF pour obtenir le document avec l'identité de l'organisme." />
      </Panel>
    </FadeIn>
  );
}
