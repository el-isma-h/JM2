import Link from "next/link";
import { and, asc, desc, eq, ilike, inArray, or, sql, type SQL } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { trainerSessionIds } from "@/server/authz";
import { runCertificationRemindersAction, syncCertificationsAction, updateCertificationAction } from "@/server/actions/certifications";
import { certificationCounts } from "@/server/certifications/service";
import { CERTIFIERS, CERTIFIER_LABELS, CERT_STATUSES, CERT_STATUS_LABELS, type CertStatus, type Certifier } from "@/server/certifications/rules";
import { fmtDate } from "@/lib/dates";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea } from "@/components/ui/field";
import { EmptyState, Notice, PageHeader, Panel, PanelHeader, Stat } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { ActionButton } from "@/components/admin/action-form";
import { FormDialog } from "@/components/admin/form-dialog";
import { Pagination, readPage, readParam } from "@/components/admin/pagination";

export const dynamic = "force-dynamic";
const PAGE = 50;

/** Rappels du process de la cliente, par certificateur (aucun identifiant ni mot de passe). */
const PROCESS_HINTS: { certifier: Certifier; text: string }[] = [
  { certifier: "icdl", text: "Convertir le compte éval (test de positionnement) en compte ICDL, puis modifier le parcours et choisir le module correspondant au thème. Sans auto-certif en stock, voir avec la direction." },
  { certifier: "tosa", text: "Sur la fiche candidat, « inscrire à un test » : sujet = thème, test = Certification (l'option évaluation ne sert qu'au positionnement), puis envoyer le message au candidat." },
  { certifier: "toeic", text: "Centre public ou voucher (distanciel). CPF : voucher 12 months 4 skills. Vérifier régulièrement les vouchers : statut « inutilisé » = relancer le candidat." },
  { certifier: "voltaire", text: "Uniquement en centre. À commander et organiser au moins 15 jours avant la date souhaitée : créer la session, puis importer la grille d'inscription du certificateur." },
];

export default async function CertificationsPage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const base = `/app/${orgId}`;
  const ctx = await guardOrg(orgId, `${base}/examens/certifications`, "exams.view");
  const sp = await searchParams;
  const certifierRaw = readParam(sp.certificateur);
  const statusRaw = readParam(sp.statut);
  const q = readParam(sp.q);
  const page = readPage(sp.page);
  const certifier = certifierRaw && (CERTIFIERS as readonly string[]).includes(certifierRaw) ? (certifierRaw as Certifier) : undefined;
  const status = statusRaw && (CERT_STATUSES as readonly string[]).includes(statusRaw) ? (statusRaw as CertStatus) : undefined;
  const scope = await trainerSessionIds(ctx);
  const canManage = ctx.permissions.has("exams.manage");

  const conds: SQL[] = [eq(schema.certificationRegistrations.orgId, ctx.org.id)];
  if (certifier) conds.push(eq(schema.certificationRegistrations.certifier, certifier));
  if (status) conds.push(eq(schema.certificationRegistrations.status, status));
  if (q) conds.push(or(ilike(schema.persons.lastName, `%${q}%`), ilike(schema.persons.firstName, `%${q}%`), ilike(schema.enrollments.reference, `%${q}%`), ilike(schema.certificationRegistrations.voucherRef, `%${q}%`))!);
  if (scope) conds.push(scope.length ? inArray(schema.enrollments.sessionId, scope) : sql`false`);
  const where = and(...conds);

  const from = () =>
    db
      .select({
        r: schema.certificationRegistrations,
        enrollmentId: schema.enrollments.id,
        reference: schema.enrollments.reference,
        enrollmentEnd: schema.enrollments.endDate,
        firstName: schema.persons.firstName,
        lastName: schema.persons.lastName,
        sessionId: schema.trainingSessions.id,
        sessionTitle: schema.trainingSessions.title,
        sessionCode: schema.trainingSessions.code,
        sessionEnd: schema.trainingSessions.endDate,
      })
      .from(schema.certificationRegistrations)
      .innerJoin(schema.enrollments, and(eq(schema.enrollments.id, schema.certificationRegistrations.enrollmentId), eq(schema.enrollments.orgId, ctx.org.id)))
      .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
      .innerJoin(schema.trainingSessions, and(eq(schema.trainingSessions.id, schema.enrollments.sessionId), eq(schema.trainingSessions.orgId, ctx.org.id)));

  const [rows, [{ total }], counts] = await Promise.all([
    from()
      .where(where)
      .orderBy(sql`case when ${schema.certificationRegistrations.status} in ('reussie','echouee','annulee') then 1 else 0 end`, asc(sql`coalesce(${schema.certificationRegistrations.examDate}, ${schema.enrollments.endDate}, ${schema.trainingSessions.endDate})`), desc(schema.certificationRegistrations.createdAt))
      .limit(PAGE)
      .offset((page - 1) * PAGE),
    db
      .select({ total: sql<number>`count(*)::int` })
      .from(schema.certificationRegistrations)
      .innerJoin(schema.enrollments, and(eq(schema.enrollments.id, schema.certificationRegistrations.enrollmentId), eq(schema.enrollments.orgId, ctx.org.id)))
      .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
      .where(where),
    certificationCounts(ctx.org.id, scope),
  ]);
  const toRegister = counts.a_inscrire ?? 0;
  const inProgress = (counts.compte_cree ?? 0) + (counts.inscrit ?? 0) + (counts.voucher_envoye ?? 0) + (counts.session_planifiee ?? 0) + (counts.passee ?? 0);

  return (
    <>
      <PageHeader
        breadcrumb={[{ label: "Pédagogie" }, { label: "Examens", href: `${base}/examens` }, { label: "Certifications externes" }]}
        title="Certifications externes"
        description="TOSA, ICDL, TOEIC, Certificat Voltaire, CléA : une ligne par inscription dont la formation porte un certificateur externe. Alerte 15 jours avant l'examen Voltaire, et 15 jours avant la fin de session si l'apprenant n'est pas encore inscrit."
        actions={
          canManage ? (
            <>
              <ActionButton action={syncCertificationsAction} fields={{ orgId: ctx.org.id }} label="Créer les inscriptions manquantes" size="md" />
              <ActionButton action={runCertificationRemindersAction} fields={{ orgId: ctx.org.id }} label="Vérifier les échéances" size="md" variant="ghost" />
            </>
          ) : null
        }
      />
      <Notice tone="info" className="mb-6" title="Aucun identifiant de plateforme">
        Les identifiants et mots de passe des interfaces certificateurs ne sont jamais enregistrés ici : seuls le statut, le module, le score de positionnement, la référence de voucher, la date d&apos;examen et le résultat sont suivis.
      </Notice>
      <Panel className="mb-6">
        <div className="grid grid-cols-2 gap-6 px-5 py-5 sm:grid-cols-4">
          <Link href={`${base}/examens/certifications?statut=a_inscrire`} className="hover:opacity-80">
            <Stat label="À inscrire" value={<span className="num">{toRegister}</span>} />
          </Link>
          <Stat label="En cours" value={<span className="num">{inProgress}</span>} hint="inscrit à passé" />
          <Link href={`${base}/examens/certifications?statut=reussie`} className="hover:opacity-80">
            <Stat label="Réussies" value={<span className="num">{counts.reussie ?? 0}</span>} />
          </Link>
          <Link href={`${base}/examens/certifications?statut=echouee`} className="hover:opacity-80">
            <Stat label="Échouées" value={<span className="num">{counts.echouee ?? 0}</span>} />
          </Link>
        </div>
      </Panel>
      <Panel className="mb-6">
        <form method="get" className="flex flex-wrap items-end gap-3 border-b border-line px-5 py-3">
          <Field label="Recherche" htmlFor="q" className="w-full max-w-xs">
            <Input id="q" name="q" defaultValue={q} placeholder="Apprenant, référence, voucher" />
          </Field>
          <Field label="Certificateur" htmlFor="certificateur" className="w-52">
            <Select id="certificateur" name="certificateur" defaultValue={certifier ?? ""}>
              <option value="">Tous</option>
              {CERTIFIERS.map((c) => (
                <option key={c} value={c}>
                  {CERTIFIER_LABELS[c]}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Statut" htmlFor="statut" className="w-56">
            <Select id="statut" name="statut" defaultValue={status ?? ""}>
              <option value="">Tous</option>
              {CERT_STATUSES.map((s) => (
                <option key={s} value={s}>
                  {CERT_STATUS_LABELS[s]}
                </option>
              ))}
            </Select>
          </Field>
          <Button type="submit" variant="secondary">
            Filtrer
          </Button>
        </form>
        {rows.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Apprenant</Th>
                <Th>Certification</Th>
                <Th>Positionnement</Th>
                <Th>Voucher</Th>
                <Th>Examen</Th>
                <Th>Score</Th>
                <Th>Statut</Th>
                {canManage ? <Th>Action</Th> : null}
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => {
                const r = row.r;
                const end = row.enrollmentEnd ?? row.sessionEnd;
                return (
                  <tr key={r.id}>
                    <Td>
                      <Link href={`${base}/inscriptions/${row.enrollmentId}`} className="font-medium text-ink hover:underline">
                        {row.firstName} {row.lastName}
                      </Link>
                      <p className="text-[12px] text-ink-3">
                        <span className="num">{row.reference}</span> ·{" "}
                        <Link href={`${base}/sessions/${row.sessionId}`} className="hover:underline">
                          {row.sessionTitle}
                        </Link>{" "}
                        · fin <span className="num">{fmtDate(end)}</span>
                      </p>
                    </Td>
                    <Td>
                      <Badge>{CERTIFIER_LABELS[r.certifier as Certifier] ?? r.certifier}</Badge>
                      {r.module ? <p className="mt-1 text-[12px] text-ink-3">{r.module}</p> : null}
                    </Td>
                    <Td className="num">{r.positioningScore ?? "-"}</Td>
                    <Td className="num">{r.voucherRef ?? "-"}</Td>
                    <Td className="num whitespace-nowrap">{r.examDate ? fmtDate(r.examDate) : "-"}</Td>
                    <Td className="num">{r.score ?? "-"}</Td>
                    <Td>
                      <StatusBadge status={r.status} />
                      {r.resultNote ? <p className="mt-1 max-w-[220px] text-[12px] text-ink-3">{r.resultNote}</p> : null}
                    </Td>
                    {canManage ? (
                      <Td>
                        <FormDialog action={updateCertificationAction} trigger="Mettre à jour" triggerVariant="secondary" triggerSize="sm" title={`${CERTIFIER_LABELS[r.certifier as Certifier] ?? r.certifier} : ${row.firstName} ${row.lastName}`} description="N'indiquez jamais d'identifiant ni de mot de passe de plateforme." submitLabel="Enregistrer" wide>
                          <input type="hidden" name="orgId" value={ctx.org.id} />
                          <input type="hidden" name="registrationId" value={r.id} />
                          <div className="grid gap-4 sm:grid-cols-2">
                            <Field label="Statut" required htmlFor={`cs-${r.id}`}>
                              <Select id={`cs-${r.id}`} name="status" defaultValue={r.status}>
                                {CERT_STATUSES.map((s) => (
                                  <option key={s} value={s}>
                                    {CERT_STATUS_LABELS[s]}
                                  </option>
                                ))}
                              </Select>
                            </Field>
                            <Field label="Module" htmlFor={`cm-${r.id}`} help="Module ou sujet de certification (ex. thème de la formation).">
                              <Input id={`cm-${r.id}`} name="module" defaultValue={r.module ?? ""} maxLength={200} />
                            </Field>
                          </div>
                          <div className="grid gap-4 sm:grid-cols-2">
                            <Field label="Score de positionnement" htmlFor={`cp-${r.id}`} help="Niveau de départ (test de positionnement).">
                              <Input id={`cp-${r.id}`} name="positioningScore" defaultValue={r.positioningScore ?? ""} maxLength={100} className="num" />
                            </Field>
                            <Field label="Référence du voucher" htmlFor={`cv-${r.id}`} help="Référence seule, jamais un identifiant de connexion.">
                              <Input id={`cv-${r.id}`} name="voucherRef" defaultValue={r.voucherRef ?? ""} maxLength={100} className="num" autoComplete="off" />
                            </Field>
                          </div>
                          <div className="grid gap-4 sm:grid-cols-2">
                            <Field label="Date d'examen" htmlFor={`cd-${r.id}`} help={r.certifier === "voltaire" ? "Voltaire : à organiser au moins 15 jours avant." : undefined}>
                              <Input id={`cd-${r.id}`} name="examDate" type="date" defaultValue={r.examDate ?? ""} />
                            </Field>
                            <Field label="Score obtenu" htmlFor={`cr-${r.id}`}>
                              <Input id={`cr-${r.id}`} name="score" defaultValue={r.score ?? ""} maxLength={100} className="num" />
                            </Field>
                          </div>
                          <Field label="Commentaire" htmlFor={`cn-${r.id}`}>
                            <Textarea id={`cn-${r.id}`} name="resultNote" rows={2} defaultValue={r.resultNote ?? ""} maxLength={1000} />
                          </Field>
                        </FormDialog>
                      </Td>
                    ) : null}
                  </tr>
                );
              })}
            </tbody>
          </Table>
        ) : (
          <EmptyState
            title="Aucune certification suivie"
            description={certifier || status || q ? "Aucun résultat pour ces filtres." : "Renseignez le certificateur externe sur les formations concernées : chaque inscription crée alors son suivi de certification. « Créer les inscriptions manquantes » rattrape les inscriptions existantes."}
          />
        )}
        <Pagination basePath={`${base}/examens/certifications`} params={{ certificateur: certifier, statut: status, q }} page={page} pageSize={PAGE} total={total} />
      </Panel>
      <Panel>
        <PanelHeader title="Rappels du process" description="Inscription sur la plateforme de chaque certificateur, puis mise à jour du statut ici." />
        <ul className="divide-y divide-line">
          {PROCESS_HINTS.map((h) => (
            <li key={h.certifier} className="grid gap-2 px-5 py-3 text-[13.5px] sm:grid-cols-[160px_1fr]">
              <span className="etiquette">{CERTIFIER_LABELS[h.certifier]}</span>
              <span className="text-ink-2">{h.text}</span>
            </li>
          ))}
        </ul>
      </Panel>
    </>
  );
}
