import { and, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { createQuoteAction } from "@/server/actions/quotes";
import { quoteFormOptions } from "@/server/crm/quote-options";
import { todayParis } from "@/lib/time";
import { PageHeader, Panel } from "@/components/ui/surface";
import { readParam } from "@/components/admin/pagination";
import { QuoteForm } from "@/components/crm/quote-form";
import type { QuoteLine } from "@/server/crm/quote-math";

export const dynamic = "force-dynamic";

/** Nouveau devis : pré-rempli depuis un besoin (?needId=) ou une entreprise (?companyId=). */
export default async function NewQuotePage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const base = `/app/${orgId}`;
  const ctx = await guardOrg(orgId, `${base}/devis/nouveau`, "crm.manage");
  const sp = await searchParams;
  const needId = readParam(sp.needId);
  const companyId = readParam(sp.companyId);
  const personId = readParam(sp.personId);
  const options = await quoteFormOptions(ctx.org.id);
  const defaults: { companyId?: string; contactId?: string; personId?: string; needId?: string; title?: string; lines?: QuoteLine[] } = {};
  if (companyId && options.companies.some((c) => c.id === companyId)) defaults.companyId = companyId;
  if (personId && options.persons.some((p) => p.id === personId)) defaults.personId = personId;
  const need = needId ? options.needs.find((n) => n.id === needId) : undefined;
  if (need) {
    defaults.needId = need.id;
    defaults.companyId = need.companyId ?? undefined;
    defaults.personId = need.personId ?? undefined;
    defaults.contactId = need.contactId ?? undefined;
    defaults.title = need.name.replace(/\s\(.+\)$/, "");
    let label = defaults.title;
    let unitCents = need.amountCents && need.headcount ? Math.round(need.amountCents / need.headcount) : need.amountCents ?? 0;
    if (need.programId) {
      const [pv] = await db
        .select({ title: schema.programs.title, priceCents: schema.programVersions.priceCents })
        .from(schema.programs)
        .leftJoin(schema.programVersions, and(eq(schema.programVersions.programId, schema.programs.id), eq(schema.programVersions.status, "active")))
        .where(and(eq(schema.programs.id, need.programId), eq(schema.programs.orgId, ctx.org.id)))
        .limit(1);
      if (pv) {
        label = pv.title;
        if (!need.amountCents && pv.priceCents) unitCents = pv.priceCents;
      }
    }
    defaults.lines = [{ label, description: null, qty: need.headcount || 1, unitCents, vatRateBp: 0 }];
  }
  return (
    <>
      <PageHeader breadcrumb={[{ label: "Commercial" }, { label: "Devis", href: `${base}/devis` }, { label: "Nouveau" }]} title="Nouveau devis" description="Numéro attribué automatiquement (DEV-AAAA-NNNN) à l'enregistrement. Montants calculés en centimes côté serveur." />
      <Panel className="p-5">
        <QuoteForm action={createQuoteAction} orgId={ctx.org.id} companies={options.companies} contacts={options.contacts} persons={options.persons} needs={options.needs} defaults={defaults} today={todayParis()} submitLabel="Créer le devis" />
      </Panel>
    </>
  );
}
