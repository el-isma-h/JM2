import { handleAuthError } from "@/server/guard";
import { requireUser } from "@/server/auth";
import { guardLearner } from "@/server/extranet/guard";
import { learnerNav } from "@/components/app/nav";
import { ExtranetShell } from "@/components/extranet/shell";

export const dynamic = "force-dynamic";

/** Extranet apprenant : sans session → /connexion?next=/moi ; sans rattachement → coquille avec état vide (pages). */
export default async function LearnerLayout({ children }: { children: React.ReactNode }) {
  let user;
  try {
    user = await requireUser();
  } catch (e) {
    handleAuthError(e, "/moi");
    throw e;
  }
  const ctx = await guardLearner("/moi");
  return (
    <ExtranetShell base="/moi" items={ctx ? learnerNav : []} user={user} org={ctx?.org ?? null} choices={ctx?.choices ?? []} subtitle={ctx ? `${ctx.person.firstName} ${ctx.person.lastName} · Espace apprenant` : undefined}>
      {children}
    </ExtranetShell>
  );
}
