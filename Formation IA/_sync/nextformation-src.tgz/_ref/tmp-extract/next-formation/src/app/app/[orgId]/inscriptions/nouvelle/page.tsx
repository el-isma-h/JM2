import Link from "next/link";
import { notFound } from "next/navigation";
import { and, asc, desc, eq, ilike, inArray, or, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { sessionPlaces } from "@/server/sessions/service";
import { contractKindLabels } from "@/server/enrollments/rules";
import { fmtDate } from "@/lib/dates";
import { readParam } from "@/components/admin/pagination";
import { NavActionForm } from "@/components/sessions/nav-action-form";
import { ParamSelect } from "@/components/enrollments/param-select";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/field";
import { EmptyState, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { FadeIn } from "@/components/ui/motion";
import { createEnrollmentAction } from "@/server/actions/enrollments";

export const dynamic = "force-dynamic";

const isUuid = (v?: string) => Boolean(v && /^[0-9a-f-]{36}$/i.test(v));

export default async function NewEnrollmentPage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const ctx = await guardOrg(orgId, `/app/${orgId}/inscriptions/nouvelle`, "enrollments.manage");
  if (ctx.trainerOnly) notFound();
  const sp = await searchParams;
  const q = readParam(sp.q);
  const personId = readParam(sp.personId);
  const companyId = readParam(sp.companyId);
  const placementId = readParam(sp.placementId);
  const programId = readParam(sp.programId);
  const sessionId = readParam(sp.sessionId);
  const quoteId = readParam(sp.quoteId);
  const create = readParam(sp.creer) === "1";
  const base = `/app/${orgId}/inscriptions/nouvelle`;

  const keep = (overrides: Record<string, string | undefined>) => {
    const u = new URLSearchParams();
    for (const [k, v] of Object.entries({ q, personId, companyId, placementId, programId, sessionId, quoteId, creer: create ? "1" : undefined, ...overrides })) if (v) u.set(k, v);
    const s = u.toString();
    return s ? `${base}?${s}` : base;
  };

  // Placement : pré-remplit la personne et l'entreprise du besoin.
  let placement: { personId: string; companyId: string | null; needTitle: string } | null = null;
  if (isUuid(placementId)) {
    const [pl] = await db
      .select({ personId: schema.placements.personId, companyId: schema.needs.companyId, needTitle: schema.needs.title, enrollmentId: schema.placements.enrollmentId })
      .from(schema.placements)
      .innerJoin(schema.needs, eq(schema.needs.id, schema.placements.needId))
      .where(and(eq(schema.placements.id, placementId!), eq(schema.placements.orgId, orgId)))
      .limit(1);
    if (pl) placement = pl;
  }
  const effectivePersonId = isUuid(personId) ? personId! : placement?.personId;
  const effectiveCompanyId = isUuid(companyId) ? companyId! : placement?.companyId ?? undefined;

  const [person] = effectivePersonId ? await db.select().from(schema.persons).where(and(eq(schema.persons.id, effectivePersonId), eq(schema.persons.orgId, orgId))).limit(1) : [null];
  const candidates =
    !person && q
      ? await db
          .select({ id: schema.persons.id, firstName: schema.persons.firstName, lastName: schema.persons.lastName, email: schema.persons.email, birthDate: schema.persons.birthDate, status: schema.persons.status, city: schema.persons.city, enrollments: sql<number>`(select count(*)::int from ${schema.enrollments} e where e.person_id = ${schema.persons.id})` })
          .from(schema.persons)
          .where(and(eq(schema.persons.orgId, orgId), sql`${schema.persons.anonymizedAt} is null`, or(ilike(schema.persons.lastName, `%${q}%`), ilike(schema.persons.firstName, `%${q}%`), ilike(schema.persons.email, `%${q}%`), sql`(${schema.persons.firstName} || ' ' || ${schema.persons.lastName}) ilike ${`%${q}%`}`)))
          .orderBy(asc(schema.persons.lastName), asc(schema.persons.firstName))
          .limit(25)
      : [];

  const sessions = await db
    .select({ id: schema.trainingSessions.id, code: schema.trainingSessions.code, title: schema.trainingSessions.title, startDate: schema.trainingSessions.startDate, endDate: schema.trainingSessions.endDate, status: schema.trainingSessions.status, capacity: schema.trainingSessions.capacity, programId: schema.programs.id, programTitle: schema.programs.title, durationHours: schema.programVersions.durationHours, isApprenticeship: schema.trainingSessions.isApprenticeship })
    .from(schema.trainingSessions)
    .innerJoin(schema.programVersions, eq(schema.programVersions.id, schema.trainingSessions.programVersionId))
    .innerJoin(schema.programs, eq(schema.programs.id, schema.programVersions.programId))
    .where(and(eq(schema.trainingSessions.orgId, orgId), inArray(schema.trainingSessions.status, ["brouillon", "ouverte", "confirmee", "en_cours"]), isUuid(programId) ? eq(schema.programs.id, programId!) : sql`true`))
    .orderBy(desc(schema.trainingSessions.startDate), asc(schema.trainingSessions.code))
    .limit(300);
  const session = sessions.find((s) => s.id === sessionId) ?? null;
  const [places, groups] = session ? await Promise.all([sessionPlaces(session.id), db.select().from(schema.groups).where(eq(schema.groups.sessionId, session.id)).orderBy(asc(schema.groups.name))]) : [null, []];
  const companies = await db.select({ id: schema.companies.id, name: schema.companies.name }).from(schema.companies).where(eq(schema.companies.orgId, orgId)).orderBy(asc(schema.companies.name)).limit(500);
  const tutors = effectiveCompanyId ? await db.select({ id: schema.contacts.id, firstName: schema.contacts.firstName, lastName: schema.contacts.lastName, jobTitle: schema.contacts.jobTitle, isTutor: schema.contacts.isTutor }).from(schema.contacts).where(and(eq(schema.contacts.orgId, orgId), eq(schema.contacts.companyId, effectiveCompanyId))).orderBy(desc(schema.contacts.isTutor), asc(schema.contacts.lastName)) : [];
  const defaultContract = session?.isApprenticeship ? "contrat_apprentissage" : "convention_formation";

  return (
    <FadeIn>
      <PageHeader title="Nouvelle inscription" breadcrumb={[{ label: "Inscriptions", href: `/app/${orgId}/inscriptions` }, { label: "Nouvelle" }]} description="Réutilisez la fiche d'une personne connue : ses inscriptions restent distinctes. Une fiche n'est créée que si la personne est absente." />
      {placement ? (
        <Notice tone="info" className="mb-5">
          Inscription depuis le placement sur le besoin « {placement.needTitle} » : la personne et l&apos;entreprise sont pré-remplies.
        </Notice>
      ) : null}
      {!sessions.length ? (
        <Panel>
          <EmptyState
            title="Aucune session ouverte"
            description="Créez ou ouvrez une session avant d&apos;inscrire une personne."
            action={
              <Button asChild variant="secondary">
                <Link href={`/app/${orgId}/sessions/nouvelle`}>Nouvelle session</Link>
              </Button>
            }
          />
        </Panel>
      ) : null}

      <div className="grid gap-6 lg:grid-cols-[1fr_1fr]">
        <Panel>
          <PanelHeader title="1. Personne" description={person ? "Personne sélectionnée." : "Recherchez par nom ou e-mail avant de créer une fiche."} />
          {person ? (
            <div className="flex flex-wrap items-start justify-between gap-3 p-5">
              <div className="text-[13.5px]">
                <p className="font-medium">
                  {person.lastName.toUpperCase()} {person.firstName} <StatusBadge status={person.status} className="ml-2" />
                </p>
                <p className="text-ink-2">
                  {person.email ?? "sans e-mail"}
                  {person.birthDate ? ` · née le ${fmtDate(person.birthDate)}` : ""}
                  {person.city ? ` · ${person.city}` : ""}
                </p>
                <Link href={`/app/${orgId}/apprenants/${person.id}`} className="text-[12.5px] text-accent hover:underline">
                  Voir ses inscriptions
                </Link>
              </div>
              <Button asChild variant="ghost" size="sm">
                <Link href={keep({ personId: undefined, placementId: undefined, creer: undefined })}>Changer de personne</Link>
              </Button>
            </div>
          ) : (
            <div className="p-5">
              <form method="get" className="flex flex-wrap items-end gap-3">
                {Object.entries({ companyId, programId, sessionId, quoteId }).map(([k, v]) => (v ? <input key={k} type="hidden" name={k} value={v} /> : null))}
                <Field label="Nom, prénom ou e-mail" htmlFor="q" className="w-full max-w-sm">
                  <Input id="q" name="q" defaultValue={q} placeholder="Ex. Okonkwo" autoFocus />
                </Field>
                <Button type="submit" variant="secondary">
                  Rechercher
                </Button>
              </form>
              {q ? (
                candidates.length ? (
                  <ul className="mt-4 divide-y divide-line border border-line">
                    {candidates.map((c) => (
                      <li key={c.id} className="flex flex-wrap items-center justify-between gap-2 px-4 py-2.5 text-[13.5px]">
                        <div>
                          <span className="font-medium">
                            {c.lastName.toUpperCase()} {c.firstName}
                          </span>
                          <span className="ml-2 text-ink-3">
                            {c.email ?? "sans e-mail"}
                            {c.birthDate ? ` · ${fmtDate(c.birthDate)}` : ""}
                          </span>
                          <span className="num ml-2 text-[12px] text-ink-3">{c.enrollments} inscription(s)</span>
                        </div>
                        <Button asChild size="sm" variant="secondary">
                          <Link href={keep({ personId: c.id, creer: undefined })}>Choisir</Link>
                        </Button>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <Notice tone="warn" className="mt-4">
                    Aucune personne ne correspond à « {q} ».{" "}
                    {!create ? (
                      <Link href={keep({ creer: "1" })} className="underline">
                        Créer une nouvelle fiche
                      </Link>
                    ) : null}
                  </Notice>
                )
              ) : (
                <p className="mt-3 text-[12.5px] text-ink-3">
                  Personne absente malgré la recherche ?{" "}
                  <Link href={keep({ creer: "1" })} className="text-accent underline">
                    Créer une nouvelle fiche
                  </Link>
                </p>
              )}
            </div>
          )}
        </Panel>

        <Panel>
          <PanelHeader title="2. Session et dossier" description="Entreprise, tuteur, contrat, dates et heures prévues." />
          <div className="p-5">
            {!person && !create ? (
              <p className="text-[13.5px] text-ink-3">Sélectionnez d&apos;abord une personne (ou créez sa fiche) pour compléter l&apos;inscription.</p>
            ) : (
              <NavActionForm action={createEnrollmentAction} submitLabel="Créer l'inscription" footerClassName="mt-6">
                <input type="hidden" name="orgId" value={orgId} />
                {person ? <input type="hidden" name="personId" value={person.id} /> : null}
                {placement ? <input type="hidden" name="placementId" value={placementId} /> : null}
                {quoteId && isUuid(quoteId) ? <input type="hidden" name="quoteId" value={quoteId} /> : null}
                <div className="grid gap-4 md:grid-cols-2">
                  {!person && create ? (
                    <>
                      <Notice tone="info" className="md:col-span-2">
                        Nouvelle fiche : si l&apos;e-mail ou l&apos;identité (nom, prénom, date de naissance) existe déjà, la création est refusée et la fiche existante vous est proposée.
                      </Notice>
                      <Field label="Civilité" htmlFor="n-civ">
                        <Select id="n-civ" name="civility" defaultValue="">
                          <option value="">-</option>
                          <option value="Mme">Mme</option>
                          <option value="M">M</option>
                          <option value="autre">Autre</option>
                        </Select>
                      </Field>
                      <div />
                      <Field label="Nom" required htmlFor="n-ln">
                        <Input id="n-ln" name="lastName" required />
                      </Field>
                      <Field label="Prénom" required htmlFor="n-fn">
                        <Input id="n-fn" name="firstName" required />
                      </Field>
                      <Field label="E-mail" htmlFor="n-email">
                        <Input id="n-email" name="email" type="email" defaultValue={q && q.includes("@") ? q : ""} />
                      </Field>
                      <Field label="Téléphone" htmlFor="n-phone">
                        <Input id="n-phone" name="phone" />
                      </Field>
                      <Field label="Date de naissance" htmlFor="n-bd" help="Permet de détecter une fiche existante sans e-mail.">
                        <Input id="n-bd" name="birthDate" type="date" className="num" />
                      </Field>
                    </>
                  ) : null}
                  <Field label="Session" required htmlFor="e-session" className="md:col-span-2" help="Sessions en brouillon, ouvertes, confirmées ou en cours. Les groupes et la durée se chargent après le choix.">
                    <ParamSelect id="e-session" name="sessionId" param="sessionId" clears={["groupId"]} required defaultValue={session?.id ?? ""}>
                      <option value="">Choisir une session</option>
                      {sessions.map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.code} · {s.title} ({fmtDate(s.startDate)} au {fmtDate(s.endDate)}, {s.status})
                        </option>
                      ))}
                    </ParamSelect>
                  </Field>
                  {session && places ? (
                    <p className="text-[12.5px] text-ink-2 md:col-span-2">
                      <Badge tone={places.remaining > 0 ? "ok" : "danger"}>{places.remaining} place(s) restante(s)</Badge>
                      <span className="ml-2">
                        {session.programTitle} · {session.durationHours} h · {session.isApprenticeship ? "CFA" : "OF"}
                      </span>
                      {places.remaining === 0 ? <span className="ml-2 text-danger-ink">Session complète : l&apos;inscription sera refusée.</span> : null}
                    </p>
                  ) : null}
                  {groups.length ? (
                    <Field label="Groupe" htmlFor="e-group">
                      <Select id="e-group" name="groupId" defaultValue="">
                        <option value="">Sans groupe</option>
                        {groups.map((g) => (
                          <option key={g.id} value={g.id}>
                            {g.name}
                            {g.capacity ? ` (${g.capacity} places)` : ""}
                          </option>
                        ))}
                      </Select>
                    </Field>
                  ) : null}
                  <Field label="Statut initial" htmlFor="e-status">
                    <Select id="e-status" name="status" defaultValue="preinscrit">
                      <option value="preinscrit">Préinscrit</option>
                      <option value="inscrit">Inscrit</option>
                    </Select>
                  </Field>
                  <Field label="Entreprise" htmlFor="e-company" help="Employeur ou entreprise d'accueil ; charge les tuteurs.">
                    <ParamSelect id="e-company" name="companyId" param="companyId" clears={["tutorContactId"]} defaultValue={effectiveCompanyId ?? ""}>
                      <option value="">Aucune (particulier)</option>
                      {companies.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.name}
                        </option>
                      ))}
                    </ParamSelect>
                  </Field>
                  <Field label="Tuteur (contact de l'entreprise)" htmlFor="e-tutor">
                    <Select id="e-tutor" name="tutorContactId" defaultValue={tutors.find((t) => t.isTutor)?.id ?? ""} disabled={!effectiveCompanyId}>
                      <option value="">{effectiveCompanyId ? (tutors.length ? "Aucun" : "Aucun contact dans cette entreprise") : "Choisissez d'abord une entreprise"}</option>
                      {tutors.map((t) => (
                        <option key={t.id} value={t.id}>
                          {t.firstName} {t.lastName}
                          {t.jobTitle ? ` · ${t.jobTitle}` : ""}
                          {t.isTutor ? " (tuteur)" : ""}
                        </option>
                      ))}
                    </Select>
                  </Field>
                  <Field label="Type de contrat" htmlFor="e-contract" help="Déclenche les pièces attendues (ex. CERFA pour l'apprentissage).">
                    <Select id="e-contract" name="contractKind" defaultValue={defaultContract} key={defaultContract}>
                      {schema.contractKindEnum.enumValues.map((k) => (
                        <option key={k} value={k}>
                          {contractKindLabels[k]}
                        </option>
                      ))}
                    </Select>
                  </Field>
                  <Field label="Numéro de contrat / convention" htmlFor="e-cn">
                    <Input id="e-cn" name="contractNumber" className="num" />
                  </Field>
                  <Field label="Début du parcours" htmlFor="e-start" help="Par défaut : dates de la session (entrée décalée possible).">
                    <Input id="e-start" name="startDate" type="date" defaultValue={session?.startDate ?? ""} key={`s-${session?.id}`} className="num" />
                  </Field>
                  <Field label="Fin du parcours" htmlFor="e-end">
                    <Input id="e-end" name="endDate" type="date" defaultValue={session?.endDate ?? ""} key={`e-${session?.id}`} className="num" />
                  </Field>
                  <Field label="Heures prévues" htmlFor="e-hours" help="Par défaut : durée de la version de programme figée à l'inscription.">
                    <Input id="e-hours" name="hoursPlanned" type="number" min={0} defaultValue={session?.durationHours ?? ""} key={`h-${session?.id}`} className="num" />
                  </Field>
                </div>
              </NavActionForm>
            )}
          </div>
        </Panel>
      </div>
    </FadeIn>
  );
}
