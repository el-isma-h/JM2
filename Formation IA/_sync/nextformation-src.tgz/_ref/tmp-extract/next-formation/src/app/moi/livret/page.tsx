import { guardLearner } from "@/server/extranet/guard";
import { listRecordEntries } from "@/server/extranet/queries";
import { NoAttachment } from "@/components/extranet/shell";
import { recordKindLabels } from "@/components/extranet/ui";
import { Badge } from "@/components/ui/badge";
import { EmptyState, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { fmtDate } from "@/lib/dates";

export const dynamic = "force-dynamic";


/** Livret d'apprentissage / de suivi : seules les entrées marquées visibles par l'apprenant sont affichées. */
export default async function LearnerRecord() {
  const ctx = await guardLearner("/moi/livret");
  if (!ctx) return <NoAttachment kind="learner" />;
  const entries = await listRecordEntries(ctx.org.id, ctx.enrollmentIds, "learner");
  return (
    <>
      <PageHeader title="Mon livret" description="Objectifs, activités, compétences et bilans partagés avec vous par l'équipe pédagogique et, le cas échéant, votre tuteur en entreprise." />
      <div className="space-y-6">
        {ctx.enrollments.map((e) => {
          const mine = entries.filter((r) => r.enrollmentId === e.enrollment.id);
          return (
            <Panel key={e.enrollment.id}>
              <PanelHeader title={e.program?.title ?? e.session.title} description={`Session ${e.session.code}`} />
              {mine.length ? (
                <ol className="divide-y divide-line">
                  {mine.map((r) => (
                    <li key={r.id} className="px-5 py-4">
                      <div className="flex flex-wrap items-center gap-3">
                        <span className="num text-[12px] text-ink-3">{fmtDate(r.date)}</span>
                        <Badge tone={r.kind === "entreprise" ? "info" : "neutral"}>{recordKindLabels[r.kind] ?? r.kind}</Badge>
                        <span className="font-medium text-ink">{r.title}</span>
                      </div>
                      {r.body ? <p className="mt-2 whitespace-pre-line text-[13.5px] text-ink-2">{r.body}</p> : null}
                      {r.authorRole ? <p className="mt-2 text-[11.5px] text-ink-3">Rédigé par : {r.authorRole}</p> : null}
                    </li>
                  ))}
                </ol>
              ) : (
                <EmptyState title="Livret vide pour l'instant" description="Les entrées partagées par l'équipe pédagogique apparaîtront ici." />
              )}
            </Panel>
          );
        })}
      </div>
    </>
  );
}
