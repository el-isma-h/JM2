"use client";

import { ActionButton } from "@/components/admin/action-form";
import { FormDialog } from "@/components/admin/form-dialog";
import { Checkbox, Field, Input, Select } from "@/components/ui/field";
import { inviteMemberAction, setMemberExpiryAction, setMemberTrainerAction, transferOwnershipAction, updateMemberPermissionsAction, updateMemberRolesAction } from "@/server/actions/security";

export type RoleOption = { key: string; label: string };
export type PermOption = { key: string; label: string; fromRoles: boolean };
export type TrainerOption = { id: string; name: string; linkedTo: string | null };

export function RolesDialog({ orgId, membershipId, name, roles, current }: { orgId: string; membershipId: string; name: string; roles: RoleOption[]; current: string[] }) {
  return (
    <FormDialog action={updateMemberRolesAction} trigger="Rôles" triggerVariant="ghost" triggerSize="sm" title={`Rôles : ${name}`} description="Rôles additifs. Leur cumul ne confère jamais la propriété ni l'administration de la sécurité." submitLabel="Enregistrer">
      <input type="hidden" name="orgId" value={orgId} />
      <input type="hidden" name="membershipId" value={membershipId} />
      <div className="grid gap-2 sm:grid-cols-2">
        {roles.map((r) => (
          <Checkbox key={r.key} name="roles" value={r.key} defaultChecked={current.includes(r.key)} label={r.label} />
        ))}
      </div>
    </FormDialog>
  );
}

export function PermissionsDialog({ orgId, membershipId, name, perms, overrides }: { orgId: string; membershipId: string; name: string; perms: PermOption[]; overrides: Record<string, boolean> }) {
  return (
    <FormDialog action={updateMemberPermissionsAction} trigger="Permissions fines" triggerVariant="ghost" triggerSize="sm" title={`Permissions fines : ${name}`} description="Ajout ou retrait par rapport aux rôles. Les permissions propriétaire (utilisateurs, rôles, journal d'audit) ne sont pas modulables." submitLabel="Enregistrer" wide>
      <input type="hidden" name="orgId" value={orgId} />
      <input type="hidden" name="membershipId" value={membershipId} />
      <div className="grid gap-x-6 gap-y-2 sm:grid-cols-2">
        {perms.map((p) => {
          const v = overrides[p.key] === true ? "grant" : overrides[p.key] === false ? "deny" : "inherit";
          return (
            <label key={p.key} className="flex items-center justify-between gap-3 border-b border-line py-1.5 text-[12.5px]">
              <span className="min-w-0">
                <span className="text-ink">{p.label}</span>
                <span className="block text-[11px] text-ink-3">{p.fromRoles ? "accordée par ses rôles" : "non accordée par ses rôles"}</span>
              </span>
              <Select name={`perm:${p.key}`} defaultValue={v} className="h-8 w-32 text-[12px]" aria-label={p.label}>
                <option value="inherit">Selon rôles</option>
                <option value="grant">Ajouter</option>
                <option value="deny">Retirer</option>
              </Select>
            </label>
          );
        })}
      </div>
    </FormDialog>
  );
}

export function ExpiryDialog({ orgId, membershipId, name, current }: { orgId: string; membershipId: string; name: string; current: string }) {
  return (
    <FormDialog action={setMemberExpiryAction} trigger="Expiration" triggerVariant="ghost" triggerSize="sm" title={`Expiration : ${name}`} description="Après cette date, le membre n'a plus aucun accès (recette : « owner expiré », « membre inactif »). Vide : sans expiration." submitLabel="Enregistrer">
      <input type="hidden" name="orgId" value={orgId} />
      <input type="hidden" name="membershipId" value={membershipId} />
      <Field label="Date d'expiration" htmlFor={`exp-${membershipId}`}>
        <Input id={`exp-${membershipId}`} name="expiresAt" type="date" defaultValue={current} className="num" />
      </Field>
    </FormDialog>
  );
}

export function TrainerDialog({ orgId, membershipId, name, trainers, current }: { orgId: string; membershipId: string; name: string; trainers: TrainerOption[]; current: string | null }) {
  return (
    <FormDialog action={setMemberTrainerAction} trigger="Formateur" triggerVariant="ghost" triggerSize="sm" title={`Rattachement formateur : ${name}`} description="Lie le compte à une fiche formateur : un formateur seul ne voit que les séances et apprenants où il est affecté." submitLabel="Enregistrer">
      <input type="hidden" name="orgId" value={orgId} />
      <input type="hidden" name="membershipId" value={membershipId} />
      <Field label="Fiche formateur" htmlFor={`tr-${membershipId}`}>
        <Select id={`tr-${membershipId}`} name="trainerId" defaultValue={current ?? ""}>
          <option value="">Aucun rattachement</option>
          {trainers.map((t) => (
            <option key={t.id} value={t.id} disabled={Boolean(t.linkedTo) && t.id !== current}>
              {t.name}
              {t.linkedTo && t.id !== current ? " (déjà rattachée)" : ""}
            </option>
          ))}
        </Select>
      </Field>
    </FormDialog>
  );
}

export function InviteDialog({ orgId, roles, trainers }: { orgId: string; roles: RoleOption[]; trainers: TrainerOption[] }) {
  return (
    <FormDialog action={inviteMemberAction} trigger="Inviter un membre" title="Inviter un membre" description="Un e-mail d'invitation est envoyé (ou un lien à transmettre si le service e-mail n'est pas configuré). Valable 7 jours." submitLabel="Inviter">
      <input type="hidden" name="orgId" value={orgId} />
      <Field label="Adresse e-mail" htmlFor="inv-email" required>
        <Input id="inv-email" name="email" type="email" required />
      </Field>
      <Field label="Rôles" htmlFor="inv-roles">
        <div id="inv-roles" className="grid gap-2 sm:grid-cols-2">
          {roles.map((r) => (
            <Checkbox key={r.key} name="roles" value={r.key} label={r.label} />
          ))}
        </div>
      </Field>
      <Field label="Rattachement formateur (facultatif)" htmlFor="inv-trainer">
        <Select id="inv-trainer" name="trainerId" defaultValue="">
          <option value="">Aucun</option>
          {trainers
            .filter((t) => !t.linkedTo)
            .map((t) => (
              <option key={t.id} value={t.id}>
                {t.name}
              </option>
            ))}
        </Select>
      </Field>
    </FormDialog>
  );
}

export function TransferDialog({ orgId, candidates }: { orgId: string; candidates: { userId: string; name: string }[] }) {
  return (
    <FormDialog action={transferOwnershipAction} trigger="Transférer la propriété" triggerVariant="danger" title="Transférer la propriété" description="Irréversible depuis votre compte : le nouveau propriétaire devient seul administrateur de la sécurité et de la charte. Confirmation par votre mot de passe ; opération journalisée." submitLabel="Transférer">
      <input type="hidden" name="orgId" value={orgId} />
      <Field label="Nouveau propriétaire" htmlFor="tf-target" required>
        <Select id="tf-target" name="targetUserId" required defaultValue="">
          <option value="" disabled>
            Choisir un membre actif
          </option>
          {candidates.map((c) => (
            <option key={c.userId} value={c.userId}>
              {c.name}
            </option>
          ))}
        </Select>
      </Field>
      <Field label="Votre mot de passe" htmlFor="tf-pw" required>
        <Input id="tf-pw" name="password" type="password" autoComplete="current-password" required />
      </Field>
    </FormDialog>
  );
}

export { ActionButton };
