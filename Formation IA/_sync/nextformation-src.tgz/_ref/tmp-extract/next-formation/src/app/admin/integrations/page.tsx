import { guardAdmin } from "@/server/guard";
import { appUrl, integrationLabels, integrations, type IntegrationName } from "@/lib/env";
import { storageBackend } from "@/server/storage";
import { Badge } from "@/components/ui/badge";
import { PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";

export const dynamic = "force-dynamic";

type Item = { label: string; ok: boolean; envVars: string[]; effect: string; required?: boolean };

function Section({ title, description, items }: { title: string; description: string; items: Item[] }) {
  const set = (k: string) => Boolean(process.env[k]);
  return (
    <Panel className="mb-6">
      <PanelHeader title={title} description={description} />
      <Table>
        <thead>
          <tr>
            <Th>Service</Th>
            <Th>État</Th>
            <Th>Variables attendues</Th>
            <Th>Effet si absent</Th>
          </tr>
        </thead>
        <tbody>
          {items.map((it) => (
            <tr key={it.label}>
              <Td className="font-medium">{it.label}</Td>
              <Td>{it.ok ? <Badge tone="ok">Configuré</Badge> : <Badge tone={it.required ? "danger" : "warn"}>{it.required ? "Manquant" : "Non configuré"}</Badge>}</Td>
              <Td>
                <div className="flex flex-wrap gap-1">
                  {it.envVars.map((v) => (
                    <code key={v} className={`num rounded-none px-1.5 py-0.5 text-[12px] ${set(v) ? "bg-ok-soft text-ok-ink" : "bg-bg-muted text-ink-2"}`}>
                      {v}
                    </code>
                  ))}
                </div>
              </Td>
              <Td className="max-w-[420px] text-[13px] text-ink-2">{it.ok ? "Actif." : it.effect}</Td>
            </tr>
          ))}
        </tbody>
      </Table>
    </Panel>
  );
}

export default async function IntegrationsPage() {
  await guardAdmin("/admin/integrations");
  const set = (k: string) => Boolean(process.env[k]);
  const external: Item[] = (Object.keys(integrations) as IntegrationName[]).map((k) => ({ label: integrationLabels[k].label, ok: integrations[k](), envVars: integrationLabels[k].envVars, effect: integrationLabels[k].effect }));
  const core: Item[] = [
    { label: "Base de données PostgreSQL", ok: set("DATABASE_URL"), envVars: ["DATABASE_URL"], effect: "Sans variable, connexion à la base locale par défaut (postgresql://nextformation:nextformation@localhost:5432/nextformation).", required: true },
    { label: "Secret applicatif (chiffrement AES-256-GCM)", ok: (process.env.APP_SECRET?.length ?? 0) >= 32, envVars: ["APP_SECRET"], effect: "Obligatoire (32 caractères minimum) : sans lui, le chiffrement du NIR, de l'IBAN et des secrets TOTP échoue. Ne jamais le changer sans rechiffrer les données.", required: true },
    { label: "Adresse publique de l'application", ok: set("APP_URL"), envVars: ["APP_URL"], effect: `Les liens des e-mails utilisent ${appUrl()}.` },
    { label: "Déclencheur des tâches de fond", ok: (process.env.CRON_SECRET?.length ?? 0) >= 16, envVars: ["CRON_SECRET"], effect: "POST /api/cron renvoie 503 : les tâches (nettoyage des démos, rappels, sauvegardes planifiées) ne s'exécutent que depuis Admin, Tâches." },
    { label: "Compte administrateur initial", ok: set("ADMIN_EMAIL") && set("ADMIN_PASSWORD"), envVars: ["ADMIN_EMAIL", "ADMIN_PASSWORD"], effect: "npm run setup ne crée pas d'administrateur plateforme." },
  ];
  return (
    <>
      <PageHeader title="Intégrations" description="Configuration lue au démarrage depuis les variables d'environnement (.env). Les valeurs ne sont jamais affichées ; une variable en vert est définie." />
      <Section title="Socle" description="Indispensable au fonctionnement de l'application." items={core} />
      <Section title="Services externes" description="Facultatifs : en leur absence, l'application fonctionne en mode dégradé explicite." items={external} />
      <p className="text-[13px] text-ink-3">Stockage documentaire actuel : {storageBackend()}.</p>
    </>
  );
}
