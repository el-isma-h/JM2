import type { Metadata } from "next";
import { publisher } from "@/lib/legal";
import { Fill, LegalDoc } from "../legal-doc";

export const metadata: Metadata = { title: "Mentions légales", description: "Éditeur, hébergeur et informations légales de Next Formation.", alternates: { canonical: "/mentions-legales" } };
export const dynamic = "force-dynamic";

export default function MentionsLegalesPage() {
  const p = publisher();
  return (
    <LegalDoc title="Mentions légales" updated="23 octobre 2026">
      <p>Informations prévues par l&apos;article 6 de la loi n° 2004-575 du 21 juin 2004 pour la confiance dans l&apos;économie numérique.</p>

      <h2>Éditeur</h2>
      <ul>
        <li>
          Raison sociale : <Fill value={p.name} label="raison sociale" />
          {p.form ? `, ${p.form}` : null}
        </li>
        <li>
          SIREN : <Fill value={p.siren} label="SIREN" />
        </li>
        <li>
          Siège : <Fill value={p.address} label="adresse du siège" />
        </li>
        <li>
          Directeur de la publication : <Fill value={p.director} label="directeur de la publication" />
        </li>
        <li>
          Contact : {p.email ? <a href={`mailto:${p.email}`}>{p.email}</a> : <Fill value="" label="adresse de contact" />}
        </li>
      </ul>

      <h2>Hébergement</h2>
      <p>
        <Fill value={p.host} label="nom, adresse et téléphone de l'hébergeur" />
      </p>

      <h2>Données personnelles</h2>
      <p>
        Le traitement des données est décrit dans la <a href="/confidentialite">politique de confidentialité</a>. Pour exercer vos droits :{" "}
        {p.dpoEmail ? <a href={`mailto:${p.dpoEmail}`}>{p.dpoEmail}</a> : <Fill value="" label="adresse dédiée" />}.
      </p>

      <h2>Propriété intellectuelle</h2>
      <p>
        Les éléments du site et de l&apos;application (textes, interface, logo, code) sont protégés par le droit de la propriété intellectuelle. Toute reproduction sans
        autorisation écrite de l&apos;éditeur est interdite. Digiforma, Galaxy, Moodle, Microsoft 365, Zapier et WordPress sont des marques de leurs titulaires
        respectifs, citées à titre de référence ou de compatibilité.
      </p>
    </LegalDoc>
  );
}
