import Link from "next/link";
import { and, desc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { listIntegrations, readSecrets, type IntegrationRow } from "@/server/integrations/store";
import { WEBHOOK_EVENTS } from "@/server/integrations/webhooks";
import { API_SCOPES } from "@/server/integrations/api-auth";
import { revokeApiKeyAction, toggleIntegrationAction } from "@/server/actions/integrations";
import { appUrl, integrationLabels, integrations as env } from "@/lib/env";
import { fmtDateTime } from "@/lib/dates";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FadeIn } from "@/components/ui/motion";
import { ActionButton } from "@/components/admin/action-form";
import { CreateApiKeyDialog, EdofButtons, MicrosoftForm, MoodleForm, WebhookForm } from "./forms";
import { ChorusForm } from "./chorus-form";
import { CHORUS_ENDPOINTS, type ChorusConfig, type ChorusSecrets } from "@/server/integrations/chorus";

export const dynamic = "force-dynamic";

function Status({ row }: { row: IntegrationRow | undefined }) {
  return (
    <div className="flex flex-wrap items-center gap-2">
      <StatusBadge status={row?.status ?? "non_configuree"} />
      {row?.lastSyncAt ? <span className="num text-[11.5px] text-ink-3">dernier échange {fmtDateTime(row.lastSyncAt)}</span> : null}
      {row?.lastError ? <span className="text-[11.5px] text-danger-ink">{row.lastError}</span> : null}
    </div>
  );
}

export default async function IntegrationsPage({ params }: { params: Promise<{ orgId: string }> }) {
  const { orgId } = await params;
  const ctx = await guardOrg(orgId, `/app/${orgId}/integrations`, "org.view");
  const canWrite = ctx.isOwner || ctx.permissions.has("integrations.manage");
  const [rows, keys] = await Promise.all([listIntegrations(orgId), db.select().from(schema.apiKeys).where(and(eq(schema.apiKeys.orgId, orgId))).orderBy(desc(schema.apiKeys.createdAt))]);
  const moodle = rows.moodle;
  const ms = rows.microsoft365;
  const wh = rows.webhook;
  const zap = rows.zapier;
  const stripeEnv = Boolean(process.env.STRIPE_SECRET_KEY);
  const smsEnv = Boolean(process.env.SMS_PROVIDER && process.env.SMS_API_KEY);
  const esignEnv = env.esign();
  const slug = ctx.tenant.slug;
  const cfg = <T,>(r: IntegrationRow | undefined, k: string, d: T): T => ((r?.config as Record<string, unknown>)?.[k] as T) ?? d;
  const toggle = (kind: string, row: IntegrationRow | undefined) => (canWrite && row ? <ActionButton action={toggleIntegrationAction} fields={{ orgId, kind }} label={row.status === "desactivee" ? "Réactiver" : "Désactiver"} variant="ghost" /> : null);

  return (
    <FadeIn>
      <PageHeader
        title="Intégrations"
        description={`Connecteurs de l'organisme. ${canWrite ? "Vous pouvez les configurer (intégrations ou propriétaire)." : "Lecture seule : la gestion des intégrations ou le propriétaire modifie ces réglages."} Chaque carte indique précisément ce qui fonctionne et ce qui manque.`}
      />
      <div className="grid gap-6 lg:grid-cols-2">
        <Panel>
          <PanelHeader title="Moodle" description="Plateforme e-learning : test de connexion réel via l'API REST (core_webservice_get_site_info)." actions={toggle("moodle", moodle)} />
          <div className="space-y-3 px-5 py-4">
            <Status row={moodle} />
            {moodle?.status === "connectee" ? <p className="text-[12.5px] text-ink-2">Site : {cfg(moodle, "sitename", "")} {cfg(moodle, "release", null) ? `(${cfg(moodle, "release", "")})` : ""}</p> : null}
            {canWrite ? <MoodleForm orgId={orgId} url={cfg(moodle, "url", "")} hasToken={Boolean(readSecrets(moodle ?? null))} /> : <p className="text-[13px] text-ink-2">{cfg(moodle, "url", "") || "Non configuré."}</p>}
            <p className="text-[12px] text-ink-3">Synchronisation des cours et progressions : à brancher dans le module E-learning (modules de type « moodle »).</p>
          </div>
        </Panel>

        <Panel>
          <PanelHeader title="Microsoft 365 / SharePoint" description="Application Entra ID (client id, tenant, secret chiffré)." actions={toggle("microsoft365", ms)} />
          <div className="space-y-3 px-5 py-4">
            <Status row={ms} />
            {canWrite ? <MicrosoftForm orgId={orgId} tenantId={cfg(ms, "tenantId", "")} clientId={cfg(ms, "clientId", "")} siteUrl={cfg(ms, "siteUrl", "") ?? ""} hasSecret={Boolean(readSecrets(ms ?? null))} /> : <p className="text-[13px] text-ink-2">{cfg(ms, "clientId", "") ? `Application ${cfg(ms, "clientId", "")}` : "Non configuré."}</p>}
            <Notice tone="info">
              Synchronisation SharePoint <strong>à brancher</strong> : il manque l&apos;autorisation d&apos;application (consentement administrateur sur Sites.ReadWrite.All), l&apos;obtention du jeton (client credentials) et la correspondance dossiers SharePoint, dossiers documentaires. Les identifiants sont enregistrés pour préparer ce raccordement ; aucun fichier n&apos;est envoyé aujourd&apos;hui.
            </Notice>
          </div>
        </Panel>

        <Panel>
          <PanelHeader title="EDOF (Mon Compte Formation)" description="Export des sessions publiées (ouvertes ou confirmées, non terminées) au format XML ou CSV, à déposer sur EDOF." />
          <div className="space-y-3 px-5 py-4">
            <Status row={rows.edof} />
            <p className="text-[12.5px] text-ink-2">Champs : code session, intitulé, code programme, RNCP / RS, certificateur, dates, modalité, durée, lieu, capacité, prix HT, NDA et SIRET de l&apos;organisme.</p>
            {ctx.permissions.has("exports.run") ? <EdofButtons orgId={orgId} canExport /> : <Notice tone="info">Génération réservée à la permission « Exporter des données » (vérification renforcée).</Notice>}
          </div>
        </Panel>

        <Panel>
          <PanelHeader title="Chorus Pro (factures publiques)" description="Dépôt des factures adressées à une entité publique via l'API Chorus Pro (PISTE) et suivi de leur statut." actions={toggle("chorus", rows.chorus)} />
          <div className="space-y-3 px-5 py-4">
            <Badge tone="warn">Bêta : à valider en qualification</Badge>
            <Status row={rows.chorus} />
            {rows.chorus ? (
              <p className="text-[12.5px] text-ink-2">
                {CHORUS_ENDPOINTS[cfg<ChorusConfig["env"]>(rows.chorus, "env", "qualification") === "production" ? "production" : "qualification"].label}
                {cfg<number | null>(rows.chorus, "supplierStructureId", null) ? ` · structure ${cfg<string>(rows.chorus, "supplierName", "") || ""} (identifiant Chorus ${cfg<number>(rows.chorus, "supplierStructureId", 0)})` : " · structure fournisseur non encore reconnue : testez la connexion."}
              </p>
            ) : null}
            {canWrite ? (
              (() => {
                const sec = readSecrets<ChorusSecrets>(rows.chorus ?? null) ?? {};
                return <ChorusForm orgId={orgId} env={cfg<ChorusConfig["env"]>(rows.chorus, "env", "qualification") === "production" ? "production" : "qualification"} supplierSiret={cfg<string | null>(rows.chorus, "supplierSiret", null) ?? ""} orgSiret={ctx.org.siret ?? null} has={{ clientId: Boolean(sec.clientId), clientSecret: Boolean(sec.clientSecret), techLogin: Boolean(sec.techLogin), techPassword: Boolean(sec.techPassword) }} isDemo={ctx.org.isDemo} />;
              })()
            ) : (
              <p className="text-[13px] text-ink-2">{rows.chorus ? "Configuré." : "Non configuré."}</p>
            )}
            <p className="text-[12px] text-ink-3">
              Prérequis : une application sur PISTE (piste.gouv.fr) abonnée à l&apos;API Chorus Pro, et un compte technique Chorus Pro rattaché à la structure de l&apos;organisme. Le PDF archivé est déposé en mode « saisie API » avec ses métadonnées (SIRET acheteur, code service, bon de commande ou engagement juridique) ; un Factur-X serait déposé en flux. Statut suivi par la tâche de fond chorus:status.
            </p>
          </div>
        </Panel>

        <Panel>
          <PanelHeader title="Zapier" description="Envoi d'événements vers un « Catch Hook » Zapier (POST JSON signé HMAC-SHA256)." actions={toggle("zapier", zap)} />
          <div className="space-y-3 px-5 py-4">
            <Status row={zap} />
            {canWrite ? <WebhookForm orgId={orgId} kind="zapier" url={cfg(zap, "url", "")} events={cfg(zap, "events", [] as string[])} allEvents={[...WEBHOOK_EVENTS]} hasSecret={Boolean(readSecrets(zap ?? null))} isDemo={ctx.org.isDemo} /> : <p className="text-[13px] text-ink-2">{cfg(zap, "url", "") || "Non configuré."}</p>}
          </div>
        </Panel>

        <Panel>
          <PanelHeader title="Webhooks" description="Même mécanisme que Zapier vers votre propre service : en-têtes X-NextFormation-Event, X-NextFormation-Timestamp, X-NextFormation-Signature." actions={toggle("webhook", wh)} />
          <div className="space-y-3 px-5 py-4">
            <Status row={wh} />
            {canWrite ? <WebhookForm orgId={orgId} kind="webhook" url={cfg(wh, "url", "")} events={cfg(wh, "events", [] as string[])} allEvents={[...WEBHOOK_EVENTS]} hasSecret={Boolean(readSecrets(wh ?? null))} isDemo={ctx.org.isDemo} /> : <p className="text-[13px] text-ink-2">{cfg(wh, "url", "") || "Non configuré."}</p>}
            <p className="text-[12px] text-ink-3">Les événements sont publiés par les modules qui appellent <span className="num">emitWebhookEvent</span> ; ceux qui ne l&apos;appellent pas encore n&apos;émettent rien.</p>
          </div>
        </Panel>

        <Panel>
          <PanelHeader title="Clés API" description="Accès en lecture : GET /api/v1/programs, /api/v1/sessions, /api/v1/enrollments avec Authorization: Bearer. Limite : 600 requêtes par minute et par clé." actions={canWrite ? <CreateApiKeyDialog orgId={orgId} scopes={[...API_SCOPES]} /> : null} />
          {keys.length ? (
            <Table>
              <thead>
                <tr>
                  <Th>Nom</Th>
                  <Th>Préfixe</Th>
                  <Th>Portées</Th>
                  <Th>Dernier usage</Th>
                  <Th>État</Th>
                  <Th />
                </tr>
              </thead>
              <tbody>
                {keys.map((k) => (
                  <tr key={k.id}>
                    <Td className="font-medium">{k.name}</Td>
                    <Td className="num">{k.prefix}…</Td>
                    <Td className="text-[12px] text-ink-2">{(Array.isArray(k.scopes) ? (k.scopes as string[]) : []).join(", ")}</Td>
                    <Td className="text-[12.5px] text-ink-2">{k.lastUsedAt ? fmtDateTime(k.lastUsedAt) : "Jamais"}</Td>
                    <Td>{k.revokedAt ? <Badge tone="danger">Révoquée</Badge> : <Badge tone="ok">Active</Badge>}</Td>
                    <Td className="text-right">{canWrite && !k.revokedAt ? <ActionButton action={revokeApiKeyAction} fields={{ orgId, keyId: k.id }} label="Révoquer" variant="ghost" confirm={{ title: "Révoquer la clé", description: `${k.name} (${k.prefix}…) sera refusée immédiatement.`, confirmLabel: "Révoquer", danger: true }} /> : null}</Td>
                  </tr>
                ))}
              </tbody>
            </Table>
          ) : (
            <p className="px-5 py-4 text-[13.5px] text-ink-2">Aucune clé API.</p>
          )}
          <p className="border-t border-line px-5 py-3 text-[12px] text-ink-3">
            Exemple : <span className="num">curl -H &quot;Authorization: Bearer nf_…&quot; {appUrl()}/api/v1/sessions?from=2026-01-01</span>
          </p>
        </Panel>

        <Panel>
          <PanelHeader title="WordPress (catalogue public)" />
          <div className="space-y-2 px-5 py-4 text-[13px] text-ink-2">
            <p>
              Le catalogue public est exposé en JSON sur <span className="num">{appUrl()}/api/public/catalogue/{slug}</span> (programmes et sessions publiés). Un plugin ou un bloc WordPress peut l&apos;appeler sans clé : ajoutez un shortcode qui lit ce flux et affiche les sessions à venir.
            </p>
            <p>
              Page publique prête à l&apos;emploi :{" "}
              <Link href={`/catalogue-public/${slug}`} className="underline">
                /catalogue-public/{slug}
              </Link>
              .
            </p>
          </div>
        </Panel>

        <Panel>
          <PanelHeader title="Signature électronique" />
          <div className="space-y-2 px-5 py-4 text-[13px] text-ink-2">
            {esignEnv ? <Badge tone="ok">Configurée ({process.env.ESIGN_PROVIDER})</Badge> : <Badge tone="warn">Non configurée</Badge>}
            <p>{esignEnv ? "Les demandes de signature passent par le prestataire configuré (module Signatures)." : `Variables attendues : ${integrationLabels.esign.envVars.join(", ")}. ${integrationLabels.esign.effect} La signature interne (dessin, horodatage, preuve) reste disponible dans le module Signatures.`}</p>
          </div>
        </Panel>

        <Panel>
          <PanelHeader title="Paiement en ligne (Stripe)" />
          <div className="space-y-2 px-5 py-4 text-[13px] text-ink-2">
            {stripeEnv ? <Badge tone="ok">Configuré</Badge> : <Badge tone="warn">Non configuré</Badge>}
            <Status row={rows.stripe} />
            <p>{stripeEnv ? "Un lien de paiement Checkout peut être créé depuis une facture émise (action « Lien de paiement » du module Factures, permission gestion finance). Le rapprochement du règlement reste manuel : le webhook Stripe n'est pas branché." : "Variable attendue : STRIPE_SECRET_KEY (clé secrète). Sans elle, aucun lien de paiement ne peut être créé ; les règlements se saisissent manuellement dans Factures."}</p>
          </div>
        </Panel>

        <Panel>
          <PanelHeader title="SMS" />
          <div className="space-y-2 px-5 py-4 text-[13px] text-ink-2">
            {smsEnv ? <Badge tone="ok">Configuré</Badge> : <Badge tone="warn">Non configuré</Badge>}
            <p>{smsEnv ? "Fournisseur SMS configuré : les rappels de séance et convocations peuvent partir par SMS quand un module le déclenche." : "Variables attendues : SMS_PROVIDER et SMS_API_KEY. Sans elles, aucun SMS ne part ; les rappels restent par e-mail et dans l'application."}</p>
          </div>
        </Panel>

        <Panel>
          <PanelHeader title="E-mail transactionnel" />
          <div className="space-y-2 px-5 py-4 text-[13px] text-ink-2">
            {env.mail() ? <Badge tone="ok">Configuré</Badge> : <Badge tone="warn">Non configuré</Badge>}
            <p>{env.mail() ? "Les e-mails partent via le service configuré (hors démonstration)." : `${integrationLabels.mail.effect} Variables : ${integrationLabels.mail.envVars.join(", ")}.`}</p>
            <Button asChild variant="ghost" size="sm">
              <Link href={`/app/${orgId}/parametres`}>Paramètres</Link>
            </Button>
          </div>
        </Panel>
      </div>
    </FadeIn>
  );
}
