import Link from "next/link";
import { and, asc, desc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardSecurityAdmin } from "@/server/security/access";
import { ASSIGNABLE_ROLES, FINE_PERMISSIONS, OWNER_ONLY_PERMISSIONS } from "@/server/security/rules";
import { permissionLabels, permissionsForRoles, ROLE_MATRIX, roleLabels, type OrgRole, type Permission } from "@/server/authz";
import { setMemberActiveAction, resendInvitationAction, revokeInvitationAction } from "@/server/actions/security";
import { fmtDate, fmtDateTime } from "@/lib/dates";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { EmptyState, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FadeIn } from "@/components/ui/motion";
import { ActionButton } from "@/components/admin/action-form";
import { ExpiryDialog, InviteDialog, PermissionsDialog, RolesDialog, TrainerDialog, TransferDialog } from "./member-dialogs";

export const dynamic = "force-dynamic";

/** S01 : page réservée au propriétaire actif (session renforcée). Chaque action revérifie côté serveur. */
export default async function SecurityPage({ params }: { params: Promise<{ orgId: string }> }) {
  const { orgId } = await params;
  const ctx = await guardSecurityAdmin(orgId, `/app/${orgId}/securite`);
  const [members, invitations, trainers] = await Promise.all([
    db
      .select({ m: schema.memberships, u: { id: schema.users.id, firstName: schema.users.firstName, lastName: schema.users.lastName, email: schema.users.email, disabledAt: schema.users.disabledAt, lastLoginAt: schema.users.lastLoginAt, totpEnabledAt: schema.users.totpEnabledAt } })
      .from(schema.memberships)
      .innerJoin(schema.users, eq(schema.users.id, schema.memberships.userId))
      .where(eq(schema.memberships.orgId, orgId))
      .orderBy(asc(schema.users.lastName), asc(schema.users.firstName)),
    db.select().from(schema.invitations).where(and(eq(schema.invitations.orgId, orgId), eq(schema.invitations.status, "pending"))).orderBy(desc(schema.invitations.createdAt)),
    db.select({ id: schema.trainers.id, firstName: schema.trainers.firstName, lastName: schema.trainers.lastName, userId: schema.trainers.userId }).from(schema.trainers).where(and(eq(schema.trainers.orgId, orgId), eq(schema.trainers.isActive, true))).orderBy(asc(schema.trainers.lastName)),
  ]);
  const roleOptions = ASSIGNABLE_ROLES.map((r) => ({ key: r, label: roleLabels[r] }));
  const trainerOptions = trainers.map((t) => ({ id: t.id, name: `${t.firstName} ${t.lastName}`, linkedTo: t.userId }));
  const now = new Date();
  const staff = members.filter(({ m }) => (Array.isArray(m.roles) ? (m.roles as string[]) : []).some((r) => r !== "learner" && r !== "employer") || m.userId === ctx.org.ownerUserId);
  const extranet = members.length - staff.length;
  const candidates = staff.filter(({ m, u }) => m.userId !== ctx.user.id && m.active && !u.disabledAt && (!m.expiresAt || m.expiresAt > now)).map(({ m, u }) => ({ userId: m.userId, name: `${u.firstName} ${u.lastName} (${u.email})` }));
  const matrixRoles = ASSIGNABLE_ROLES;
  const matrixPerms = [...FINE_PERMISSIONS, "self.view" as Permission];

  return (
    <FadeIn>
      <PageHeader
        title="Utilisateurs et rôles"
        description="Administration de la sécurité, réservée au propriétaire actif du tenant : membres, rôles additifs, permissions fines, invitations, transfert de propriété. Le cumul de rôles ne donne jamais ces droits ; chaque action est revérifiée côté serveur et journalisée."
        actions={
          <>
            <Button asChild variant="secondary">
              <Link href={`/app/${orgId}/audit`}>Journal d&apos;audit</Link>
            </Button>
            <InviteDialog orgId={orgId} roles={roleOptions} trainers={trainerOptions} />
          </>
        }
      />

      <Panel className="mb-6">
        <PanelHeader title="Membres de l'organisme" description={`${staff.length} membre(s) de l'équipe${extranet ? `, ${extranet} accès extranet (apprenants, entreprises) gérés depuis leurs modules` : ""}.`} />
        {staff.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Personne</Th>
                <Th>Rôles</Th>
                <Th>Permissions fines</Th>
                <Th>État</Th>
                <Th>Formateur</Th>
                <Th />
              </tr>
            </thead>
            <tbody>
              {staff.map(({ m, u }) => {
                const roles = (Array.isArray(m.roles) ? (m.roles as string[]) : []).filter((r): r is OrgRole => r in roleLabels);
                const overrides = (m.permissions ?? {}) as Record<string, boolean>;
                const isOwner = ctx.org.ownerUserId === m.userId;
                const expired = Boolean(m.expiresAt && m.expiresAt <= now);
                const fromRoles = permissionsForRoles(roles);
                const name = `${u.firstName} ${u.lastName}`;
                const trainer = trainerOptions.find((t) => t.id === m.trainerId);
                const granted = Object.entries(overrides).filter(([, v]) => v === true).map(([k]) => k);
                const denied = Object.entries(overrides).filter(([, v]) => v === false).map(([k]) => k);
                return (
                  <tr key={m.id}>
                    <Td>
                      <span className="font-medium">{name}</span>
                      {isOwner ? (
                        <Badge tone="accent" className="ml-2">
                          Propriétaire
                        </Badge>
                      ) : null}
                      <p className="text-[12px] text-ink-3">{u.email}</p>
                      <p className="text-[11.5px] text-ink-3">
                        {u.lastLoginAt ? `Dernière connexion ${fmtDateTime(u.lastLoginAt)}` : "Jamais connecté"}
                        {u.totpEnabledAt ? ", double authentification" : ""}
                      </p>
                    </Td>
                    <Td className="max-w-[240px] text-ink-2">{roles.length ? roles.map((r) => roleLabels[r]).join(", ") : <span className="text-ink-3">Aucun rôle</span>}</Td>
                    <Td className="max-w-[260px] text-[12.5px]">
                      {granted.length ? <p className="text-ok-ink">+ {granted.map((k) => permissionLabels[k as Permission] ?? k).join(", ")}</p> : null}
                      {denied.length ? <p className="text-danger-ink">- {denied.map((k) => permissionLabels[k as Permission] ?? k).join(", ")}</p> : null}
                      {!granted.length && !denied.length ? <span className="text-ink-3">Selon rôles</span> : null}
                    </Td>
                    <Td>
                      <div className="flex flex-wrap gap-1">
                        {u.disabledAt ? <Badge tone="danger">Compte désactivé</Badge> : m.active ? <Badge tone="ok">Actif</Badge> : <Badge tone="danger">Inactif</Badge>}
                        {m.expiresAt ? <Badge tone={expired ? "danger" : "warn"}>{expired ? "Expiré" : `Expire le ${fmtDate(m.expiresAt)}`}</Badge> : null}
                      </div>
                    </Td>
                    <Td className="text-ink-2">{trainer ? trainer.name : <span className="text-ink-3">-</span>}</Td>
                    <Td>
                      <div className="flex flex-wrap justify-end gap-1">
                        <RolesDialog orgId={orgId} membershipId={m.id} name={name} roles={roleOptions} current={roles} />
                        <PermissionsDialog orgId={orgId} membershipId={m.id} name={name} perms={FINE_PERMISSIONS.map((p) => ({ key: p, label: permissionLabels[p], fromRoles: fromRoles.has(p) }))} overrides={overrides} />
                        <ExpiryDialog orgId={orgId} membershipId={m.id} name={name} current={m.expiresAt ? m.expiresAt.toISOString().slice(0, 10) : ""} />
                        <TrainerDialog orgId={orgId} membershipId={m.id} name={name} trainers={trainerOptions} current={m.trainerId} />
                        {!isOwner ? (
                          m.active ? (
                            <ActionButton action={setMemberActiveAction} fields={{ orgId, membershipId: m.id, active: "0" }} label="Désactiver" variant="ghost" confirm={{ title: "Désactiver le membre", description: `${name} n'aura plus aucun accès à cet organisme ; ses sessions seront fermées. Réversible.`, confirmLabel: "Désactiver", danger: true }} />
                          ) : (
                            <ActionButton action={setMemberActiveAction} fields={{ orgId, membershipId: m.id, active: "1" }} label="Réactiver" variant="ghost" />
                          )
                        ) : null}
                      </div>
                    </Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucun membre" description="Invitez votre équipe avec des rôles additifs." />
        )}
      </Panel>

      <div className="mb-6 grid gap-6 lg:grid-cols-2">
        <Panel>
          <PanelHeader title="Invitations en attente" description="Renvoyer génère un nouveau lien ; révoquer invalide le lien immédiatement." />
          {invitations.length ? (
            <Table>
              <tbody>
                {invitations.map((i) => (
                  <tr key={i.id}>
                    <Td>
                      {i.email}
                      <p className="text-[12px] text-ink-3">
                        {(Array.isArray(i.roles) ? (i.roles as string[]) : []).map((r) => roleLabels[r as OrgRole] ?? r).join(", ") || "Sans rôle"}, expire le {fmtDate(i.expiresAt)}
                      </p>
                    </Td>
                    <Td className="text-right">
                      <div className="flex justify-end gap-1">
                        <ActionButton action={resendInvitationAction} fields={{ orgId, invitationId: i.id }} label="Renvoyer" variant="ghost" />
                        <ActionButton action={revokeInvitationAction} fields={{ orgId, invitationId: i.id }} label="Révoquer" variant="ghost" confirm={{ title: "Révoquer l'invitation", description: i.email, confirmLabel: "Révoquer", danger: true }} />
                      </div>
                    </Td>
                  </tr>
                ))}
              </tbody>
            </Table>
          ) : (
            <p className="px-5 py-4 text-[13.5px] text-ink-2">Aucune invitation en attente.</p>
          )}
        </Panel>

        <Panel>
          <PanelHeader title="Propriété du tenant" description="Un seul propriétaire actif administre la sécurité et la charte. Le transfert exige votre mot de passe et un membre actif cible." />
          <div className="space-y-3 px-5 py-4 text-[13.5px]">
            <p>
              Propriétaire actuel : <span className="font-medium">{ctx.user.firstName} {ctx.user.lastName}</span> ({ctx.user.email}).
            </p>
            {candidates.length ? <TransferDialog orgId={orgId} candidates={candidates} /> : <Notice tone="info">Aucun autre membre actif : invitez d&apos;abord la personne qui recevra la propriété.</Notice>}
          </div>
        </Panel>
      </div>

      <Panel>
        <PanelHeader title="Matrice des droits (lecture)" description="Permissions accordées par chaque rôle. Les permissions propriétaire ne figurent dans aucun rôle : utilisateurs, rôles et journal d'audit relèvent du seul propriétaire actif." />
        <Table>
          <thead>
            <tr>
              <Th>Permission</Th>
              {matrixRoles.map((r) => (
                <Th key={r} className="whitespace-nowrap text-[10px]">
                  {roleLabels[r]}
                </Th>
              ))}
            </tr>
          </thead>
          <tbody>
            {matrixPerms.map((p) => (
              <tr key={p}>
                <Td className="whitespace-nowrap text-[12.5px]">{permissionLabels[p]}</Td>
                {matrixRoles.map((r) => (
                  <Td key={r} className="text-center">
                    {ROLE_MATRIX[r].includes(p) ? <span className="text-accent" aria-label="oui">●</span> : <span className="text-ink-3/40" aria-label="non">·</span>}
                  </Td>
                ))}
              </tr>
            ))}
            {OWNER_ONLY_PERMISSIONS.map((p) => (
              <tr key={p}>
                <Td className="whitespace-nowrap text-[12.5px]">
                  {permissionLabels[p]} <Badge tone="accent" className="ml-1">Propriétaire</Badge>
                </Td>
                {matrixRoles.map((r) => (
                  <Td key={r} className="text-center">
                    <span className="text-ink-3/40" aria-label="non">·</span>
                  </Td>
                ))}
              </tr>
            ))}
          </tbody>
        </Table>
      </Panel>
    </FadeIn>
  );
}
