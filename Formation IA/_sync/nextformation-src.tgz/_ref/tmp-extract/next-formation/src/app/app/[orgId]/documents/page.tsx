import Link from "next/link";
import { inArray } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { listDocumentsFor, filterVisible, CATEGORY_LABELS, VISIBILITY_LABELS, STATUS_LABELS } from "@/server/documents/queries";
import { downloadDocumentAction, uploadDocumentAction } from "@/server/actions/documents";
import { ACCEPT_ATTR, ALLOWED_LABEL } from "@/server/documents/upload-rules";
import { fmtDateTime } from "@/lib/dates";
import { fmtBytes } from "@/components/admin/utils";
import { StatusBadge, Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/field";
import { EmptyState, Notice, PageHeader, Panel } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FormDialog } from "@/components/admin/form-dialog";
import { Pagination, readPage, readParam } from "@/components/admin/pagination";
import { DownloadButton } from "@/components/documents/download-button";
import { FadeIn } from "@/components/ui/motion";

export const dynamic = "force-dynamic";
const PAGE = 40;
type Cat = (typeof schema.documentCategoryEnum.enumValues)[number];
type Vis = (typeof schema.documentVisibilityEnum.enumValues)[number];
type Stat = (typeof schema.documentStatusEnum.enumValues)[number];
const isUuid = (v?: string) => Boolean(v && /^[0-9a-f-]{36}$/i.test(v));

export default async function DocumentsPage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const base = `/app/${orgId}/documents`;
  const ctx = await guardOrg(orgId, base, "documents.view");
  const sp = await searchParams;
  const q = readParam(sp.q);
  const category = readParam(sp.category);
  const status = readParam(sp.status);
  const visibility = readParam(sp.visibility);
  const enrollmentId = readParam(sp.enrollmentId);
  const sessionId = readParam(sp.sessionId);
  const companyId = readParam(sp.companyId);
  const personId = readParam(sp.personId);
  const archived = readParam(sp.archived) === "1";
  const page = readPage(sp.page);

  const all = await listDocumentsFor({
    orgId,
    q,
    category: category && (schema.documentCategoryEnum.enumValues as readonly string[]).includes(category) ? (category as Cat) : null,
    status: status && (schema.documentStatusEnum.enumValues as readonly string[]).includes(status) ? (status as Stat) : null,
    visibility: visibility && (schema.documentVisibilityEnum.enumValues as readonly string[]).includes(visibility) ? (visibility as Vis) : null,
    enrollmentId: isUuid(enrollmentId) ? enrollmentId : null,
    sessionId: isUuid(sessionId) ? sessionId : null,
    companyId: isUuid(companyId) ? companyId : null,
    personId: isUuid(personId) ? personId : null,
    includeArchived: archived,
    limit: 2000,
  });
  const visible = await filterVisible(ctx, all);
  const hidden = all.length - visible.length;
  const rows = visible.slice((page - 1) * PAGE, page * PAGE);

  const personIds = [...new Set(rows.map((r) => r.personId).filter((x): x is string => Boolean(x)))];
  const sessionIds = [...new Set(rows.map((r) => r.sessionId).filter((x): x is string => Boolean(x)))];
  const [persons, sessions] = await Promise.all([
    personIds.length ? db.select({ id: schema.persons.id, firstName: schema.persons.firstName, lastName: schema.persons.lastName }).from(schema.persons).where(inArray(schema.persons.id, personIds)) : [],
    sessionIds.length ? db.select({ id: schema.trainingSessions.id, title: schema.trainingSessions.title, code: schema.trainingSessions.code }).from(schema.trainingSessions).where(inArray(schema.trainingSessions.id, sessionIds)) : [],
  ]);
  const personName = new Map(persons.map((p) => [p.id, `${p.firstName} ${p.lastName}`]));
  const sessionName = new Map(sessions.map((s) => [s.id, s.code]));
  const canGenerate = ctx.permissions.has("documents.generate");
  const canAdmin = ctx.permissions.has("dossier.admin_docs.manage");
  const scopeHidden = { enrollmentId, sessionId, companyId, personId };
  const filterParams = { q, category, status, visibility, enrollmentId, sessionId, companyId, personId, archived: archived ? "1" : undefined };

  return (
    <FadeIn>
      <PageHeader
        title="Documents"
        description="Bibliothèque des documents du parcours : conventions, convocations, attestations, pièces déposées. Chaque document garde ses versions ; une régénération ne remplace jamais un document signé."
        actions={
          <>
            {canGenerate ? (
              <Button asChild variant="secondary">
                <Link href={`${base}/modeles`}>Modèles</Link>
              </Button>
            ) : null}
            {canGenerate ? (
              <FormDialog action={uploadDocumentAction} trigger="Déposer un fichier" triggerVariant="secondary" title="Déposer un document" description={`Formats acceptés : ${ALLOWED_LABEL}, 20 Mo maximum. Le fichier est stocké en privé.`} submitLabel="Déposer">
                <input type="hidden" name="orgId" value={orgId} />
                {Object.entries(scopeHidden).map(([k, v]) => (isUuid(v) ? <input key={k} type="hidden" name={k} value={v} /> : null))}
                <Field label="Titre" required htmlFor="up-title">
                  <Input id="up-title" name="title" required />
                </Field>
                <Field label="Fichier" required htmlFor="up-file">
                  <Input id="up-file" name="file" type="file" accept={ACCEPT_ATTR} required className="py-1.5" />
                </Field>
                <Field label="Catégorie" htmlFor="up-cat">
                  <Select id="up-cat" name="category" defaultValue="justificatif">
                    {schema.documentCategoryEnum.enumValues
                      .filter((c) => c !== "rib")
                      .map((c) => (
                        <option key={c} value={c}>
                          {CATEGORY_LABELS[c]}
                        </option>
                      ))}
                  </Select>
                </Field>
                <Field label="Visibilité" htmlFor="up-vis" help={canAdmin ? "Administratif et confidentiel : réservés aux habilitations pièces administratives." : "Les visibilités administratif et confidentiel exigent l'habilitation « gérer les pièces administratives »."}>
                  <Select id="up-vis" name="visibility" defaultValue="interne">
                    {schema.documentVisibilityEnum.enumValues
                      .filter((v) => v !== "public" && (canAdmin || (v !== "administratif" && v !== "confidentiel")))
                      .map((v) => (
                        <option key={v} value={v}>
                          {VISIBILITY_LABELS[v]}
                        </option>
                      ))}
                  </Select>
                </Field>
                {!isUuid(enrollmentId) && !isUuid(sessionId) ? (
                  <Field label="Rattachement (facultatif)" htmlFor="up-enr" help="Identifiant d'inscription ; depuis un dossier, le rattachement est automatique.">
                    <Input id="up-enr" name="enrollmentId" placeholder="Identifiant d'inscription" className="num" />
                  </Field>
                ) : null}
              </FormDialog>
            ) : null}
            {canGenerate ? (
              <Button asChild>
                <Link href={`${base}/nouveau${isUuid(enrollmentId) ? `?enrollmentId=${enrollmentId}` : isUuid(sessionId) ? `?sessionId=${sessionId}` : ""}`}>Générer depuis un modèle</Link>
              </Button>
            ) : null}
          </>
        }
      />

      {isUuid(enrollmentId) || isUuid(sessionId) || isUuid(companyId) || isUuid(personId) ? (
        <Notice tone="info" className="mb-4">
          Filtre actif sur un dossier. <Link href={base} className="underline">Voir tous les documents</Link>
          {isUuid(enrollmentId) ? (
            <>
              {" "}
              ou <Link href={`/app/${orgId}/inscriptions/${enrollmentId}`} className="underline">retourner au dossier d&apos;inscription</Link>.
            </>
          ) : null}
        </Notice>
      ) : null}

      <Panel>
        <form method="get" className="flex flex-wrap items-end gap-3 border-b border-line px-5 py-3">
          {Object.entries(scopeHidden).map(([k, v]) => (isUuid(v) ? <input key={k} type="hidden" name={k} value={v} /> : null))}
          <Field label="Recherche" htmlFor="q" className="w-full max-w-xs">
            <Input id="q" name="q" defaultValue={q} placeholder="Titre ou nom de fichier" />
          </Field>
          <Field label="Catégorie" htmlFor="category" className="w-48">
            <Select id="category" name="category" defaultValue={category ?? ""}>
              <option value="">Toutes</option>
              {schema.documentCategoryEnum.enumValues.map((c) => (
                <option key={c} value={c}>
                  {CATEGORY_LABELS[c]}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Statut" htmlFor="status" className="w-40">
            <Select id="status" name="status" defaultValue={status ?? ""}>
              <option value="">Tous</option>
              {schema.documentStatusEnum.enumValues.map((s) => (
                <option key={s} value={s}>
                  {STATUS_LABELS[s]}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Visibilité" htmlFor="visibility" className="w-40">
            <Select id="visibility" name="visibility" defaultValue={visibility ?? ""}>
              <option value="">Toutes</option>
              {schema.documentVisibilityEnum.enumValues.map((v) => (
                <option key={v} value={v}>
                  {VISIBILITY_LABELS[v]}
                </option>
              ))}
            </Select>
          </Field>
          <label className="mb-2 inline-flex items-center gap-2 text-[13px] text-ink-2">
            <input type="checkbox" name="archived" value="1" defaultChecked={archived} className="h-4 w-4 rounded-none" /> Inclure les archives
          </label>
          <Button type="submit" variant="secondary">
            Filtrer
          </Button>
        </form>
        {hidden > 0 ? (
          <p className="border-b border-line px-5 py-2 text-[12px] text-ink-3">
            {hidden} document(s) non affiché(s) : habilitation nécessaire (pièces administratives, pédagogie, CV, RIB ou périmètre formateur).
          </p>
        ) : null}
        {rows.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Document</Th>
                <Th>Catégorie</Th>
                <Th>Rattachement</Th>
                <Th>Visibilité</Th>
                <Th>Statut</Th>
                <Th num>Version</Th>
                <Th>Date</Th>
                <Th></Th>
              </tr>
            </thead>
            <tbody>
              {rows.map((d) => (
                <tr key={d.id}>
                  <Td>
                    <Link href={`${base}/${d.id}`} className="font-medium text-ink hover:underline">
                      {d.title}
                    </Link>
                    <p className="num text-[12px] text-ink-3">
                      {d.fileName} · {fmtBytes(d.sizeBytes)}
                    </p>
                  </Td>
                  <Td>{CATEGORY_LABELS[d.category]}</Td>
                  <Td className="text-[12.5px]">
                    {d.enrollmentId ? (
                      <Link href={`/app/${orgId}/inscriptions/${d.enrollmentId}`} className="hover:underline">
                        {d.personId ? (personName.get(d.personId) ?? "Inscription") : "Inscription"}
                      </Link>
                    ) : d.sessionId ? (
                      <Link href={`/app/${orgId}/sessions/${d.sessionId}`} className="hover:underline">
                        Session {sessionName.get(d.sessionId) ?? ""}
                      </Link>
                    ) : d.personId ? (
                      personName.get(d.personId)
                    ) : d.companyId ? (
                      <Link href={`/app/${orgId}/entreprises/${d.companyId}`} className="hover:underline">
                        Entreprise
                      </Link>
                    ) : (
                      <span className="text-ink-3">Organisme</span>
                    )}
                  </Td>
                  <Td>
                    <Badge tone={d.visibility === "confidentiel" || d.visibility === "administratif" ? "warn" : "neutral"}>{VISIBILITY_LABELS[d.visibility]}</Badge>
                  </Td>
                  <Td>
                    <StatusBadge status={d.status} />
                  </Td>
                  <Td num>v{d.version}</Td>
                  <Td className="whitespace-nowrap text-[12.5px]">{fmtDateTime(d.createdAt)}</Td>
                  <Td>
                    <DownloadButton action={downloadDocumentAction} fields={{ orgId, documentId: d.id }} />
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
        ) : (
          <EmptyState
            title="Aucun document"
            description={all.length ? "Aucun document visible avec vos habilitations pour ces filtres." : "Générez un document depuis un modèle ou déposez un fichier."}
            action={
              canGenerate ? (
                <Button asChild>
                  <Link href={`${base}/nouveau`}>Générer depuis un modèle</Link>
                </Button>
              ) : undefined
            }
          />
        )}
        <Pagination basePath={base} params={filterParams} page={page} pageSize={PAGE} total={visible.length} />
      </Panel>
    </FadeIn>
  );
}
