import { redirect } from "next/navigation";
import { handleAuthError } from "@/server/guard";
import { requireUser } from "@/server/auth";
import { guardTrainer } from "@/server/extranet/guard";
import { trainerNav } from "@/components/app/nav";
import { ExtranetShell } from "@/components/extranet/shell";

export const dynamic = "force-dynamic";

/**
 * Espace formateur externe : sans session → /connexion?next=/formateur ; un formateur cumulant un autre rôle staff
 * utilise l'application principale (/app) ; sans fiche formateur → état vide.
 */
export default async function TrainerLayout({ children }: { children: React.ReactNode }) {
  let user;
  try {
    user = await requireUser();
  } catch (e) {
    handleAuthError(e, "/formateur");
    throw e;
  }
  const ctx = await guardTrainer("/formateur");
  if (ctx?.hasOtherStaffRole) redirect(`/app/${ctx.org.id}`);
  return (
    <ExtranetShell base="/formateur" items={ctx ? trainerNav : []} user={user} org={ctx?.org ?? null} choices={ctx?.choices ?? []} subtitle={ctx ? `${ctx.trainer.firstName} ${ctx.trainer.lastName} · Espace formateur` : undefined}>
      {children}
    </ExtranetShell>
  );
}
