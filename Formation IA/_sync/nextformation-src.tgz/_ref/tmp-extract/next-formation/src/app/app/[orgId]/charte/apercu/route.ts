import { NextResponse } from "next/server";
import { requireOrg } from "@/server/authz";
import { brandFromOrg } from "@/server/documents/brand";
import { renderBrandedPdf } from "@/server/documents/pdf";
import { renderTemplate } from "@/server/documents/render";
import { PLATFORM_TEMPLATES, TEMPLATE_VARIABLES } from "@/server/documents/templates-data";
import { collectTemplateData } from "@/server/documents/generate";

/**
 * Document témoin : l'attestation de fin de formation rendue avec la charte et des données fictives explicitement marquées,
 * pour vérifier logo, couleurs, en-tête, pied de page et pagination. Rien n'est enregistré.
 */
export async function GET(_req: Request, { params }: { params: Promise<{ orgId: string }> }) {
  const { orgId } = await params;
  let ctx;
  try {
    ctx = await requireOrg(orgId, "org.view");
  } catch {
    return new NextResponse("Accès refusé.", { status: 403 });
  }
  const template = PLATFORM_TEMPLATES.find((t) => t.code === "attestation_fin_formation")!;
  const { data } = await collectTemplateData(orgId, {}, { resultSummary: "EXEMPLE : objectifs atteints (données fictives du document témoin)." });
  data.enrollment = {
    reference: "TEMOIN-0001",
    startDate: "1 septembre 2026",
    endDate: "30 septembre 2026",
    hoursPlanned: 35,
    hoursDone: "35",
    person: { fullName: "Prénom NOM (exemple)", civility: "Madame", birthDate: "1 janvier 1990" },
  };
  data.session = { title: "Session témoin", code: "TEMOIN" };
  data.programVersion = { title: "Formation témoin (document d'aperçu, données fictives)", objectives: "Vérifier le rendu de la charte institutionnelle : logo, couleurs, en-tête et pied de page.", modalityLabel: "Présentiel" };
  const { text } = renderTemplate(`${template.body}\n\n***\n\nDocument témoin généré pour vérifier la charte : les données de l'apprenant et de la formation sont fictives. Ce PDF n'est pas enregistré.`, data, { labels: TEMPLATE_VARIABLES });
  const pdf = await renderBrandedPdf(text, { title: "Document témoin", brand: await brandFromOrg(ctx.org), reference: "TEMOIN" });
  return new NextResponse(new Uint8Array(pdf), { headers: { "Content-Type": "application/pdf", "Content-Disposition": "inline; filename=document-temoin.pdf", "Cache-Control": "private, no-store" } });
}
