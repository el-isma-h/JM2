import Link from "next/link";
import { notFound } from "next/navigation";
import { and, asc, desc, eq, inArray } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg, handleAuthError } from "@/server/guard";
import { assertEnrollmentInScope, roleLabels, type OrgContext, type OrgRole } from "@/server/authz";
import { enrollmentSummary, type EnrollmentSummary } from "@/server/enrollments/service";
import { CLOSED_ENROLLMENT_STATUSES, commercialStatusLabels, contractKindLabels, enrollmentStatusLabels, examStateLabels, fundingStateLabels, nextEnrollmentStatuses, progressionLabels, providedByLabels, type EnrollmentStatus } from "@/server/enrollments/rules";
import { fmtDate, fmtDateTime } from "@/lib/dates";
import { fmtMinutes } from "@/lib/time";
import { formatCents } from "@/lib/money";
import { readParam } from "@/components/admin/pagination";
import { ActionButton, ActionForm } from "@/components/admin/action-form";
import { FormDialog } from "@/components/admin/form-dialog";
import { TabNav } from "@/components/sessions/tabs";
import { PieceReview, PieceUpload } from "@/components/enrollments/piece-actions";
import { WorkflowPanel } from "@/components/enrollments/workflow-panel";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox, Field, Input, Select, Textarea } from "@/components/ui/field";
import { EmptyState, KeyValue, PageHeader, Panel, PanelHeader, Stat } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FadeIn } from "@/components/ui/motion";
import { analysisSummaryForEnrollment } from "@/server/quality/analysis";
import { financeSummary } from "@/server/finance/service";
import { ribLinkLabel } from "@/server/documents/rib";
import { CATEGORY_LABELS, VISIBILITY_LABELS, filterVisible, listDocumentsFor } from "@/server/documents/queries";
import { ProposeButton } from "@/components/ai/propose-button";
import { Notice } from "@/components/ui/surface";
import { runAnalysisAction } from "@/server/actions/quality";
import { addNoteAction, closePedagogyAction, earlyExitAction, moveEnrollmentAction, reopenEnrollmentAction, resyncPiecesAction, savePlanAction, transitionEnrollmentAction, updateEnrollmentDetailsAction } from "@/server/actions/enrollments";

export const dynamic = "force-dynamic";

type Note = typeof schema.dossierNotes.$inferSelect & { author: string | null };

export default async function EnrollmentPage({ params, searchParams }: { params: Promise<{ orgId: string; enrollmentId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId, enrollmentId } = await params;
  const path = `/app/${orgId}/inscriptions/${enrollmentId}`;
  // Formateur seul : pas de enrollments.view, mais accès pédagogique au dossier des apprenants de ses sessions (0045).
  const ctx = await guardOrg(orgId, path, "org.view");
  if (!ctx.permissions.has("enrollments.view") && !(ctx.trainerOnly && ctx.permissions.has("dossier.pedagogy.view"))) notFound();
  if (!/^[0-9a-f-]{36}$/i.test(enrollmentId)) notFound();
  try {
    await assertEnrollmentInScope(ctx, enrollmentId);
  } catch (e) {
    handleAuthError(e, path);
  }
  const summary = await enrollmentSummary(orgId, enrollmentId);
  if (!summary) notFound();
  const e = summary.enrollment;
  const sp = await searchParams;

  const rights = {
    manage: ctx.permissions.has("enrollments.manage") && !ctx.trainerOnly,
    adminDocs: ctx.permissions.has("dossier.admin_docs.view") && !ctx.trainerOnly,
    adminDocsManage: ctx.permissions.has("dossier.admin_docs.manage") && !ctx.trainerOnly,
    internal: ctx.permissions.has("dossier.internal.view") && !ctx.trainerOnly,
    pedagogy: ctx.permissions.has("dossier.pedagogy.view"),
    pedagogyManage: ctx.permissions.has("dossier.pedagogy.manage"),
    finance: ctx.permissions.has("finance.view") && !ctx.trainerOnly,
    documents: ctx.permissions.has("documents.view"),
    exams: ctx.permissions.has("exams.view") && !ctx.trainerOnly,
    cv: ctx.permissions.has("candidates.cv.view") && !ctx.trainerOnly,
  };
  const tabs = [
    { key: "resume", label: "Résumé" },
    ...(rights.adminDocs ? [{ key: "pieces", label: "Pièces", count: summary.missingPieces.filter((p) => p.status !== "deposee").length }] : []),
    ...(rights.pedagogy ? [{ key: "parcours", label: "Parcours" }] : []),
    { key: "heures", label: "Heures" },
    ...(rights.finance ? [{ key: "financements", label: "Financements" }] : []),
    ...(rights.documents && !ctx.trainerOnly ? [{ key: "documents", label: "Documents" }] : []),
    ...(rights.exams ? [{ key: "examens", label: "Examens" }] : []),
    ...(!ctx.trainerOnly ? [{ key: "journal", label: "Journal" }] : []),
  ];
  const rawTab = readParam(sp.onglet) ?? "resume";
  const tab = tabs.some((t) => t.key === rawTab) ? rawTab : "resume";

  const [row] = await db
    .select({ p: schema.persons, s: schema.trainingSessions, v: schema.programVersions, prog: schema.programs, g: schema.groups, company: schema.companies, tutor: schema.contacts })
    .from(schema.enrollments)
    .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
    .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.enrollments.sessionId))
    .leftJoin(schema.programVersions, eq(schema.programVersions.id, schema.enrollments.programVersionId))
    .leftJoin(schema.programs, eq(schema.programs.id, schema.programVersions.programId))
    .leftJoin(schema.groups, eq(schema.groups.id, schema.enrollments.groupId))
    .leftJoin(schema.companies, eq(schema.companies.id, schema.enrollments.companyId))
    .leftJoin(schema.contacts, eq(schema.contacts.id, schema.enrollments.tutorContactId))
    .where(eq(schema.enrollments.id, e.id))
    .limit(1);
  if (!row) notFound();
  const { p, s, v, prog, g, company, tutor } = row;
  const notes: Note[] = (
    await db
      .select({ n: schema.dossierNotes, firstName: schema.users.firstName, lastName: schema.users.lastName })
      .from(schema.dossierNotes)
      .leftJoin(schema.users, eq(schema.users.id, schema.dossierNotes.authorId))
      .where(and(eq(schema.dossierNotes.orgId, orgId), eq(schema.dossierNotes.enrollmentId, e.id)))
      .orderBy(desc(schema.dossierNotes.pinned), desc(schema.dossierNotes.createdAt))
  ).map((r) => ({ ...r.n, author: r.firstName ? `${r.firstName} ${r.lastName}` : null }));
  const personLabel = `${p.lastName.toUpperCase()} ${p.firstName}`;
  const closed = CLOSED_ENROLLMENT_STATUSES.includes(e.status);

  return (
    <FadeIn>
      <PageHeader
        title={personLabel}
        breadcrumb={[{ label: "Inscriptions", href: `/app/${orgId}/inscriptions` }, { label: e.reference }]}
        description={
          <span className="space-y-2">
            <span className="block">
              <Link href={`/app/${orgId}/sessions/${s.id}`} className="hover:underline">
                {s.title}
              </Link>{" "}
              <span className="num text-ink-3">({s.code})</span>
              {g ? ` · ${g.name}` : ""} · {prog ? `${prog.title}, version v${v?.version ?? "?"} figée` : "version de programme non figée"} · du {fmtDate(e.startDate)} au {fmtDate(e.endDate)}
            </span>
            <span className="flex flex-wrap gap-x-4 gap-y-1.5">
              <StatusLine label="Commercial" status={e.commercialStatus} text={commercialStatusLabels[e.commercialStatus]} />
              <StatusLine label="Inscription" status={e.status} text={enrollmentStatusLabels[e.status]} />
              <StatusLine label="Progression" status={e.progression} text={progressionLabels[e.progression]} />
              <StatusLine label="Financement" status={e.fundingState} text={fundingStateLabels[e.fundingState]} />
              <StatusLine label="Examen" status={e.examState} text={examStateLabels[e.examState]} />
            </span>
          </span>
        }
        actions={
          !ctx.trainerOnly ? (
            <>
              <ProposeButton orgId={orgId} agent="dossier" entityType="enrollment" entityId={e.id} back={path} size="md" />
              <Button asChild variant="secondary">
                <Link href={`/app/${orgId}/apprenants/${p.id}`}>Fiche apprenant</Link>
              </Button>
            </>
          ) : null
        }
      />
      <TabNav basePath={path} tabs={tabs} current={tab} />

      {tab === "resume" ? (
        <div className="grid gap-6 lg:grid-cols-[2fr_1fr]">
          <div className="space-y-6">
            <NextActions summary={summary} ctx={ctx} />
            {!ctx.trainerOnly ? <WorkflowPanel orgId={orgId} enrollmentId={e.id} canManage={rights.manage} /> : null}
            <Panel>
              <PanelHeader
                title="Dossier"
                actions={
                  rights.manage ? (
                    <DetailsDialog orgId={orgId} e={e} companyId={company?.id ?? null} tutorId={tutor?.id ?? null} />
                  ) : null
                }
              />
              <div className="grid gap-6 p-6 md:grid-cols-2">
                <KeyValue
                  items={[
                    { k: "Référence", v: <span className="num">{e.reference}</span> },
                    { k: "Contrat", v: `${contractKindLabels[e.contractKind]}${e.contractNumber ? ` · ${e.contractNumber}` : ""}` },
                    { k: "Entreprise", v: company ? <Link href={`/app/${orgId}/entreprises/${company.id}`} className="hover:underline">{company.name}</Link> : "Aucune (particulier)" },
                    { k: "Tuteur", v: tutor ? `${tutor.firstName} ${tutor.lastName}${tutor.jobTitle ? ` · ${tutor.jobTitle}` : ""}${tutor.email ? ` · ${tutor.email}` : ""}` : "-" },
                    { k: "Prix HT", v: <span className="num">{formatCents(e.priceCents)}</span> },
                  ]}
                />
                <KeyValue
                  items={[
                    { k: "Contact", v: `${p.email ?? "sans e-mail"}${p.phone ? ` · ${p.phone}` : ""}` },
                    { k: "Adresse", v: [p.addressLine1, p.postalCode, p.city].filter(Boolean).join(" ") || "-" },
                    { k: "Naissance", v: p.birthDate ? fmtDate(p.birthDate) : "-" },
                    { k: "Aménagements", v: p.hasAccommodations ? (rights.internal || rights.pedagogy ? p.accommodations ?? "Oui (détail non renseigné)" : "Oui (détail réservé)") : "Aucun déclaré" },
                    { k: "Sortie", v: e.exitDate ? `${fmtDate(e.exitDate)} : ${e.exitReason ?? ""}` : "-" },
                  ]}
                />
              </div>
            </Panel>
            <Panel className="grid grid-cols-2 gap-6 p-6 md:grid-cols-5">
              <Stat label="Prévues" value={<span className="num">{summary.hours.plannedHours} h</span>} />
              <Stat label="Programmées" value={<span className="num">{fmtMinutes(summary.hours.scheduledMinutes)}</span>} />
              <Stat label="Effectuées" value={<span className="num">{fmtMinutes(summary.hours.doneMinutes)}</span>} />
              <Stat label="Justifiées" value={<span className="num">{fmtMinutes(summary.hours.justifiedMinutes)}</span>} />
              <Stat label="Validées" value={<span className="num">{fmtMinutes(summary.hours.validatedMinutes)}</span>} hint="périodes clôturées" />
            </Panel>
            <NotesPanel orgId={orgId} enrollmentId={e.id} section="commentaire" title="Commentaires et interventions" notes={notes.filter((n) => n.section === "commentaire")} canWrite={ctx.permissions.has("enrollments.view")} />
            {rights.internal ? <NotesPanel orgId={orgId} enrollmentId={e.id} section="interne" title="Informations internes" description="Visibles uniquement avec le droit « informations internes » (jamais par un formateur seul)." notes={notes.filter((n) => n.section === "interne")} canWrite /> : null}
          </div>
          <div className="space-y-6">
            {rights.finance ? <FinancePanel orgId={orgId} enrollmentId={e.id} ctx={ctx} /> : null}
            {ctx.permissions.has("quality.view") && !ctx.trainerOnly ? <QualityPanel orgId={orgId} enrollmentId={e.id} canManage={ctx.permissions.has("quality.manage")} /> : null}
            {rights.manage ? <StatusPanel orgId={orgId} e={e} closed={closed} /> : null}
            {rights.manage && !closed ? <MovePanel orgId={orgId} e={e} currentSession={s} /> : null}
            {rights.pedagogyManage && e.status === "en_cours" ? (
              <Panel>
                <PanelHeader title="Clôture pédagogique" description="Fixe la progression finale et termine l'inscription. Ne solde jamais le financement." />
                <div className="p-5">
                  <FormDialog action={closePedagogyAction} trigger="Clôturer pédagogiquement" triggerVariant="secondary" triggerSize="sm" title="Clôture pédagogique" description={`Le financement reste « ${fundingStateLabels[e.fundingState]} » : il est traité séparément.`} submitLabel="Clôturer">
                    <input type="hidden" name="orgId" value={orgId} />
                    <input type="hidden" name="enrollmentId" value={e.id} />
                    <Field label="Progression finale" htmlFor="cp-prog">
                      <Select id="cp-prog" name="progression" defaultValue="acquise">
                        <option value="acquise">Acquise</option>
                        <option value="partielle">Partielle</option>
                        <option value="non_acquise">Non acquise</option>
                      </Select>
                    </Field>
                    <Field label="Note" htmlFor="cp-note">
                      <Textarea id="cp-note" name="note" />
                    </Field>
                  </FormDialog>
                </div>
              </Panel>
            ) : null}
          </div>
        </div>
      ) : null}

      {tab === "pieces" && rights.adminDocs ? <PiecesTab orgId={orgId} e={e} canManage={rights.adminDocsManage} notes={notes.filter((n) => n.section === "administratif")} /> : null}
      {tab === "parcours" && rights.pedagogy ? <ParcoursTab orgId={orgId} e={e} canManage={rights.pedagogyManage} notes={notes.filter((n) => n.section === "pedagogique")} trainerOnly={ctx.trainerOnly} /> : null}
      {tab === "heures" ? <HoursTab orgId={orgId} summary={summary} /> : null}
      {tab === "financements" && rights.finance ? <FundingsTab orgId={orgId} e={e} /> : null}
      {tab === "documents" && rights.documents ? <DocumentsTab orgId={orgId} e={e} ctx={ctx} canGenerate={ctx.permissions.has("documents.generate") && !ctx.trainerOnly} /> : null}
      {tab === "examens" && rights.exams ? <ExamsTab orgId={orgId} e={e} /> : null}
      {tab === "journal" ? <JournalTab e={e} /> : null}
    </FadeIn>
  );
}

function StatusLine({ label, status, text }: { label: string; status: string; text: string }) {
  return (
    <span className="inline-flex items-center gap-1.5 text-[12.5px]">
      <span className="font-mono text-[10px] uppercase tracking-[0.16em] text-ink-3">{label}</span>
      <StatusBadge status={status} />
      <span className="sr-only">{text}</span>
    </span>
  );
}

function ownerLabel(owner: string | null | undefined): string {
  if (!owner) return "";
  if (owner in roleLabels) return roleLabels[owner as OrgRole];
  return providedByLabels[owner] ?? owner;
}

function NextActions({ summary, ctx }: { summary: EnrollmentSummary; ctx: OrgContext }) {
  const actions = ctx.trainerOnly ? summary.nextActions.filter((a) => a.kind === "exam" || a.kind === "status") : summary.nextActions;
  return (
    <Panel>
      <PanelHeader title="Prochaine action" description={actions.length ? "Ce qui bloque ou reste à faire, avec responsable et échéance." : "Rien ne bloque : le dossier est à jour."} />
      {actions.length ? (
        <ul className="divide-y divide-line">
          {actions.map((a, i) => (
            <li key={i} className="flex flex-wrap items-center justify-between gap-2 px-5 py-3 text-[13.5px]">
              <span className="flex items-center gap-2">
                <Badge tone={a.kind === "piece" ? "warn" : a.kind === "funding" ? "info" : a.kind === "exam" ? "accent" : "neutral"}>{{ piece: "Pièce", funding: "Financement", exam: "Examen", task: "Tâche", status: "Statut" }[a.kind]}</Badge>
                {a.href ? (
                  <Link href={a.href} className="hover:underline">
                    {a.label}
                  </Link>
                ) : (
                  a.label
                )}
              </span>
              <span className="flex items-center gap-3 text-[12.5px] text-ink-3">
                {a.owner ? <span>{ownerLabel(a.owner)}</span> : null}
                {a.dueDate ? <span className="num">échéance {fmtDate(a.dueDate)}</span> : null}
              </span>
            </li>
          ))}
        </ul>
      ) : null}
    </Panel>
  );
}

function StatusPanel({ orgId, e, closed }: { orgId: string; e: typeof schema.enrollments.$inferSelect; closed: boolean }) {
  const next = nextEnrollmentStatuses(e.status);
  return (
    <Panel>
      <PanelHeader title="Statut d'inscription" description="Transitions contrôlées et journalisées. Le financement n'est jamais modifié ici." />
      <div className="space-y-2.5 p-5">
        {next.map((to) => {
          const exit = ["abandon", "annule", "reporte"].includes(to);
          return (
            <ActionButton
              key={to}
              action={transitionEnrollmentAction}
              fields={{ orgId, enrollmentId: e.id, to }}
              label={`Passer à « ${enrollmentStatusLabels[to as EnrollmentStatus]} »`}
              variant={exit ? "danger" : "secondary"}
              confirm={{ title: `Passer l'inscription à « ${enrollmentStatusLabels[to as EnrollmentStatus]} »`, description: exit ? "Le motif est obligatoire et conservé dans le journal." : "Le changement est journalisé.", input: { name: "reason", label: "Motif", help: exit ? "Obligatoire" : "Facultatif" }, danger: exit, confirmLabel: "Confirmer" }}
            />
          );
        })}
        {e.status === "en_cours" || e.status === "inscrit" ? (
          <FormDialog action={earlyExitAction} trigger="Sortie anticipée" triggerVariant="danger" triggerSize="sm" title="Sortie anticipée" description="Date et motif obligatoires ; la fin du parcours est alignée sur la date de sortie." submitLabel="Enregistrer la sortie">
            <input type="hidden" name="orgId" value={orgId} />
            <input type="hidden" name="enrollmentId" value={e.id} />
            <Field label="Date de sortie" required htmlFor="ex-date">
              <Input id="ex-date" name="exitDate" type="date" required className="num" />
            </Field>
            <Field label="Issue" htmlFor="ex-to">
              <Select id="ex-to" name="to" defaultValue="abandon">
                <option value="abandon">Abandon / rupture</option>
                {e.status === "en_cours" ? <option value="termine">Terminé avant la date prévue</option> : null}
              </Select>
            </Field>
            <Field label="Motif" required htmlFor="ex-reason">
              <Textarea id="ex-reason" name="reason" required />
            </Field>
          </FormDialog>
        ) : null}
        {closed ? (
          <ActionButton action={reopenEnrollmentAction} fields={{ orgId, enrollmentId: e.id }} label="Rouvrir le dossier" variant="secondary" confirm={{ title: "Réouverture tracée", description: "Le dossier redevient actif ; le motif et l'auteur sont conservés dans le journal.", input: { name: "reason", label: "Motif de réouverture", help: "Obligatoire" }, confirmLabel: "Rouvrir" }} />
        ) : null}
        {!next.length && !closed ? <p className="text-[13px] text-ink-3">Aucune transition disponible.</p> : null}
      </div>
    </Panel>
  );
}

async function MovePanel({ orgId, e, currentSession }: { orgId: string; e: typeof schema.enrollments.$inferSelect; currentSession: typeof schema.trainingSessions.$inferSelect }) {
  const sessions = await db
    .select({ id: schema.trainingSessions.id, code: schema.trainingSessions.code, title: schema.trainingSessions.title, startDate: schema.trainingSessions.startDate })
    .from(schema.trainingSessions)
    .where(and(eq(schema.trainingSessions.orgId, orgId), inArray(schema.trainingSessions.status, ["brouillon", "ouverte", "confirmee", "en_cours"])))
    .orderBy(desc(schema.trainingSessions.startDate))
    .limit(200);
  const groups = await db
    .select({ id: schema.groups.id, name: schema.groups.name, sessionId: schema.groups.sessionId, code: schema.trainingSessions.code })
    .from(schema.groups)
    .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.groups.sessionId))
    .where(and(eq(schema.groups.orgId, orgId), inArray(schema.groups.sessionId, sessions.map((x) => x.id).concat(currentSession.id))))
    .orderBy(asc(schema.trainingSessions.code), asc(schema.groups.name));
  return (
    <Panel>
      <PanelHeader title="Groupe et session" description="Changement contrôlé (même organisme, capacité) et journalisé. Les heures et les pièces restent rattachées à cette inscription." />
      <div className="p-5">
        <FormDialog action={moveEnrollmentAction} trigger="Changer de groupe ou de session" triggerVariant="secondary" triggerSize="sm" title="Changer de groupe ou de session" submitLabel="Appliquer le changement">
          <input type="hidden" name="orgId" value={orgId} />
          <input type="hidden" name="enrollmentId" value={e.id} />
          <Field label="Session" htmlFor="mv-session" help={`Actuelle : ${currentSession.code}`}>
            <Select id="mv-session" name="sessionId" defaultValue={currentSession.id}>
              {[currentSession, ...sessions.filter((x) => x.id !== currentSession.id)].map((x) => (
                <option key={x.id} value={x.id}>
                  {x.code} · {x.title} ({fmtDate(x.startDate)})
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Groupe" htmlFor="mv-group" help="Le groupe doit appartenir à la session choisie (vérifié côté serveur).">
            <Select id="mv-group" name="groupId" defaultValue={e.groupId ?? ""}>
              <option value="">Sans groupe</option>
              {groups.map((x) => (
                <option key={x.id} value={x.id}>
                  {x.code} · {x.name}
                </option>
              ))}
            </Select>
          </Field>
          <Checkbox name="allowOtherProgram" label="Autoriser un transfert vers une autre formation (la version figée du dossier est conservée)" />
          <Field label="Motif" required htmlFor="mv-reason">
            <Textarea id="mv-reason" name="reason" required />
          </Field>
        </FormDialog>
      </div>
    </Panel>
  );
}

async function DetailsDialog({ orgId, e, companyId, tutorId }: { orgId: string; e: typeof schema.enrollments.$inferSelect; companyId: string | null; tutorId: string | null }) {
  const companies = await db.select({ id: schema.companies.id, name: schema.companies.name }).from(schema.companies).where(eq(schema.companies.orgId, orgId)).orderBy(asc(schema.companies.name)).limit(500);
  const contacts = companyId ? await db.select({ id: schema.contacts.id, firstName: schema.contacts.firstName, lastName: schema.contacts.lastName }).from(schema.contacts).where(and(eq(schema.contacts.orgId, orgId), eq(schema.contacts.companyId, companyId))).orderBy(asc(schema.contacts.lastName)) : [];
  return (
    <FormDialog action={updateEnrollmentDetailsAction} trigger="Modifier" triggerVariant="secondary" triggerSize="sm" title="Modifier le dossier" description="Un changement de type de contrat ajoute les pièces attendues correspondantes." submitLabel="Enregistrer" wide>
      <input type="hidden" name="orgId" value={orgId} />
      <input type="hidden" name="enrollmentId" value={e.id} />
      <div className="grid gap-4 md:grid-cols-2">
        <Field label="Statut commercial" htmlFor="d-com">
          <Select id="d-com" name="commercialStatus" defaultValue={e.commercialStatus}>
            {schema.commercialStatusEnum.enumValues.map((k) => (
              <option key={k} value={k}>
                {commercialStatusLabels[k]}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Type de contrat" htmlFor="d-ck">
          <Select id="d-ck" name="contractKind" defaultValue={e.contractKind}>
            {schema.contractKindEnum.enumValues.map((k) => (
              <option key={k} value={k}>
                {contractKindLabels[k]}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Numéro de contrat" htmlFor="d-cn">
          <Input id="d-cn" name="contractNumber" defaultValue={e.contractNumber ?? ""} className="num" />
        </Field>
        <Field label="Heures prévues" htmlFor="d-h">
          <Input id="d-h" name="hoursPlanned" type="number" min={0} defaultValue={e.hoursPlanned} className="num" />
        </Field>
        <Field label="Début du parcours" htmlFor="d-sd">
          <Input id="d-sd" name="startDate" type="date" defaultValue={e.startDate ?? ""} className="num" />
        </Field>
        <Field label="Fin du parcours" htmlFor="d-ed">
          <Input id="d-ed" name="endDate" type="date" defaultValue={e.endDate ?? ""} className="num" />
        </Field>
        <Field label="Entreprise" htmlFor="d-co">
          <Select id="d-co" name="companyId" defaultValue={companyId ?? ""}>
            <option value="">Aucune</option>
            {companies.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Tuteur" htmlFor="d-tu" help="Contacts de l'entreprise actuelle ; enregistrez d'abord un changement d'entreprise pour voir ses contacts.">
          <Select id="d-tu" name="tutorContactId" defaultValue={tutorId ?? ""}>
            <option value="">Aucun</option>
            {contacts.map((c) => (
              <option key={c.id} value={c.id}>
                {c.firstName} {c.lastName}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Solde historique (heures)" htmlFor="d-lh" help="Anciennes feuilles non réconciliées : affiché à part, jamais additionné aux heures justifiées.">
          <Input id="d-lh" name="legacyHours" type="number" min={0} defaultValue={e.legacyHours} className="num" />
        </Field>
        <Field label="Note sur le solde historique" htmlFor="d-lhn">
          <Input id="d-lhn" name="legacyHoursNote" defaultValue={e.legacyHoursNote ?? ""} />
        </Field>
      </div>
    </FormDialog>
  );
}

function NotesPanel({ orgId, enrollmentId, section, title, description, notes, canWrite }: { orgId: string; enrollmentId: string; section: "commentaire" | "interne" | "pedagogique" | "administratif"; title: string; description?: string; notes: Note[]; canWrite: boolean }) {
  return (
    <Panel>
      <PanelHeader title={title} description={description} />
      {notes.length ? (
        <ul className="divide-y divide-line">
          {notes.map((n) => (
            <li key={n.id} className="px-5 py-3 text-[13.5px]">
              <p className="flex flex-wrap items-center gap-2 text-[12px] text-ink-3">
                <span className="num">{fmtDateTime(n.createdAt)}</span>
                <span>{n.author ?? "Système"}</span>
                {n.pinned ? <Badge tone="accent">Épinglée</Badge> : null}
              </p>
              <p className="mt-1 whitespace-pre-wrap text-ink">{n.body}</p>
            </li>
          ))}
        </ul>
      ) : (
        <p className="px-5 py-4 text-[13px] text-ink-3">Aucune note.</p>
      )}
      {canWrite ? (
        <div className="border-t border-line p-5">
          <ActionForm action={addNoteAction} submitLabel="Ajouter la note" submitVariant="secondary" submitSize="sm" footerClassName="mt-3">
            <input type="hidden" name="orgId" value={orgId} />
            <input type="hidden" name="enrollmentId" value={enrollmentId} />
            <input type="hidden" name="section" value={section} />
            <Field label="Nouvelle note" htmlFor={`note-${section}`}>
              <Textarea id={`note-${section}`} name="body" required className="min-h-20" />
            </Field>
            <Checkbox name="pinned" label="Épingler en tête" className="mt-2" />
          </ActionForm>
        </div>
      ) : null}
    </Panel>
  );
}

async function PiecesTab({ orgId, e, canManage, notes }: { orgId: string; e: typeof schema.enrollments.$inferSelect; canManage: boolean; notes: Note[] }) {
  const pieces = await db
    .select({ s: schema.pieceSubmissions, p: schema.requiredPieces, doc: schema.documents, reviewer: schema.users })
    .from(schema.pieceSubmissions)
    .innerJoin(schema.requiredPieces, eq(schema.requiredPieces.id, schema.pieceSubmissions.requiredPieceId))
    .leftJoin(schema.documents, eq(schema.documents.id, schema.pieceSubmissions.documentId))
    .leftJoin(schema.users, eq(schema.users.id, schema.pieceSubmissions.reviewedBy))
    .where(and(eq(schema.pieceSubmissions.orgId, orgId), eq(schema.pieceSubmissions.enrollmentId, e.id)))
    .orderBy(asc(schema.requiredPieces.position));
  return (
    <div className="space-y-6">
      <Panel>
        <PanelHeader
          title="Pièces administratives"
          description="Dépôt, contrôle, acceptation ou refus motivé, versions et échéances. Une pièce acceptée résout la tâche de relais."
          actions={canManage ? <ActionButton action={resyncPiecesAction} fields={{ orgId, enrollmentId: e.id }} label="Recalculer les pièces attendues" variant="ghost" /> : null}
        />
        {pieces.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Pièce</Th>
                <Th>Fournie par</Th>
                <Th>Échéance</Th>
                <Th>Statut</Th>
                <Th num>Version</Th>
                <Th>Document</Th>
                {canManage ? <Th></Th> : null}
              </tr>
            </thead>
            <tbody>
              {pieces.map(({ s, p, doc, reviewer }) => (
                <tr key={s.id}>
                  <Td>
                    <span className="font-medium">{p.label}</span> {p.isRequired ? <Badge tone="warn">Obligatoire</Badge> : <Badge>Facultative</Badge>}
                    {s.refusalReason ? <p className="mt-1 text-[12.5px] text-danger-ink">Refus : {s.refusalReason}</p> : null}
                    {s.naReason ? <p className="mt-1 text-[12.5px] text-ink-3">Non applicable : {s.naReason}</p> : null}
                    {reviewer && s.reviewedAt ? (
                      <p className="text-[12px] text-ink-3">
                        Contrôlée par {reviewer.firstName} {reviewer.lastName} le {fmtDateTime(s.reviewedAt)}
                      </p>
                    ) : null}
                  </Td>
                  <Td>{providedByLabels[p.providedBy] ?? p.providedBy}</Td>
                  <Td className="num whitespace-nowrap">{s.dueDate ? fmtDate(s.dueDate) : "-"}</Td>
                  <Td>
                    <StatusBadge status={s.status} />
                  </Td>
                  <Td num>{s.documentId ? s.version : "-"}</Td>
                  <Td>
                    {doc ? (
                      <Link href={`/app/${orgId}/documents/${doc.id}`} className="hover:underline">
                        {doc.fileName}
                      </Link>
                    ) : (
                      "-"
                    )}
                  </Td>
                  {canManage ? (
                    <Td>
                      <div className="flex flex-wrap items-center justify-end gap-1.5">
                        {s.status !== "non_applicable" ? <PieceUpload orgId={orgId} submissionId={s.id} label={p.label} hasVersion={Boolean(s.documentId)} /> : null}
                        <PieceReview orgId={orgId} submissionId={s.id} status={s.status} label={p.label} canRemind={p.providedBy !== "financeur"} />
                      </div>
                    </Td>
                  ) : null}
                </tr>
              ))}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucune pièce attendue" description="Le paramétrage des pièces attendues ne retient aucune pièce pour ce contrat et ce financement." action={canManage ? <ActionButton action={resyncPiecesAction} fields={{ orgId, enrollmentId: e.id }} label="Recalculer" variant="secondary" /> : undefined} />
        )}
      </Panel>
      <NotesPanel orgId={orgId} enrollmentId={e.id} section="administratif" title="Notes administratives" notes={notes} canWrite={canManage} />
    </div>
  );
}

const PLAN_FIELDS: { key: string; label: string; help?: string }[] = [
  { key: "objectifs", label: "Objectifs individualisés" },
  { key: "prerequis_verifies", label: "Prérequis vérifiés" },
  { key: "niveau_entree", label: "Niveau d'entrée" },
  { key: "besoins_specifiques", label: "Besoins spécifiques et aménagements" },
  { key: "modalites_adaptees", label: "Modalités adaptées" },
  { key: "observations", label: "Observations" },
];
const POS_FIELDS: { key: string; label: string; help?: string }[] = [
  { key: "date", label: "Date du positionnement", help: "JJ/MM/AAAA" },
  { key: "methode", label: "Méthode (entretien, test, dossier)" },
  { key: "resultat", label: "Résultat" },
  { key: "niveau", label: "Niveau constaté" },
  { key: "preconisations", label: "Préconisations" },
];

function ParcoursTab({ orgId, e, canManage, notes, trainerOnly }: { orgId: string; e: typeof schema.enrollments.$inferSelect; canManage: boolean; notes: Note[]; trainerOnly: boolean }) {
  const plan = (e.individualPlan ?? {}) as Record<string, string>;
  const pos = (e.positioning ?? {}) as Record<string, string>;
  return (
    <div className="space-y-6">
      <Panel>
        <PanelHeader title="Positionnement et plan individuel" description="Suivi pédagogique (F07) : champs libres, conservés avec le dossier." />
        <div className="p-6">
          <ActionForm action={savePlanAction} submitLabel="Enregistrer le parcours" submitVariant="secondary" footerClassName="mt-5">
            <input type="hidden" name="orgId" value={orgId} />
            <input type="hidden" name="enrollmentId" value={e.id} />
            <div className="grid gap-5 md:grid-cols-2">
              <div className="space-y-4">
                <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">Positionnement</p>
                {POS_FIELDS.map((f) => (
                  <Field key={f.key} label={f.label} htmlFor={`pos-${f.key}`} help={f.help}>
                    {f.key === "date" ? <Input id={`pos-${f.key}`} name={`pos_${f.key}`} defaultValue={pos[f.key] ?? ""} readOnly={!canManage} className="num" /> : <Textarea id={`pos-${f.key}`} name={`pos_${f.key}`} defaultValue={pos[f.key] ?? ""} readOnly={!canManage} className="min-h-16" />}
                  </Field>
                ))}
              </div>
              <div className="space-y-4">
                <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">Plan individuel de formation</p>
                {PLAN_FIELDS.map((f) => (
                  <Field key={f.key} label={f.label} htmlFor={`plan-${f.key}`}>
                    <Textarea id={`plan-${f.key}`} name={`plan_${f.key}`} defaultValue={plan[f.key] ?? ""} readOnly={!canManage} className="min-h-16" />
                  </Field>
                ))}
                <Field label="Progression pédagogique" htmlFor="plan-prog" help="Statut distinct de l'inscription, du financement et de l'examen.">
                  <Select id="plan-prog" name="progression" defaultValue={e.progression} disabled={!canManage}>
                    {schema.progressionEnum.enumValues.map((k) => (
                      <option key={k} value={k}>
                        {progressionLabels[k]}
                      </option>
                    ))}
                  </Select>
                </Field>
              </div>
            </div>
            {!canManage ? <p className="mt-3 text-[12.5px] text-ink-3">Lecture seule : la modification demande le droit « gérer le suivi pédagogique ».</p> : null}
          </ActionForm>
        </div>
      </Panel>
      <div className="flex flex-wrap gap-2">
        <Button asChild variant="secondary" size="sm">
          <Link href={`/app/${orgId}/evaluations?enrollment=${e.id}`}>Évaluations et livret</Link>
        </Button>
        {!trainerOnly ? (
          <Button asChild variant="secondary" size="sm">
            <Link href={`/app/${orgId}/suivi-entreprise?enrollment=${e.id}`}>Suivi en entreprise</Link>
          </Button>
        ) : null}
      </div>
      <NotesPanel orgId={orgId} enrollmentId={e.id} section="pedagogique" title="Notes pédagogiques" notes={notes} canWrite={canManage} />
    </div>
  );
}

async function HoursTab({ orgId, summary }: { orgId: string; summary: EnrollmentSummary }) {
  const h = summary.hours;
  const e = summary.enrollment;
  const sheets = await db.select().from(schema.legacyAttendanceSheets).where(and(eq(schema.legacyAttendanceSheets.orgId, orgId), eq(schema.legacyAttendanceSheets.enrollmentId, e.id))).orderBy(desc(schema.legacyAttendanceSheets.date)).limit(100);
  return (
    <div className="space-y-6">
      <Panel>
        <PanelHeader title="Heures du parcours" description="Cinq compteurs distincts (F05/F06), jamais additionnés entre eux. Les présences se saisissent par période depuis l'émargement." actions={<Button asChild variant="secondary" size="sm"><Link href={`/app/${orgId}/emargement?enrollment=${e.id}`}>Émargement</Link></Button>} />
        <div className="grid grid-cols-2 gap-6 p-6 md:grid-cols-5">
          <Stat label="Prévues" value={<span className="num">{h.plannedHours} h</span>} hint="plan du parcours" />
          <Stat label="Programmées" value={<span className="num">{fmtMinutes(h.scheduledMinutes)}</span>} hint="séances planifiées" />
          <Stat label="Effectuées" value={<span className="num">{fmtMinutes(h.doneMinutes)}</span>} hint="présences comptées" />
          <Stat label="Justifiées" value={<span className="num">{fmtMinutes(h.justifiedMinutes)}</span>} hint="absences justifiées" />
          <Stat label="Validées" value={<span className="num">{fmtMinutes(h.validatedMinutes)}</span>} hint="périodes clôturées" />
        </div>
      </Panel>
      <Panel>
        <PanelHeader title="Solde historique (anciennes feuilles)" description="Reprise : conservé à part, jamais converti en signatures par demi-journée ni ajouté aux heures justifiées." />
        <div className="grid gap-6 p-6 md:grid-cols-2">
          <Stat label="Solde déclaré" value={<span className="num">{h.legacyHours} h</span>} hint={h.legacyHoursNote ?? "saisi sur le dossier"} />
          <Stat label="Feuilles importées" value={<span className="num">{fmtMinutes(h.legacySheetsMinutes)}</span>} hint={`${sheets.length} feuille(s)`} />
        </div>
        {sheets.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Date</Th>
                <Th num>Durée</Th>
                <Th>Signée</Th>
                <Th>Source</Th>
                <Th>Note</Th>
              </tr>
            </thead>
            <tbody>
              {sheets.map((sh) => (
                <tr key={sh.id}>
                  <Td className="num">{fmtDate(sh.date)}</Td>
                  <Td num>{fmtMinutes(sh.hours)}</Td>
                  <Td>{sh.signed ? "Oui" : "Non"}</Td>
                  <Td>{sh.source ?? "-"}</Td>
                  <Td>{sh.note ?? "-"}</Td>
                </tr>
              ))}
            </tbody>
          </Table>
        ) : null}
      </Panel>
    </div>
  );
}

async function FundingsTab({ orgId, e }: { orgId: string; e: typeof schema.enrollments.$inferSelect }) {
  const fundings = await db.select({ f: schema.fundings, funder: schema.funders }).from(schema.fundings).leftJoin(schema.funders, eq(schema.funders.id, schema.fundings.funderId)).where(and(eq(schema.fundings.orgId, orgId), eq(schema.fundings.enrollmentId, e.id))).orderBy(asc(schema.fundings.createdAt));
  return (
    <Panel>
      <PanelHeader title="Financements" description={`État global : ${fundingStateLabels[e.fundingState]}. La clôture pédagogique ne solde jamais le financier.`} actions={<Button asChild size="sm"><Link href={`/app/${orgId}/financements?enrollment=${e.id}`}>Gérer dans Financements</Link></Button>} />
      {fundings.length ? (
        <Table>
          <thead>
            <tr>
              <Th>Financement</Th>
              <Th>Financeur</Th>
              <Th>Type</Th>
              <Th num>Montant</Th>
              <Th>Accord</Th>
              <Th>Statut</Th>
            </tr>
          </thead>
          <tbody>
            {fundings.map(({ f, funder }) => (
              <tr key={f.id}>
                <Td className="font-medium">{f.label}</Td>
                <Td>{funder?.name ?? "-"}</Td>
                <Td>{f.kind}</Td>
                <Td num>{formatCents(f.amountCents)}</Td>
                <Td className="num">{f.agreementRef ? `${f.agreementRef}${f.agreementDate ? ` (${fmtDate(f.agreementDate)})` : ""}` : "-"}</Td>
                <Td>
                  <StatusBadge status={f.status} />
                </Td>
              </tr>
            ))}
          </tbody>
        </Table>
      ) : (
        <EmptyState title="Aucun financement" description="Le financement est à définir : prise en charge OPCO, CPF, entreprise, particulier…" />
      )}
    </Panel>
  );
}

async function DocumentsTab({ orgId, e, ctx, canGenerate }: { orgId: string; e: typeof schema.enrollments.$inferSelect; ctx: OrgContext; canGenerate: boolean }) {
  // Liste via le service documents (isolation orgId) puis filtrage par les droits du contexte (pièces admin, CV, périmètre formateur).
  const docs = await filterVisible(ctx, await listDocumentsFor({ orgId, enrollmentId: e.id, limit: 200 }));
  return (
    <Panel>
      <PanelHeader
        title="Documents du dossier"
        description="Brouillon, généré, transmis, signé, validé. Une régénération crée une version."
        actions={
          <span className="flex flex-wrap gap-2">
            {canGenerate ? (
              <Button asChild size="sm">
                <Link href={`/app/${orgId}/documents/nouveau?enrollmentId=${e.id}`}>Générer un document</Link>
              </Button>
            ) : null}
            <Button asChild variant="secondary" size="sm">
              <Link href={`/app/${orgId}/documents?enrollment=${e.id}`}>Tous les documents</Link>
            </Button>
          </span>
        }
      />
      {docs.length ? (
        <Table>
          <thead>
            <tr>
              <Th>Document</Th>
              <Th>Catégorie</Th>
              <Th>Visibilité</Th>
              <Th>Statut</Th>
              <Th num>Version</Th>
              <Th>Date</Th>
            </tr>
          </thead>
          <tbody>
            {docs.map((d) => (
              <tr key={d.id}>
                <Td>
                  <Link href={`/app/${orgId}/documents/${d.id}`} className="font-medium hover:underline">
                    {d.title}
                  </Link>
                </Td>
                <Td>{CATEGORY_LABELS[d.category] ?? d.category}</Td>
                <Td>{VISIBILITY_LABELS[d.visibility] ?? d.visibility}</Td>
                <Td>
                  <StatusBadge status={d.status} />
                </Td>
                <Td num>{d.version}</Td>
                <Td className="whitespace-nowrap">{fmtDate(d.createdAt)}</Td>
              </tr>
            ))}
          </tbody>
        </Table>
      ) : (
        <EmptyState
          title="Aucun document"
          description="Les pièces déposées et les documents générés (convention, convocation, attestation) apparaîtront ici."
          action={canGenerate ? <Button asChild size="sm"><Link href={`/app/${orgId}/documents/nouveau?enrollmentId=${e.id}`}>Générer un document</Link></Button> : undefined}
        />
      )}
    </Panel>
  );
}

/** Résumé financier (F11) : prévu, accordé, facturé, encaissé, solde, prochaine échéance ; lien RIB central selon droits (F12). */
async function FinancePanel({ orgId, enrollmentId, ctx }: { orgId: string; enrollmentId: string; ctx: OrgContext }) {
  const f = await financeSummary(orgId, enrollmentId);
  const rib = ribLinkLabel(ctx);
  return (
    <Panel>
      <PanelHeader title="Finance" description={`Financement : ${fundingStateLabels[f.fundingState as keyof typeof fundingStateLabels] ?? f.fundingState}. Distinct de la clôture pédagogique.`} actions={<Button asChild variant="secondary" size="sm"><Link href={`/app/${orgId}/financements?enrollment=${enrollmentId}`}>Financements</Link></Button>} />
      <div className="grid grid-cols-2 gap-4 p-5">
        <Stat label="Prévu" value={<span className="num">{formatCents(f.plannedCents)}</span>} />
        <Stat label="Accordé" value={<span className="num">{formatCents(f.grantedCents)}</span>} />
        <Stat label="Facturé TTC" value={<span className="num">{formatCents(f.billedCents)}</span>} />
        <Stat label="Encaissé" value={<span className="num">{formatCents(f.paidCents)}</span>} />
        <Stat label="Solde dû" value={<span className="num">{formatCents(f.balanceCents)}</span>} hint="facturé moins encaissé" />
        <Stat label="Prochaine échéance" value={f.nextDue ? <span className="num">{fmtDate(f.nextDue.dueDate)}</span> : "Aucune"} hint={f.nextDue ? `${f.nextDue.label} : ${formatCents(f.nextDue.amountCents)}` : undefined} />
      </div>
      {f.invoices.length ? (
        <ul className="divide-y divide-line border-t border-line text-[13px]">
          {f.invoices.slice(0, 5).map((i) => (
            <li key={i.id} className="flex items-center justify-between gap-2 px-5 py-2">
              <Link href={`/app/${orgId}/factures/${i.id}`} className="num hover:underline">
                {i.number ?? "Brouillon"}
              </Link>
              <StatusBadge status={i.status} />
              <span className="num">{formatCents(i.totalTtcCents)}</span>
            </li>
          ))}
        </ul>
      ) : null}
      {rib ? (
        <p className="border-t border-line px-5 py-3 text-[13px]">
          <Link href={rib.href} className="hover:underline">
            {rib.label}
          </Link>
        </p>
      ) : null}
    </Panel>
  );
}

/** Synthèse qualité (F13) : lit la même photographie que l'analyse complète ; « Aucune analyse » sans photographie. */
async function QualityPanel({ orgId, enrollmentId, canManage }: { orgId: string; enrollmentId: string; canManage: boolean }) {
  const a = await analysisSummaryForEnrollment(orgId, enrollmentId);
  const run = canManage ? <ActionButton action={runAnalysisAction} fields={{ orgId, scope: "inscription", scopeId: enrollmentId }} label={a ? "Relancer l'analyse" : "Lancer une analyse"} variant="secondary" size="sm" /> : null;
  return (
    <Panel>
      <PanelHeader title="Qualité" description="Un pourcentage n'est pas une attestation : la photographie reste explicable preuve par preuve." actions={run} />
      {!a ? (
        <p className="px-5 py-4 text-[13.5px] text-ink-3">Aucune analyse pour ce dossier.</p>
      ) : (
        <div className="space-y-3 p-5">
          {a.stale ? <Notice tone="warn">Preuves modifiées depuis l&apos;analyse : relancez l&apos;analyse pour une photographie à jour.</Notice> : null}
          <div className="grid grid-cols-2 gap-4">
            <Stat label="Prouvés" value={<span className="num">{a.summary.proven} / {a.summary.total - a.summary.notApplicable}</span>} hint={`${a.summary.coveragePct} % couverts`} />
            <Stat label="À examiner" value={<span className="num">{a.summary.humanReview}</span>} hint="revue humaine" />
          </div>
          {a.humanReview.length ? (
            <ul className="space-y-1 text-[13px]">
              {a.humanReview.slice(0, 4).map((c) => (
                <li key={c.indicator} className="flex items-center gap-2">
                  <StatusBadge status="a_examiner" />
                  <span>
                    <span className="num">{c.indicator}</span> {c.label}
                  </span>
                </li>
              ))}
            </ul>
          ) : null}
          {a.missing.length ? <p className="text-[13px] text-ink-3">{a.missing.length} indicateur(s) sans preuve.</p> : null}
          <p className="text-[12.5px] text-ink-3">
            Analyse du <span className="num">{fmtDateTime(a.analysedAt)}</span>, référence <span className="num">{fmtDate(a.referenceDate)}</span>, moteur <span className="num">{a.engineVersion}</span>.{" "}
            <Link href={`/app/${orgId}/qualite/analyses/${a.analysisId}`} className="hover:underline">
              Voir l&apos;analyse
            </Link>
          </p>
        </div>
      )}
    </Panel>
  );
}

async function ExamsTab({ orgId, e }: { orgId: string; e: typeof schema.enrollments.$inferSelect }) {
  const members = await db.select({ m: schema.examMembers, c: schema.examCohorts }).from(schema.examMembers).innerJoin(schema.examCohorts, eq(schema.examCohorts.id, schema.examMembers.cohortId)).where(and(eq(schema.examMembers.orgId, orgId), eq(schema.examMembers.enrollmentId, e.id))).orderBy(desc(schema.examCohorts.date));
  return (
    <Panel>
      <PanelHeader title="Examens" description={`État : ${examStateLabels[e.examState]}. L'affectation à une cohorte se fait depuis le module examens.`} actions={<Button asChild variant="secondary" size="sm"><Link href={`/app/${orgId}/examens`}>Cohortes d&apos;examen</Link></Button>} />
      {members.length ? (
        <Table>
          <thead>
            <tr>
              <Th>Cohorte</Th>
              <Th>Date</Th>
              <Th>Statut</Th>
              <Th>Résultat</Th>
              <Th num>Note</Th>
            </tr>
          </thead>
          <tbody>
            {members.map(({ m, c }) => (
              <tr key={m.id}>
                <Td>
                  <Link href={`/app/${orgId}/examens/${c.id}`} className="font-medium hover:underline">
                    {c.label}
                  </Link>
                  <p className="num text-[12px] text-ink-3">{c.code}</p>
                </Td>
                <Td className="num">{fmtDate(c.date)}</Td>
                <Td>
                  <StatusBadge status={m.status} />
                </Td>
                <Td>{m.result ? <StatusBadge status={m.result} /> : "-"}</Td>
                <Td num>{m.score ?? "-"}</Td>
              </tr>
            ))}
          </tbody>
        </Table>
      ) : (
        <EmptyState title="Aucune cohorte" description={e.examState === "a_inscrire" ? "Cette inscription prépare une certification : inscrivez-la à une cohorte d&apos;examen." : "Aucune inscription à un examen pour ce dossier."} />
      )}
    </Panel>
  );
}

async function JournalTab({ e }: { e: typeof schema.enrollments.$inferSelect }) {
  const events = await db
    .select({ ev: schema.enrollmentEvents, firstName: schema.users.firstName, lastName: schema.users.lastName })
    .from(schema.enrollmentEvents)
    .leftJoin(schema.users, eq(schema.users.id, schema.enrollmentEvents.userId))
    .where(eq(schema.enrollmentEvents.enrollmentId, e.id))
    .orderBy(desc(schema.enrollmentEvents.at))
    .limit(300);
  const kindLabels: Record<string, string> = { creation: "Création", statut: "Statut", session: "Changement de session", groupe: "Changement de groupe", sortie_anticipee: "Sortie anticipée", cloture_pedagogique: "Clôture pédagogique", reouverture: "Réouverture", piece: "Pièce", modification: "Modification", progression: "Progression", import: "Import" };
  return (
    <Panel>
      <PanelHeader title="Journal du dossier" description="Tous les changements d'état et de rattachement, avec auteur et motif. Jamais effacé." />
      {events.length ? (
        <ul className="divide-y divide-line">
          {events.map(({ ev, firstName, lastName }) => (
            <li key={ev.id} className="flex flex-wrap items-baseline gap-x-4 gap-y-1 px-5 py-3 text-[13.5px]">
              <span className="num shrink-0 text-[12px] text-ink-3">{fmtDateTime(ev.at)}</span>
              <span className="shrink-0 text-ink-2">{firstName ? `${firstName} ${lastName}` : "Système"}</span>
              <Badge>{kindLabels[ev.kind] ?? ev.kind}</Badge>
              <span>
                {ev.fromValue || ev.toValue ? (
                  <span className="num">
                    {ev.fromValue ?? "-"} → {ev.toValue ?? "-"}
                  </span>
                ) : null}
                {ev.reason ? <span className="ml-2 text-ink-2">{ev.reason}</span> : null}
              </span>
            </li>
          ))}
        </ul>
      ) : (
        <EmptyState title="Journal vide" />
      )}
    </Panel>
  );
}
