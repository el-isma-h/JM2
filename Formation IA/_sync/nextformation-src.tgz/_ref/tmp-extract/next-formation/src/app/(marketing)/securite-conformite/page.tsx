import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight } from "@phosphor-icons/react/dist/ssr";
import { PageHero, btnContour, btnEncre, btnOsContour, btnPastel } from "@/components/marketing/site";
import { SECURITE } from "@/lib/marketing-data";
import { breadcrumbJsonLd, jsonLdScript, pageMeta } from "@/lib/seo";

export const metadata: Metadata = pageMeta("/securite-conformite", "Sécurité et conformité", "Hébergement en France, RGPD, isolation stricte par organisme, journal d'audit, sauvegardes quotidiennes chiffrées, restauration testée, double authentification TOTP, fichiers privés servis par liens temporaires.");

const PROFILS = [
  ["Propriétaire actif", "Administration de la sécurité, charte institutionnelle, journal d'audit, RIB central. Vérifié indépendamment de toute permission."],
  ["Direction, agence", "Pilotage et opérations selon permissions ; aucune administration de sécurité par défaut."],
  ["Responsable pédagogique", "Supervision, parcours, groupes, formateurs, examens, blocs internes. Pas de pièces administratives du seul fait de ce rôle."],
  ["Formateur seul", "Séances et apprenants effectivement affectés ; ni blocs internes, ni pièces administratives, ni finances."],
  ["Administratif", "Inscriptions et pièces administratives selon périmètre ; finance en lecture si attribuée ; pas de sécurité."],
  ["Finance", "Lecture ou gestion financière selon droits ; aucune ouverture automatique des CV ni des notes pédagogiques."],
  ["Qualité, auditeur", "Preuves et contrôles autorisés ; l'auditeur est en lecture seule."],
  ["Commercial", "Besoins, candidats et placements ; accès aux CV attribué explicitement."],
];

export default function SecuritePage() {
  return (
    <article>
      <script type="application/ld+json" dangerouslySetInnerHTML={jsonLdScript(breadcrumbJsonLd([{ name: "Accueil", path: "/" }, { name: "Sécurité", path: "/securite-conformite" }]))} />
      <PageHero crumbs={[{ label: "Accueil", href: "/" }, { label: "Sécurité" }]} eyebrow="Sécurité et conformité" title="Discrète pour l'équipe, réelle sur le serveur et en base." description="Chaque accès dépend d'un utilisateur actif, de son organisme, de sa permission et du dossier concerné. Un identifiant transmis par le navigateur n'est jamais une autorisation." filigrane="S">
        <Link href="/demo" className={btnPastel}>
          Tester les droits en démonstration <ArrowRight size={14} />
        </Link>
        <Link href="/confidentialite" className={btnContour}>
          Politique de confidentialité
        </Link>
      </PageHero>

      <section className="conteneur py-16 lg:py-24">
        <ul className="grid gap-px border border-line-strong bg-line-strong sm:grid-cols-2 lg:grid-cols-4">
          {SECURITE.map((s) => (
            <li key={s.t} className="bg-bg p-6">
              <h2 className="text-[18px]">{s.t}</h2>
              <p className="mt-3 text-[13.5px] leading-relaxed text-ink-2">{s.d}</p>
            </li>
          ))}
        </ul>
      </section>

      <section className="border-t border-line bg-bg-sunken">
        <div className="conteneur grid gap-12 py-16 lg:grid-cols-[0.8fr_1.2fr] lg:py-24">
          <div>
            <h2 className="text-[26px] sm:text-[32px]">Onze rôles additifs, un seul propriétaire.</h2>
            <p className="mt-5 max-w-md text-[14.5px] leading-relaxed text-ink-2">Les rôles s&apos;additionnent pour les fonctions métier. Leur cumul ne confère jamais le statut de propriétaire : une formatrice qui est aussi responsable d&apos;agence et responsable pédagogique conserve sa supervision et sa consultation financière, sans administration de sécurité ni modification de la charte.</p>
          </div>
          <dl className="border-t border-line-strong">
            {PROFILS.map(([t, d]) => (
              <div key={t} className="grid gap-2 border-b border-line py-4 sm:grid-cols-[200px_1fr]">
                <dt className="font-display text-[15px] font-medium">{t}</dt>
                <dd className="text-[13.5px] leading-relaxed text-ink-2">{d}</dd>
              </div>
            ))}
          </dl>
        </div>
      </section>

      <section className="conteneur py-16 lg:py-24">
        <div className="grid gap-px border border-line-strong bg-line-strong lg:grid-cols-3">
          {[
            ["Ce que nous journalisons", "Auteur, date, action, entité, état avant et après pour toute écriture ou lecture sensible. Jamais de mot de passe, de clé ni de copie inutile de pièce."],
            ["Ce que nous chiffrons", "Secrets d'authentification et coordonnées bancaires au repos ; connexions en TLS ; sauvegardes chiffrées."],
            ["Ce que vous gardez", "Vos données : exportables à tout moment, supprimées à la fin du contrat sous réserve des durées légales. Aucune utilisation pour entraîner un modèle."],
          ].map(([t, d], i) => (
            <div key={t} className={i === 1 ? "sombre bg-[#0a0b0d] p-8 text-[#f3f0e8]" : "bg-bg p-8"}>
              <h2 className="text-[22px]">{t}</h2>
              <p className={`mt-4 text-[14px] leading-relaxed ${i === 1 ? "text-[#f3f0e8]/65" : "text-ink-2"}`}>{d}</p>
            </div>
          ))}
        </div>
        <p className="mt-6 max-w-[90ch] text-[12.5px] leading-relaxed text-ink-3">Les engagements contractuels de sauvegarde et de restauration (perte maximale de données, délai de remise en service, fréquence des exercices) sont précisés dans le contrat de service ; les valeurs ci-dessus sont la proposition de départ.</p>
        <div className="mt-10 flex flex-wrap gap-3">
          <Link href="/contact" className={btnEncre}>
            Poser une question sécurité <ArrowRight size={14} />
          </Link>
          <Link href="/mentions-legales" className={btnOsContour}>
            Mentions légales
          </Link>
        </div>
      </section>
    </article>
  );
}
