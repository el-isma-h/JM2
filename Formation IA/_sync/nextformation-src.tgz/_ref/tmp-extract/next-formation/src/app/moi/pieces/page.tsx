import { guardLearner } from "@/server/extranet/guard";
import { listPieces } from "@/server/extranet/queries";
import { uploadPieceAction } from "@/server/actions/self";
import { NoAttachment } from "@/components/extranet/shell";
import { UploadDialog } from "@/components/extranet/upload-dialog";
import { StatusBadge } from "@/components/ui/badge";
import { EmptyState, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { fmtDate } from "@/lib/dates";

export const dynamic = "force-dynamic";

/** Pièces attendues à fournir par l'apprenant : dépôt → statut « déposée », contrôle par l'organisme. */
export default async function LearnerPieces() {
  const ctx = await guardLearner("/moi/pieces");
  if (!ctx) return <NoAttachment kind="learner" />;
  const rows = await listPieces(ctx.org.id, ctx.enrollmentIds, ["apprenant"]);
  const todo = rows.filter((r) => r.submission.status === "attendue" || r.submission.status === "refusee");
  return (
    <>
      <PageHeader title="Mes pièces à fournir" description="Pièces demandées par l'organisme pour votre dossier. Une pièce déposée est contrôlée par l'équipe administrative ; en cas de refus, le motif s'affiche ici et vous pouvez la redéposer." />
      {todo.length ? (
        <Notice tone="warn" className="mb-6" title={`${todo.length} pièce${todo.length > 1 ? "s" : ""} en attente de dépôt`}>
          Déposez chaque pièce depuis le tableau ci-dessous. Formats : PDF, image, Word.
        </Notice>
      ) : rows.length ? (
        <Notice tone="ok" className="mb-6">
          Toutes vos pièces ont été déposées.
        </Notice>
      ) : null}
      <div className="space-y-6">
        {ctx.enrollments.map((e) => {
          const mine = rows.filter((r) => r.submission.enrollmentId === e.enrollment.id);
          return (
            <Panel key={e.enrollment.id}>
              <PanelHeader title={e.program?.title ?? e.session.title} description={`Session ${e.session.code}`} />
              {mine.length ? (
                <Table>
                  <thead>
                    <tr>
                      <Th>Pièce</Th>
                      <Th>État</Th>
                      <Th>Échéance</Th>
                      <Th>Dernier dépôt</Th>
                      <Th className="text-right">Action</Th>
                    </tr>
                  </thead>
                  <tbody>
                    {mine.map((r) => (
                      <tr key={r.submission.id}>
                        <Td>
                          <span className="font-medium text-ink">{r.piece.label}</span>
                          {r.piece.description ? <span className="block text-[12.5px] text-ink-3">{r.piece.description}</span> : null}
                          {r.submission.status === "refusee" && r.submission.refusalReason ? <span className="mt-1 block text-[12.5px] text-danger-ink">Motif du refus : {r.submission.refusalReason}</span> : null}
                        </Td>
                        <Td>
                          <StatusBadge status={r.submission.status} />
                        </Td>
                        <Td className="num">{r.submission.dueDate ? fmtDate(r.submission.dueDate) : "-"}</Td>
                        <Td className="num">{r.submission.submittedAt ? fmtDate(r.submission.submittedAt) : "-"}</Td>
                        <Td className="text-right">
                          {r.submission.status === "acceptee" || r.submission.status === "non_applicable" ? (
                            <span className="text-[12.5px] text-ink-3">Rien à faire</span>
                          ) : (
                            <UploadDialog
                              action={uploadPieceAction}
                              trigger={r.submission.status === "deposee" ? "Remplacer" : "Déposer"}
                              triggerVariant={r.submission.status === "deposee" ? "secondary" : "primary"}
                              title={r.piece.label}
                              description={r.piece.description ?? "Le fichier est transmis à l'organisme pour contrôle."}
                              fields={{ submissionId: r.submission.id }}
                            />
                          )}
                        </Td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
              ) : (
                <EmptyState title="Aucune pièce demandée" description="L'organisme ne vous demande aucune pièce pour cette inscription." />
              )}
            </Panel>
          );
        })}
      </div>
    </>
  );
}
