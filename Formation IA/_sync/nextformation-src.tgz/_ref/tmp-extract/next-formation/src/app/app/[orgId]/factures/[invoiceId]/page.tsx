import Link from "next/link";
import { notFound } from "next/navigation";
import { and, asc, desc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { addPaymentAction, cancelInvoiceAction, deleteInvoiceDraftAction, deletePaymentAction, downloadInvoicePdfAction, issueInvoiceAction, sendInvoiceAction, updateInvoiceDraftAction } from "@/server/actions/finance";
import { centsToInput, invoiceKindLabels, paymentMethodLabels } from "@/server/finance/compute";
import { readBillTo } from "@/server/finance/service";
import { formatCents } from "@/lib/money";
import { fmtDate, fmtDateTime } from "@/lib/dates";
import { todayParis } from "@/lib/time";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea } from "@/components/ui/field";
import { KeyValue, Notice, PageHeader, Panel, PanelHeader, Stat } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { ActionButton } from "@/components/admin/action-form";
import { FormDialog } from "@/components/admin/form-dialog";
import { InvoiceForm } from "@/components/finance/invoice-form";
import { ChorusPanel } from "@/components/finance/chorus-panel";
import { CHORUS_ENDPOINTS, chorusBlockers, getChorusState } from "@/server/integrations/chorus";

export const dynamic = "force-dynamic";

export default async function InvoicePage({ params }: { params: Promise<{ orgId: string; invoiceId: string }> }) {
  const { orgId, invoiceId } = await params;
  const ctx = await guardOrg(orgId, `/app/${orgId}/factures/${invoiceId}`, "finance.view");
  const canManage = ctx.permissions.has("finance.manage");
  if (!/^[0-9a-f-]{36}$/.test(invoiceId)) notFound();
  const [inv] = await db.select().from(schema.invoices).where(and(eq(schema.invoices.id, invoiceId), eq(schema.invoices.orgId, orgId))).limit(1);
  if (!inv) notFound();
  const [lines, payments, history, credits, original, enrollment, funding] = await Promise.all([
    db.select().from(schema.invoiceLines).where(eq(schema.invoiceLines.invoiceId, inv.id)).orderBy(asc(schema.invoiceLines.position)),
    db.select().from(schema.payments).where(and(eq(schema.payments.invoiceId, inv.id), eq(schema.payments.orgId, orgId))).orderBy(asc(schema.payments.date)),
    db.select().from(schema.auditLogs).where(and(eq(schema.auditLogs.orgId, orgId), eq(schema.auditLogs.entityType, "invoice"), eq(schema.auditLogs.entityId, inv.id))).orderBy(desc(schema.auditLogs.createdAt)).limit(30),
    db.select({ id: schema.invoices.id, number: schema.invoices.number, status: schema.invoices.status, totalTtcCents: schema.invoices.totalTtcCents }).from(schema.invoices).where(and(eq(schema.invoices.orgId, orgId), eq(schema.invoices.creditOfInvoiceId, inv.id))),
    inv.creditOfInvoiceId ? db.select({ id: schema.invoices.id, number: schema.invoices.number }).from(schema.invoices).where(and(eq(schema.invoices.id, inv.creditOfInvoiceId), eq(schema.invoices.orgId, orgId))).limit(1).then((r) => r[0] ?? null) : Promise.resolve(null),
    inv.enrollmentId ? db.select({ id: schema.enrollments.id, reference: schema.enrollments.reference }).from(schema.enrollments).where(and(eq(schema.enrollments.id, inv.enrollmentId), eq(schema.enrollments.orgId, orgId))).limit(1).then((r) => r[0] ?? null) : Promise.resolve(null),
    inv.fundingId ? db.select({ id: schema.fundings.id, label: schema.fundings.label, agreementRef: schema.fundings.agreementRef }).from(schema.fundings).where(and(eq(schema.fundings.id, inv.fundingId), eq(schema.fundings.orgId, orgId))).limit(1).then((r) => r[0] ?? null) : Promise.resolve(null),
  ]);
  const chorus = await getChorusState(orgId);
  const chorusPanel = (
    <ChorusPanel
      orgId={orgId}
      invoice={inv}
      envLabel={chorus.row ? CHORUS_ENDPOINTS[chorus.env].label : null}
      blockers={chorusBlockers(chorus, inv)}
      canManage={canManage}
      isDraft={inv.status === "brouillon"}
    />
  );
  const billTo = readBillTo(inv.billTo);
  const today = todayParis();
  const isDraft = inv.status === "brouillon";
  const isOpen = ["emise", "envoyee", "partiellement_payee", "en_retard"].includes(inv.status);
  const remaining = inv.totalTtcCents - inv.paidCents;
  const isLate = isOpen && inv.dueDate && inv.dueDate < today && remaining > 0;
  const title = `${invoiceKindLabels[inv.kind]} ${inv.number ?? "(brouillon)"}`;

  return (
    <>
      <PageHeader
        breadcrumb={[{ label: "Finance" }, { label: "Factures", href: `/app/${orgId}/factures` }, { label: inv.number ?? "Brouillon" }]}
        title={title}
        description={
          <>
            {billTo.name} · émise le {fmtDate(inv.issueDate)}
            {inv.dueDate ? ` · échéance ${fmtDate(inv.dueDate)}` : ""}
            {enrollment ? (
              <>
                {" · inscription "}
                <Link href={`/app/${orgId}/inscriptions/${enrollment.id}`} className="num underline">
                  {enrollment.reference}
                </Link>
              </>
            ) : null}
            {funding ? (
              <>
                {" · financement "}
                <Link href={`/app/${orgId}/financements/${funding.id}`} className="underline">
                  {funding.label}
                </Link>
              </>
            ) : null}
            {original ? (
              <>
                {" · avoir sur "}
                <Link href={`/app/${orgId}/factures/${original.id}`} className="num underline">
                  {original.number}
                </Link>
              </>
            ) : null}
          </>
        }
        actions={
          <>
            <StatusBadge status={inv.status} />
            {isLate ? <Badge tone="danger">Échue</Badge> : null}
            {inv.documentId ? <ActionButton action={downloadInvoicePdfAction} fields={{ orgId, invoiceId: inv.id }} label="Télécharger le PDF" size="md" /> : null}
            {canManage && isDraft ? (
              <ActionButton action={issueInvoiceAction} fields={{ orgId, invoiceId: inv.id }} label={inv.kind === "avoir" ? "Émettre l'avoir" : "Émettre la facture"} variant="primary" size="md" confirm={{ title: inv.kind === "avoir" ? "Émettre l'avoir ?" : "Émettre la facture ?", description: "Un numéro continu est attribué, les montants et le destinataire sont figés, le PDF est archivé. Le document ne pourra plus être modifié.", confirmLabel: "Émettre" }} />
            ) : null}
            {canManage && !isDraft && inv.status !== "annulee" ? (
              <FormDialog action={sendInvoiceAction} trigger={inv.sentAt ? "Renvoyer par e-mail" : "Envoyer par e-mail"} triggerVariant="secondary" title="Envoyer la facture" description={ctx.org.isDemo ? "Espace de démonstration : l'e-mail est journalisé mais ne part pas." : "Le destinataire reçoit le récapitulatif (numéro, montants, échéance, conditions)."} submitLabel="Envoyer">
                <input type="hidden" name="orgId" value={orgId} />
                <input type="hidden" name="invoiceId" value={inv.id} />
                <Field label="Adresse e-mail" required htmlFor="send-to">
                  <Input id="send-to" name="to" type="email" required defaultValue={billTo.email ?? ""} />
                </Field>
              </FormDialog>
            ) : null}
            {canManage && isOpen && remaining > 0 ? (
              <FormDialog action={sendInvoiceAction} trigger="Relancer" triggerVariant="secondary" title="Envoyer une relance" description={`Reste dû : ${formatCents(remaining)}. La relance est journalisée dans les notes de la facture.`} submitLabel="Envoyer la relance">
                <input type="hidden" name="orgId" value={orgId} />
                <input type="hidden" name="invoiceId" value={inv.id} />
                <input type="hidden" name="reminder" value="1" />
                <Field label="Adresse e-mail" required htmlFor="rem-to">
                  <Input id="rem-to" name="to" type="email" required defaultValue={billTo.email ?? ""} />
                </Field>
              </FormDialog>
            ) : null}
            {canManage && !isDraft && inv.kind !== "avoir" && inv.status !== "annulee" ? (
              <Button asChild variant="secondary">
                <Link href={`/app/${orgId}/factures/nouvelle?creditOf=${inv.id}`}>Créer un avoir</Link>
              </Button>
            ) : null}
          </>
        }
      />

      {isDraft ? <Notice tone="info" className="mb-6">Brouillon : sans numéro ni valeur comptable. Les totaux affichés sont recalculés à partir des lignes ; ils seront figés à l&apos;émission.</Notice> : null}
      {inv.status === "annulee" ? <Notice tone="warn" className="mb-6">Facture annulée par avoir ; elle reste consultable et numérotée (continuité légale).</Notice> : null}

      <Panel className="mb-6 grid grid-cols-2 gap-6 p-5 md:grid-cols-5">
        <Stat label="Total HT" value={formatCents(inv.totalHtCents)} />
        <Stat label="TVA" value={inv.vatExempt ? "Exonérée" : formatCents(inv.vatCents)} hint={inv.vatExempt ? "art. 261-4-4° a CGI" : undefined} />
        <Stat label={inv.vatExempt ? "Net à payer" : "Total TTC"} value={formatCents(inv.totalTtcCents)} />
        <Stat label="Réglé" value={inv.kind === "avoir" ? "-" : formatCents(inv.paidCents)} hint={inv.paidAt ? `soldée le ${fmtDate(inv.paidAt)}` : undefined} />
        <Stat label="Reste dû" value={inv.kind === "avoir" || isDraft ? "-" : formatCents(remaining)} hint={isLate ? "En retard" : undefined} />
      </Panel>

      {canManage && isDraft ? (
        <Panel className="p-5">
          <InvoiceForm
            orgId={orgId}
            action={updateInvoiceDraftAction}
            submitLabel="Enregistrer le brouillon"
            readOnlyLinks={[enrollment ? { label: "Inscription", value: enrollment.reference } : null, funding ? { label: "Financement", value: funding.label } : null, original ? { label: "Facture d'origine", value: original.number ?? "" } : null].filter(Boolean) as { label: string; value: string }[]}
            initial={{
              invoiceId: inv.id,
              kind: inv.kind,
              enrollmentId: inv.enrollmentId,
              sessionId: inv.sessionId,
              companyId: inv.companyId,
              funderId: inv.funderId,
              personId: inv.personId,
              fundingId: inv.fundingId,
              creditOfInvoiceId: inv.creditOfInvoiceId,
              scheduleIndex: null,
              billTo,
              vatExempt: inv.vatExempt,
              vatMention: inv.vatMention,
              dueDate: inv.dueDate,
              servicePeriodStart: inv.servicePeriodStart,
              servicePeriodEnd: inv.servicePeriodEnd,
              paymentTerms: inv.paymentTerms,
              notes: inv.notes,
              purchaseOrderNumber: inv.purchaseOrderNumber,
              serviceCode: inv.serviceCode,
              legalCommitment: inv.legalCommitment,
              buyerSiret: inv.buyerSiret,
              lines: lines.map((l) => ({ label: l.label, description: l.description ?? "", quantity: (l.quantity / 1000).toString().replace(".", ","), unit: l.unit, unitPrice: centsToInput(l.unitCents), vatRate: (l.vatRateBp / 100).toString() })),
            }}
          />
          <div className="mt-6 border-t border-line pt-4">
            <ActionButton action={deleteInvoiceDraftAction} fields={{ orgId, invoiceId: inv.id }} label="Supprimer le brouillon" variant="danger" confirm={{ title: "Supprimer ce brouillon ?", description: "Aucun numéro n'a été attribué : la suppression n'affecte pas la continuité.", danger: true, confirmLabel: "Supprimer" }} />
          </div>
        </Panel>
      ) : (
        <div className="grid gap-6 xl:grid-cols-[1.4fr_1fr]">
          <div className="space-y-6">
            <Panel>
              <PanelHeader title="Lignes" description="Montants figés à l'émission." />
              <Table>
                <thead>
                  <tr>
                    <Th>Désignation</Th>
                    <Th num>Qté</Th>
                    <Th>Unité</Th>
                    <Th num>PU HT</Th>
                    {!inv.vatExempt ? <Th num>TVA</Th> : null}
                    <Th num>Total HT</Th>
                  </tr>
                </thead>
                <tbody>
                  {lines.map((l) => (
                    <tr key={l.id}>
                      <Td>
                        {l.label}
                        {l.description ? <p className="text-[12px] text-ink-3">{l.description}</p> : null}
                      </Td>
                      <Td num>{(l.quantity / 1000).toLocaleString("fr-FR", { maximumFractionDigits: 3 })}</Td>
                      <Td>{l.unit}</Td>
                      <Td num>{formatCents(l.unitCents)}</Td>
                      {!inv.vatExempt ? <Td num>{(l.vatRateBp / 100).toLocaleString("fr-FR")} %</Td> : null}
                      <Td num>{formatCents(l.totalHtCents)}</Td>
                    </tr>
                  ))}
                </tbody>
              </Table>
              <div className="border-t border-line px-5 py-4 text-[12.5px] text-ink-2">
                <p>{inv.vatMention}</p>
                <p className="mt-1">{inv.paymentTerms}</p>
                {inv.notes ? <p className="mt-1 whitespace-pre-line">{inv.notes}</p> : null}
              </div>
            </Panel>

            {inv.kind !== "avoir" && inv.kind !== "proforma" ? (
              <Panel>
                <PanelHeader
                  title="Règlements"
                  description="Le statut (partiellement payée / payée) est recalculé à chaque règlement ; le trop-perçu est refusé."
                  actions={
                    canManage && isOpen && remaining > 0 ? (
                      <FormDialog action={addPaymentAction} trigger="Enregistrer un règlement" triggerSize="sm" title="Nouveau règlement" description={`Reste dû : ${formatCents(remaining)}.`} submitLabel="Enregistrer">
                        <input type="hidden" name="orgId" value={orgId} />
                        <input type="hidden" name="invoiceId" value={inv.id} />
                        <div className="grid grid-cols-2 gap-3">
                          <Field label="Montant (€)" required htmlFor="p-amount">
                            <Input id="p-amount" name="amount" className="num" required defaultValue={centsToInput(remaining)} inputMode="decimal" />
                          </Field>
                          <Field label="Date" required htmlFor="p-date">
                            <Input id="p-date" name="date" type="date" required defaultValue={today} max={today} />
                          </Field>
                        </div>
                        <Field label="Mode" htmlFor="p-method">
                          <Select id="p-method" name="method" defaultValue="virement">
                            {schema.paymentMethodEnum.enumValues.map((m) => (
                              <option key={m} value={m}>
                                {paymentMethodLabels[m]}
                              </option>
                            ))}
                          </Select>
                        </Field>
                        <Field label="Référence" htmlFor="p-ref" help="Libellé du virement, numéro de chèque ou d'avoir compensé.">
                          <Input id="p-ref" name="reference" className="num" />
                        </Field>
                        <Field label="Note" htmlFor="p-note">
                          <Textarea id="p-note" name="note" className="min-h-14" />
                        </Field>
                      </FormDialog>
                    ) : null
                  }
                />
                {payments.length ? (
                  <Table>
                    <thead>
                      <tr>
                        <Th>Date</Th>
                        <Th>Mode</Th>
                        <Th>Référence</Th>
                        <Th>Rapprochement</Th>
                        <Th num>Montant</Th>
                        <Th></Th>
                      </tr>
                    </thead>
                    <tbody>
                      {payments.map((p) => (
                        <tr key={p.id}>
                          <Td>{fmtDate(p.date)}</Td>
                          <Td>{paymentMethodLabels[p.method]}</Td>
                          <Td className="num">
                            {p.reference ?? "-"}
                            {p.note && !p.note.startsWith("RELEVE:") ? <p className="font-sans text-[12px] text-ink-3">{p.note}</p> : null}
                          </Td>
                          <Td>{p.reconciledAt ? <Badge tone="ok">Relevé bancaire</Badge> : <span className="text-ink-3">Manuel</span>}</Td>
                          <Td num>{formatCents(p.amountCents)}</Td>
                          <Td>
                            {canManage ? (
                              <ActionButton action={deletePaymentAction} fields={{ orgId, paymentId: p.id }} label="Retirer" variant="ghost" confirm={{ title: "Retirer ce règlement ?", description: "Le statut de paiement est recalculé. Le motif est conservé dans l'audit.", danger: true, confirmLabel: "Retirer", input: { name: "reason", label: "Motif" } }} />
                            ) : null}
                          </Td>
                        </tr>
                      ))}
                    </tbody>
                  </Table>
                ) : (
                  <p className="px-5 py-6 text-[13px] text-ink-3">Aucun règlement enregistré.</p>
                )}
              </Panel>
            ) : null}
          </div>

          <div className="space-y-6">
            <Panel>
              <PanelHeader title="Destinataire (figé)" />
              <div className="p-5">
                <KeyValue items={[{ k: "Nature", v: billTo.kind }, { k: "Nom", v: billTo.name }, { k: "Adresse", v: [billTo.addressLine1, billTo.addressLine2, [billTo.postalCode, billTo.city].filter(Boolean).join(" ")].filter(Boolean).join(", ") || "-" }, { k: "SIRET", v: billTo.siret || null }, { k: "TVA", v: billTo.vatNumber || null }, { k: "E-mail", v: billTo.email || null }]} />
              </div>
            </Panel>
            <Panel>
              <PanelHeader title="Document" />
              <div className="p-5">
                <KeyValue items={[{ k: "Numéro", v: <span className="num">{inv.number ?? "-"}</span> }, { k: "Type", v: invoiceKindLabels[inv.kind] }, { k: "Émission", v: fmtDate(inv.issueDate) }, { k: "Échéance", v: inv.dueDate ? fmtDate(inv.dueDate) : "-" }, { k: "Prestation", v: inv.servicePeriodStart || inv.servicePeriodEnd ? `${inv.servicePeriodStart ? fmtDate(inv.servicePeriodStart) : "…"} au ${inv.servicePeriodEnd ? fmtDate(inv.servicePeriodEnd) : "…"}` : "-" }, { k: "Envoyée", v: inv.sentAt ? fmtDateTime(inv.sentAt) : "non" }, { k: "Export", v: inv.exportBatch ? `${inv.exportBatch} (${inv.exportedAt ? fmtDate(inv.exportedAt) : ""})` : "non exportée" }, { k: "Avoirs", v: credits.length ? credits.map((c) => <Link key={c.id} href={`/app/${orgId}/factures/${c.id}`} className="num mr-2 underline">{c.number ?? "brouillon"}</Link>) : "aucun" }]} />
                {canManage && isOpen && inv.paidCents === 0 && credits.some((c) => c.status !== "brouillon") ? (
                  <ActionButton action={cancelInvoiceAction} fields={{ orgId, invoiceId: inv.id }} label="Marquer annulée (soldée par avoir)" variant="secondary" className="mt-4" confirm={{ title: "Annuler la facture ?", description: "Possible uniquement si un avoir émis couvre le montant total.", confirmLabel: "Annuler la facture", input: { name: "reason", label: "Motif" } }} />
                ) : null}
              </div>
            </Panel>
            {chorusPanel}
            <Panel>
              <PanelHeader title="Historique" description="Journal d'audit de la facture." />
              <ul className="divide-y divide-line text-[12.5px]">
                {history.map((h) => (
                  <li key={h.id} className="px-5 py-2.5">
                    <span className="num text-ink-3">{fmtDateTime(h.createdAt)}</span> · <span className="font-mono text-[11px]">{h.action}</span>
                  </li>
                ))}
              </ul>
            </Panel>
          </div>
        </div>
      )}
    </>
  );
}
