import type { Metadata } from "next";
import Link from "next/link";
import { ArrowUpRight } from "@phosphor-icons/react/dist/ssr";
import { PageHero } from "@/components/marketing/site";
import { SOLUTIONS } from "@/lib/marketing-data";
import { pageMeta } from "@/lib/seo";

export const metadata: Metadata = pageMeta("/solutions", "Solutions par profil", "Next Formation pour les organismes de formation, les CFA, les formateurs indépendants, les centres multi-sites, les organismes d'habilitation et de DPC.");

export default function SolutionsIndex() {
  return (
    <article>
      <PageHero crumbs={[{ label: "Accueil", href: "/" }, { label: "Solutions" }]} eyebrow="Six profils" title="Le même dossier, adapté à votre activité." description="Les règles métier ne changent pas ; le point de départ, le plan conseillé et les fonctions mises en avant, si." filigrane="6" />
      <section className="conteneur py-16 lg:py-24">
        <ul className="grid gap-px border border-line-strong bg-line-strong sm:grid-cols-2 lg:grid-cols-3">
          {SOLUTIONS.map((s, i) => (
            <li key={s.slug} className={`group transition-colors duration-300 ${i === 1 ? "sombre bg-[#0a0b0d] text-[#f3f0e8]" : "bg-bg hover:bg-ink hover:text-bg"}`}>
              <Link href={`/solutions/${s.slug}`} className="flex h-full flex-col p-7">
                <span className={`flex items-center justify-between font-mono text-[11px] tracking-[0.2em] ${i === 1 ? "text-[#c9b8f0]" : "text-accent group-hover:text-[#c9b8f0]"}`}>
                  {s.short}
                  <ArrowUpRight size={14} className="opacity-0 transition-opacity group-hover:opacity-100" />
                </span>
                <h2 className="mt-8 text-[24px] leading-[1]">{s.title}</h2>
                <p className={`mt-4 flex-1 text-[13.5px] leading-relaxed ${i === 1 ? "text-[#f3f0e8]/65" : "text-ink-2 group-hover:text-bg/70"}`}>{s.intro}</p>
              </Link>
            </li>
          ))}
        </ul>
      </section>
    </article>
  );
}
