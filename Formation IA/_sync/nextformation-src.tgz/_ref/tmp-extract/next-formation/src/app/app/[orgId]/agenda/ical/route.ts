import { NextResponse, type NextRequest } from "next/server";
import { requireOrg } from "@/server/authz";
import { AuthError } from "@/server/auth";
import { agendaFor, toICal } from "@/server/tasks/agenda";
import { todayParis } from "@/lib/time";
import { addDays, format, parseISO } from "date-fns";

export const dynamic = "force-dynamic";

/** Export iCal de l'agenda de l'utilisateur connecté (session requise). */
export async function GET(req: NextRequest, { params }: { params: Promise<{ orgId: string }> }) {
  const { orgId } = await params;
  let ctx;
  try {
    ctx = await requireOrg(orgId);
  } catch (e) {
    const status = e instanceof AuthError && e.code === "unauthenticated" ? 401 : 403;
    return NextResponse.json({ error: "Accès refusé." }, { status });
  }
  const sp = req.nextUrl.searchParams;
  const ok = (v: string | null) => (v && /^\d{4}-\d{2}-\d{2}$/.test(v) ? v : null);
  const from = ok(sp.get("from")) ?? format(addDays(parseISO(todayParis()), -30), "yyyy-MM-dd");
  const to = ok(sp.get("to")) ?? format(addDays(parseISO(todayParis()), 90), "yyyy-MM-dd");
  const items = await agendaFor(ctx, from, to);
  const body = toICal(items, `Next Formation : ${ctx.user.firstName} ${ctx.user.lastName}`);
  return new NextResponse(body, { headers: { "Content-Type": "text/calendar; charset=utf-8", "Content-Disposition": `attachment; filename="agenda-${from}.ics"`, "Cache-Control": "no-store" } });
}
