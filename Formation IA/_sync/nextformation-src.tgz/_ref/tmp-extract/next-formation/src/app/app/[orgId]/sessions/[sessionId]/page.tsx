import Link from "next/link";
import { notFound } from "next/navigation";
import { and, asc, desc, eq, inArray } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg, handleAuthError } from "@/server/guard";
import { assertSessionInScope } from "@/server/authz";
import { sessionFormData } from "@/server/sessions/queries";
import { groupPlaces, sessionPlaces, sessionRhythm, checkSessionTransition } from "@/server/sessions/service";
import { nextSessionStatuses, sessionKindLabels, sessionStatusLabels, modalityLabels, WEEKDAY_LABELS, type SessionStatus } from "@/server/sessions/rules";
import { missingPiecesCount } from "@/server/enrollments/service";
import { financeSummaryForSession } from "@/server/finance/service";
import { ProposeButton } from "@/components/ai/propose-button";
import { contractKindLabels } from "@/server/enrollments/rules";
import { fmtDate, fmtDateTime } from "@/lib/dates";
import { formatCents } from "@/lib/money";
import { minutesBetween, fmtMinutes } from "@/lib/time";
import { readParam } from "@/components/admin/pagination";
import { ActionButton } from "@/components/admin/action-form";
import { FormDialog } from "@/components/admin/form-dialog";
import { NavFormDialog } from "@/components/sessions/nav-action-form";
import { SessionForm } from "@/components/sessions/session-form";
import { TabNav } from "@/components/sessions/tabs";
import { StatusBadge, Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/field";
import { EmptyState, KeyValue, Notice, PageHeader, Panel, PanelHeader, Stat } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FadeIn } from "@/components/ui/motion";
import { addSessionTrainerAction, deleteGroupAction, duplicateSessionAction, removeSessionTrainerAction, saveGroupAction, transitionSessionAction } from "@/server/actions/sessions";

export const dynamic = "force-dynamic";

const TABS = ["resume", "parametres", "groupes", "formateurs", "inscrits", "documents", "journal"] as const;
const trainerRoleLabels: Record<string, string> = { principal: "Formateur principal", intervenant: "Intervenant", jury: "Jury", tuteur_pedagogique: "Tuteur pédagogique" };

export default async function SessionPage({ params, searchParams }: { params: Promise<{ orgId: string; sessionId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId, sessionId } = await params;
  const path = `/app/${orgId}/sessions/${sessionId}`;
  const ctx = await guardOrg(orgId, path, "sessions.view");
  if (!/^[0-9a-f-]{36}$/i.test(sessionId)) notFound();
  try {
    await assertSessionInScope(ctx, sessionId);
  } catch (e) {
    handleAuthError(e, path);
  }
  const sp = await searchParams;
  const rawTab = readParam(sp.onglet) ?? "resume";
  const canManage = ctx.permissions.has("sessions.manage") && !ctx.trainerOnly;
  const tab = (TABS as readonly string[]).includes(rawTab) && (rawTab !== "parametres" || canManage) ? rawTab : "resume";

  const [row] = await db
    .select({ s: schema.trainingSessions, version: schema.programVersions, program: schema.programs, site: schema.sites, room: schema.rooms, company: schema.companies })
    .from(schema.trainingSessions)
    .innerJoin(schema.programVersions, eq(schema.programVersions.id, schema.trainingSessions.programVersionId))
    .innerJoin(schema.programs, eq(schema.programs.id, schema.programVersions.programId))
    .leftJoin(schema.sites, eq(schema.sites.id, schema.trainingSessions.siteId))
    .leftJoin(schema.rooms, eq(schema.rooms.id, schema.trainingSessions.roomId))
    .leftJoin(schema.companies, eq(schema.companies.id, schema.trainingSessions.companyId))
    .where(and(eq(schema.trainingSessions.id, sessionId), eq(schema.trainingSessions.orgId, orgId)))
    .limit(1);
  if (!row) notFound();
  const { s, version, program, site, room, company } = row;

  const [places, groups, groupCounts, trainers, members, enrollments] = await Promise.all([
    sessionPlaces(s.id),
    db.select().from(schema.groups).where(eq(schema.groups.sessionId, s.id)).orderBy(asc(schema.groups.name)),
    groupPlaces(s.id),
    db
      .select({ st: schema.sessionTrainers, t: schema.trainers, g: schema.groups })
      .from(schema.sessionTrainers)
      .innerJoin(schema.trainers, eq(schema.trainers.id, schema.sessionTrainers.trainerId))
      .leftJoin(schema.groups, eq(schema.groups.id, schema.sessionTrainers.groupId))
      .where(and(eq(schema.sessionTrainers.sessionId, s.id), eq(schema.sessionTrainers.orgId, orgId)))
      .orderBy(asc(schema.sessionTrainers.role), asc(schema.trainers.lastName)),
    db
      .select({ id: schema.users.id, firstName: schema.users.firstName, lastName: schema.users.lastName })
      .from(schema.memberships)
      .innerJoin(schema.users, eq(schema.users.id, schema.memberships.userId))
      .where(and(eq(schema.memberships.orgId, orgId), inArray(schema.memberships.userId, [s.pedagogyManagerUserId ?? "00000000-0000-0000-0000-000000000000", s.adminManagerUserId ?? "00000000-0000-0000-0000-000000000000"]))),
    db
      .select({ e: schema.enrollments, p: schema.persons, g: schema.groups, companyName: schema.companies.name })
      .from(schema.enrollments)
      .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
      .leftJoin(schema.groups, eq(schema.groups.id, schema.enrollments.groupId))
      .leftJoin(schema.companies, eq(schema.companies.id, schema.enrollments.companyId))
      .where(and(eq(schema.enrollments.sessionId, s.id), eq(schema.enrollments.orgId, orgId)))
      .orderBy(asc(schema.persons.lastName), asc(schema.persons.firstName)),
  ]);
  const rhythm = sessionRhythm(s, ctx.org);
  const pm = members.find((m) => m.id === s.pedagogyManagerUserId);
  const am = members.find((m) => m.id === s.adminManagerUserId);
  const dayMinutes = minutesBetween(rhythm.morning.start, rhythm.morning.end) + minutesBetween(rhythm.afternoon.start, rhythm.afternoon.end);
  const nextStatuses = nextSessionStatuses(s.status);
  const transitions = canManage ? await Promise.all(nextStatuses.map(async (to) => ({ to, check: await checkSessionTransition(s, to) }))) : [];
  const docCount = tab === "documents" ? null : undefined;

  const tabs = [
    { key: "resume", label: "Résumé" },
    ...(canManage ? [{ key: "parametres", label: "Paramètres" }] : []),
    { key: "groupes", label: "Groupes", count: groups.length },
    { key: "formateurs", label: "Formateurs", count: trainers.length },
    { key: "inscrits", label: "Inscrits", count: enrollments.length },
    { key: "documents", label: "Documents", count: docCount },
    { key: "journal", label: "Journal" },
  ];

  return (
    <FadeIn>
      <PageHeader
        title={s.title}
        breadcrumb={[{ label: "Sessions", href: `/app/${orgId}/sessions` }, { label: s.code }]}
        description={
          <span className="flex flex-wrap items-center gap-2">
            <StatusBadge status={s.status} />
            <span>
              {program.title} · {sessionKindLabels[s.kind] ?? s.kind} · {s.isApprenticeship ? "Apprentissage (CFA)" : "Formation continue (OF)"} · du {fmtDate(s.startDate)} au {fmtDate(s.endDate)}
            </span>
          </span>
        }
        actions={
          canManage ? (
            <>
              {ctx.permissions.has("planning.manage") ? <ProposeButton orgId={orgId} agent="planning" entityType="session" entityId={s.id} back={path} size="md" /> : null}
              {ctx.permissions.has("quality.view") ? <ProposeButton orgId={orgId} agent="qualite" entityType="session" entityId={s.id} back={path} size="md" /> : null}
              {ctx.permissions.has("enrollments.manage") && !["terminee", "annulee"].includes(s.status) ? (
                <Button asChild variant="secondary">
                  <Link href={`/app/${orgId}/inscriptions/nouvelle?sessionId=${s.id}`}>Inscrire une personne</Link>
                </Button>
              ) : null}
              <NavFormDialog action={duplicateSessionAction} trigger="Dupliquer" triggerVariant="secondary" title="Dupliquer la session" description="Copie les paramètres, les groupes et les formateurs affectés, sans les inscriptions. La copie est créée en brouillon." submitLabel="Dupliquer">
                <input type="hidden" name="orgId" value={orgId} />
                <input type="hidden" name="sessionId" value={s.id} />
                <Field label="Nouvelle date de début" htmlFor="dup-start" help="La durée de la session est conservée.">
                  <Input id="dup-start" name="startDate" type="date" defaultValue={s.startDate} className="num" />
                </Field>
              </NavFormDialog>
            </>
          ) : null
        }
      />
      <TabNav basePath={path} tabs={tabs} current={tab} />

      {tab === "resume" ? (
        <div className="grid gap-6 lg:grid-cols-[2fr_1fr]">
          <div className="space-y-6">
            <Panel className="grid grid-cols-2 gap-6 p-6 md:grid-cols-4">
              <Stat label="Places" value={<span className="num">{places.capacity}</span>} hint={`minimum ${places.minCapacity} pour confirmer`} />
              <Stat label="Inscrits" value={<span className="num">{places.enrolled}</span>} hint={`${places.confirmed} confirmé(s)`} />
              <Stat label="Places restantes" value={<span className="num">{places.remaining}</span>} hint={places.remaining === 0 ? "session complète" : undefined} />
              <Stat label="Journée type" value={<span className="num">{fmtMinutes(dayMinutes)}</span>} hint="pause méridienne exclue" />
            </Panel>
            <Panel>
              <PanelHeader title="Organisation" />
              <div className="grid gap-6 p-6 md:grid-cols-2">
                <KeyValue
                  items={[
                    { k: "Formation", v: <Link href={`/app/${orgId}/catalogue/${program.id}`} className="hover:underline">{program.title}</Link> },
                    { k: "Version", v: <span className="num">v{version.version} · {version.durationHours} h{version.companyHours ? ` (+ ${version.companyHours} h entreprise)` : ""}</span> },
                    { k: "Dates", v: <span className="num">{fmtDate(s.startDate)} au {fmtDate(s.endDate)}</span> },
                    { k: "Modalité", v: modalityLabels[s.modality] ?? s.modality },
                    { k: "Site", v: site ? `${site.name}${site.city ? `, ${site.city}` : ""}` : "Non précisé" },
                    { k: "Salle", v: room?.name ?? "Non précisée" },
                    { k: "Entreprise", v: company ? <Link href={`/app/${orgId}/entreprises/${company.id}`} className="hover:underline">{company.name}</Link> : "-" },
                    { k: "Prix HT", v: <span className="num">{formatCents(s.priceCents ?? version.priceCents)}</span> },
                  ]}
                />
                <KeyValue
                  items={[
                    { k: "Rythme", v: rhythm.label },
                    { k: "Jours de centre", v: rhythm.weekdays.length ? rhythm.weekdays.map((d) => WEEKDAY_LABELS[d]).join(", ") : rhythm.centerDays ? `${rhythm.centerDays} jour(s) par cycle` : "-" },
                    { k: "Matin", v: <span className="num">{rhythm.morning.start} - {rhythm.morning.end}</span> },
                    { k: "Après-midi", v: <span className="num">{rhythm.afternoon.start} - {rhythm.afternoon.end}</span> },
                    { k: "Resp. pédagogique", v: pm ? `${pm.firstName} ${pm.lastName}` : "Non désigné" },
                    { k: "Resp. administratif", v: am ? `${am.firstName} ${am.lastName}` : "Non désigné" },
                    { k: "Catalogue public", v: s.isPublished ? "Dates publiées" : "Non publiée" },
                    { k: "Clôture", v: s.closedAt ? fmtDateTime(s.closedAt) : "-" },
                  ]}
                />
              </div>
              {s.notes ? <p className="whitespace-pre-wrap border-t border-line px-6 py-4 text-[13.5px] text-ink-2">{s.notes}</p> : null}
            </Panel>
            {ctx.permissions.has("finance.view") && !ctx.trainerOnly ? <SessionFinancePanel orgId={orgId} sessionId={s.id} /> : null}
          </div>
          <div className="space-y-6">
            <Panel>
              <PanelHeader title="Statut" description="Transitions contrôlées : ce qui bloque est indiqué." />
              <div className="space-y-3 p-5">
                <p className="text-[13.5px]">
                  Actuel : <StatusBadge status={s.status} />
                </p>
                {canManage && transitions.length ? (
                  transitions.map(({ to, check }) =>
                    check.ok ? (
                      <ActionButton
                        key={to}
                        action={transitionSessionAction}
                        fields={{ orgId, sessionId: s.id, to }}
                        label={`Passer à « ${sessionStatusLabels[to as SessionStatus]} »`}
                        variant={to === "annulee" ? "danger" : "secondary"}
                        confirm={{
                          title: `Passer la session à « ${sessionStatusLabels[to as SessionStatus]} »`,
                          description: to === "terminee" ? "Terminer la session ne solde pas les financements des inscriptions : ils restent à traiter dans le module finance." : to === "annulee" ? "L'annulation est journalisée ; les inscriptions restent consultables." : undefined,
                          input: { name: "reason", label: "Motif", help: to === "annulee" || (to === "brouillon" && s.status === "annulee") ? "Obligatoire" : "Facultatif, conservé dans les notes." },
                          danger: to === "annulee",
                          confirmLabel: "Confirmer",
                        }}
                      />
                    ) : (
                      <Notice key={to} tone="warn">
                        <span className="font-medium">{sessionStatusLabels[to as SessionStatus]} :</span> {check.reason}
                      </Notice>
                    ),
                  )
                ) : s.status === "terminee" ? (
                  <p className="text-[13px] text-ink-3">Session terminée : aucune transition possible.</p>
                ) : null}
              </div>
            </Panel>
            <Panel>
              <PanelHeader title="Inscriptions" />
              <ul className="divide-y divide-line text-[13.5px]">
                {(["preinscrit", "inscrit", "en_cours", "termine", "abandon", "annule", "reporte"] as const).map((st) => {
                  const n = enrollments.filter((x) => x.e.status === st).length;
                  return n ? (
                    <li key={st} className="flex items-center justify-between px-5 py-2.5">
                      <StatusBadge status={st} />
                      <span className="num">{n}</span>
                    </li>
                  ) : null;
                })}
                {!enrollments.length ? <li className="px-5 py-3 text-ink-3">Aucune inscription.</li> : null}
              </ul>
            </Panel>
          </div>
        </div>
      ) : null}

      {tab === "parametres" && canManage ? (
        <Panel className="p-6">
          {s.status === "terminee" ? <Notice tone="info" className="mb-5">Session terminée : les paramètres ne sont plus modifiables.</Notice> : null}
          <SessionForm orgId={orgId} session={s} rhythm={rhythm} orgKind={ctx.org.kind} {...(await sessionFormData(orgId))} />
        </Panel>
      ) : null}

      {tab === "groupes" ? (
        <Panel>
          <PanelHeader
            title="Groupes"
            description="Sous-ensembles d'une session (capacité propre). Les séances peuvent viser un groupe ou toute la session."
            actions={
              canManage ? (
                <FormDialog action={saveGroupAction} trigger="Nouveau groupe" triggerSize="sm" title="Nouveau groupe" submitLabel="Créer">
                  <input type="hidden" name="orgId" value={orgId} />
                  <input type="hidden" name="sessionId" value={s.id} />
                  <Field label="Nom" required htmlFor="g-name">
                    <Input id="g-name" name="name" required placeholder="Ex. Groupe A" />
                  </Field>
                  <Field label="Capacité" htmlFor="g-cap" help="Facultatif : limite propre au groupe.">
                    <Input id="g-cap" name="capacity" type="number" min={1} className="num" />
                  </Field>
                </FormDialog>
              ) : null
            }
          />
          {groups.length ? (
            <Table>
              <thead>
                <tr>
                  <Th>Groupe</Th>
                  <Th num>Inscrits</Th>
                  <Th num>Capacité</Th>
                  <Th>Formateurs</Th>
                  {canManage ? <Th></Th> : null}
                </tr>
              </thead>
              <tbody>
                {groups.map((g) => (
                  <tr key={g.id}>
                    <Td className="font-medium">{g.name}</Td>
                    <Td num>{groupCounts.get(g.id) ?? 0}</Td>
                    <Td num>{g.capacity ?? "-"}</Td>
                    <Td>{trainers.filter((t) => t.st.groupId === g.id).map((t) => `${t.t.firstName} ${t.t.lastName}`).join(", ") || "-"}</Td>
                    {canManage ? (
                      <Td>
                        <div className="flex justify-end gap-2">
                          <FormDialog action={saveGroupAction} trigger="Modifier" triggerVariant="ghost" triggerSize="sm" title={`Modifier « ${g.name} »`} submitLabel="Enregistrer">
                            <input type="hidden" name="orgId" value={orgId} />
                            <input type="hidden" name="sessionId" value={s.id} />
                            <input type="hidden" name="groupId" value={g.id} />
                            <Field label="Nom" required htmlFor={`g-name-${g.id}`}>
                              <Input id={`g-name-${g.id}`} name="name" required defaultValue={g.name} />
                            </Field>
                            <Field label="Capacité" htmlFor={`g-cap-${g.id}`}>
                              <Input id={`g-cap-${g.id}`} name="capacity" type="number" min={1} defaultValue={g.capacity ?? ""} className="num" />
                            </Field>
                          </FormDialog>
                          <ActionButton action={deleteGroupAction} fields={{ orgId, groupId: g.id }} label="Supprimer" variant="ghost" confirm={{ title: `Supprimer le groupe « ${g.name} »`, description: "Possible uniquement si aucune inscription n'y est rattachée.", danger: true }} />
                        </div>
                      </Td>
                    ) : null}
                  </tr>
                ))}
              </tbody>
            </Table>
          ) : (
            <EmptyState title="Aucun groupe" description="Sans groupe, toutes les inscriptions suivent le même planning." />
          )}
          <p className="border-t border-line px-5 py-3 text-[12.5px] text-ink-3">
            Sans groupe : <span className="num">{groupCounts.get(null) ?? 0}</span> inscription(s).
          </p>
        </Panel>
      ) : null}

      {tab === "formateurs" ? (
        <Panel>
          <PanelHeader
            title="Formateurs affectés"
            description="Un formateur ne voit que les sessions où il est affecté. Il ne peut jamais créer sa propre affectation."
            actions={
              canManage ? (
                <TrainerDialog orgId={orgId} sessionId={s.id} groups={groups} ownTrainerId={ctx.trainerId} canSelfAssign={ctx.isOwner || ctx.permissions.has("planning.manage")} />
              ) : null
            }
          />
          {trainers.length ? (
            <Table>
              <thead>
                <tr>
                  <Th>Formateur</Th>
                  <Th>Rôle</Th>
                  <Th>Groupe</Th>
                  <Th>Type</Th>
                  {canManage ? <Th></Th> : null}
                </tr>
              </thead>
              <tbody>
                {trainers.map(({ st, t, g }) => (
                  <tr key={st.id}>
                    <Td>
                      <Link href={`/app/${orgId}/formateurs/${t.id}`} className="font-medium hover:underline">
                        {t.firstName} {t.lastName}
                      </Link>
                      {t.email ? <p className="text-[12px] text-ink-3">{t.email}</p> : null}
                    </Td>
                    <Td>
                      <Badge tone={st.role === "principal" ? "accent" : "neutral"}>{trainerRoleLabels[st.role] ?? st.role}</Badge>
                    </Td>
                    <Td>{g?.name ?? "Toute la session"}</Td>
                    <Td>{t.kind === "interne" ? "Interne" : t.kind === "externe" ? "Externe" : "Sous-traitant"}</Td>
                    {canManage ? (
                      <Td>
                        <div className="flex justify-end">
                          <ActionButton action={removeSessionTrainerAction} fields={{ orgId, id: st.id }} label="Retirer" variant="ghost" confirm={{ title: `Retirer ${t.firstName} ${t.lastName} de la session`, description: "Les séances déjà planifiées avec ce formateur ne sont pas modifiées." }} />
                        </div>
                      </Td>
                    ) : null}
                  </tr>
                ))}
              </tbody>
            </Table>
          ) : (
            <EmptyState title="Aucun formateur affecté" description="Affectez un formateur principal et, si besoin, des intervenants par groupe." />
          )}
        </Panel>
      ) : null}

      {tab === "inscrits" ? <EnrolledTab orgId={orgId} rows={enrollments} canManage={ctx.permissions.has("enrollments.manage") && !ctx.trainerOnly} sessionClosed={["terminee", "annulee"].includes(s.status)} sessionId={s.id} /> : null}

      {tab === "documents" ? <DocumentsTab orgId={orgId} sessionId={s.id} /> : null}

      {tab === "journal" ? <JournalTab orgId={orgId} sessionId={s.id} /> : null}
    </FadeIn>
  );
}

async function TrainerDialog({ orgId, sessionId, groups, ownTrainerId, canSelfAssign }: { orgId: string; sessionId: string; groups: { id: string; name: string }[]; ownTrainerId: string | null; canSelfAssign: boolean }) {
  const list = await db.select({ id: schema.trainers.id, firstName: schema.trainers.firstName, lastName: schema.trainers.lastName, kind: schema.trainers.kind }).from(schema.trainers).where(and(eq(schema.trainers.orgId, orgId), eq(schema.trainers.isActive, true))).orderBy(asc(schema.trainers.lastName));
  const options = list.filter((t) => canSelfAssign || t.id !== ownTrainerId);
  if (!list.length) {
    return (
      <Button asChild variant="secondary" size="sm">
        <Link href={`/app/${orgId}/formateurs`}>Créer un formateur</Link>
      </Button>
    );
  }
  return (
    <FormDialog action={addSessionTrainerAction} trigger="Affecter un formateur" triggerSize="sm" title="Affecter un formateur" submitLabel="Affecter">
      <input type="hidden" name="orgId" value={orgId} />
      <input type="hidden" name="sessionId" value={sessionId} />
      <Field label="Formateur" required htmlFor="t-id" help={!canSelfAssign && ownTrainerId ? "Votre propre fiche n'est pas proposée : une affectation personnelle passe par le responsable pédagogique." : undefined}>
        <Select id="t-id" name="trainerId" required defaultValue="">
          <option value="">Choisir</option>
          {options.map((t) => (
            <option key={t.id} value={t.id}>
              {t.lastName} {t.firstName} ({t.kind})
            </option>
          ))}
        </Select>
      </Field>
      <Field label="Rôle" htmlFor="t-role">
        <Select id="t-role" name="role" defaultValue="intervenant">
          <option value="principal">Formateur principal</option>
          <option value="intervenant">Intervenant</option>
          <option value="jury">Jury</option>
          <option value="tuteur_pedagogique">Tuteur pédagogique</option>
        </Select>
      </Field>
      <Field label="Groupe" htmlFor="t-group">
        <Select id="t-group" name="groupId" defaultValue="">
          <option value="">Toute la session</option>
          {groups.map((g) => (
            <option key={g.id} value={g.id}>
              {g.name}
            </option>
          ))}
        </Select>
      </Field>
    </FormDialog>
  );
}

async function EnrolledTab({ orgId, rows, canManage, sessionClosed, sessionId }: { orgId: string; rows: { e: typeof schema.enrollments.$inferSelect; p: typeof schema.persons.$inferSelect; g: typeof schema.groups.$inferSelect | null; companyName: string | null }[]; canManage: boolean; sessionClosed: boolean; sessionId: string }) {
  const missing = await missingPiecesCount(orgId, rows.map((r) => r.e.id));
  return (
    <Panel>
      <PanelHeader
        title="Inscrits"
        description="Chaque inscription a ses statuts propres : inscription, progression, financement, examen."
        actions={
          canManage && !sessionClosed ? (
            <Button asChild size="sm">
              <Link href={`/app/${orgId}/inscriptions/nouvelle?sessionId=${sessionId}`}>Inscrire une personne</Link>
            </Button>
          ) : null
        }
      />
      {rows.length ? (
        <Table>
          <thead>
            <tr>
              <Th>Personne</Th>
              <Th>Référence</Th>
              <Th>Groupe</Th>
              <Th>Contrat</Th>
              <Th>Inscription</Th>
              <Th>Progression</Th>
              <Th>Financement</Th>
              <Th>Examen</Th>
              <Th num>Pièces manquantes</Th>
            </tr>
          </thead>
          <tbody>
            {rows.map(({ e, p, g, companyName }) => (
              <tr key={e.id}>
                <Td>
                  <Link href={`/app/${orgId}/inscriptions/${e.id}`} className="font-medium hover:underline">
                    {p.lastName.toUpperCase()} {p.firstName}
                  </Link>
                  {companyName ? <p className="text-[12px] text-ink-3">{companyName}</p> : null}
                </Td>
                <Td className="num">{e.reference}</Td>
                <Td>{g?.name ?? "-"}</Td>
                <Td>{contractKindLabels[e.contractKind]}</Td>
                <Td>
                  <StatusBadge status={e.status} />
                </Td>
                <Td>
                  <StatusBadge status={e.progression} />
                </Td>
                <Td>
                  <StatusBadge status={e.fundingState} />
                </Td>
                <Td>
                  <StatusBadge status={e.examState} />
                </Td>
                <Td num>{missing.get(e.id) ?? 0}</Td>
              </tr>
            ))}
          </tbody>
        </Table>
      ) : (
        <EmptyState title="Aucune inscription" description="Inscrivez une personne existante (candidat, apprenant) sans recréer sa fiche." />
      )}
    </Panel>
  );
}

async function DocumentsTab({ orgId, sessionId }: { orgId: string; sessionId: string }) {
  const docs = await db.select().from(schema.documents).where(and(eq(schema.documents.orgId, orgId), eq(schema.documents.sessionId, sessionId))).orderBy(desc(schema.documents.createdAt)).limit(200);
  return (
    <Panel>
      <PanelHeader
        title="Documents de session"
        description="Convocations, feuilles d'émargement, annexes : générés depuis le module documents."
        actions={
          <Button asChild variant="secondary" size="sm">
            <Link href={`/app/${orgId}/documents?session=${sessionId}`}>Ouvrir dans Documents</Link>
          </Button>
        }
      />
      {docs.length ? (
        <Table>
          <thead>
            <tr>
              <Th>Document</Th>
              <Th>Catégorie</Th>
              <Th>Statut</Th>
              <Th num>Version</Th>
              <Th>Créé le</Th>
            </tr>
          </thead>
          <tbody>
            {docs.map((d) => (
              <tr key={d.id}>
                <Td>
                  <Link href={`/app/${orgId}/documents/${d.id}`} className="font-medium hover:underline">
                    {d.title}
                  </Link>
                </Td>
                <Td>{d.category}</Td>
                <Td>
                  <StatusBadge status={d.status} />
                </Td>
                <Td num>{d.version}</Td>
                <Td className="whitespace-nowrap">{fmtDate(d.createdAt)}</Td>
              </tr>
            ))}
          </tbody>
        </Table>
      ) : (
        <EmptyState title="Aucun document de session" description="Les documents rattachés à la session (et non à une inscription) apparaîtront ici." />
      )}
    </Panel>
  );
}

async function JournalTab({ orgId, sessionId }: { orgId: string; sessionId: string }) {
  const [auditRows, events] = await Promise.all([
    db
      .select({ action: schema.auditLogs.action, at: schema.auditLogs.createdAt, after: schema.auditLogs.after, before: schema.auditLogs.before, firstName: schema.users.firstName, lastName: schema.users.lastName })
      .from(schema.auditLogs)
      .leftJoin(schema.users, eq(schema.users.id, schema.auditLogs.userId))
      .where(and(eq(schema.auditLogs.orgId, orgId), eq(schema.auditLogs.entityType, "session"), eq(schema.auditLogs.entityId, sessionId)))
      .orderBy(desc(schema.auditLogs.createdAt))
      .limit(100),
    db
      .select({ ev: schema.enrollmentEvents, reference: schema.enrollments.reference, enrollmentId: schema.enrollments.id, firstName: schema.users.firstName, lastName: schema.users.lastName })
      .from(schema.enrollmentEvents)
      .innerJoin(schema.enrollments, eq(schema.enrollments.id, schema.enrollmentEvents.enrollmentId))
      .leftJoin(schema.users, eq(schema.users.id, schema.enrollmentEvents.userId))
      .where(and(eq(schema.enrollments.orgId, orgId), eq(schema.enrollments.sessionId, sessionId), inArray(schema.enrollmentEvents.kind, ["creation", "session", "groupe", "statut"])))
      .orderBy(desc(schema.enrollmentEvents.at))
      .limit(100),
  ]);
  const items = [
    ...auditRows.map((a) => ({ at: a.at, who: a.firstName ? `${a.firstName} ${a.lastName}` : "Système", label: auditLabel(a.action, a.before, a.after), href: null as string | null })),
    ...events.map((e) => ({ at: e.ev.at, who: e.firstName ? `${e.firstName} ${e.lastName}` : "Système", label: `${e.reference} : ${e.ev.kind}${e.ev.fromValue || e.ev.toValue ? ` (${e.ev.fromValue ?? "-"} → ${e.ev.toValue ?? "-"})` : ""}${e.ev.reason ? ` : ${e.ev.reason}` : ""}`, href: `/app/${orgId}/inscriptions/${e.enrollmentId}` })),
  ].sort((a, b) => b.at.getTime() - a.at.getTime());
  return (
    <Panel>
      <PanelHeader title="Journal" description="Modifications de la session et mouvements des inscriptions (création, changement de session ou de groupe, statut)." />
      {items.length ? (
        <ul className="divide-y divide-line">
          {items.map((it, i) => (
            <li key={i} className="flex flex-wrap items-baseline gap-x-4 gap-y-1 px-5 py-3 text-[13.5px]">
              <span className="num shrink-0 text-[12px] text-ink-3">{fmtDateTime(it.at)}</span>
              <span className="shrink-0 text-ink-2">{it.who}</span>
              {it.href ? (
                <Link href={it.href} className="hover:underline">
                  {it.label}
                </Link>
              ) : (
                <span>{it.label}</span>
              )}
            </li>
          ))}
        </ul>
      ) : (
        <EmptyState title="Journal vide" />
      )}
    </Panel>
  );
}

function auditLabel(action: string, before: unknown, after: unknown): string {
  const b = (before ?? {}) as Record<string, unknown>;
  const a = (after ?? {}) as Record<string, unknown>;
  switch (action) {
    case "session.create":
      return `Session créée (${a.code ?? ""})`;
    case "session.update":
      return "Paramètres modifiés";
    case "session.transition":
      return `Statut : ${b.status ?? "-"} → ${a.status ?? "-"}${a.reason ? ` : ${a.reason}` : ""}`;
    case "session.duplicate":
      return `Dupliquée depuis ${b.code ?? ""}`;
    case "session.trainer.add":
      return `Formateur affecté (${a.role ?? ""})`;
    case "session.trainer.remove":
      return "Formateur retiré";
    default:
      return action;
  }
}

/** Résumé financier de la session (F11) : prévu, accordé, facturé, encaissé sur l'ensemble des inscriptions. */
async function SessionFinancePanel({ orgId, sessionId }: { orgId: string; sessionId: string }) {
  const f = await financeSummaryForSession(orgId, sessionId);
  return (
    <Panel>
      <PanelHeader title="Finance" description={`${f.enrollments} inscription(s). La clôture de la session ne solde jamais les financements.`} actions={<Button asChild variant="secondary" size="sm"><Link href={`/app/${orgId}/financements?session=${sessionId}`}>Financements</Link></Button>} />
      <div className="grid grid-cols-2 gap-6 p-6 md:grid-cols-4">
        <Stat label="Prévu" value={<span className="num">{formatCents(f.plannedCents)}</span>} />
        <Stat label="Accordé" value={<span className="num">{formatCents(f.grantedCents)}</span>} />
        <Stat label="Facturé TTC" value={<span className="num">{formatCents(f.billedCents)}</span>} />
        <Stat label="Encaissé" value={<span className="num">{formatCents(f.paidCents)}</span>} />
      </div>
    </Panel>
  );
}
