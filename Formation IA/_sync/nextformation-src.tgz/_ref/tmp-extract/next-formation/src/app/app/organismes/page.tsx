import Link from "next/link";
import { requireUser } from "@/server/auth";
import { listAccessibleOrgs } from "@/server/authz";
import { Logo } from "@/components/ui/logo";
import { EmptyState, Panel, PanelHeader } from "@/components/ui/surface";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export const metadata = { title: "Mes organismes" };

export default async function OrgsIndex() {
  const user = await requireUser();
  const orgs = await listAccessibleOrgs(user);
  return (
    <main className="mx-auto max-w-3xl px-4 py-12">
      <div className="mb-8 flex items-center justify-between">
        <Logo />
        <form action="/deconnexion" method="post">
          <button type="submit" className="font-mono text-[10px] uppercase tracking-[0.18em] text-ink-3 hover:text-ink">
            Déconnexion
          </button>
        </form>
      </div>
      <Panel>
        <PanelHeader title="Vos organismes" description="Choisissez l'organisme dans lequel travailler. Chaque organisme est isolé : droits, dossiers et documents ne se mélangent pas." />
        {orgs.length ? (
          <ul>
            {orgs.map((o) => (
              <li key={o.id} className="flex items-center justify-between gap-4 border-t border-line px-5 py-4">
                <div>
                  <p className="text-[14px] font-medium text-ink">{o.tradeName ?? o.legalName}</p>
                  <p className="text-[12px] text-ink-3">
                    {o.kind === "cfa" ? "CFA" : o.kind === "of_cfa" ? "Organisme de formation et CFA" : "Organisme de formation"}
                    {o.siret ? ` · SIRET ${o.siret}` : ""}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  {o.isDemo ? <Badge tone="warn">Démo</Badge> : null}
                  <Button asChild size="sm">
                    <Link href={`/app/${o.id}`}>Ouvrir</Link>
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        ) : (
          <EmptyState title="Aucun organisme rattaché à votre compte" description="Demandez une invitation au propriétaire de votre organisme, ou créez un nouvel espace." action={<Button asChild><Link href="/inscription">Créer un espace</Link></Button>} />
        )}
      </Panel>
    </main>
  );
}
