import Link from "next/link";
import { guardOrg } from "@/server/guard";
import { bpfDetail, computeBpf } from "@/server/finance/bpf";
import { fmtDateTime } from "@/lib/dates";
import { todayParis } from "@/lib/time";
import { Button } from "@/components/ui/button";
import { Field, Select } from "@/components/ui/field";
import { EmptyState, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { readParam } from "@/components/admin/pagination";
import { RibLink } from "@/components/finance/rib-link";

export const dynamic = "force-dynamic";

export default async function BpfPage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const ctx = await guardOrg(orgId, `/app/${orgId}/bpf`, "finance.view");
  const canManage = ctx.permissions.has("finance.manage");
  const canExport = ctx.permissions.has("exports.run");
  const sp = await searchParams;
  const currentYear = Number(todayParis().slice(0, 4));
  const y = Number(readParam(sp.year));
  const year = Number.isInteger(y) && y >= 2000 && y <= currentYear + 1 ? y : currentYear - 1;
  const detail = readParam(sp.detail);
  const report = await computeBpf(orgId, year);
  const indicator = detail ? report.sections.flatMap((s) => s.indicators).find((i) => i.code === detail) : null;
  const rows = indicator ? await bpfDetail(orgId, year, indicator.code) : [];
  const years = Array.from({ length: 6 }, (_, i) => currentYear - 4 + i);

  return (
    <>
      <PageHeader
        title="Bilan pédagogique et financier"
        description="Calcul préparatoire du BPF pour une année civile : produits par type de financeur, charges, stagiaires et heures validées, spécialités. Chaque indicateur affiche sa définition, son dénominateur, ses exclusions et sa date de calcul, et ouvre la liste qui le compose."
        actions={
          <>
            <RibLink orgId={orgId} manage={canManage || ctx.isOwner} />
            <Button asChild variant="secondary">
              <Link href={`/app/${orgId}/bpf/depenses`}>Dépenses</Link>
            </Button>
            {canExport ? (
              <>
                <Button asChild variant="secondary">
                  <Link href={`/app/${orgId}/bpf/export?year=${year}&format=csv`}>Export CSV</Link>
                </Button>
                <Button asChild>
                  <Link href={`/app/${orgId}/bpf/export?year=${year}&format=pdf`}>Récapitulatif PDF</Link>
                </Button>
              </>
            ) : null}
          </>
        }
      />
      <Panel className="mb-6">
        <form method="get" className="flex flex-wrap items-end gap-3 px-5 py-3">
          <Field label="Année civile" htmlFor="year" className="w-40">
            <Select id="year" name="year" defaultValue={String(year)}>
              {years.map((yy) => (
                <option key={yy} value={yy}>
                  {yy}
                </option>
              ))}
            </Select>
          </Field>
          <Button type="submit" variant="secondary">
            Calculer
          </Button>
          <p className="mb-2 ml-auto text-[12.5px] text-ink-3">Calculé le {fmtDateTime(new Date(report.computedAt))} (heure serveur). Les exports exigent « exports.run » et une session renforcée.</p>
        </form>
      </Panel>
      {!canExport ? <Notice tone="info" className="mb-6">Consultation seule : l&apos;export CSV / PDF du BPF est réservé aux habilitations « exports.run » avec vérification renforcée.</Notice> : null}

      <div className="grid gap-6 xl:grid-cols-[1.3fr_1fr]">
        <div className="space-y-6">
          {report.sections.map((s) => (
            <Panel key={s.code}>
              <PanelHeader title={s.title} />
              {s.indicators.length ? (
                <Table>
                  <thead>
                    <tr>
                      <Th>Indicateur</Th>
                      <Th num>Valeur</Th>
                      <Th num>Éléments</Th>
                      <Th></Th>
                    </tr>
                  </thead>
                  <tbody>
                    {s.indicators.map((i) => (
                      <tr key={i.code} className={i.code === detail ? "bg-bg-sunken" : undefined}>
                        <Td>
                          <p className={i.code.endsWith("_total") ? "font-medium text-ink" : ""}>{i.label}</p>
                          <p className="text-[12px] text-ink-3">{i.definition}</p>
                        </Td>
                        <Td num className={i.code.endsWith("_total") ? "font-medium" : undefined}>
                          {i.display}
                        </Td>
                        <Td num>{i.count}</Td>
                        <Td>
                          <Button asChild variant="ghost" size="sm">
                            <Link href={`/app/${orgId}/bpf?year=${year}&detail=${i.code}`}>Voir la liste</Link>
                          </Button>
                        </Td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
              ) : (
                <p className="px-5 py-5 text-[13px] text-ink-3">Aucune donnée pour {year}.</p>
              )}
            </Panel>
          ))}
        </div>
        <Panel className="self-start xl:sticky xl:top-6">
          <PanelHeader title={indicator ? indicator.label : "Détail d'un indicateur"} description={indicator ? `${indicator.display} · ${year}` : "Cliquez sur « Voir la liste » pour afficher la définition complète et les éléments composant l'indicateur."} />
          {indicator ? (
            <>
              <dl className="grid grid-cols-[max-content_1fr] gap-x-4 gap-y-2 border-b border-line px-5 py-4 text-[12.5px]">
                <dt className="font-mono text-[10px] uppercase tracking-[0.16em] text-ink-3">Définition</dt>
                <dd>{indicator.definition}</dd>
                <dt className="font-mono text-[10px] uppercase tracking-[0.16em] text-ink-3">Dénominateur</dt>
                <dd>{indicator.denominator}</dd>
                <dt className="font-mono text-[10px] uppercase tracking-[0.16em] text-ink-3">Exclusions</dt>
                <dd>{indicator.exclusions}</dd>
                <dt className="font-mono text-[10px] uppercase tracking-[0.16em] text-ink-3">Calculé le</dt>
                <dd className="num">{fmtDateTime(new Date(report.computedAt))}</dd>
              </dl>
              {rows.length ? (
                <ul className="max-h-[60dvh] divide-y divide-line overflow-y-auto text-[13px]">
                  {rows.map((r) => (
                    <li key={r.id} className="flex items-start justify-between gap-3 px-5 py-2.5">
                      <div className="min-w-0">
                        <Link href={r.href} className="text-ink hover:underline">
                          {r.label}
                        </Link>
                        <p className="truncate text-[12px] text-ink-3">{r.sub}</p>
                      </div>
                      <span className="num shrink-0 text-ink-2">{r.value}</span>
                    </li>
                  ))}
                </ul>
              ) : (
                <EmptyState title="Aucun élément" description="Aucune ligne ne compose cet indicateur pour l'année choisie." />
              )}
            </>
          ) : null}
        </Panel>
      </div>
    </>
  );
}
