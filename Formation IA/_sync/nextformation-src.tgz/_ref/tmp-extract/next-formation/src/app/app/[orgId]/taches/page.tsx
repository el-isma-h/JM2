import Link from "next/link";
import { guardOrg } from "@/server/guard";
import { myTasks, orgStaff, overdueCount, readTaskFilters } from "@/server/tasks/queries";
import { todayParis } from "@/lib/time";
import { Button } from "@/components/ui/button";
import { PageHeader, Panel, Stat } from "@/components/ui/surface";
import { FadeIn } from "@/components/ui/motion";
import { TaskTable } from "./_components/task-table";
import { TaskFiltersForm } from "./_components/task-filters";
import { CreateTaskDialog } from "./_components/create-task-dialog";

export const dynamic = "force-dynamic";

export default async function MyTasksPage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const ctx = await guardOrg(orgId, `/app/${orgId}/taches`);
  const sp = await searchParams;
  const f = readTaskFilters(sp);
  const today = todayParis();
  const [tasks, late, staff] = await Promise.all([myTasks(ctx, f), overdueCount(ctx), orgStaff(orgId)]);
  const staffMap = new Map(staff.map((s) => [s.id, s.name]));
  const blocked = tasks.filter((t) => t.status === "bloquee").length;
  const canCreate = ctx.permissions.has("tasks.manage");

  return (
    <FadeIn>
      <PageHeader
        title="Mes tâches"
        description="Tâches qui vous sont affectées, ou affectées à l'un de vos rôles sans responsable nommé. Prenez-les en charge, commentez, bloquez avec motif, réaffectez ou reportez : chaque action est tracée."
        actions={
          <>
            {ctx.permissions.has("tasks.view_all") ? (
              <Button asChild variant="secondary">
                <Link href={`/app/${orgId}/taches/supervision`}>Supervision</Link>
              </Button>
            ) : null}
            {canCreate ? <CreateTaskDialog orgId={orgId} staff={staff} /> : null}
          </>
        }
      />
      <Panel className="mb-6">
        <div className="grid grid-cols-2 gap-x-6 gap-y-5 px-5 py-5 md:grid-cols-4">
          <Stat label="Ouvertes" value={tasks.filter((t) => t.status !== "terminee" && t.status !== "annulee").length} hint={`au ${today.split("-").reverse().join("/")}`} />
          <Stat label="En retard" value={<Link href={`/app/${orgId}/taches?late=1`} className={late ? "text-danger-ink hover:underline" : "hover:underline"}>{late}</Link>} hint="échéance dépassée" />
          <Stat label="Bloquées" value={<Link href={`/app/${orgId}/taches?status=bloquee`} className="hover:underline">{blocked}</Link>} hint="prérequis ou décision en attente" />
          <Stat label="Pour mes rôles" value={tasks.filter((t) => !t.assigneeUserId).length} hint="sans responsable nommé" />
        </div>
      </Panel>
      <Panel>
        <TaskFiltersForm f={f} />
        <TaskTable tasks={tasks} orgId={orgId} staff={staffMap} today={today} emptyTitle="Aucune tâche à traiter" emptyDescription="Rien ne vous est affecté avec ces filtres. Les relais automatiques (pièces manquantes, convocations, financements) apparaîtront ici." />
      </Panel>
    </FadeIn>
  );
}
