"use client";

import * as React from "react";
import { ActionForm } from "@/components/admin/action-form";
import { Field, Input } from "@/components/ui/field";
import { exportPersonDataAction, searchPersonsAction } from "@/server/actions/settings";

export function RgpdExport({ orgId }: { orgId: string }) {
  const [q, setQ] = React.useState("");
  const [results, setResults] = React.useState<{ id: string; label: string }[]>([]);
  const [chosen, setChosen] = React.useState<{ id: string; label: string } | null>(null);
  React.useEffect(() => {
    if (q.trim().length < 2) return;
    let cancelled = false;
    const h = setTimeout(async () => {
      const fd = new FormData();
      fd.set("orgId", orgId);
      fd.set("q", q);
      const r = await searchPersonsAction({}, fd);
      if (cancelled) return;
      try {
        setResults(JSON.parse(r.data?.results ?? "[]"));
      } catch {
        setResults([]);
      }
    }, 250);
    return () => {
      cancelled = true;
      clearTimeout(h);
    };
  }, [q, orgId]);
  return (
    <ActionForm action={exportPersonDataAction} submitLabel="Générer l'export" submitVariant="secondary" className="max-w-2xl space-y-4" footerClassName="pt-1" confirm={{ title: "Générer l'export RGPD", description: chosen ? `Un fichier ZIP sera généré pour ${chosen.label} et journalisé.` : "Choisissez d'abord une personne.", confirmLabel: "Générer" }}>
      <input type="hidden" name="orgId" value={orgId} />
      <input type="hidden" name="personId" value={chosen?.id ?? ""} />
      <Field label="Personne" htmlFor="rg-q" help={chosen ? `Sélectionnée : ${chosen.label}` : "Nom, prénom ou e-mail (deux caractères minimum)."}>
        <Input id="rg-q" value={q} onChange={(e) => {
                setQ(e.target.value);
                if (e.target.value.trim().length < 2) setResults([]);
              }} autoComplete="off" />
        {results.length ? (
          <ul className="mt-1 max-h-40 overflow-y-auto border border-line-strong bg-bg-elev text-[13px]" role="listbox">
            {results.map((r) => (
              <li key={r.id}>
                <button
                  type="button"
                  role="option"
                  aria-selected={chosen?.id === r.id}
                  className="block w-full px-3 py-1.5 text-left hover:bg-bg-sunken"
                  onClick={() => {
                    setChosen(r);
                    setResults([]);
                    setQ(r.label);
                  }}
                >
                  {r.label}
                </button>
              </li>
            ))}
          </ul>
        ) : null}
      </Field>
      <Field label="Motif de la demande" htmlFor="rg-reason" required help="Demande de la personne, référence du courrier, date.">
        <Input id="rg-reason" name="reason" required />
      </Field>
    </ActionForm>
  );
}
