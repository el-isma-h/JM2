import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight } from "@phosphor-icons/react/dist/ssr";
import { PageHero, btnEncre, btnOsContour } from "@/components/marketing/site";
import { FAMILLE } from "@/lib/marketing-data";
import { publisher } from "@/lib/legal";
import { breadcrumbJsonLd, jsonLdScript, pageMeta } from "@/lib/seo";

export const metadata: Metadata = pageMeta("/a-propos", "À propos", "Next Formation est un produit de la famille Next Capital, aux côtés de Next RH, Next Optimisation, Next Ads et Next Bank : des logiciels français qui rendent les règles compréhensibles et les protections prouvables.");
export const dynamic = "force-dynamic";

function Fill({ value, label }: { value: string; label: string }) {
  return value ? <>{value}</> : <span className="bg-warn-soft px-1 text-warn-ink">[À compléter : {label}]</span>;
}

export default function AProposPage() {
  const p = publisher();
  return (
    <article>
      <script type="application/ld+json" dangerouslySetInnerHTML={jsonLdScript(breadcrumbJsonLd([{ name: "Accueil", path: "/" }, { name: "À propos", path: "/a-propos" }]))} />
      <PageHero crumbs={[{ label: "Accueil", href: "/" }, { label: "À propos" }]} eyebrow="La maison" title="Un produit de la famille Next Capital." description="Des logiciels français construits sur la même conviction : les règles métier doivent être compréhensibles, et les protections prouvables sur le serveur, pas seulement promises dans l'interface." filigrane="N" />

      <section className="conteneur grid gap-12 py-16 lg:grid-cols-[1fr_1fr] lg:py-24">
        <div>
          <h2 className="text-[26px] sm:text-[32px]">Pourquoi Next Formation</h2>
          <div className="mt-6 space-y-4 text-[15px] leading-relaxed text-ink-2">
            <p>Les organismes de formation et les CFA vivent avec des règles précises : heures distinctes selon leur statut, périodes d&apos;émargement verrouillées, preuves qualité reliées aux actions réelles, droits qui dépendent du rôle et du dossier. Les outils généralistes les contournent ; les outils historiques les figent.</p>
            <p>Next Formation reprend ces règles telles qu&apos;elles sont écrites dans les cahiers des charges métier et les fait respecter par le serveur. L&apos;interface reste sobre, en français, avec une prochaine action claire sur chaque dossier.</p>
            <p>Le prix suit la même logique de transparence : 90 % du prix public de référence, source et date affichées sur chaque ligne.</p>
          </div>
        </div>
        <div>
          <h2 className="text-[26px] sm:text-[32px]">La famille</h2>
          <ul className="mt-6 border-t border-line-strong">
            <li className="grid gap-1 border-b border-line py-4 sm:grid-cols-[180px_1fr]">
              <span className="font-display text-[15px] font-medium text-accent">Next Formation</span>
              <span className="text-[13.5px] text-ink-2">Gestion d&apos;organismes de formation et de CFA</span>
            </li>
            {FAMILLE.map((f) => (
              <li key={f.name} className="grid gap-1 border-b border-line py-4 sm:grid-cols-[180px_1fr]">
                <span className="font-display text-[15px] font-medium">{f.name}</span>
                <span className="text-[13.5px] text-ink-2">{f.d}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="border-t border-line bg-bg-sunken">
        <div className="conteneur grid gap-12 py-16 lg:grid-cols-[0.8fr_1.2fr] lg:py-24">
          <h2 className="text-[26px] sm:text-[32px]">L&apos;éditeur</h2>
          <dl className="grid gap-x-8 gap-y-3 border-t border-line-strong pt-6 text-[14.5px] sm:grid-cols-[220px_1fr]">
            <dt className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">Raison sociale</dt>
            <dd><Fill value={p.name} label="raison sociale" />{p.form ? `, ${p.form}` : null}</dd>
            <dt className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">SIREN</dt>
            <dd><Fill value={p.siren} label="SIREN" /></dd>
            <dt className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">Siège</dt>
            <dd><Fill value={p.address} label="adresse du siège" /></dd>
            <dt className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">Directeur de la publication</dt>
            <dd><Fill value={p.director} label="directeur de la publication" /></dd>
            <dt className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">Contact</dt>
            <dd>{p.email ? <a href={`mailto:${p.email}`} className="text-accent hover:underline">{p.email}</a> : <Fill value="" label="adresse de contact" />}</dd>
          </dl>
        </div>
      </section>

      <section className="conteneur flex flex-wrap items-center justify-between gap-6 py-14">
        <p className="max-w-[52ch] text-[15px] text-ink-2">Une question sur le produit, un partenariat, une reprise de données depuis un autre outil ?</p>
        <div className="flex flex-wrap gap-3">
          <Link href="/contact" className={btnEncre}>
            Nous écrire <ArrowRight size={14} />
          </Link>
          <Link href="/mentions-legales" className={btnOsContour}>
            Mentions légales
          </Link>
        </div>
      </section>
    </article>
  );
}
