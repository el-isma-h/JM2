import { guardLearner } from "@/server/extranet/guard";
import { attendanceForEnrollment } from "@/server/extranet/queries";
import { uploadJustificationAction } from "@/server/actions/self";
import { NoAttachment } from "@/components/extranet/shell";
import { HoursStats, hhmm, partLabels } from "@/components/extranet/ui";
import { UploadDialog } from "@/components/extranet/upload-dialog";
import { StatusBadge } from "@/components/ui/badge";
import { EmptyState, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { fmtDate } from "@/lib/dates";
import { fmtMinutes } from "@/lib/time";

export const dynamic = "force-dynamic";

const justifiable = ["absent", "retard", "depart_anticipe", "retard_et_depart", "excuse"];

export default async function LearnerAttendance() {
  const ctx = await guardLearner("/moi/presences");
  if (!ctx) return <NoAttachment kind="learner" />;
  const data = await Promise.all(ctx.enrollments.map(async (e) => ({ e, ...(await attendanceForEnrollment(ctx.org.id, e.enrollment.id, e.enrollment.hoursPlanned, e.enrollment.legacyHours)) })));
  return (
    <>
      <PageHeader
        title="Mes présences"
        description="Présences par période telles qu'enregistrées par l'organisme. Heures prévues, programmées, effectuées et justifiées sont des compteurs distincts : ils ne s'additionnent pas."
      />
      <div className="space-y-6">
        {data.map(({ e, rows, hours }) => (
          <Panel key={e.enrollment.id}>
            <PanelHeader title={e.program?.title ?? e.session.title} description={`Session ${e.session.code}`} />
            <HoursStats hours={hours} />
            {hours.legacy ? (
              <Notice tone="info" className="mx-5 mb-4">
                Solde historique (anciennes feuilles d&apos;émargement, non réconcilié) : <span className="num">{fmtMinutes(hours.legacy)}</span>. Il est conservé à part et n&apos;est jamais ajouté aux heures effectuées.
              </Notice>
            ) : null}
            {rows.length ? (
              <Table className="border-t border-line">
                <thead>
                  <tr>
                    <Th>Date</Th>
                    <Th>Période</Th>
                    <Th>Présence</Th>
                    <Th num>Heures comptées</Th>
                    <Th>Période</Th>
                    <Th className="text-right">Justificatif</Th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((r) => (
                    <tr key={r.attendance.id}>
                      <Td className="num whitespace-nowrap">{fmtDate(r.slotDate)}</Td>
                      <Td className="num whitespace-nowrap">
                        {partLabels[r.period.part] ?? r.period.part} {hhmm(r.period.startTime)} - {hhmm(r.period.endTime)}
                      </Td>
                      <Td>
                        <StatusBadge status={r.attendance.status} />
                        {r.attendance.status === "retard" && r.attendance.arrivedAt ? <span className="num ml-2 text-[12px] text-ink-3">arrivée {hhmm(r.attendance.arrivedAt)}</span> : null}
                        {r.attendance.status === "depart_anticipe" && r.attendance.leftAt ? <span className="num ml-2 text-[12px] text-ink-3">départ {hhmm(r.attendance.leftAt)}</span> : null}
                      </Td>
                      <Td num>{fmtMinutes(r.attendance.minutesCounted)}</Td>
                      <Td>
                        <StatusBadge status={r.period.status} />
                      </Td>
                      <Td className="text-right">
                        {r.attendance.justificationDocumentId ? (
                          <span className="text-[12.5px] text-ink-3">Justificatif reçu</span>
                        ) : justifiable.includes(r.attendance.status) ? (
                          <UploadDialog
                            action={uploadJustificationAction}
                            trigger="Déposer un justificatif"
                            title="Justificatif d'absence"
                            description={`${fmtDate(r.slotDate)}, ${partLabels[r.period.part] ?? r.period.part}. L'organisme examine le justificatif et décide si l'absence est justifiée ; la présence n'est pas modifiée automatiquement.`}
                            fields={{ attendanceId: r.attendance.id }}
                            withNote={{ label: "Message (facultatif)", help: "Précisez le motif si utile." }}
                          />
                        ) : (
                          <span className="text-[12.5px] text-ink-3">-</span>
                        )}
                      </Td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            ) : (
              <EmptyState className="border-t border-line" title="Aucune présence enregistrée" description="Les présences apparaissent après chaque période émargée." />
            )}
          </Panel>
        ))}
        {!data.length ? (
          <Panel>
            <EmptyState title="Aucune inscription" description="Aucune inscription n'est rattachée à votre dossier." />
          </Panel>
        ) : null}
      </div>
    </>
  );
}
