import { NextResponse, type NextRequest } from "next/server";
import { safeEqual } from "@/lib/crypto";
import { runDueJobs } from "@/server/jobs/runner";

export const dynamic = "force-dynamic";

/**
 * Déclencheur des tâches de fond. À appeler toutes les minutes par un planificateur externe :
 *   curl -fsS -X POST -H "x-cron-secret: $CRON_SECRET" https://<hôte>/api/cron
 * (`Authorization: Bearer <CRON_SECRET>` est aussi accepté).
 */
async function handle(req: NextRequest) {
  const secret = process.env.CRON_SECRET;
  if (!secret || secret.length < 16) {
    return NextResponse.json({ error: "CRON_SECRET non configuré (16 caractères minimum) : le déclencheur est désactivé." }, { status: 503 });
  }
  const provided = req.headers.get("x-cron-secret") ?? req.headers.get("authorization")?.replace(/^Bearer\s+/i, "") ?? "";
  if (!provided || !safeEqual(provided, secret)) return NextResponse.json({ error: "Non autorisé." }, { status: 401 });
  const limit = Math.min(50, Math.max(1, Number(req.nextUrl.searchParams.get("limit") ?? 10) || 10));
  const report = await runDueJobs({ limit });
  return NextResponse.json({ ok: true, ...report });
}

export const POST = handle;
export const GET = handle;
