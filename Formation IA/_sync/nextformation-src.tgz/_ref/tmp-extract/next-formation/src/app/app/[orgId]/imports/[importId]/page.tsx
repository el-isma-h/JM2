import Link from "next/link";
import { notFound } from "next/navigation";
import { and, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { IMPORT_KINDS, isImportKind } from "@/server/imports/kinds";
import type { RowDuplicate, RowError } from "@/server/imports/service";
import { fmtDateTime } from "@/lib/dates";
import { ActionForm } from "@/components/admin/action-form";
import { NavActionForm } from "@/components/sessions/nav-action-form";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Select } from "@/components/ui/field";
import { Notice, PageHeader, Panel, PanelHeader, Stat } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FadeIn } from "@/components/ui/motion";
import { applyImportAction, deleteImportAction, mapImportAction } from "@/server/actions/imports";

export const dynamic = "force-dynamic";

export default async function ImportDetailPage({ params }: { params: Promise<{ orgId: string; importId: string }> }) {
  const { orgId, importId } = await params;
  const base = `/app/${orgId}/imports`;
  const ctx = await guardOrg(orgId, `${base}/${importId}`, "enrollments.manage");
  if (ctx.trainerOnly || !/^[0-9a-f-]{36}$/i.test(importId)) notFound();
  const [imp] = await db.select().from(schema.dataImports).where(and(eq(schema.dataImports.id, importId), eq(schema.dataImports.orgId, orgId))).limit(1);
  if (!imp || !isImportKind(imp.kind)) notFound();
  const def = IMPORT_KINDS[imp.kind];
  const preview = imp.preview as { headers: string[]; sample: Record<string, string>[]; total: number; truncated?: boolean };
  const mapping = imp.mapping as Record<string, string>;
  const errors = imp.errors as RowError[];
  const duplicates = imp.duplicates as RowDuplicate[];
  const badRows = new Set([...errors.map((e) => e.row), ...duplicates.map((d) => d.row)]);
  const ready = Math.max(0, preview.total - badRows.size);
  const step = imp.status === "applied" ? 4 : imp.status === "validated" ? 3 : 2;

  return (
    <FadeIn>
      <PageHeader
        title={`Import : ${def.label}`}
        breadcrumb={[{ label: "Imports et exports", href: base }, { label: imp.fileName }]}
        description={
          <span className="flex flex-wrap items-center gap-2">
            <StatusBadge status={imp.status} />
            <span>
              {imp.fileName} · déposé le {fmtDateTime(imp.createdAt)} · <span className="num">{preview.total}</span> ligne(s)
              {preview.truncated ? " (tronqué à 5 000)" : ""}
            </span>
          </span>
        }
        actions={
          imp.status !== "applied" ? (
            <NavActionForm action={deleteImportAction} submitLabel="Abandonner l'import" submitVariant="danger" confirm={{ title: "Abandonner cet import", description: "Le fichier lu est supprimé ; rien n'a été écrit dans les données.", danger: true }}>
              <input type="hidden" name="orgId" value={orgId} />
              <input type="hidden" name="importId" value={imp.id} />
            </NavActionForm>
          ) : null
        }
      />
      <ol className="mb-6 grid gap-px bg-line sm:grid-cols-4">
        {["Dépôt", "Association des colonnes", "Validation", "Application"].map((label, i) => (
          <li key={label} className={`bg-bg-elev px-4 py-3 font-mono text-[10.5px] uppercase tracking-[0.18em] ${i + 1 <= step ? "text-ink" : "text-ink-3"}`}>
            <span className="num mr-2">{i + 1}.</span>
            {label}
            {i + 1 < step ? <span className="ml-2 text-ok-ink">fait</span> : i + 1 === step ? <span className="ml-2 text-accent">en cours</span> : null}
          </li>
        ))}
      </ol>

      <div className="grid gap-6 lg:grid-cols-[1fr_1fr]">
        <Panel>
          <PanelHeader title="2. Association des colonnes" description={`Faites correspondre chaque champ attendu à une colonne du fichier. Doublons : ${def.duplicateRule.toLowerCase()}`} />
          <div className="p-5">
            {imp.status === "applied" ? (
              <dl className="grid grid-cols-[max-content_1fr] gap-x-6 gap-y-2 text-[13.5px]">
                {def.fields.map((f) => (
                  <div key={f.key} className="contents">
                    <dt className="font-mono text-[10px] uppercase tracking-[0.16em] text-ink-3">{f.label}</dt>
                    <dd>{mapping[f.key] ?? <span className="text-ink-3">non associé</span>}</dd>
                  </div>
                ))}
              </dl>
            ) : (
              <ActionForm action={mapImportAction} submitLabel={imp.status === "validated" ? "Revalider" : "Valider les lignes"} footerClassName="mt-4">
                <input type="hidden" name="orgId" value={orgId} />
                <input type="hidden" name="importId" value={imp.id} />
                <div className="grid gap-3 sm:grid-cols-2">
                  {def.fields.map((f) => (
                    <Field key={f.key} label={f.label} required={f.required} htmlFor={`map-${f.key}`} help={f.hint}>
                      <Select id={`map-${f.key}`} name={`map_${f.key}`} defaultValue={mapping[f.key] ?? ""}>
                        <option value="">Non importé</option>
                        {preview.headers.map((h) => (
                          <option key={h} value={h}>
                            {h}
                          </option>
                        ))}
                      </Select>
                    </Field>
                  ))}
                </div>
              </ActionForm>
            )}
          </div>
        </Panel>
        <div className="space-y-6">
          <Panel>
            <PanelHeader title="Aperçu du fichier" description="Cinq premières lignes telles que lues." />
            <Table>
              <thead>
                <tr>
                  {preview.headers.map((h) => (
                    <Th key={h}>{h}</Th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {preview.sample.map((r, i) => (
                  <tr key={i}>
                    {preview.headers.map((h) => (
                      <Td key={h} className="max-w-[16ch] truncate">
                        {r[h]}
                      </Td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </Table>
          </Panel>
          {imp.status === "validated" || imp.status === "applied" || imp.status === "failed" ? (
            <Panel>
              <PanelHeader title={imp.status === "applied" ? "4. Résultat" : "3. Validation"} />
              <div className="grid grid-cols-3 gap-6 p-5">
                <Stat label={imp.status === "applied" ? "Appliquées" : "Prêtes"} value={<span className="num">{imp.status === "applied" ? imp.appliedCount : ready}</span>} />
                <Stat label="Erreurs" value={<span className="num">{errors.length}</span>} />
                <Stat label="Doublons" value={<span className="num">{duplicates.length}</span>} hint="jamais fusionnés" />
              </div>
              {imp.status === "validated" ? (
                <div className="border-t border-line p-5">
                  {ready === 0 ? (
                    <Notice tone="warn">Aucune ligne applicable : corrigez le fichier ou l&apos;association des colonnes.</Notice>
                  ) : (
                    <ActionForm action={applyImportAction} submitLabel={`Appliquer ${ready} ligne(s)`} confirm={{ title: "Appliquer l'import", description: `${ready} ligne(s) seront créées. Les ${badRows.size} ligne(s) en erreur ou en doublon sont ignorées et restent listées. Les lignes sont revalidées juste avant l'écriture.`, checkbox: { name: "understood", label: "J'ai vérifié l'association des colonnes et la liste des doublons." }, confirmLabel: "Appliquer" }}>
                      <input type="hidden" name="orgId" value={orgId} />
                      <input type="hidden" name="importId" value={imp.id} />
                    </ActionForm>
                  )}
                </div>
              ) : null}
              {imp.status === "applied" ? (
                <div className="border-t border-line p-5">
                  <Notice tone="ok">
                    Import appliqué le {fmtDateTime(imp.appliedAt)} : {imp.appliedCount} ligne(s).{" "}
                    <Link href={`/app/${orgId}/${{ entreprises: "entreprises", contacts: "contacts", personnes: "candidats", inscriptions: "inscriptions", heures: "inscriptions" }[imp.kind]}`} className="underline">
                      Voir les données
                    </Link>
                  </Notice>
                </div>
              ) : null}
            </Panel>
          ) : null}
        </div>
      </div>

      {duplicates.length ? (
        <Panel className="mt-6">
          <PanelHeader title="Doublons détectés" description="Listés et ignorés à l'application : à traiter à la main (fusion jamais automatique, T03)." />
          <Table>
            <thead>
              <tr>
                <Th num>Ligne</Th>
                <Th>Raison</Th>
                <Th>Enregistrement existant</Th>
              </tr>
            </thead>
            <tbody>
              {duplicates.slice(0, 300).map((d, i) => (
                <tr key={i}>
                  <Td num>{d.row}</Td>
                  <Td>{d.reason}</Td>
                  <Td>
                    {d.existingId ? (
                      <Link href={existingHref(orgId, imp.kind, d.existingId)} className="hover:underline">
                        {d.label ?? d.existingId}
                      </Link>
                    ) : (
                      <Badge>dans le fichier</Badge>
                    )}
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Panel>
      ) : null}
      {errors.length ? (
        <Panel className="mt-6">
          <PanelHeader title="Erreurs par ligne" description="Ces lignes ne sont pas importées. Corrigez le fichier puis déposez-le à nouveau." />
          <Table>
            <thead>
              <tr>
                <Th num>Ligne</Th>
                <Th>Champ</Th>
                <Th>Erreur</Th>
              </tr>
            </thead>
            <tbody>
              {errors.slice(0, 300).map((e, i) => (
                <tr key={i}>
                  <Td num>{e.row}</Td>
                  <Td>{e.field ? (def.fields.find((f) => f.key === e.field)?.label ?? e.field) : "-"}</Td>
                  <Td>{e.message}</Td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Panel>
      ) : null}
      <div className="mt-6">
        <Button asChild variant="ghost" size="sm">
          <Link href={base}>Retour aux imports</Link>
        </Button>
      </div>
    </FadeIn>
  );
}

function existingHref(orgId: string, kind: string, id: string): string {
  switch (kind) {
    case "entreprises":
      return `/app/${orgId}/entreprises/${id}`;
    case "contacts":
      return `/app/${orgId}/contacts`;
    case "personnes":
      return `/app/${orgId}/apprenants/${id}`;
    default:
      return `/app/${orgId}/inscriptions/${id}`;
  }
}
