import Link from "next/link";
import { guardOrg } from "@/server/guard";
import { aiStatus } from "@/server/ai/provider";
import { getConversation, listConversations, listMessages } from "@/server/ai/assistant";
import { agentsForEntity } from "@/server/ai/agents";
import { listProposals } from "@/server/ai/store";
import { availableTools, enrollmentSummary } from "@/server/ai/tools";
import { deterministicDossier } from "@/server/ai/agents/dossier";
import { integrationLabels } from "@/lib/env";
import { readParam } from "@/components/admin/pagination";
import { AssistantChat } from "@/components/ai/chat";
import { ProposeButton, type ProposeAgent } from "@/components/ai/propose-button";
import { ProgrammeFields } from "@/components/ai/programme-fields";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";

export const dynamic = "force-dynamic";

const entityLabels: Record<string, string> = { enrollment: "Inscription", session: "Session", company: "Entreprise", document: "Document", invoice: "Facture", program: "Formation", survey_response: "Enquête" };

/** Assistant IA : conversation avec outils en lecture seule, contexte optionnel (?entityType=…&entityId=…), agents en « Proposer ». */
export default async function AssistantPage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const ctx = await guardOrg(orgId, `/app/${orgId}/assistant`);
  const sp = await searchParams;
  const convId = readParam(sp.c);
  const conv = convId ? await getConversation(ctx, convId) : null;
  const convContext = (conv?.context ?? {}) as { entityType?: string | null; entityId?: string | null };
  const entityType = convContext.entityType ?? readParam(sp.entityType) ?? null;
  const rawEntityId = convContext.entityId ?? readParam(sp.entityId) ?? null;
  const entityId = rawEntityId && /^[0-9a-f-]{36}$/i.test(rawEntityId) ? rawEntityId : null;
  const [status, conversations, messages, pending] = await Promise.all([Promise.resolve(aiStatus()), listConversations(ctx), conv ? listMessages(conv.id) : Promise.resolve([]), listProposals(ctx.org.id, ["proposee"], 50)]);
  const agents = agentsForEntity(ctx, entityType);
  const tools = availableTools(ctx);
  const summary = entityType === "enrollment" && entityId ? await enrollmentSummary(ctx, entityId) : null;
  const det = summary ? deterministicDossier(summary as Parameters<typeof deterministicDossier>[0]) : null;
  const base = `/app/${orgId}`;
  const suggestions = entityId
    ? ["Où en est ce dossier et que manque-t-il ?", "Quelles sont les tâches ouvertes et leur responsable ?", "Quel est l'état du financement ?"]
    : ["Quelles inscriptions ont des pièces manquantes ?", "Quelles tâches sont bloquées cette semaine ?", "Résume la session en cours la plus proche"];

  return (
    <>
      <PageHeader
        title="Assistant IA"
        description="L'assistant lit les données selon vos habilitations et ne modifie rien. Toute action (envoi, génération, création) passe par une proposition validée par un humain."
        actions={
          <Button asChild variant="secondary">
            <Link href={`${base}/assistant/propositions`}>
              Propositions en attente {pending.length ? <Badge tone="warn">{pending.length}</Badge> : null}
            </Link>
          </Button>
        }
      />

      {!status.configured ? (
        <Notice tone="warn" className="mb-6" title="Assistant non configuré : réponses libres indisponibles">
          {status.explanation} Variables : {integrationLabels.ai.envVars.join(", ")}. {integrationLabels.ai.effect}
        </Notice>
      ) : (
        <p className="mb-6 font-mono text-[10px] uppercase tracking-[0.16em] text-ink-3">
          Fournisseur : {status.label} · modèle {status.model} · outils de lecture : {tools.map((t) => t.name).join(", ") || "aucun"}
        </p>
      )}

      <div className="grid gap-6 lg:grid-cols-[1fr_300px]">
        <div className="space-y-6">
          {entityType && entityId ? (
            <Panel>
              <PanelHeader
                title={`Contexte : ${entityLabels[entityType] ?? entityType}`}
                description={summary ? `${(summary as { person: { firstName: string; lastName: string } }).person.firstName} ${(summary as { person: { firstName: string; lastName: string } }).person.lastName} · ${(summary as { session: { title: string } }).session.title}` : entityId}
                actions={
                  <Button asChild variant="ghost" size="sm">
                    <Link href={`${base}/assistant`}>Sans contexte</Link>
                  </Button>
                }
              />
              {det ? (
                <div className="px-5 py-4">
                  <p className="whitespace-pre-line text-[13.5px] text-ink-2">{det.text}</p>
                </div>
              ) : null}
              {agents.length ? (
                <div className="flex flex-wrap gap-2 border-t border-line px-5 py-4">
                  {agents.map((a) => (
                    <ProposeButton key={a.name} orgId={orgId} agent={a.name as ProposeAgent} entityType={entityType} entityId={entityId} label={`Proposer : ${a.label}`} back={`${base}/assistant?entityType=${entityType}&entityId=${entityId}`} />
                  ))}
                </div>
              ) : null}
            </Panel>
          ) : null}

          <Panel>
            <AssistantChat
              orgId={orgId}
              conversationId={conv?.id ?? null}
              messages={messages.map((m) => ({ id: m.id, role: m.role, content: m.content, meta: (m.meta ?? {}) as Record<string, unknown>, provider: m.provider, createdAt: m.createdAt.toISOString() }))}
              entityType={entityType}
              entityId={entityId}
              suggestions={suggestions}
              agentsAvailable={agents.map((a) => a.name as ProposeAgent)}
              placeholder={status.configured ? "Ex. : où en est l'inscription de Camille Aubert ? Quelles pièces manquent ?" : "Sans clé IA : « inscription <nom> » recherche un dossier ; le résumé est disponible depuis un dossier."}
            />
          </Panel>
        </div>

        <div className="space-y-6">
          <Panel>
            <PanelHeader title="Actions déterministes" description="Disponibles avec ou sans clé IA." />
            <div className="space-y-3 px-5 py-4 text-[13px] text-ink-2">
              <p>Depuis un dossier : « Analyser avec l&apos;assistant » (résumé, relance, document). Depuis une session : calendrier, synthèse qualité. Depuis le catalogue : proposition de programme.</p>
              {ctx.permissions.has("quality.view") ? <ProposeButton orgId={orgId} agent="qualite" entityType="organisme" label="Synthèse qualité de l'organisme" /> : null}
              {ctx.permissions.has("catalog.manage") ? (
                <details className="border border-line px-3 py-2">
                  <summary className="cursor-pointer text-[12.5px] text-ink">Proposer un programme à partir d&apos;un titre</summary>
                  <ProgrammeFields orgId={orgId} />
                </details>
              ) : null}
            </div>
          </Panel>
          <Panel>
            <PanelHeader title="Conversations récentes" />
            {conversations.length ? (
              <ul className="divide-y divide-line">
                {conversations.map((c) => (
                  <li key={c.id}>
                    <Link href={`${base}/assistant?c=${c.id}`} className={`block px-5 py-2.5 text-[13px] hover:bg-bg-sunken ${conv?.id === c.id ? "text-ink" : "text-ink-2"}`}>
                      <span className="line-clamp-1">{c.title ?? "Conversation"}</span>
                      <span className="num block text-[11px] text-ink-3">{c.updatedAt.toLocaleDateString("fr-FR")}</span>
                    </Link>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="px-5 py-4 text-[12.5px] text-ink-3">Aucune conversation.</p>
            )}
            {conv ? (
              <div className="border-t border-line px-5 py-3">
                <Button asChild variant="ghost" size="sm">
                  <Link href={`${base}/assistant`}>Nouvelle conversation</Link>
                </Button>
              </div>
            ) : null}
          </Panel>
        </div>
      </div>
    </>
  );
}
