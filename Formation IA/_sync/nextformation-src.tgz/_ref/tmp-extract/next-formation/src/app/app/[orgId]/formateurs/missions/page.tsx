import Link from "next/link";
import { guardOrg } from "@/server/guard";
import { countMissions, listMissions, missionFormOptions } from "@/server/missions/queries";
import { missionCounts } from "@/server/missions/service";
import { MISSION_STATUS_LABELS } from "@/server/missions/rules";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/field";
import { Notice, PageHeader, Panel, Stat } from "@/components/ui/surface";
import { Pagination, readPage, readParam } from "@/components/admin/pagination";
import { MissionsTable, ProposeMissionDialog } from "@/components/missions/mission-ui";

export const dynamic = "force-dynamic";
const PAGE = 50;

/**
 * Missions formateurs : proposition (e-mail « Proposition de mission »), réponses, relances à 5 jours ouvrés,
 * remplacement en l'absence de réponse et contrat de prestation. Un formateur seul ne voit que ses missions.
 */
export default async function MissionsPage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const base = `/app/${orgId}`;
  const ctx = await guardOrg(orgId, `${base}/formateurs/missions`, "planning.view");
  const sp = await searchParams;
  const status = readParam(sp.statut);
  const q = readParam(sp.q);
  const page = readPage(sp.page);
  // Périmètre formateur : un formateur seul ne voit que ses propres missions, quel que soit le filtre.
  const scopedTrainer = ctx.trainerOnly ? (ctx.trainerId ?? "00000000-0000-0000-0000-000000000000") : (readParam(sp.formateur) ?? null);
  const trainerFilter = scopedTrainer && /^[0-9a-f-]{36}$/i.test(scopedTrainer) ? scopedTrainer : null;

  const canManage = ctx.permissions.has("planning.manage") && !ctx.trainerOnly;
  const canGenerate = canManage && ctx.permissions.has("documents.generate");
  const canDownload = ctx.permissions.has("documents.view");
  const filters = { status, trainerId: ctx.trainerOnly ? scopedTrainer : trainerFilter, q };
  const [rows, total, counts, options] = await Promise.all([
    listMissions(ctx.org.id, { ...filters, limit: PAGE, offset: (page - 1) * PAGE }),
    countMissions(ctx.org.id, filters),
    missionCounts(ctx.org.id, ctx.trainerOnly ? scopedTrainer : null),
    missionFormOptions(ctx.org.id, { excludeTrainerId: ctx.trainerId }),
  ]);
  const waiting = (counts.proposee ?? 0) + (counts.sans_reponse ?? 0);
  const statLink = (s: string) => `${base}/formateurs/missions?statut=${s}`;

  return (
    <>
      <PageHeader
        breadcrumb={[{ label: "Formation" }, { label: "Formateurs", href: `${base}/formateurs` }, { label: "Missions" }]}
        title="Missions formateurs"
        description="Proposition de mission, réponse du formateur, relance après 5 jours ouvrés, remplacement et contrat de prestation."
        actions={canManage ? <ProposeMissionDialog orgId={ctx.org.id} options={options} /> : null}
      />
      {(counts.sans_reponse ?? 0) || (counts.refusee ?? 0) ? (
        <Notice tone="warn" title="Prochaine action" className="mb-6">
          {counts.sans_reponse ? `${counts.sans_reponse} mission(s) sans réponse` : ""}
          {counts.sans_reponse && counts.refusee ? " et " : ""}
          {counts.refusee ? `${counts.refusee} mission(s) refusée(s)` : ""} : mobilisez un autre formateur avec « Remplacer ».
        </Notice>
      ) : null}
      <Panel className="mb-6">
        <div className="grid grid-cols-2 gap-6 px-5 py-5 sm:grid-cols-4">
          <Link href={statLink("proposee")} className="hover:opacity-80">
            <Stat label="En attente de réponse" value={<span className="num">{waiting}</span>} />
          </Link>
          <Link href={statLink("acceptee")} className="hover:opacity-80">
            <Stat label="Acceptées" value={<span className="num">{counts.acceptee ?? 0}</span>} />
          </Link>
          <Link href={statLink("sans_reponse")} className="hover:opacity-80">
            <Stat label="Sans réponse" value={<span className="num">{counts.sans_reponse ?? 0}</span>} hint="à remplacer" />
          </Link>
          <Link href={statLink("terminee")} className="hover:opacity-80">
            <Stat label="Terminées" value={<span className="num">{counts.terminee ?? 0}</span>} />
          </Link>
        </div>
      </Panel>
      <Panel>
        <form method="get" className="flex flex-wrap items-end gap-3 border-b border-line px-5 py-3">
          <Field label="Recherche" htmlFor="q" className="w-full max-w-xs">
            <Input id="q" name="q" defaultValue={q} placeholder="Thème, formateur, apprenant, session" />
          </Field>
          <Field label="Statut" htmlFor="statut" className="w-48">
            <Select id="statut" name="statut" defaultValue={status ?? ""}>
              <option value="">Tous</option>
              {Object.entries(MISSION_STATUS_LABELS).map(([v, l]) => (
                <option key={v} value={v}>
                  {l}
                </option>
              ))}
            </Select>
          </Field>
          {!ctx.trainerOnly ? (
            <Field label="Formateur" htmlFor="formateur" className="w-56">
              <Select id="formateur" name="formateur" defaultValue={trainerFilter ?? ""}>
                <option value="">Tous</option>
                {options.trainers.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.lastName} {t.firstName}
                  </option>
                ))}
              </Select>
            </Field>
          ) : null}
          <Button type="submit" variant="secondary">
            Filtrer
          </Button>
        </form>
        <MissionsTable
          orgId={ctx.org.id}
          rows={rows}
          canManage={canManage}
          canGenerate={canGenerate}
          canDownload={canDownload}
          ownTrainerId={ctx.trainerId}
          trainers={options.trainers}
          emptyTitle="Aucune mission"
          emptyDescription={status || q || trainerFilter ? "Aucun résultat pour ces filtres." : canManage ? "Proposez une mission à un formateur : thème, dates, heures avec formateur et taux horaire." : "Les missions qui vous sont proposées apparaîtront ici."}
        />
        <Pagination basePath={`${base}/formateurs/missions`} params={{ statut: status, q, formateur: ctx.trainerOnly ? undefined : (trainerFilter ?? undefined) }} page={page} pageSize={PAGE} total={total} />
      </Panel>
    </>
  );
}
