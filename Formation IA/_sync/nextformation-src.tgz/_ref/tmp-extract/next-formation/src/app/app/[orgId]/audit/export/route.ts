import { NextResponse, type NextRequest } from "next/server";
import { desc, eq } from "drizzle-orm";
import Papa from "papaparse";
import { db, schema } from "@/db";
import { AuthError } from "@/server/auth";
import { audit } from "@/server/audit";
import { requireSecurityAdmin } from "@/server/security/access";
import { orgAuditWhere, readOrgAuditFilters } from "@/server/security/audit-query";

export const dynamic = "force-dynamic";
const MAX_ROWS = 50_000;

/** Export CSV du journal de l'organisme : propriétaire actif + exports.run (renforcé). */
export async function GET(req: NextRequest, { params }: { params: Promise<{ orgId: string }> }) {
  const { orgId } = await params;
  let ctx;
  try {
    ctx = await requireSecurityAdmin(orgId);
    if (!ctx.permissions.has("exports.run")) throw new AuthError("forbidden");
  } catch (e) {
    const status = e instanceof AuthError && e.code === "unauthenticated" ? 401 : 403;
    return NextResponse.json({ error: "Export réservé au propriétaire actif avec session renforcée." }, { status });
  }
  const f = readOrgAuditFilters(Object.fromEntries(req.nextUrl.searchParams));
  const rows = await db.select({ a: schema.auditLogs, email: schema.users.email }).from(schema.auditLogs).leftJoin(schema.users, eq(schema.users.id, schema.auditLogs.userId)).where(orgAuditWhere(orgId, f)).orderBy(desc(schema.auditLogs.createdAt)).limit(MAX_ROWS);
  const csv = Papa.unparse(
    rows.map(({ a, email }) => ({ date: a.createdAt.toISOString(), action: a.action, utilisateur_id: a.userId ?? "", utilisateur_email: email ?? "", objet_type: a.entityType ?? "", objet_id: a.entityId ?? "", avant: a.before === null ? "" : JSON.stringify(a.before), apres: a.after === null ? "" : JSON.stringify(a.after), ip: a.ip ?? "" })),
    { delimiter: ";", escapeFormulae: true },
  );
  await audit({ action: "audit.export", userId: ctx.user.id, orgId, entityType: "audit_logs", after: { filters: f, rows: rows.length } });
  return new NextResponse(`﻿${csv}`, { headers: { "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": `attachment; filename="journal-audit-${new Date().toISOString().slice(0, 10)}.csv"`, "Cache-Control": "no-store" } });
}
