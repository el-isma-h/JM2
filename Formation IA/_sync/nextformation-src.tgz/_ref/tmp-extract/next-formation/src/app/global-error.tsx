"use client";

import "./globals.css";

export default function GlobalError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <html lang="fr">
      <body className="flex min-h-[100dvh] flex-col items-start justify-center gap-6 bg-bg px-5 text-ink sm:px-16">
        <p className="etiquette">Erreur</p>
        <h1 className="titre-geant text-[40px] sm:text-[60px]">Next Formation est momentanément indisponible.</h1>
        <p className="max-w-[56ch] text-[15px] text-ink-2">Réessayez dans un instant.</p>
        {error.digest ? <p className="font-mono text-[12px] text-ink-3">Référence : {error.digest}</p> : null}
        <button onClick={reset} className="h-10 border border-ink bg-ink px-4 text-[11px] font-medium uppercase tracking-[0.18em] text-bg">
          Réessayer
        </button>
      </body>
    </html>
  );
}
