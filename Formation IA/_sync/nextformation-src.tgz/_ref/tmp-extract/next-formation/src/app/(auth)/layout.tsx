import Link from "next/link";
import { FiletMarque, Logo } from "@/components/ui/logo";

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="grid min-h-[100dvh] lg:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)]">
      <aside className="hidden flex-col justify-between bg-encre p-10 text-os lg:flex">
        <Link href="/" aria-label="Next Formation">
          <Logo clair />
        </Link>
        <div className="max-w-[46ch]">
          <p className="etiquette !text-os/50">Formation, apprentissage, qualité</p>
          <p className="titre-geant mt-6 text-[40px] xl:text-[52px]">
            Tout le métier,
            <br />
            un seul dossier.
          </p>
          <p className="mt-6 font-serif text-[22px] italic leading-snug text-os/75">
            Du premier contact à la clôture : inscriptions, émargement par demi-journée, documents, financements et preuves qualité reliées aux actions réelles. Pour les organismes de formation et les CFA.
          </p>
        </div>
        <div className="flex flex-wrap items-center justify-between gap-4 font-mono text-[10px] uppercase tracking-[0.2em] text-os/40">
          <FiletMarque />
          <span>Données sensibles chiffrées au repos</span>
        </div>
      </aside>
      <main className="flex items-center justify-center px-5 py-12">
        <div className="w-full max-w-md">
          <Link href="/" className="mb-10 block lg:hidden" aria-label="Next Formation">
            <Logo />
          </Link>
          {children}
          <p className="mt-12 flex flex-wrap gap-4 font-mono text-[10px] uppercase tracking-[0.16em] text-ink-3">
            <Link href="/cgu" className="hover:text-ink">Conditions</Link>
            <Link href="/confidentialite" className="hover:text-ink">Confidentialité</Link>
            <Link href="/mentions-legales" className="hover:text-ink">Mentions légales</Link>
          </p>
        </div>
      </main>
    </div>
  );
}
