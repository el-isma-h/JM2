import Link from "next/link";
import { guardOrg } from "@/server/guard";
import { filterVisible } from "@/server/documents/queries";
import { listSignatureRequests, SIGNER_ROLE_LABELS, signersOf } from "@/server/documents/signatures";
import { cancelSignatureRequestAction, resendSignatureAction } from "@/server/actions/signatures";
import { integrations, integrationLabels } from "@/lib/env";
import { fmtDateTime } from "@/lib/dates";
import { ActionButton } from "@/components/admin/action-form";
import { readParam } from "@/components/admin/pagination";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Select } from "@/components/ui/field";
import { EmptyState, Notice, PageHeader, Panel } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FadeIn } from "@/components/ui/motion";

export const dynamic = "force-dynamic";
const STATUSES = ["envoyee", "signee_partiellement", "signee", "non_configure", "refusee", "expiree", "annulee"] as const;

export default async function SignaturesPage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const ctx = await guardOrg(orgId, `/app/${orgId}/signatures`, "documents.view");
  const sp = await searchParams;
  const status = readParam(sp.status);
  const rows = await listSignatureRequests(orgId, { status: status && (STATUSES as readonly string[]).includes(status) ? status : null });
  const visibleDocs = new Set((await filterVisible(ctx, rows.map((r) => r.doc))).map((d) => d.id));
  const visible = rows.filter((r) => visibleDocs.has(r.doc.id));
  const canManage = ctx.permissions.has("documents.generate");
  const esign = integrations.esign();
  const pending = visible.filter((r) => r.r.status === "envoyee" || r.r.status === "signee_partiellement").length;

  return (
    <FadeIn>
      <PageHeader
        title="Signatures"
        description="Demandes de signature électronique des documents du parcours. Une demande se crée depuis la fiche d'un document PDF généré ou transmis."
        actions={
          <Button asChild variant="secondary">
            <Link href={`/app/${orgId}/documents`}>Documents</Link>
          </Button>
        }
      />
      <Notice tone={esign ? "ok" : "info"} className="mb-4">
        {esign
          ? `Prestataire externe configuré : ${process.env.ESIGN_PROVIDER}. Les demandes passent par l'adaptateur correspondant.`
          : `Signature interne active (lien personnel, consentement, code par e-mail, horodatage serveur, page de preuve). ${integrationLabels.esign.label} externe non configurée : variables ${integrationLabels.esign.envVars.join(", ")}.`}
        {!integrations.mail() ? " E-mail non configuré : les liens et codes sont affichés à l'écran au lieu d'être envoyés." : ""}
      </Notice>
      <Panel>
        <form method="get" className="flex flex-wrap items-end gap-3 border-b border-line px-5 py-3">
          <Field label="Statut" htmlFor="status" className="w-52">
            <Select id="status" name="status" defaultValue={status ?? ""}>
              <option value="">Tous ({visible.length})</option>
              {STATUSES.map((s) => (
                <option key={s} value={s}>
                  {{ envoyee: "Envoyée", signee_partiellement: "Signée partiellement", signee: "Signée", non_configure: "Non configuré", refusee: "Refusée", expiree: "Expirée", annulee: "Annulée" }[s]}
                </option>
              ))}
            </Select>
          </Field>
          <Button type="submit" variant="secondary">
            Filtrer
          </Button>
          <span className="mb-2 ml-auto text-[12.5px] text-ink-3">{pending} demande(s) en attente</span>
        </form>
        {visible.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Document</Th>
                <Th>Signataires</Th>
                <Th>Statut</Th>
                <Th>Créée</Th>
                <Th>Expire</Th>
                <Th></Th>
              </tr>
            </thead>
            <tbody>
              {visible.map(({ r, doc }) => {
                const signers = signersOf(r);
                return (
                  <tr key={r.id}>
                    <Td>
                      <Link href={`/app/${orgId}/documents/${doc.id}`} className="font-medium text-ink hover:underline">
                        {doc.title}
                      </Link>
                      {r.signedDocumentId ? (
                        <p className="text-[12px]">
                          <Link href={`/app/${orgId}/documents/${r.signedDocumentId}`} className="underline">
                            PDF signé
                          </Link>
                        </p>
                      ) : null}
                    </Td>
                    <Td>
                      <ul className="space-y-0.5 text-[12.5px]">
                        {signers.map((s) => (
                          <li key={s.id}>
                            {s.name} <span className="text-ink-3">({SIGNER_ROLE_LABELS[s.role] ?? s.role})</span> {s.signedAt ? <Badge tone="ok">Signé</Badge> : <Badge tone="warn">Attente</Badge>}
                          </li>
                        ))}
                      </ul>
                    </Td>
                    <Td>
                      <StatusBadge status={r.status} />
                    </Td>
                    <Td className="whitespace-nowrap text-[12.5px]">{fmtDateTime(r.createdAt)}</Td>
                    <Td className="whitespace-nowrap text-[12.5px]">{r.expiresAt ? fmtDateTime(r.expiresAt) : "-"}</Td>
                    <Td>
                      {canManage && r.provider === "interne" && (r.status === "envoyee" || r.status === "signee_partiellement") ? (
                        <div className="flex justify-end gap-2">
                          <ActionButton action={resendSignatureAction} fields={{ orgId, requestId: r.id }} label="Relancer" />
                          <ActionButton action={cancelSignatureRequestAction} fields={{ orgId, requestId: r.id }} label="Annuler" variant="danger" confirm={{ title: "Annuler la demande", description: "Les liens envoyés ne fonctionneront plus.", input: { name: "reason", label: "Motif" }, confirmLabel: "Annuler la demande", danger: true }} />
                        </div>
                      ) : null}
                    </Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucune demande de signature" description="Ouvrez un document PDF généré et utilisez « Demander une signature »." action={<Button asChild><Link href={`/app/${orgId}/documents`}>Voir les documents</Link></Button>} />
        )}
      </Panel>
    </FadeIn>
  );
}
