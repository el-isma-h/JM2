import { NextResponse, type NextRequest } from "next/server";
import Papa from "papaparse";
import { requireOrg } from "@/server/authz";
import { AuthError } from "@/server/auth";
import { audit } from "@/server/audit";
import { dashboardMetrics } from "@/server/pilotage/metrics";
import { definedIndicators } from "@/server/pilotage/indicators";
import { resolvePeriod } from "@/server/pilotage/period";
import { todayParis } from "@/lib/time";
import { formatMetric } from "@/components/dashboard/metric-card";

export const dynamic = "force-dynamic";

/** Export CSV des indicateurs de pilotage (exports.run : session renforcée). */
export async function GET(req: NextRequest, { params }: { params: Promise<{ orgId: string }> }) {
  const { orgId } = await params;
  let ctx;
  try {
    ctx = await requireOrg(orgId, "dashboards.view", "exports.run");
  } catch (e) {
    const status = e instanceof AuthError && e.code === "unauthenticated" ? 401 : 403;
    return NextResponse.json({ error: e instanceof AuthError && e.code === "elevation_required" ? "Vérification renforcée requise pour exporter." : "Accès refusé." }, { status });
  }
  const today = todayParis();
  const period = resolvePeriod(Object.fromEntries(req.nextUrl.searchParams), today);
  const [{ groups, updatedAt }, indicators] = await Promise.all([dashboardMetrics(ctx, period, today), definedIndicators(orgId, period)]);
  const rows = [
    ...groups.flatMap((g) => g.metrics.map((m) => ({ groupe: g.title, indicateur: m.label, valeur: m.unit === "cents" ? (m.value / 100).toFixed(2) : m.unit === "hours" ? (m.value / 60).toFixed(2) : String(m.value), unite: m.unit === "cents" ? "EUR" : m.unit === "hours" ? "heures" : "nombre", affichage: formatMetric(m), perimetre: m.scope, filtre: m.filter, periode_debut: period.from, periode_fin: period.to, mise_a_jour: updatedAt.toISOString() }))),
    ...indicators.map((i) => ({ groupe: "Indicateurs à définition explicite", indicateur: i.label, valeur: i.value === null ? "" : String(i.value), unite: "%", affichage: i.value === null ? "non calculable" : `${i.value} %`, perimetre: `${i.numerator} / ${i.denominator}`, filtre: `${i.definition} Exclusions : ${i.exclusions}.`, periode_debut: period.from, periode_fin: period.to, mise_a_jour: updatedAt.toISOString() })),
  ];
  const csv = Papa.unparse(rows, { delimiter: ";", escapeFormulae: true });
  await audit({ action: "pilotage.export", userId: ctx.user.id, orgId, entityType: "pilotage", after: { period, rows: rows.length } });
  return new NextResponse(`﻿${csv}`, { headers: { "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": `attachment; filename="pilotage-${period.from}-${period.to}.csv"`, "Cache-Control": "no-store" } });
}
