import Link from "next/link";
import { guardLearner } from "@/server/extranet/guard";
import { enrollmentStatusLabels } from "@/server/extranet/context";
import { attendanceForEnrollment, listPieces, listSlotsForSessions, listSurveys, nextSlotForSessions } from "@/server/extranet/queries";
import { NoAttachment } from "@/components/extranet/shell";
import { hhmm, partLabels } from "@/components/extranet/ui";
import { StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { EmptyState, KeyValue, Notice, PageHeader, Panel, PanelHeader, Stat } from "@/components/ui/surface";
import { fmtDate } from "@/lib/dates";
import { fmtMinutes, todayParis } from "@/lib/time";

export const dynamic = "force-dynamic";

export default async function LearnerHome() {
  const ctx = await guardLearner("/moi");
  if (!ctx) return <NoAttachment kind="learner" />;

  const sessionIds = [...new Set(ctx.enrollments.map((e) => e.session.id))];
  const [next, pieces, surveys, past] = await Promise.all([
    nextSlotForSessions(ctx.org.id, sessionIds),
    listPieces(ctx.org.id, ctx.enrollmentIds, ["apprenant"]),
    listSurveys(ctx.org.id, { enrollmentIds: ctx.enrollmentIds }),
    listSlotsForSessions(ctx.org.id, sessionIds, { to: todayParis() }),
  ]);
  const hours = await Promise.all(ctx.enrollments.map((e) => attendanceForEnrollment(ctx.org.id, e.enrollment.id, e.enrollment.hoursPlanned, e.enrollment.legacyHours)));
  const piecesToProvide = pieces.filter((p) => p.submission.status === "attendue" || p.submission.status === "refusee");
  const pendingSurveys = surveys.filter((s) => !s.response.submittedAt && s.survey.status === "active");
  const doneSlots = past.filter((s) => s.slot.status !== "annulee").length;

  return (
    <>
      <PageHeader
        title={`Bonjour ${ctx.person.firstName}`}
        description={`Votre parcours chez ${ctx.org.tradeName ?? ctx.org.legalName} : inscriptions, prochaine séance, pièces à fournir et progression.`}
      />

      {piecesToProvide.length || pendingSurveys.length ? (
        <div className="mb-8 space-y-3">
          {piecesToProvide.length ? (
            <Notice tone="warn" title={`${piecesToProvide.length} pièce${piecesToProvide.length > 1 ? "s" : ""} à fournir`}>
              {piecesToProvide.map((p) => p.piece.label).join(", ")}.{" "}
              <Link href="/moi/pieces" className="font-medium underline underline-offset-4">
                Déposer mes pièces
              </Link>
            </Notice>
          ) : null}
          {pendingSurveys.length ? (
            <Notice tone="info" title={`${pendingSurveys.length} enquête${pendingSurveys.length > 1 ? "s" : ""} en attente de votre réponse`}>
              <Link href="/moi/enquetes" className="font-medium underline underline-offset-4">
                Répondre
              </Link>
            </Notice>
          ) : null}
        </div>
      ) : null}

      <div className="grid gap-6 lg:grid-cols-3">
        <Panel className="lg:col-span-2">
          <PanelHeader title="Mes inscriptions" description="Chaque inscription correspond à une session. Les statuts sont ceux enregistrés par l'organisme." />
          {ctx.enrollments.length ? (
            <ul className="divide-y divide-line">
              {ctx.enrollments.map((e, i) => {
                const h = hours[i].hours;
                const pct = h.planned ? Math.min(100, Math.round((h.done / h.planned) * 100)) : null;
                return (
                  <li key={e.enrollment.id} className="px-5 py-5">
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div className="min-w-0">
                        <p className="font-medium text-ink">{e.program?.title ?? e.session.title}</p>
                        <p className="mt-0.5 text-[12.5px] text-ink-3">
                          Session {e.session.code} · du {fmtDate(e.enrollment.startDate ?? e.session.startDate)} au {fmtDate(e.enrollment.endDate ?? e.session.endDate)}
                          {e.group ? ` · groupe ${e.group.name}` : ""}
                        </p>
                      </div>
                      <StatusBadge status={e.enrollment.status} />
                    </div>
                    <p className="mt-2 text-[13px] text-ink-2">{enrollmentStatusLabels[e.enrollment.status] ?? e.enrollment.status}</p>
                    <div className="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-4">
                      <Stat label="Progression" value={<StatusBadge status={e.enrollment.progression} />} />
                      <Stat label="Heures effectuées" value={<span className="num">{fmtMinutes(h.done)}</span>} hint={h.planned ? `sur ${fmtMinutes(h.planned)} prévues` : "durée prévue non renseignée"} />
                      <Stat label="Absences justifiées" value={<span className="num">{fmtMinutes(h.justified)}</span>} />
                      <Stat label="Avancement" value={<span className="num">{pct === null ? "-" : `${pct} %`}</span>} hint="heures effectuées / prévues" />
                    </div>
                    {pct !== null ? (
                      <div className="mt-3 h-1 w-full bg-bg-sunken" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100} aria-label="Avancement des heures">
                        <div className="h-1 bg-accent" style={{ width: `${pct}%` }} />
                      </div>
                    ) : null}
                  </li>
                );
              })}
            </ul>
          ) : (
            <EmptyState title="Aucune inscription" description="Aucune inscription n'est rattachée à votre dossier pour le moment." />
          )}
        </Panel>

        <div className="space-y-6">
          <Panel>
            <PanelHeader title="Prochaine séance" />
            {next ? (
              <div className="px-5 py-5">
                <p className="font-display text-[22px] font-light uppercase tracking-[0.04em] text-ink">{fmtDate(next.slot.date, "EEEE d MMMM")}</p>
                <KeyValue
                  className="mt-4"
                  items={[
                    { k: "Session", v: next.sessionTitle },
                    { k: "Horaires", v: next.periods.length ? next.periods.map((p) => `${partLabels[p.part] ?? p.part} ${hhmm(p.startTime)} - ${hhmm(p.endTime)}`).join(" · ") : "à préciser" },
                    { k: "Lieu", v: next.siteName ?? (next.slot.modality === "distanciel" ? "À distance" : "-") },
                    { k: "Formateur", v: next.trainerName ?? "-" },
                  ]}
                />
                <Button asChild variant="secondary" size="sm" className="mt-5">
                  <Link href="/moi/planning">Voir tout mon planning</Link>
                </Button>
              </div>
            ) : (
              <EmptyState title="Aucune séance à venir" description="Le planning sera visible ici dès que l'organisme l'aura publié." />
            )}
          </Panel>
          <Panel>
            <PanelHeader title="En un coup d'œil" />
            <div className="grid grid-cols-2 gap-5 px-5 py-5">
              <Stat label="Séances passées" value={<span className="num">{doneSlots}</span>} />
              <Stat label="Pièces à fournir" value={<span className="num">{piecesToProvide.length}</span>} />
            </div>
          </Panel>
        </div>
      </div>
    </>
  );
}
