import { and, desc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { canEditSettings } from "@/server/security/rules";
import { formatObjectiveTarget, OBJECTIVE_METRICS } from "@/server/pilotage/objectives";
import { deleteObjectiveAction, saveObjectiveAction } from "@/server/actions/settings";
import { fmtDate } from "@/lib/dates";
import { todayParis } from "@/lib/time";
import { Field, Input, Select } from "@/components/ui/field";
import { EmptyState, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FadeIn } from "@/components/ui/motion";
import { ActionButton } from "@/components/admin/action-form";
import { FormDialog } from "@/components/admin/form-dialog";

export const dynamic = "force-dynamic";

export default async function ObjectivesPage({ params }: { params: Promise<{ orgId: string }> }) {
  const { orgId } = await params;
  const ctx = await guardOrg(orgId, `/app/${orgId}/pilotage/objectifs`, "dashboards.view");
  const canEdit = canEditSettings(ctx);
  const rows = await db.select().from(schema.objectives).where(and(eq(schema.objectives.orgId, orgId))).orderBy(desc(schema.objectives.periodStart));
  const today = todayParis();
  const year = today.slice(0, 4);

  const form = (o?: (typeof rows)[number]) => (
    <>
      <input type="hidden" name="orgId" value={orgId} />
      {o ? <input type="hidden" name="id" value={o.id} /> : null}
      <Field label="Indicateur" htmlFor="ob-metric">
        <Select id="ob-metric" name="metric" defaultValue={o?.metric ?? "enrollments_started"}>
          {OBJECTIVE_METRICS.map((m) => (
            <option key={m.key} value={m.key}>
              {m.label} ({m.unit === "cents" ? "€" : m.unit === "percent" ? "%" : m.unit === "hours" ? "heures" : "nombre"})
            </option>
          ))}
        </Select>
      </Field>
      <div className="grid gap-4 sm:grid-cols-3">
        <Field label="Début" htmlFor="ob-start" required>
          <Input id="ob-start" name="periodStart" type="date" defaultValue={o?.periodStart ?? `${year}-01-01`} required className="num" />
        </Field>
        <Field label="Fin" htmlFor="ob-end" required>
          <Input id="ob-end" name="periodEnd" type="date" defaultValue={o?.periodEnd ?? `${year}-12-31`} required className="num" />
        </Field>
        <Field label="Cible" htmlFor="ob-target" required help="Nombre, heures, euros ou pourcentage selon l'indicateur.">
          <Input id="ob-target" name="target" defaultValue={o ? (o.unit === "cents" ? (o.target / 100).toFixed(2).replace(".", ",") : String(o.target)) : ""} required className="num" inputMode="decimal" />
        </Field>
      </div>
    </>
  );

  return (
    <FadeIn>
      <PageHeader
        breadcrumb={[{ label: "Pilotage", href: `/app/${orgId}/pilotage` }, { label: "Objectifs" }]}
        title="Objectifs"
        description="Cibles paramétrables par période. Un objectif est affiché à côté des indicateurs comme une cible : il n'est jamais présenté comme un résultat mesuré."
        actions={canEdit ? <FormDialog action={saveObjectiveAction} trigger="Nouvel objectif" title="Nouvel objectif" submitLabel="Enregistrer">{form()}</FormDialog> : null}
      />
      {!canEdit ? <Notice tone="info" className="mb-6">Lecture seule : la direction ou le propriétaire paramètre les objectifs.</Notice> : null}
      <Panel>
        <PanelHeader title="Objectifs paramétrés" />
        {rows.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Indicateur</Th>
                <Th>Période</Th>
                <Th num>Cible</Th>
                {canEdit ? <Th /> : null}
              </tr>
            </thead>
            <tbody>
              {rows.map((o) => (
                <tr key={o.id}>
                  <Td className="font-medium">{o.label}</Td>
                  <Td className="whitespace-nowrap">
                    {fmtDate(o.periodStart)} au {fmtDate(o.periodEnd)}
                  </Td>
                  <Td num>{formatObjectiveTarget(o.target, o.unit)}</Td>
                  {canEdit ? (
                    <Td className="text-right">
                      <div className="flex justify-end gap-2">
                        <FormDialog action={saveObjectiveAction} trigger="Modifier" triggerVariant="ghost" triggerSize="sm" title={`Modifier : ${o.label}`} submitLabel="Enregistrer">
                          {form(o)}
                        </FormDialog>
                        <ActionButton action={deleteObjectiveAction} fields={{ orgId, id: o.id }} label="Supprimer" variant="ghost" confirm={{ title: "Supprimer l'objectif", description: `${o.label}, ${fmtDate(o.periodStart)} au ${fmtDate(o.periodEnd)}.`, confirmLabel: "Supprimer", danger: true }} />
                      </div>
                    </Td>
                  ) : null}
                </tr>
              ))}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucun objectif" description="Définissez des cibles par période : entrées en formation, heures, encaissements, satisfaction, réussite…" />
        )}
      </Panel>
    </FadeIn>
  );
}
