import type { Metadata } from "next";
import { asc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { Home } from "@/components/marketing/home";
import { SITE, homeJsonLd, jsonLdScript } from "@/lib/seo";

export const metadata: Metadata = {
  title: { absolute: SITE.title },
  description: SITE.description,
  alternates: { canonical: "/" },
  openGraph: { type: "website", locale: SITE.locale, siteName: SITE.name, title: SITE.title, description: SITE.description, url: "/" },
};
export const dynamic = "force-dynamic";

export default async function HomePage() {
  const plans = await db.select().from(schema.pricingPlans).where(eq(schema.pricingPlans.isActive, true)).orderBy(asc(schema.pricingPlans.sortOrder));
  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={jsonLdScript(homeJsonLd(plans))} />
      <Home plans={plans} />
    </>
  );
}
