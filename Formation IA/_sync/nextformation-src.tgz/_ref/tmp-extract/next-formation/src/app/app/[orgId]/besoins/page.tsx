import Link from "next/link";
import { and, desc, eq, ilike, or, sql, type SQL } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { createNeedAction, setNeedStageAction } from "@/server/actions/crm";
import { isOverdue, listStaffUsers, userNames } from "@/server/crm/queries";
import { todayParis } from "@/lib/time";
import { fmtDate } from "@/lib/dates";
import { formatCents } from "@/lib/money";
import { cn } from "@/lib/utils";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/field";
import { EmptyState, PageHeader, Panel } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FormDialog } from "@/components/admin/form-dialog";
import { Pagination, readPage, readParam } from "@/components/admin/pagination";
import { NeedFields, needKindLabels, needStageLabels } from "@/components/crm/fields";
import { NextActionCell } from "@/components/crm/next-action";
import { StageSelect } from "@/components/crm/stage-select";

export const dynamic = "force-dynamic";
const PAGE = 50;
const STAGES = schema.needStageEnum.enumValues;

export default async function NeedsPage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const base = `/app/${orgId}`;
  const ctx = await guardOrg(orgId, `${base}/besoins`, "crm.view");
  const sp = await searchParams;
  const vue = readParam(sp.vue) === "tableau" ? "tableau" : "kanban";
  const q = readParam(sp.q);
  const assigned = readParam(sp.assigned);
  const kind = readParam(sp.kind);
  const stage = readParam(sp.stage);
  const page = readPage(sp.page);
  const today = todayParis();
  const canManage = ctx.permissions.has("crm.manage");

  const conds: SQL[] = [eq(schema.needs.orgId, ctx.org.id)];
  if (q) conds.push(or(ilike(schema.needs.title, `%${q}%`), ilike(schema.companies.name, `%${q}%`), ilike(schema.persons.lastName, `%${q}%`))!);
  if (assigned && /^[0-9a-f-]{36}$/i.test(assigned)) conds.push(eq(schema.needs.assignedUserId, assigned));
  if (kind && (schema.needKindEnum.enumValues as readonly string[]).includes(kind)) conds.push(eq(schema.needs.kind, kind as "formation"));
  if (vue === "tableau" && stage && (STAGES as readonly string[]).includes(stage)) conds.push(eq(schema.needs.stage, stage as "nouveau"));
  const where = and(...conds);

  const selectBase = () =>
    db
      .select({ n: schema.needs, companyName: schema.companies.name, personFirst: schema.persons.firstName, personLast: schema.persons.lastName, programTitle: schema.programs.title, placements: sql<number>`(select count(*)::int from ${schema.placements} p where p.need_id = "needs"."id")` })
      .from(schema.needs)
      .leftJoin(schema.companies, eq(schema.companies.id, schema.needs.companyId))
      .leftJoin(schema.persons, eq(schema.persons.id, schema.needs.personId))
      .leftJoin(schema.programs, eq(schema.programs.id, schema.needs.programId))
      .where(where)
      .orderBy(desc(schema.needs.updatedAt));

  const [rows, [{ total }], staff, companies, persons, programs, contacts] = await Promise.all([
    vue === "tableau" ? selectBase().limit(PAGE).offset((page - 1) * PAGE) : selectBase().limit(400),
    db.select({ total: sql<number>`count(*)::int` }).from(schema.needs).leftJoin(schema.companies, eq(schema.companies.id, schema.needs.companyId)).leftJoin(schema.persons, eq(schema.persons.id, schema.needs.personId)).where(where),
    listStaffUsers(ctx.org.id),
    db.select({ id: schema.companies.id, name: schema.companies.name }).from(schema.companies).where(eq(schema.companies.orgId, ctx.org.id)).orderBy(schema.companies.name).limit(500),
    db.select({ id: schema.persons.id, firstName: schema.persons.firstName, lastName: schema.persons.lastName }).from(schema.persons).where(eq(schema.persons.orgId, ctx.org.id)).orderBy(schema.persons.lastName).limit(500),
    db.select({ id: schema.programs.id, name: schema.programs.title }).from(schema.programs).where(and(eq(schema.programs.orgId, ctx.org.id), eq(schema.programs.status, "actif"))).orderBy(schema.programs.title),
    db.select({ id: schema.contacts.id, firstName: schema.contacts.firstName, lastName: schema.contacts.lastName, companyName: schema.companies.name }).from(schema.contacts).leftJoin(schema.companies, eq(schema.companies.id, schema.contacts.companyId)).where(eq(schema.contacts.orgId, ctx.org.id)).orderBy(schema.contacts.lastName).limit(500),
  ]);
  const names = await userNames(rows.map((r) => r.n.assignedUserId));
  const who = (r: (typeof rows)[number]) => r.companyName ?? (r.personFirst ? `${r.personFirst} ${r.personLast}` : "Sans rattachement");
  const filterParams = { q, assigned, kind, stage: vue === "tableau" ? stage : undefined };
  const toggleHref = (v: "kanban" | "tableau") => {
    const u = new URLSearchParams();
    for (const [k, val] of Object.entries(filterParams)) if (val) u.set(k, val);
    if (v === "tableau") u.set("vue", "tableau");
    const s = u.toString();
    return `${base}/besoins${s ? `?${s}` : ""}`;
  };
  const moveOptions = STAGES.filter((s) => s !== "perdu").map((value) => ({ value, label: needStageLabels[value] }));
  const pipelineCents = rows.filter((r) => r.n.stage !== "perdu" && r.n.stage !== "gagne").reduce((a, r) => a + Math.round(((r.n.amountCents ?? 0) * r.n.probability) / 100), 0);

  return (
    <>
      <PageHeader
        title="Besoins et pipeline"
        description={`Suivi des besoins de formation et de recrutement. ${vue === "kanban" ? `Pondéré en cours : ${formatCents(pipelineCents)} HT.` : ""}`}
        actions={
          <>
            <div className="flex border border-line-strong">
              <Button asChild variant={vue === "kanban" ? "primary" : "ghost"} size="sm">
                <Link href={toggleHref("kanban")}>Kanban</Link>
              </Button>
              <Button asChild variant={vue === "tableau" ? "primary" : "ghost"} size="sm">
                <Link href={toggleHref("tableau")}>Tableau</Link>
              </Button>
            </div>
            {canManage ? (
              <FormDialog action={createNeedAction} trigger="Nouveau besoin" title="Nouveau besoin" submitLabel="Créer le besoin" wide>
                <NeedFields orgId={ctx.org.id} companies={companies} contacts={contacts.map((c) => ({ id: c.id, name: `${c.firstName} ${c.lastName}${c.companyName ? ` (${c.companyName})` : ""}` }))} persons={persons.map((p) => ({ id: p.id, name: `${p.firstName} ${p.lastName}` }))} programs={programs} staff={staff} />
              </FormDialog>
            ) : null}
          </>
        }
      />
      <Panel className="mb-6">
        <form method="get" className="flex flex-wrap items-end gap-3 px-5 py-3">
          {vue === "tableau" ? <input type="hidden" name="vue" value="tableau" /> : null}
          <Field label="Recherche" htmlFor="q" className="w-full max-w-xs">
            <Input id="q" name="q" defaultValue={q} placeholder="Intitulé, entreprise ou personne" />
          </Field>
          <Field label="Type" htmlFor="kind" className="w-40">
            <Select id="kind" name="kind" defaultValue={kind ?? ""}>
              <option value="">Tous</option>
              {Object.entries(needKindLabels).map(([v, l]) => (
                <option key={v} value={v}>
                  {l}
                </option>
              ))}
            </Select>
          </Field>
          {vue === "tableau" ? (
            <Field label="Étape" htmlFor="stage" className="w-40">
              <Select id="stage" name="stage" defaultValue={stage ?? ""}>
                <option value="">Toutes</option>
                {STAGES.map((s) => (
                  <option key={s} value={s}>
                    {needStageLabels[s]}
                  </option>
                ))}
              </Select>
            </Field>
          ) : null}
          <Field label="Commercial référent" htmlFor="assigned" className="w-56">
            <Select id="assigned" name="assigned" defaultValue={assigned ?? ""}>
              <option value="">Tous</option>
              {staff.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </Select>
          </Field>
          <Button type="submit" variant="secondary">
            Filtrer
          </Button>
        </form>
      </Panel>

      {vue === "kanban" ? (
        <div className="grid gap-4 md:grid-cols-3 xl:grid-cols-6">
          {STAGES.map((s) => {
            const col = rows.filter((r) => r.n.stage === s);
            const sum = col.reduce((a, r) => a + (r.n.amountCents ?? 0), 0);
            return (
              <section key={s} className="min-w-0 border border-line bg-bg-elev" aria-label={needStageLabels[s]}>
                <header className="flex items-center justify-between border-b border-line px-3 py-2.5">
                  <StatusBadge status={s} />
                  <span className="num text-[11px] text-ink-3">
                    {col.length} · {formatCents(sum)}
                  </span>
                </header>
                <div className="space-y-2 p-2">
                  {col.length ? (
                    col.map((r) => {
                      const overdue = s !== "gagne" && s !== "perdu" && isOverdue(r.n.nextActionAt, today);
                      return (
                        <article key={r.n.id} className={cn("border bg-bg p-3 text-[13px]", overdue ? "border-danger" : "border-line")}>
                          <Link href={`${base}/besoins/${r.n.id}`} className="font-medium text-ink hover:underline">
                            {r.n.title}
                          </Link>
                          <p className="mt-0.5 text-[12px] text-ink-2">{who(r)}</p>
                          <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-[12px] text-ink-3">
                            <span className="num">{formatCents(r.n.amountCents)}</span>
                            <span className="num">{r.n.probability} %</span>
                            <span className="num">{r.n.headcount} pers.</span>
                            {r.placements ? <span className="num">{r.placements} placement{r.placements > 1 ? "s" : ""}</span> : null}
                          </div>
                          {r.n.nextActionAt && s !== "gagne" && s !== "perdu" ? (
                            <p className={cn("mt-2 text-[12px]", overdue ? "font-medium text-danger-ink" : "text-ink-2")}>
                              {r.n.nextAction || "Prochaine action"} · <span className="num">{fmtDate(r.n.nextActionAt)}</span>
                              {overdue ? " (dépassée)" : ""}
                            </p>
                          ) : null}
                          {r.n.assignedUserId ? <p className="mt-1 text-[11px] text-ink-3">{names.get(r.n.assignedUserId)}</p> : null}
                          {canManage && s !== "perdu" ? <StageSelect action={setNeedStageAction} fields={{ orgId: ctx.org.id, needId: r.n.id }} name="stage" value={s} label={`Déplacer ${r.n.title}`} options={moveOptions} className="mt-2" /> : null}
                        </article>
                      );
                    })
                  ) : (
                    <p className="px-2 py-6 text-center text-[12px] text-ink-3">Aucun besoin</p>
                  )}
                </div>
              </section>
            );
          })}
        </div>
      ) : (
        <Panel>
          {rows.length ? (
            <Table>
              <thead>
                <tr>
                  <Th>Besoin</Th>
                  <Th>Entreprise / personne</Th>
                  <Th>Type</Th>
                  <Th>Étape</Th>
                  <Th num>Effectif</Th>
                  <Th num>Montant HT</Th>
                  <Th num>Prob.</Th>
                  <Th>Référent</Th>
                  <Th>Prochaine action</Th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.n.id}>
                    <Td>
                      <Link href={`${base}/besoins/${r.n.id}`} className="font-medium text-ink hover:underline">
                        {r.n.title}
                      </Link>
                      {r.programTitle ? <p className="text-[12px] text-ink-3">{r.programTitle}</p> : null}
                    </Td>
                    <Td>{who(r)}</Td>
                    <Td>
                      <Badge>{needKindLabels[r.n.kind]}</Badge>
                    </Td>
                    <Td>
                      <StatusBadge status={r.n.stage} />
                    </Td>
                    <Td num>{r.n.headcount}</Td>
                    <Td num>{formatCents(r.n.amountCents)}</Td>
                    <Td num>{r.n.probability} %</Td>
                    <Td>{r.n.assignedUserId ? names.get(r.n.assignedUserId) : <span className="text-ink-3">-</span>}</Td>
                    <Td>
                      <NextActionCell date={r.n.stage === "gagne" || r.n.stage === "perdu" ? null : r.n.nextActionAt} label={r.n.nextAction} overdue={isOverdue(r.n.nextActionAt, today)} />
                    </Td>
                  </tr>
                ))}
              </tbody>
            </Table>
          ) : (
            <EmptyState title="Aucun besoin" description="Créez un besoin depuis une fiche entreprise ou ici." />
          )}
          <Pagination basePath={`${base}/besoins`} params={{ ...filterParams, vue: "tableau" }} page={page} pageSize={PAGE} total={total} />
        </Panel>
      )}
    </>
  );
}
