import { NextResponse } from "next/server";
import { guardOrg } from "@/server/guard";
import { exportSalesJournal } from "@/server/finance/export";
import { todayParis } from "@/lib/time";

export const dynamic = "force-dynamic";

/**
 * Journal des ventes au format CSV (date ; pièce ; compte ; libellé ; débit ; crédit).
 * Export massif : permission `exports.run` (session renforcée). `mark=1` pose exportedAt + exportBatch.
 */
export async function GET(req: Request, { params }: { params: Promise<{ orgId: string }> }) {
  const { orgId } = await params;
  const url = new URL(req.url);
  const ctx = await guardOrg(orgId, `/app/${orgId}/factures/export?${url.searchParams.toString()}`, "finance.view", "exports.run");
  const iso = /^\d{4}-\d{2}-\d{2}$/;
  const year = todayParis().slice(0, 4);
  const from = iso.test(url.searchParams.get("from") ?? "") ? url.searchParams.get("from")! : `${year}-01-01`;
  const to = iso.test(url.searchParams.get("to") ?? "") ? url.searchParams.get("to")! : todayParis();
  if (from > to) return NextResponse.json({ error: "Période inversée." }, { status: 400 });
  const r = await exportSalesJournal({ orgId: ctx.org.id, from, to, onlyNew: url.searchParams.get("onlyNew") === "1", mark: url.searchParams.get("mark") === "1", userId: ctx.user.id, settings: ctx.org.settings });
  const name = `journal-ventes_${from}_${to}${r.batch ? `_${r.batch}` : ""}.csv`;
  return new NextResponse("﻿" + r.csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="${name}"`,
      "X-Invoice-Count": String(r.count),
      "Cache-Control": "no-store",
    },
  });
}
