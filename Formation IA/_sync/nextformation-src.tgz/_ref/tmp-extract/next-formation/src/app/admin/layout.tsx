import Link from "next/link";
import { guardAdmin } from "@/server/guard";
import { AppShell } from "@/components/app/shell";
import { Logo } from "@/components/ui/logo";
import { adminNav } from "@/components/app/nav";
import { Badge } from "@/components/ui/badge";

export const dynamic = "force-dynamic";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const user = await guardAdmin("/admin");
  return (
    <AppShell
      base="/admin"
      items={adminNav}
      brand={
        <Link href="/admin" className="flex items-center gap-3 text-ink">
          <Logo />
          <Badge tone="neutral">Administration</Badge>
        </Link>
      }
      context={
        <Link href="/app" className="block px-2 text-[12.5px] text-ink-3 hover:text-ink">
          Revenir à l&apos;espace de travail
        </Link>
      }
      user={{ name: `${user.firstName} ${user.lastName}`, email: user.email, isAdmin: true }}
    >
      {children}
    </AppShell>
  );
}
