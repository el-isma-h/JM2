import Link from "next/link";
import { and, desc, eq, inArray, isNull } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { trainerSessionIds } from "@/server/authz";
import { listTemplates, previewDocument, DEFAULT_VISIBILITY } from "@/server/documents/generate";
import { CATEGORY_LABELS, VISIBILITY_LABELS } from "@/server/documents/queries";
import type { TemplateQuestion } from "@/server/documents/templates-data";
import { generateDocumentAction } from "@/server/actions/documents";
import { fmtDate } from "@/lib/dates";
import { readParam } from "@/components/admin/pagination";
import { ActionForm } from "@/components/admin/action-form";
import { MarkdownPreview } from "@/components/documents/markdown-preview";
import { Button } from "@/components/ui/button";
import { Checkbox, Field, Input, Select, Textarea } from "@/components/ui/field";
import { Badge } from "@/components/ui/badge";
import { Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { FadeIn } from "@/components/ui/motion";

export const dynamic = "force-dynamic";
const isUuid = (v?: string) => Boolean(v && /^[0-9a-f-]{36}$/i.test(v));

export default async function NewDocumentPage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const base = `/app/${orgId}/documents`;
  const ctx = await guardOrg(orgId, `${base}/nouveau`, "documents.generate");
  const sp = await searchParams;
  const enrollmentId = readParam(sp.enrollmentId);
  const sessionId = readParam(sp.sessionId);
  const companyId = readParam(sp.companyId);
  const personId = readParam(sp.personId);
  const templateCode = readParam(sp.template);
  const scope = {
    enrollmentId: isUuid(enrollmentId) ? enrollmentId! : null,
    sessionId: isUuid(sessionId) ? sessionId! : null,
    companyId: isUuid(companyId) ? companyId! : null,
    personId: isUuid(personId) ? personId! : null,
  };
  const scopeKind = scope.enrollmentId ? "enrollment" : scope.sessionId ? "session" : scope.companyId ? "company" : scope.personId ? "person" : null;
  const answers: Record<string, string> = {};
  for (const [k, v] of Object.entries(sp)) if (k.startsWith("a.") && typeof v === "string" && v.trim()) answers[k.slice(2)] = v.trim();

  const trainerScope = await trainerSessionIds(ctx);
  const sessionCond = trainerScope ? (trainerScope.length ? inArray(schema.trainingSessions.id, trainerScope) : isNull(schema.trainingSessions.id)) : undefined;

  // Étape 1 : choix du dossier.
  if (!scopeKind) {
    const [enrollments, sessions] = await Promise.all([
      db
        .select({ id: schema.enrollments.id, reference: schema.enrollments.reference, firstName: schema.persons.firstName, lastName: schema.persons.lastName, sessionTitle: schema.trainingSessions.title })
        .from(schema.enrollments)
        .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
        .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.enrollments.sessionId))
        .where(and(eq(schema.enrollments.orgId, orgId), ...(sessionCond ? [sessionCond] : [])))
        .orderBy(desc(schema.enrollments.createdAt))
        .limit(300),
      db
        .select({ id: schema.trainingSessions.id, code: schema.trainingSessions.code, title: schema.trainingSessions.title, startDate: schema.trainingSessions.startDate })
        .from(schema.trainingSessions)
        .where(and(eq(schema.trainingSessions.orgId, orgId), ...(sessionCond ? [sessionCond] : [])))
        .orderBy(desc(schema.trainingSessions.startDate))
        .limit(300),
    ]);
    return (
      <FadeIn>
        <PageHeader breadcrumb={[{ label: "Documents", href: base }, { label: "Générer" }]} title="Générer un document" description="Choisissez d'abord le dossier concerné (inscription ou session) : les données et l'identité institutionnelle de cet organisme seront reprises." />
        <div className="grid gap-5 lg:grid-cols-2">
          <Panel>
            <PanelHeader title="Depuis une inscription" description="Convention, contrat, convocation, attestations, certificat, livret, annexe de parcours." />
            <form method="get" className="space-y-4 p-5">
              <Field label="Inscription" htmlFor="enrollmentId" required>
                <Select id="enrollmentId" name="enrollmentId" required defaultValue="">
                  <option value="">Choisir…</option>
                  {enrollments.map((e) => (
                    <option key={e.id} value={e.id}>
                      {e.lastName.toUpperCase()} {e.firstName} · {e.sessionTitle} ({e.reference})
                    </option>
                  ))}
                </Select>
              </Field>
              <Button type="submit">Continuer</Button>
            </form>
          </Panel>
          <Panel>
            <PanelHeader title="Depuis une session" description="Programme de formation, feuille d'émargement vierge." />
            <form method="get" className="space-y-4 p-5">
              <Field label="Session" htmlFor="sessionId" required>
                <Select id="sessionId" name="sessionId" required defaultValue="">
                  <option value="">Choisir…</option>
                  {sessions.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.code} · {s.title} ({fmtDate(s.startDate)})
                    </option>
                  ))}
                </Select>
              </Field>
              <Button type="submit">Continuer</Button>
            </form>
          </Panel>
        </div>
      </FadeIn>
    );
  }

  const templates = (await listTemplates(orgId)).filter((t) => t.scope === scopeKind || (scopeKind === "enrollment" && t.scope === "session"));
  const activityOk = (t: { activity: string }) => t.activity === "both" || ctx.org.kind === "of_cfa" || t.activity === ctx.org.kind;
  const scopeQuery = new URLSearchParams(Object.entries(scope).filter(([, v]) => v) as [string, string][]);

  // Étape 2 : choix du modèle.
  if (!templateCode) {
    return (
      <FadeIn>
        <PageHeader breadcrumb={[{ label: "Documents", href: base }, { label: "Générer" }]} title="Choisir un modèle" description="Les modèles propres à l'organisme remplacent le modèle plateforme de même code. Les données manquantes seront signalées avant la génération." actions={<Button asChild variant="secondary"><Link href={`${base}/nouveau`}>Changer de dossier</Link></Button>} />
        <Panel>
          <ul className="divide-y divide-line">
            {templates.filter(activityOk).map((t) => (
              <li key={t.id} className="flex flex-wrap items-center justify-between gap-3 px-5 py-4">
                <div className="min-w-0">
                  <p className="font-medium text-ink">
                    {t.title} {t.orgId ? <Badge tone="accent" className="ml-2">Modèle de l&apos;organisme</Badge> : null}
                  </p>
                  <p className="text-[12.5px] text-ink-2">{t.description}</p>
                  <p className="mt-1 font-mono text-[10px] uppercase tracking-[0.16em] text-ink-3">
                    {CATEGORY_LABELS[t.category]} · visibilité {VISIBILITY_LABELS[DEFAULT_VISIBILITY[t.category] ?? "interne"]}
                  </p>
                </div>
                <Button asChild variant="secondary" size="sm">
                  <Link href={`${base}/nouveau?${scopeQuery.toString()}&template=${encodeURIComponent(t.code)}`}>Choisir</Link>
                </Button>
              </li>
            ))}
          </ul>
        </Panel>
      </FadeIn>
    );
  }

  // Étape 3 : aperçu, questions, génération.
  let preview: Awaited<ReturnType<typeof previewDocument>> | null = null;
  let error: string | null = null;
  try {
    preview = await previewDocument({ orgId, templateCode, scope, answers });
  } catch (e) {
    error = e instanceof Error ? e.message : "Aperçu impossible.";
  }
  if (!preview) {
    return (
      <FadeIn>
        <PageHeader breadcrumb={[{ label: "Documents", href: base }, { label: "Générer" }]} title="Aperçu impossible" />
        <Notice tone="danger">{error}</Notice>
      </FadeIn>
    );
  }
  const questions = preview.questions as TemplateQuestion[];
  const missingData = preview.missing.filter((m) => !m.key.startsWith("answers."));
  const missingAnswers = preview.missing.filter((m) => m.key.startsWith("answers."));
  const visibility = DEFAULT_VISIBILITY[preview.template.category] ?? "interne";

  return (
    <FadeIn>
      <PageHeader
        breadcrumb={[{ label: "Documents", href: base }, { label: "Générer" }, { label: preview.template.title }]}
        title={preview.template.title}
        description={preview.template.description ?? undefined}
        actions={
          <Button asChild variant="secondary">
            <Link href={`${base}/nouveau?${scopeQuery.toString()}`}>Changer de modèle</Link>
          </Button>
        }
      />
      <div className="grid gap-5 lg:grid-cols-[380px_1fr]">
        <div className="space-y-5">
          <Panel>
            <PanelHeader title="Questions du modèle" description={questions.length ? "Vos réponses sont intégrées au document." : "Ce modèle ne pose aucune question."} />
            <form method="get" className="space-y-4 p-5">
              {Object.entries(scope).map(([k, v]) => (v ? <input key={k} type="hidden" name={k} value={v} /> : null))}
              <input type="hidden" name="template" value={templateCode} />
              {questions.map((q) => (
                <Field key={q.key} label={q.label} required={q.required} htmlFor={`a-${q.key}`} help={q.help}>
                  {q.kind === "textarea" ? (
                    <Textarea id={`a-${q.key}`} name={`a.${q.key}`} defaultValue={answers[q.key] ?? ""} />
                  ) : q.kind === "choice" ? (
                    <Select id={`a-${q.key}`} name={`a.${q.key}`} defaultValue={answers[q.key] ?? ""}>
                      <option value="">Choisir…</option>
                      {(q.options ?? []).map((o) => (
                        <option key={o.value} value={o.value}>
                          {o.label}
                        </option>
                      ))}
                    </Select>
                  ) : (
                    <Input id={`a-${q.key}`} name={`a.${q.key}`} type={q.kind === "date" ? "date" : q.kind === "number" ? "number" : "text"} defaultValue={answers[q.key] ?? ""} />
                  )}
                </Field>
              ))}
              {questions.length ? (
                <Button type="submit" variant="secondary">
                  Mettre à jour l&apos;aperçu
                </Button>
              ) : null}
            </form>
          </Panel>

          <Panel>
            <PanelHeader title="Données manquantes" description="Chaque donnée absente reste visible dans le document sous la forme « [À COMPLÉTER : …] » ; rien n'est inventé." />
            <div className="p-5">
              {preview.missing.length === 0 ? (
                <Notice tone="ok">Toutes les données du modèle sont renseignées.</Notice>
              ) : (
                <ul className="space-y-1.5 text-[13px]">
                  {missingData.map((m) => (
                    <li key={m.key} className="flex items-start gap-2">
                      <Badge tone="warn">Dossier</Badge>
                      <span>
                        {m.label} <span className="num text-[11px] text-ink-3">({m.key})</span>
                      </span>
                    </li>
                  ))}
                  {missingAnswers.map((m) => (
                    <li key={m.key} className="flex items-start gap-2">
                      <Badge tone="info">Question</Badge>
                      <span>{m.label}</span>
                    </li>
                  ))}
                </ul>
              )}
              {missingData.length ? (
                <p className="mt-3 text-[12.5px] text-ink-3">
                  Complétez le dossier (inscription, session, programme, entreprise ou charte) puis rechargez cette page, ou générez avec les marqueurs et régénérez ensuite : une nouvelle version sera créée.
                </p>
              ) : null}
            </div>
          </Panel>

          <Panel>
            <PanelHeader title="Générer" description={`Produit un PDF (charte de ${ctx.org.legalName}) et une version Word, statut « généré » (jamais signé par la génération).`} />
            <div className="p-5">
              <ActionForm action={generateDocumentAction} submitLabel="Générer le document" className="space-y-4" footerClassName="mt-2">
                <input type="hidden" name="orgId" value={orgId} />
                <input type="hidden" name="templateCode" value={templateCode} />
                {Object.entries(scope).map(([k, v]) => (v ? <input key={k} type="hidden" name={k} value={v} /> : null))}
                {questions.map((q) => (
                  <input key={q.key} type="hidden" name={`answers.${q.key}`} value={answers[q.key] ?? ""} />
                ))}
                <Field label="Visibilité du document" htmlFor="visibility">
                  <Select id="visibility" name="visibility" defaultValue={visibility}>
                    {schema.documentVisibilityEnum.enumValues
                      .filter((v) => v !== "public")
                      .map((v) => (
                        <option key={v} value={v}>
                          {VISIBILITY_LABELS[v]}
                        </option>
                      ))}
                  </Select>
                </Field>
                {preview.missing.length ? <Checkbox name="allowMissing" value="1" label="Générer malgré les données manquantes (marqueurs visibles dans le document)." /> : null}
              </ActionForm>
              <p className="mt-3 text-[12px] text-ink-3">
                Après génération, retrouvez le document dans la <Link href={`${base}?${scopeQuery.toString()}`} className="underline">bibliothèque du dossier</Link>.
              </p>
            </div>
          </Panel>
        </div>

        <Panel>
          <PanelHeader title="Aperçu du contenu" description="Rendu texte avant mise en page. L'en-tête, le pied de page, le logo et la pagination sont ajoutés au PDF selon la charte." />
          <div className="p-6">
            <MarkdownPreview text={preview.text} />
          </div>
        </Panel>
      </div>
    </FadeIn>
  );
}
