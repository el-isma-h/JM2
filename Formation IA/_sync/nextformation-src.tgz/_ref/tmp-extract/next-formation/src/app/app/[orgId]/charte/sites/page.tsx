import Link from "next/link";
import { asc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { createRoomAction, createSiteAction, deleteRoomAction, deleteSiteAction, removeAccessPlanAction, updateSiteAction, uploadAccessPlanAction } from "@/server/actions/charte";
import { ActionButton, ActionForm } from "@/components/admin/action-form";
import { FormDialog } from "@/components/admin/form-dialog";
import { Badge } from "@/components/ui/badge";
import { Checkbox, Field, Input, Textarea } from "@/components/ui/field";
import { EmptyState, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { FadeIn } from "@/components/ui/motion";

export const dynamic = "force-dynamic";

/** Sites et salles (F10) : modifiables par org.view + sessions.manage, indépendamment de la charte (propriétaire). */
export default async function SitesPage({ params }: { params: Promise<{ orgId: string }> }) {
  const { orgId } = await params;
  const base = `/app/${orgId}/charte`;
  const ctx = await guardOrg(orgId, `${base}/sites`, "org.view");
  const canManage = ctx.permissions.has("sessions.manage");
  const [sites, rooms] = await Promise.all([
    db.select().from(schema.sites).where(eq(schema.sites.orgId, orgId)).orderBy(asc(schema.sites.isMain), asc(schema.sites.name)),
    db.select().from(schema.rooms).where(eq(schema.rooms.orgId, orgId)).orderBy(asc(schema.rooms.name)),
  ]);
  const siteFields = (s?: typeof schema.sites.$inferSelect) => (
    <>
      <Field label="Nom du site" required htmlFor={`name-${s?.id ?? "new"}`}>
        <Input id={`name-${s?.id ?? "new"}`} name="name" defaultValue={s?.name ?? ""} required />
      </Field>
      <Field label="Adresse" htmlFor={`addr-${s?.id ?? "new"}`}>
        <Input id={`addr-${s?.id ?? "new"}`} name="addressLine1" defaultValue={s?.addressLine1 ?? ""} />
      </Field>
      <div className="grid grid-cols-[120px_1fr] gap-3">
        <Field label="Code postal" htmlFor={`cp-${s?.id ?? "new"}`}>
          <Input id={`cp-${s?.id ?? "new"}`} name="postalCode" defaultValue={s?.postalCode ?? ""} className="num" />
        </Field>
        <Field label="Ville" htmlFor={`city-${s?.id ?? "new"}`}>
          <Input id={`city-${s?.id ?? "new"}`} name="city" defaultValue={s?.city ?? ""} />
        </Field>
      </div>
      <Field label="Capacité d'accueil" htmlFor={`cap-${s?.id ?? "new"}`}>
        <Input id={`cap-${s?.id ?? "new"}`} name="capacity" type="number" min={0} defaultValue={s?.capacity ?? ""} className="num" />
      </Field>
      <Field label="Accessibilité (handicap)" htmlFor={`acc-${s?.id ?? "new"}`} help="Repris dans les convocations et le livret d'accueil.">
        <Textarea id={`acc-${s?.id ?? "new"}`} name="accessibilityNote" rows={2} defaultValue={s?.accessibilityNote ?? ""} />
      </Field>
    </>
  );
  return (
    <FadeIn>
      <PageHeader
        breadcrumb={[{ label: "Charte institutionnelle", href: base }, { label: "Sites et salles" }]}
        title="Sites et salles"
        description="Lieux de formation, salles et plans d'accès (documents publics). Ces éléments ne dépendent pas de la charte institutionnelle et restent modifiables par les responsables de sessions."
        actions={
          canManage ? (
            <FormDialog action={createSiteAction} trigger="Nouveau site" title="Nouveau site" submitLabel="Créer le site">
              <input type="hidden" name="orgId" value={orgId} />
              {siteFields()}
            </FormDialog>
          ) : undefined
        }
      />
      {!canManage ? <Notice tone="info" className="mb-4">Lecture seule : la gestion des sites exige l&apos;habilitation « gérer les sessions ».</Notice> : null}
      {sites.length ? (
        <div className="space-y-5">
          {sites.map((s) => {
            const siteRooms = rooms.filter((r) => r.siteId === s.id);
            return (
              <Panel key={s.id}>
                <PanelHeader
                  title={
                    <>
                      {s.name} {s.isMain ? <Badge tone="accent" className="ml-2">Site principal</Badge> : null}
                    </>
                  }
                  description={[s.addressLine1, [s.postalCode, s.city].filter(Boolean).join(" ")].filter(Boolean).join(", ") || "Adresse non renseignée"}
                  actions={
                    canManage ? (
                      <>
                        <FormDialog action={updateSiteAction} trigger="Modifier" triggerVariant="secondary" triggerSize="sm" title={`Modifier ${s.name}`} submitLabel="Enregistrer">
                          <input type="hidden" name="orgId" value={orgId} />
                          <input type="hidden" name="siteId" value={s.id} />
                          {siteFields(s)}
                          {!s.isMain ? <Checkbox name="isMain" value="1" label="Désigner comme site principal" /> : null}
                        </FormDialog>
                        {!s.isMain ? <ActionButton action={deleteSiteAction} fields={{ orgId, siteId: s.id }} label="Supprimer" variant="danger" confirm={{ title: `Supprimer ${s.name}`, description: "Impossible si une session utilise ce site.", danger: true }} /> : null}
                      </>
                    ) : undefined
                  }
                />
                <div className="grid gap-5 p-5 md:grid-cols-2">
                  <div>
                    <p className="mb-2 font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">Plan d&apos;accès (public)</p>
                    {s.accessPlanKey ? (
                      <p className="text-[13px]">
                        <a href={`${base}/sites/${s.id}/plan`} target="_blank" rel="noreferrer" className="underline">
                          Ouvrir le plan d&apos;accès
                        </a>{" "}
                        <span className="text-ink-3">(lien public utilisable dans les convocations)</span>
                      </p>
                    ) : (
                      <p className="text-[13px] text-ink-3">Aucun plan d&apos;accès déposé.</p>
                    )}
                    {canManage ? (
                      <div className="mt-3 space-y-2">
                        <ActionForm action={uploadAccessPlanAction} submitLabel="Déposer un plan" submitSize="sm" className="space-y-2">
                          <input type="hidden" name="orgId" value={orgId} />
                          <input type="hidden" name="siteId" value={s.id} />
                          <Input name="file" type="file" accept=".pdf,.png,.jpg,.jpeg" required aria-label="Fichier du plan d'accès" className="py-1.5" />
                        </ActionForm>
                        {s.accessPlanKey ? <ActionButton action={removeAccessPlanAction} fields={{ orgId, siteId: s.id }} label="Retirer le plan" variant="ghost" /> : null}
                      </div>
                    ) : null}
                    {s.accessibilityNote ? <p className="mt-3 text-[12.5px] text-ink-2">Accessibilité : {s.accessibilityNote}</p> : null}
                  </div>
                  <div>
                    <p className="mb-2 font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">Salles ({siteRooms.length})</p>
                    {siteRooms.length ? (
                      <ul className="divide-y divide-line border border-line">
                        {siteRooms.map((r) => (
                          <li key={r.id} className="flex items-center justify-between gap-2 px-3 py-2 text-[13px]">
                            <span>
                              {r.name} {r.capacity ? <span className="num text-ink-3">· {r.capacity} places</span> : null}
                              {Array.isArray(r.equipment) && r.equipment.length ? <span className="text-ink-3"> · {(r.equipment as string[]).join(", ")}</span> : null}
                            </span>
                            {canManage ? <ActionButton action={deleteRoomAction} fields={{ orgId, roomId: r.id }} label="Supprimer" variant="ghost" confirm={{ title: `Supprimer la salle ${r.name}`, danger: true }} /> : null}
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <p className="text-[13px] text-ink-3">Aucune salle.</p>
                    )}
                    {canManage ? (
                      <ActionForm action={createRoomAction} submitLabel="Ajouter" submitSize="sm" className="mt-3 space-y-2">
                        <input type="hidden" name="orgId" value={orgId} />
                        <input type="hidden" name="siteId" value={s.id} />
                        <div className="grid grid-cols-[1fr_90px] gap-2">
                          <Input name="name" placeholder="Nom de la salle" required aria-label="Nom de la salle" />
                          <Input name="capacity" type="number" min={0} placeholder="Places" aria-label="Capacité" className="num" />
                        </div>
                        <Input name="equipment" placeholder="Équipements, séparés par des virgules" aria-label="Équipements" />
                      </ActionForm>
                    ) : null}
                  </div>
                </div>
              </Panel>
            );
          })}
        </div>
      ) : (
        <Panel>
          <EmptyState title="Aucun site" description="Créez le lieu principal de formation pour les convocations et le planning." />
        </Panel>
      )}
      <p className="mt-5 text-[12.5px] text-ink-3">
        <Link href={base} className="underline">
          Retour à la charte
        </Link>
      </p>
    </FadeIn>
  );
}
