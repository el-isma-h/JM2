import { appUrl } from "@/lib/env";
import { filterByFamily, loadPublicCatalogueByRef, publicCatalogueJson } from "@/server/catalog/public";
import { cachedResponse, limitPublic, preflight, PUBLIC_CORS } from "@/server/catalog/public-http";

export const dynamic = "force-dynamic";

function x(v: unknown): string {
  if (v === null || v === undefined) return "";
  return String(v).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}

function el(name: string, v: unknown): string {
  return v === null || v === undefined || v === "" ? "" : `<${name}>${x(v)}</${name}>`;
}

/**
 * GET /api/public/{slug | id}/catalogue.xml[?famille=…] : même contenu que l'API JSON, en XML
 * (outils d'import de sites, agrégateurs, tableurs).
 */
export async function GET(req: Request, { params }: { params: Promise<{ org: string }> }) {
  const limited = await limitPublic();
  if (limited) return limited;
  const { org } = await params;
  const data = await loadPublicCatalogueByRef(org);
  if (!data) return new Response(`<?xml version="1.0" encoding="UTF-8"?><erreur>Catalogue introuvable.</erreur>`, { status: 404, headers: { ...PUBLIC_CORS, "Content-Type": "application/xml; charset=utf-8" } });
  const famille = new URL(req.url).searchParams.get("famille");
  const j = publicCatalogueJson(filterByFamily(data, famille));
  const base = `${appUrl()}/catalogue-public/${data.tenant.slug}`;
  const formations = j.formations
    .map(
      (f) =>
        `<formation id="${x(f.id)}">${el("code", f.code)}${el("titre", f.titre)}${el("type", f.type)}${el("famille", f.categorie)}${el("eligibleCpf", f.eligibleCpf)}${el("lien", `${base}#${f.slug}`)}` +
        (f.certification ? `<certification>${el("titre", f.certification.titre)}${el("rncp", f.certification.rncp)}${el("rs", f.certification.rs)}${el("niveau", f.certification.niveau)}</certification>` : "") +
        (f.programme
          ? `<programme>${el("version", f.programme.version)}${el("objectifs", f.programme.objectifs)}${el("prerequis", f.programme.prerequis)}${el("public", f.programme.public)}${el("modalite", f.programme.modalite)}${el("dureeHeures", f.programme.dureeHeures)}${el("dureeJours", f.programme.dureeJours)}${el("contenu", f.programme.contenu)}${el("tarifHtCents", f.programme.tarifHtCents)}${el("accessibilite", f.programme.accessibilite)}${el("delaiAcces", f.programme.delaiAcces)}</programme>`
          : "") +
        `<sessions>${f.sessions.map((s) => `<session id="${x(s.id)}">${el("debut", s.debut)}${el("fin", s.fin)}${el("modalite", s.modalite)}${el("type", s.type)}${el("tarifCents", s.tarifCents)}</session>`).join("")}</sessions></formation>`,
    )
    .join("");
  const stable = `<?xml version="1.0" encoding="UTF-8"?><catalogue organismeId="${x(data.org.id)}">${el("organisme", j.organisme.nom)}${el("nda", j.organisme.nda)}${el("siret", j.organisme.siret)}<formations>${formations}</formations>`;
  const body = `${stable}${el("genereLe", j.generéLe)}</catalogue>`;
  return cachedResponse(req, body, "application/xml; charset=utf-8", stable);
}

export const HEAD = GET;

export function OPTIONS() {
  return preflight();
}
