import Link from "next/link";
import { guardOrg } from "@/server/guard";
import { roleLabels } from "@/server/authz";
import { dashboardMetrics, objectivesFor } from "@/server/pilotage/metrics";
import { resolvePeriod } from "@/server/pilotage/period";
import { todayParis } from "@/lib/time";
import { fmtDateTime } from "@/lib/dates";
import { Button } from "@/components/ui/button";
import { Notice, PageHeader } from "@/components/ui/surface";
import { FadeIn } from "@/components/ui/motion";
import { MetricGroupPanel } from "@/components/dashboard/metric-card";
import { ObjectivesStrip } from "@/components/dashboard/objectives";
import { OnboardingNotice } from "@/components/dashboard/onboarding";

export const dynamic = "force-dynamic";

/** Tableau de bord adapté au rôle (F15) : indicateurs cliquables avec période, filtre et date de mise à jour. */
export default async function OrgDashboard({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const ctx = await guardOrg(orgId, `/app/${orgId}`);
  const sp = await searchParams;
  const today = todayParis();
  const period = resolvePeriod(sp, today);
  const [{ groups, updatedAt }, objectives] = await Promise.all([dashboardMetrics(ctx, period, today), ctx.permissions.has("dashboards.view") ? objectivesFor(orgId, period) : Promise.resolve([])]);
  const updated = fmtDateTime(updatedAt);
  const canPilot = ctx.permissions.has("dashboards.view");

  return (
    <FadeIn>
      <PageHeader
        title="Tableau de bord"
        description={`${ctx.org.tradeName ?? ctx.org.legalName} : ${ctx.isOwner ? "propriétaire" : ""}${ctx.isOwner && ctx.roles.length ? ", " : ""}${ctx.roles.map((r) => roleLabels[r]).join(", ")}. Période de référence : ${period.label}. Mise à jour : ${updated}.`}
        actions={
          canPilot ? (
            <Button asChild variant="secondary">
              <Link href={`/app/${orgId}/pilotage?periode=${period.key}${period.key === "personnalise" ? `&from=${period.from}&to=${period.to}` : ""}`}>Pilotage détaillé</Link>
            </Button>
          ) : null
        }
      />
      {!ctx.org.onboardingCompletedAt && (ctx.isOwner || ctx.roles.includes("direction")) ? <OnboardingNotice orgId={orgId} step={ctx.org.onboardingStep} /> : null}
      {ctx.org.isDemo ? (
        <Notice tone="warn" className="mb-6">
          Espace de démonstration : aucune donnée réelle, aucun envoi externe.
        </Notice>
      ) : null}
      <div className="space-y-6">
        {groups.map((g, i) => (
          <MetricGroupPanel key={g.key} g={g} updatedAt={updated} objectives={i === 0 && canPilot ? <ObjectivesStrip objectives={objectives} orgId={orgId} canEdit={ctx.isOwner || ctx.roles.includes("direction")} /> : undefined} />
        ))}
      </div>
    </FadeIn>
  );
}
