import { NextResponse, type NextRequest } from "next/server";
import { and, asc, eq, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { authenticateApiKey, readPagination } from "@/server/integrations/api-auth";

export const dynamic = "force-dynamic";

/** GET /api/v1/programs : programmes actifs de l'organisme de la clé (scope catalog.read). */
export async function GET(req: NextRequest) {
  const a = await authenticateApiKey(req, "catalog.read");
  if (!a.ok) return a.response;
  const { limit, offset } = readPagination(req);
  const where = and(eq(schema.programs.orgId, a.auth.orgId), eq(schema.programs.status, "actif"));
  const [rows, [{ total }]] = await Promise.all([
    db
      .select({ id: schema.programs.id, code: schema.programs.code, slug: schema.programs.slug, title: schema.programs.title, kind: schema.programs.kind, isPublished: schema.programs.isPublished, rncp: schema.certifications.rncpCode, rs: schema.certifications.rsCode, updatedAt: schema.programs.updatedAt })
      .from(schema.programs)
      .leftJoin(schema.certifications, eq(schema.certifications.id, schema.programs.certificationId))
      .where(where)
      .orderBy(asc(schema.programs.title))
      .limit(limit)
      .offset(offset),
    db.select({ total: sql<number>`count(*)::int` }).from(schema.programs).where(where),
  ]);
  return NextResponse.json({ data: rows, total, limit, offset }, { headers: { "Cache-Control": "no-store" } });
}
