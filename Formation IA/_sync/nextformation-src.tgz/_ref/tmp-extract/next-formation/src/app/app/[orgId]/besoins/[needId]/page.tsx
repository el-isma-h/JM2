import Link from "next/link";
import { notFound } from "next/navigation";
import { and, desc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { addInteractionAction, addPlacementAction, setNeedStageAction, setPlacementStatusAction, updateNeedAction } from "@/server/actions/crm";
import { isOverdue, listStaffUsers, nextActionForNeed, userNames } from "@/server/crm/queries";
import { todayParis } from "@/lib/time";
import { fmtDate, fmtDateTime } from "@/lib/dates";
import { formatCents } from "@/lib/money";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Select, Textarea } from "@/components/ui/field";
import { EmptyState, KeyValue, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FormDialog } from "@/components/admin/form-dialog";
import { ActionButton } from "@/components/admin/action-form";
import { InteractionFields, NeedFields, interactionKindLabels, needKindLabels, needStageLabels, placementStatusLabels } from "@/components/crm/fields";
import { NextActionBanner } from "@/components/crm/next-action";
import { StageSelect } from "@/components/crm/stage-select";
import { FadeIn } from "@/components/ui/motion";

export const dynamic = "force-dynamic";
const STAGES = schema.needStageEnum.enumValues;
const PLACEMENT = schema.placementStatusEnum.enumValues;

export default async function NeedPage({ params }: { params: Promise<{ orgId: string; needId: string }> }) {
  const { orgId, needId } = await params;
  const base = `/app/${orgId}`;
  const ctx = await guardOrg(orgId, `${base}/besoins/${needId}`, "crm.view");
  if (!/^[0-9a-f-]{36}$/i.test(needId)) notFound();
  const [need] = await db.select().from(schema.needs).where(and(eq(schema.needs.id, needId), eq(schema.needs.orgId, ctx.org.id))).limit(1);
  if (!need) notFound();
  const canManage = ctx.permissions.has("crm.manage");
  const today = todayParis();
  const closed = need.stage === "gagne" || need.stage === "perdu";

  const [company, contact, person, program, placements, quotes, interactions, staff, companies, contacts, persons, programs, action] = await Promise.all([
    need.companyId ? db.select().from(schema.companies).where(and(eq(schema.companies.id, need.companyId), eq(schema.companies.orgId, ctx.org.id))).limit(1).then((r) => r[0] ?? null) : null,
    need.contactId ? db.select().from(schema.contacts).where(and(eq(schema.contacts.id, need.contactId), eq(schema.contacts.orgId, ctx.org.id))).limit(1).then((r) => r[0] ?? null) : null,
    need.personId ? db.select().from(schema.persons).where(and(eq(schema.persons.id, need.personId), eq(schema.persons.orgId, ctx.org.id))).limit(1).then((r) => r[0] ?? null) : null,
    need.programId ? db.select().from(schema.programs).where(and(eq(schema.programs.id, need.programId), eq(schema.programs.orgId, ctx.org.id))).limit(1).then((r) => r[0] ?? null) : null,
    db
      .select({ pl: schema.placements, p: schema.persons, enrollmentRef: schema.enrollments.reference })
      .from(schema.placements)
      .innerJoin(schema.persons, eq(schema.persons.id, schema.placements.personId))
      .leftJoin(schema.enrollments, eq(schema.enrollments.id, schema.placements.enrollmentId))
      .where(and(eq(schema.placements.orgId, ctx.org.id), eq(schema.placements.needId, need.id)))
      .orderBy(desc(schema.placements.proposedAt)),
    db.select().from(schema.quotes).where(and(eq(schema.quotes.orgId, ctx.org.id), eq(schema.quotes.needId, need.id))).orderBy(desc(schema.quotes.createdAt)),
    db.select().from(schema.interactions).where(and(eq(schema.interactions.orgId, ctx.org.id), eq(schema.interactions.needId, need.id))).orderBy(desc(schema.interactions.at)).limit(50),
    listStaffUsers(ctx.org.id),
    db.select({ id: schema.companies.id, name: schema.companies.name }).from(schema.companies).where(eq(schema.companies.orgId, ctx.org.id)).orderBy(schema.companies.name).limit(500),
    db.select({ id: schema.contacts.id, firstName: schema.contacts.firstName, lastName: schema.contacts.lastName, companyId: schema.contacts.companyId }).from(schema.contacts).where(eq(schema.contacts.orgId, ctx.org.id)).orderBy(schema.contacts.lastName).limit(500),
    db.select({ id: schema.persons.id, firstName: schema.persons.firstName, lastName: schema.persons.lastName, status: schema.persons.status }).from(schema.persons).where(eq(schema.persons.orgId, ctx.org.id)).orderBy(schema.persons.lastName, schema.persons.firstName).limit(500),
    db.select({ id: schema.programs.id, name: schema.programs.title }).from(schema.programs).where(and(eq(schema.programs.orgId, ctx.org.id), eq(schema.programs.status, "actif"))).orderBy(schema.programs.title),
    nextActionForNeed(ctx.org.id, need),
  ]);
  const names = await userNames([need.assignedUserId, ...interactions.map((i) => i.userId)]);
  const contactOptions = contacts.filter((c) => !need.companyId || c.companyId === need.companyId).map((c) => ({ id: c.id, name: `${c.firstName} ${c.lastName}` }));
  const personOptions = persons.map((p) => ({ id: p.id, name: `${p.firstName} ${p.lastName}` }));
  const alreadyPlaced = new Set(placements.map((p) => p.pl.personId));

  return (
    <FadeIn>
      <PageHeader
        breadcrumb={[{ label: "Commercial" }, { label: "Besoins", href: `${base}/besoins` }, { label: need.title }]}
        title={need.title}
        description={[needKindLabels[need.kind], company ? company.name : person ? `${person.firstName} ${person.lastName}` : null, program ? `Formation visée : ${program.title}` : null].filter(Boolean).join(" · ")}
        actions={
          <>
            <StatusBadge status={need.stage} />
            {canManage ? (
              <>
                {!closed ? <StageSelect action={setNeedStageAction} fields={{ orgId: ctx.org.id, needId: need.id }} name="stage" value={need.stage} label="Changer l'étape" options={STAGES.filter((s) => s !== "perdu" && s !== "gagne").map((value) => ({ value, label: needStageLabels[value] }))} /> : null}
                {need.stage !== "gagne" ? <ActionButton action={setNeedStageAction} fields={{ orgId: ctx.org.id, needId: need.id, stage: "gagne" }} label="Gagné" variant="accent" size="md" confirm={{ title: "Marquer le besoin gagné", description: "Si aucune inscription n'existe, une tâche « Créer l'inscription » est transmise à l'administratif.", confirmLabel: "Confirmer : gagné" }} /> : null}
                {need.stage !== "perdu" ? <ActionButton action={setNeedStageAction} fields={{ orgId: ctx.org.id, needId: need.id, stage: "perdu" }} label="Perdu" variant="danger" size="md" confirm={{ title: "Marquer le besoin perdu", description: "Le motif est conservé dans l'historique.", confirmLabel: "Confirmer : perdu", danger: true, input: { name: "lostReason", label: "Motif de la perte", placeholder: "Budget, concurrent, report, sans suite…" } }} /> : null}
                {closed ? <ActionButton action={setNeedStageAction} fields={{ orgId: ctx.org.id, needId: need.id, stage: "negociation" }} label="Rouvrir" variant="secondary" size="md" confirm={{ title: "Rouvrir le besoin", description: "Le besoin repasse en négociation.", confirmLabel: "Rouvrir" }} /> : null}
                <FormDialog action={updateNeedAction} trigger="Modifier" triggerVariant="secondary" title="Modifier le besoin" submitLabel="Enregistrer" wide>
                  <NeedFields orgId={ctx.org.id} need={need} companies={companies} contacts={contacts.map((c) => ({ id: c.id, name: `${c.firstName} ${c.lastName}` }))} persons={personOptions} programs={programs} staff={staff} prefix="en" />
                </FormDialog>
              </>
            ) : null}
          </>
        }
      />
      <NextActionBanner action={action} base={base} />
      {need.stage === "perdu" && need.lostReason ? (
        <Notice tone="danger" title={`Perdu le ${fmtDate(need.lostAt)}`} className="mb-6">
          Motif : {need.lostReason}
        </Notice>
      ) : null}
      {need.stage === "gagne" ? (
        <Notice tone="ok" title={`Gagné le ${fmtDate(need.wonAt)}`} className="mb-6">
          Créez l&apos;inscription depuis le placement retenu ci-dessous (les informations sont reprises sans ressaisie).
        </Notice>
      ) : null}

      <div className="grid gap-6 lg:grid-cols-[minmax(0,2fr)_minmax(0,1fr)]">
        <div className="space-y-6">
          <Panel>
            <PanelHeader title="Synthèse" />
            <div className="grid gap-6 p-5 md:grid-cols-2">
              <KeyValue
                items={[
                  { k: "Entreprise", v: company ? <Link href={`${base}/entreprises/${company.id}`} className="hover:underline">{company.name}</Link> : null },
                  { k: "Interlocuteur", v: contact ? `${contact.firstName} ${contact.lastName}${contact.jobTitle ? `, ${contact.jobTitle}` : ""}` : null },
                  { k: "Personne", v: person ? <Link href={`${base}/candidats/${person.id}`} className="hover:underline">{person.firstName} {person.lastName}</Link> : null },
                  { k: "Formation visée", v: program ? <Link href={`${base}/catalogue/${program.id}`} className="hover:underline">{program.title}</Link> : "À définir" },
                  { k: "Source", v: need.source },
                ]}
              />
              <KeyValue
                items={[
                  { k: "Effectif", v: <span className="num">{need.headcount}</span> },
                  { k: "Montant HT", v: <span className="num">{formatCents(need.amountCents)}</span> },
                  { k: "Probabilité", v: <span className="num">{need.probability} %</span> },
                  { k: "Clôture prévue", v: need.expectedCloseDate ? <span className="num">{fmtDate(need.expectedCloseDate)}</span> : null },
                  { k: "Référent", v: need.assignedUserId ? names.get(need.assignedUserId) : "Non attribué" },
                  { k: "Créé le", v: <span className="num">{fmtDate(need.createdAt)}</span> },
                ]}
              />
            </div>
            {need.description ? <p className="whitespace-pre-line border-t border-line px-5 py-4 text-[13.5px] text-ink-2">{need.description}</p> : null}
          </Panel>

          <Panel>
            <PanelHeader
              title="Placements de candidats"
              description="Proposé, entretien, retenu, placé : le placement retenu alimente l'inscription sans ressaisie."
              actions={
                canManage && !closed ? (
                  <FormDialog action={addPlacementAction} trigger="Associer un candidat" triggerVariant="secondary" triggerSize="sm" title="Proposer un candidat" submitLabel="Proposer">
                    <input type="hidden" name="orgId" value={ctx.org.id} />
                    <input type="hidden" name="needId" value={need.id} />
                    <Field label="Candidat" required htmlFor="pl-person" help="Les personnes déjà associées n'apparaissent pas.">
                      <Select id="pl-person" name="personId" required defaultValue="">
                        <option value="">Choisir…</option>
                        {persons
                          .filter((p) => !alreadyPlaced.has(p.id))
                          .map((p) => (
                            <option key={p.id} value={p.id}>
                              {p.firstName} {p.lastName} ({p.status})
                            </option>
                          ))}
                      </Select>
                    </Field>
                    <Field label="Note" htmlFor="pl-notes">
                      <Textarea id="pl-notes" name="notes" rows={2} />
                    </Field>
                  </FormDialog>
                ) : null
              }
            />
            {placements.length ? (
              <Table>
                <thead>
                  <tr>
                    <Th>Candidat</Th>
                    <Th>Statut</Th>
                    <Th>Proposé le</Th>
                    <Th>Décision</Th>
                    <Th>Inscription</Th>
                  </tr>
                </thead>
                <tbody>
                  {placements.map(({ pl, p, enrollmentRef }) => {
                    const canEnroll = ctx.permissions.has("enrollments.manage") && (pl.status === "retenu" || pl.status === "place") && !pl.enrollmentId;
                    const enrollUrl = `${base}/inscriptions/nouvelle?personId=${p.id}&placementId=${pl.id}${need.companyId ? `&companyId=${need.companyId}` : ""}${need.programId ? `&programId=${need.programId}` : ""}`;
                    return (
                      <tr key={pl.id}>
                        <Td>
                          <Link href={`${base}/candidats/${p.id}`} className="font-medium text-ink hover:underline">
                            {p.firstName} {p.lastName}
                          </Link>
                          {pl.notes ? <p className="text-[12px] text-ink-3">{pl.notes}</p> : null}
                        </Td>
                        <Td>
                          <div className="flex items-center gap-2">
                            <StatusBadge status={pl.status} />
                            {canManage && !pl.enrollmentId ? <StageSelect action={setPlacementStatusAction} fields={{ orgId: ctx.org.id, placementId: pl.id }} name="status" value={pl.status} label={`Statut du placement de ${p.firstName} ${p.lastName}`} options={PLACEMENT.map((value) => ({ value, label: placementStatusLabels[value] }))} /> : null}
                          </div>
                        </Td>
                        <Td className="num whitespace-nowrap">{fmtDate(pl.proposedAt)}</Td>
                        <Td className="num whitespace-nowrap">{pl.decidedAt ? fmtDateTime(pl.decidedAt) : pl.interviewAt ? `Entretien ${fmtDate(pl.interviewAt)}` : "-"}</Td>
                        <Td>
                          {pl.enrollmentId ? (
                            <Link href={`${base}/inscriptions/${pl.enrollmentId}`} className="num hover:underline">
                              {enrollmentRef ?? "Voir l'inscription"}
                            </Link>
                          ) : canEnroll ? (
                            <Button asChild variant="accent" size="sm">
                              <Link href={enrollUrl}>Créer l&apos;inscription depuis ce placement</Link>
                            </Button>
                          ) : (
                            <span className="text-[12px] text-ink-3">{pl.status === "retenu" || pl.status === "place" ? "Création réservée aux inscriptions" : "Après décision « retenu »"}</span>
                          )}
                        </Td>
                      </tr>
                    );
                  })}
                </tbody>
              </Table>
            ) : (
              <EmptyState title="Aucun candidat proposé" description="Associez une personne du vivier pour suivre la proposition jusqu'au placement." className="py-8" />
            )}
          </Panel>

          <Panel>
            <PanelHeader title="Devis" actions={canManage && !closed ? <Button asChild variant="secondary" size="sm"><Link href={`${base}/devis/nouveau?needId=${need.id}`}>Nouveau devis</Link></Button> : null} />
            {quotes.length ? (
              <Table>
                <thead>
                  <tr>
                    <Th>Numéro</Th>
                    <Th>Objet</Th>
                    <Th>Statut</Th>
                    <Th num>Total TTC</Th>
                    <Th>Validité</Th>
                  </tr>
                </thead>
                <tbody>
                  {quotes.map((q) => (
                    <tr key={q.id}>
                      <Td>
                        <Link href={`${base}/devis/${q.id}`} className="num font-medium text-ink hover:underline">
                          {q.number}
                        </Link>
                      </Td>
                      <Td>{q.title}</Td>
                      <Td>
                        <StatusBadge status={q.status} />
                      </Td>
                      <Td num>{formatCents(q.totalTtcCents)}</Td>
                      <Td className={q.status === "envoye" && isOverdue(q.validUntil, today) ? "text-danger-ink" : ""}>{q.validUntil ? fmtDate(q.validUntil) : "-"}</Td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            ) : (
              <EmptyState title="Aucun devis" description="Un devis accepté fait passer le besoin en « gagné »." className="py-8" />
            )}
          </Panel>
        </div>

        <Panel className="self-start">
          <PanelHeader
            title="Échanges"
            actions={
              canManage ? (
                <FormDialog action={addInteractionAction} trigger="Ajouter" triggerVariant="secondary" triggerSize="sm" title="Nouvel échange" submitLabel="Enregistrer">
                  <InteractionFields orgId={ctx.org.id} needId={need.id} companyId={need.companyId} personId={need.personId} contacts={contactOptions} today={today} />
                </FormDialog>
              ) : null
            }
          />
          {interactions.length ? (
            <ol className="divide-y divide-line">
              {interactions.map((i) => (
                <li key={i.id} className="px-5 py-3.5 text-[13.5px]">
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge>{interactionKindLabels[i.kind] ?? i.kind}</Badge>
                    <span className="num text-[12px] text-ink-3">{fmtDate(i.at)}</span>
                    {i.userId ? <span className="text-[12px] text-ink-3">{names.get(i.userId)}</span> : null}
                  </div>
                  <p className="mt-1.5 font-medium text-ink">{i.subject}</p>
                  {i.body ? <p className="mt-1 whitespace-pre-line text-ink-2">{i.body}</p> : null}
                  {i.nextActionAt ? (
                    <p className={`mt-1.5 text-[12.5px] ${isOverdue(i.nextActionAt, today) ? "font-medium text-danger-ink" : "text-ink-2"}`}>
                      Prochaine action : {i.nextAction} le <span className="num">{fmtDate(i.nextActionAt)}</span>
                    </p>
                  ) : null}
                </li>
              ))}
            </ol>
          ) : (
            <EmptyState title="Aucun échange" className="py-8" />
          )}
        </Panel>
      </div>
    </FadeIn>
  );
}
