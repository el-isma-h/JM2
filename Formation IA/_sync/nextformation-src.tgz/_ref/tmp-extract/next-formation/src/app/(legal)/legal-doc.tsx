/** Mise en forme commune du texte légal. */
export function LegalDoc({ title, updated, children }: { title: string; updated: string; children: React.ReactNode }) {
  return (
    <article className="text-[15px] leading-relaxed text-ink-2 [&_a]:text-accent [&_a:hover]:underline [&_h2]:mt-12 [&_h2]:text-[20px] [&_h2]:text-ink [&_li]:mt-1.5 [&_p]:mt-4 [&_strong]:font-medium [&_strong]:text-ink [&_ul]:mt-4 [&_ul]:list-disc [&_ul]:pl-5">
      <p className="etiquette">Information légale</p>
      <h1 className="titre-geant mt-6 text-[40px] sm:text-[56px]">{title}</h1>
      <p className="!mt-6 font-mono text-[11px] uppercase tracking-[0.16em] text-ink-3">Version du {updated}</p>
      {children}
    </article>
  );
}

/** Valeur d'identification de l'éditeur, signalée visiblement tant qu'elle n'est pas renseignée. */
export function Fill({ value, label }: { value: string; label: string }) {
  return value ? <>{value}</> : <span className="bg-warn-soft px-1 text-warn-ink">[{label} à renseigner]</span>;
}
