import { guardLearner } from "@/server/extranet/guard";
import { consentAction, requestGdprExportAction, updateMyInfoAction } from "@/server/actions/self";
import { NoAttachment } from "@/components/extranet/shell";
import { ActionForm } from "@/components/admin/action-form";
import { Checkbox, Field, Input, Select, Textarea } from "@/components/ui/field";
import { KeyValue, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { fmtDate, fmtDateTime } from "@/lib/dates";

export const dynamic = "force-dynamic";

/** Mes informations : coordonnées modifiables, identité en lecture, consentement et droits RGPD. */
export default async function LearnerInfo() {
  const ctx = await guardLearner("/moi/informations");
  if (!ctx) return <NoAttachment kind="learner" />;
  const p = ctx.person;
  return (
    <>
      <PageHeader title="Mes informations" description="Vos coordonnées sont modifiables ici. L'identité (nom, date de naissance) est contractuelle : pour la corriger, adressez une demande de rectification à l'organisme." />
      <div className="grid gap-6 lg:grid-cols-2">
        <Panel>
          <PanelHeader title="Identité" description="Lecture seule" />
          <div className="px-5 py-5">
            <KeyValue
              items={[
                { k: "Nom", v: `${p.civility ? `${p.civility} ` : ""}${p.firstName} ${p.lastName}` },
                { k: "Nom de naissance", v: p.birthName ?? "-" },
                { k: "Date de naissance", v: p.birthDate ? fmtDate(p.birthDate) : "-" },
                { k: "Organisme", v: ctx.org.tradeName ?? ctx.org.legalName },
                { k: "Compte", v: ctx.user.email },
              ]}
            />
          </div>
        </Panel>

        <Panel>
          <PanelHeader title="Coordonnées" description="Utilisées pour les convocations et les échanges avec l'organisme." />
          <div className="px-5 py-5">
            <ActionForm action={updateMyInfoAction} submitLabel="Enregistrer" className="space-y-4" footerClassName="pt-2">
              <Field label="E-mail de contact" htmlFor="i-email" help="L'adresse de connexion à votre compte ne change pas ici.">
                <Input id="i-email" name="email" type="email" defaultValue={p.email ?? ""} />
              </Field>
              <Field label="Téléphone" htmlFor="i-phone">
                <Input id="i-phone" name="phone" defaultValue={p.phone ?? ""} />
              </Field>
              <Field label="Adresse" htmlFor="i-a1">
                <Input id="i-a1" name="addressLine1" defaultValue={p.addressLine1 ?? ""} />
              </Field>
              <Field label="Complément" htmlFor="i-a2">
                <Input id="i-a2" name="addressLine2" defaultValue={p.addressLine2 ?? ""} />
              </Field>
              <div className="grid grid-cols-[120px_1fr] gap-3">
                <Field label="Code postal" htmlFor="i-cp">
                  <Input id="i-cp" name="postalCode" defaultValue={p.postalCode ?? ""} />
                </Field>
                <Field label="Ville" htmlFor="i-city">
                  <Input id="i-city" name="city" defaultValue={p.city ?? ""} />
                </Field>
              </div>
            </ActionForm>
          </div>
        </Panel>

        <Panel>
          <PanelHeader title="Consentement" description="Traitement de vos données pour la gestion de votre parcours de formation." />
          <div className="px-5 py-5">
            {p.gdprConsentAt ? (
              <Notice tone="ok">Consentement enregistré le {fmtDateTime(p.gdprConsentAt)}.</Notice>
            ) : (
              <ActionForm action={consentAction} submitLabel="Enregistrer mon consentement" submitVariant="secondary" className="space-y-4" footerClassName="pt-2">
                <Checkbox name="consent" label="J'accepte que l'organisme traite mes données personnelles pour la gestion de ma formation, de mon financement et des obligations réglementaires associées." />
              </ActionForm>
            )}
          </div>
        </Panel>

        <Panel>
          <PanelHeader title="Mes droits (RGPD)" description="Export, rectification ou effacement de vos données : la demande est transmise à la direction de l'organisme, qui répond sous un mois." />
          <div className="px-5 py-5">
            <ActionForm action={requestGdprExportAction} submitLabel="Envoyer la demande" submitVariant="secondary" className="space-y-4" footerClassName="pt-2">
              <Field label="Demande" htmlFor="r-kind">
                <Select id="r-kind" name="kind" defaultValue="export">
                  <option value="export">Recevoir une copie de mes données</option>
                  <option value="rectification">Corriger une information</option>
                  <option value="effacement">Demander l&apos;effacement (hors obligations légales de conservation)</option>
                </Select>
              </Field>
              <Field label="Précisions (facultatif)" htmlFor="r-detail">
                <Textarea id="r-detail" name="detail" maxLength={1000} />
              </Field>
            </ActionForm>
          </div>
        </Panel>
      </div>
    </>
  );
}
