import Link from "next/link";
import { guardOrg } from "@/server/guard";
import { listTemplates } from "@/server/documents/generate";
import { CATEGORY_LABELS } from "@/server/documents/queries";
import { copyTemplateAction, toggleTemplateAction } from "@/server/actions/documents";
import { ActionButton } from "@/components/admin/action-form";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FadeIn } from "@/components/ui/motion";

export const dynamic = "force-dynamic";
const SCOPE_LABELS: Record<string, string> = { enrollment: "Inscription", session: "Session", company: "Entreprise", person: "Personne", org: "Organisme" };
const ACTIVITY_LABELS: Record<string, string> = { of: "OF", cfa: "CFA", both: "OF et CFA" };

export default async function TemplatesPage({ params }: { params: Promise<{ orgId: string }> }) {
  const { orgId } = await params;
  const base = `/app/${orgId}/documents`;
  const ctx = await guardOrg(orgId, `${base}/modeles`, "documents.generate");
  const all = await listTemplates(orgId, { includeInactive: true });
  const canEdit = !ctx.trainerOnly;
  return (
    <FadeIn>
      <PageHeader
        breadcrumb={[{ label: "Documents", href: base }, { label: "Modèles" }]}
        title="Modèles de documents"
        description="Les modèles plateforme sont fournis avec les mentions usuelles. Copiez-en un pour l'adapter : votre version remplace alors le modèle plateforme de même code pour cet organisme."
        actions={
          <Button asChild variant="secondary">
            <Link href={`${base}/nouveau`}>Générer un document</Link>
          </Button>
        }
      />
      {!canEdit ? <Notice tone="info" className="mb-4">Lecture seule : la personnalisation des modèles est réservée aux responsables.</Notice> : null}
      <Panel>
        <PanelHeader title={`${all.length} modèle(s)`} description="Un modèle désactivé n'est plus proposé à la génération ; le modèle plateforme de même code redevient utilisé." />
        <Table>
          <thead>
            <tr>
              <Th>Modèle</Th>
              <Th>Catégorie</Th>
              <Th>Portée</Th>
              <Th>Activité</Th>
              <Th>Origine</Th>
              <Th num>Version</Th>
              <Th></Th>
            </tr>
          </thead>
          <tbody>
            {all.map((t) => (
              <tr key={t.id}>
                <Td>
                  <p className="font-medium text-ink">{t.title}</p>
                  <p className="text-[12px] text-ink-3">{t.description}</p>
                  <p className="num mt-0.5 text-[11px] text-ink-3">{t.code}</p>
                </Td>
                <Td>{CATEGORY_LABELS[t.category]}</Td>
                <Td>{SCOPE_LABELS[t.scope] ?? t.scope}</Td>
                <Td>{ACTIVITY_LABELS[t.activity] ?? t.activity}</Td>
                <Td>
                  {t.orgId ? <Badge tone="accent">Organisme</Badge> : <Badge>Plateforme</Badge>} {!t.isActive ? <Badge tone="warn">Désactivé</Badge> : null}
                  {t.verifiedAt ? null : t.orgId ? <Badge tone="neutral" className="ml-1">Non relu</Badge> : null}
                </Td>
                <Td num>{t.version}</Td>
                <Td>
                  {canEdit ? (
                    <div className="flex flex-wrap justify-end gap-2">
                      {t.orgId ? (
                        <>
                          <Button asChild variant="secondary" size="sm">
                            <Link href={`${base}/modeles/${t.id}`}>Modifier</Link>
                          </Button>
                          <ActionButton action={toggleTemplateAction} fields={{ orgId, templateId: t.id }} label={t.isActive ? "Désactiver" : "Activer"} variant="ghost" />
                        </>
                      ) : (
                        <ActionButton action={copyTemplateAction} fields={{ orgId, templateCode: t.code }} label="Copier pour adapter" />
                      )}
                    </div>
                  ) : null}
                </Td>
              </tr>
            ))}
          </tbody>
        </Table>
      </Panel>
    </FadeIn>
  );
}
