"use client";

import Link from "next/link";
import { useActionState } from "react";
import { acceptInvitationAction, type ActionState } from "@/server/actions/auth";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/field";
import { Notice } from "@/components/ui/surface";

export function InvitationForm({ token, isLoggedIn }: { token: string; isLoggedIn: boolean }) {
  const [state, action, pending] = useActionState<ActionState, FormData>(acceptInvitationAction, {});
  return (
    <form action={action} className="mt-6 space-y-4">
      <input type="hidden" name="token" value={token} />
      {!isLoggedIn ? (
        <>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Prénom" htmlFor="firstName" required>
              <Input id="firstName" name="firstName" required />
            </Field>
            <Field label="Nom" htmlFor="lastName" required>
              <Input id="lastName" name="lastName" required />
            </Field>
          </div>
          <Field label="Mot de passe" htmlFor="password" required help="12 caractères minimum. Si un compte existe déjà pour cette adresse, saisissez son mot de passe.">
            <Input id="password" name="password" type="password" autoComplete="new-password" required minLength={12} />
          </Field>
        </>
      ) : null}
      {state.error ? <Notice tone="danger">{state.error}</Notice> : null}
      {!isLoggedIn ? (
        <p className="text-[12.5px] text-ink-3">
          En acceptant, vous acceptez les{" "}
          <Link href="/cgu" target="_blank" className="text-accent hover:underline">
            conditions générales
          </Link>{" "}
          et la{" "}
          <Link href="/confidentialite" target="_blank" className="text-accent hover:underline">
            politique de confidentialité
          </Link>
          .
        </p>
      ) : null}
      <Button type="submit" size="lg" className="w-full" loading={pending}>
        Accepter l&apos;invitation
      </Button>
    </form>
  );
}
