import Link from "next/link";
import { guardOrg } from "@/server/guard";
import { createComplaintAction, createQualityActionAction, updateComplaintAction, updateQualityActionStatusAction } from "@/server/actions/quality";
import { activeReferential, referentialCriteria } from "@/server/quality/analysis";
import { listComplaints, listQualityActions, memberNames, orgMembers, orgSessions } from "@/server/quality/queries";
import { flattenIndicators, QUALIOPI_INDICATORS } from "@/server/quality/referential-data";
import { actionOriginLabels, complaintSourceLabels } from "@/server/quality/labels";
import { fmtDate } from "@/lib/dates";
import { todayParis } from "@/lib/time";
import { StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox, Field, Input, Select, Textarea } from "@/components/ui/field";
import { EmptyState, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FormDialog } from "@/components/admin/form-dialog";
import { readParam } from "@/components/admin/pagination";
import { FadeIn } from "@/components/ui/motion";

export const dynamic = "force-dynamic";

export default async function ActionsPage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const path = `/app/${orgId}/qualite/actions`;
  const ctx = await guardOrg(orgId, path, "quality.view");
  const canManage = ctx.permissions.has("quality.manage");
  const sp = await searchParams;
  const actionStatus = readParam(sp.statut);
  const complaintStatus = readParam(sp.reclamation);
  const today = todayParis();
  const [ref, actions, complaints, members, names, sessions] = await Promise.all([
    activeReferential(ctx.org.id, today),
    listQualityActions(ctx.org.id, actionStatus),
    listComplaints(ctx.org.id, complaintStatus),
    orgMembers(ctx.org.id),
    memberNames(ctx.org.id),
    orgSessions(ctx.org.id),
  ]);
  const indicators = ref ? flattenIndicators(referentialCriteria(ref)) : QUALIOPI_INDICATORS;
  const sessionById = new Map(sessions.map((s) => [s.id, s]));
  const actionById = new Map(actions.map((a) => [a.id, a]));

  const assigneeSelect = (id: string) => (
    <Field label="Responsable" htmlFor={id} help="Une tâche lui est affectée (responsable identifiable). Par défaut : vous.">
      <Select id={id} name="assigneeUserId" defaultValue={ctx.user.id}>
        {members.map((m) => (
          <option key={m.userId} value={m.userId}>
            {m.name}
          </option>
        ))}
      </Select>
    </Field>
  );

  return (
    <FadeIn>
      <PageHeader
        breadcrumb={[{ label: "Qualité", href: `/app/${orgId}/qualite` }, { label: "Actions et réclamations" }]}
        title="Actions et réclamations"
        description="Plan d'amélioration (indicateur 32) et traitement des réclamations et aléas (indicateur 31). Chaque entrée crée une tâche pour un responsable identifiable ; une réclamation traitée devient une preuve."
        actions={
          canManage ? (
            <>
              <FormDialog action={createComplaintAction} trigger="Nouvelle réclamation" triggerVariant="secondary" title="Enregistrer une réclamation ou un aléa" submitLabel="Enregistrer">
                <input type="hidden" name="orgId" value={ctx.org.id} />
                <Field label="Source" required htmlFor="c-source">
                  <Select id="c-source" name="source" defaultValue="apprenant">
                    {Object.entries(complaintSourceLabels).map(([k, v]) => (
                      <option key={k} value={k}>
                        {v}
                      </option>
                    ))}
                  </Select>
                </Field>
                <Field label="Objet" required htmlFor="c-subject">
                  <Input id="c-subject" name="subject" required maxLength={200} />
                </Field>
                <Field label="Description" htmlFor="c-desc">
                  <Textarea id="c-desc" name="description" maxLength={4000} />
                </Field>
                <div className="grid gap-4 sm:grid-cols-2">
                  <Field label="Reçue le" required htmlFor="c-date">
                    <Input id="c-date" name="receivedAt" type="date" defaultValue={today} max={today} required />
                  </Field>
                  <Field label="Session concernée" htmlFor="c-session">
                    <Select id="c-session" name="sessionId" defaultValue="">
                      <option value="">Aucune</option>
                      {sessions.map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.code} : {s.title}
                        </option>
                      ))}
                    </Select>
                  </Field>
                </div>
                {assigneeSelect("c-assignee")}
              </FormDialog>
              <FormDialog action={createQualityActionAction} trigger="Nouvelle action" title="Nouvelle action qualité" description="Issue d'un audit, d'une enquête, d'une réclamation, d'une veille ou d'une analyse." submitLabel="Créer l'action">
                <input type="hidden" name="orgId" value={ctx.org.id} />
                <Field label="Intitulé" required htmlFor="a-title">
                  <Input id="a-title" name="title" required maxLength={200} />
                </Field>
                <Field label="Description" htmlFor="a-desc">
                  <Textarea id="a-desc" name="description" maxLength={4000} />
                </Field>
                <div className="grid gap-4 sm:grid-cols-2">
                  <Field label="Origine" required htmlFor="a-origin">
                    <Select id="a-origin" name="origin" defaultValue="audit">
                      {Object.entries(actionOriginLabels).map(([k, v]) => (
                        <option key={k} value={k}>
                          {v}
                        </option>
                      ))}
                    </Select>
                  </Field>
                  <Field label="Indicateur" htmlFor="a-ind">
                    <Select id="a-ind" name="indicatorCode" defaultValue="">
                      <option value="">Aucun</option>
                      {indicators.map((i) => (
                        <option key={i.code} value={i.code}>
                          {i.number}. {i.label.slice(0, 60)}…
                        </option>
                      ))}
                    </Select>
                  </Field>
                </div>
                <div className="grid gap-4 sm:grid-cols-2">
                  {assigneeSelect("a-assignee")}
                  <Field label="Échéance" htmlFor="a-due">
                    <Input id="a-due" name="dueDate" type="date" min={today} />
                  </Field>
                </div>
              </FormDialog>
            </>
          ) : null
        }
      />

      <Panel className="mb-6">
        <PanelHeader
          title="Réclamations et aléas"
          description="Indicateur 31 : clôturer une réclamation avec sa résolution enregistre la preuve de traitement."
          actions={
            <form method="get" className="flex items-end gap-2">
              <input type="hidden" name="statut" value={actionStatus ?? ""} />
              <Select name="reclamation" defaultValue={complaintStatus ?? ""} aria-label="Filtrer par statut" className="h-8 w-40 text-[12px]">
                <option value="">Tous statuts</option>
                <option value="recue">Reçues</option>
                <option value="en_cours">En cours</option>
                <option value="traitee">Traitées</option>
                <option value="close">Closes</option>
              </Select>
              <Button type="submit" variant="secondary" size="sm">
                Filtrer
              </Button>
            </form>
          }
        />
        {complaints.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Reçue le</Th>
                <Th>Source</Th>
                <Th>Objet</Th>
                <Th>Responsable</Th>
                <Th>Statut</Th>
                <Th>Résolution</Th>
                {canManage ? <Th>Avancement</Th> : null}
              </tr>
            </thead>
            <tbody>
              {complaints.map((c) => {
                const s = c.sessionId ? sessionById.get(c.sessionId) : null;
                const linked = c.qualityActionId ? actionById.get(c.qualityActionId) : null;
                return (
                  <tr key={c.id}>
                    <Td className="num align-top whitespace-nowrap">{fmtDate(c.receivedAt)}</Td>
                    <Td className="align-top">{complaintSourceLabels[c.source] ?? c.source}</Td>
                    <Td className="align-top">
                      {c.subject}
                      {c.description ? <p className="max-w-[40ch] text-[12px] text-ink-3">{c.description}</p> : null}
                      {s ? <p className="text-[12px] text-ink-3">Session {s.code}</p> : null}
                    </Td>
                    <Td className="align-top">{c.assigneeUserId ? (names.get(c.assigneeUserId) ?? "Membre") : "-"}</Td>
                    <Td className="align-top">
                      <StatusBadge status={c.status} />
                    </Td>
                    <Td className="max-w-[36ch] align-top text-[12.5px]">
                      {c.resolution ?? "-"}
                      {c.resolvedAt ? <p className="num text-ink-3">le {fmtDate(c.resolvedAt)}</p> : null}
                      {linked ? <p className="text-[12px] text-ink-3">Action liée : {linked.title}</p> : null}
                    </Td>
                    {canManage ? (
                      <Td className="align-top">
                        {c.status !== "close" ? (
                          <FormDialog action={updateComplaintAction} trigger="Avancer" triggerVariant="secondary" triggerSize="sm" title={`Réclamation : ${c.subject}`} description="Passer en cours, traitée (preuve indicateur 31) ou close. Une action qualité liée peut être créée." submitLabel="Enregistrer">
                            <input type="hidden" name="orgId" value={ctx.org.id} />
                            <input type="hidden" name="complaintId" value={c.id} />
                            <Field label="Nouveau statut" required htmlFor={`cs-${c.id}`}>
                              <Select id={`cs-${c.id}`} name="status" defaultValue={c.status === "recue" ? "en_cours" : "traitee"}>
                                <option value="en_cours">En cours</option>
                                <option value="traitee">Traitée (résolution apportée)</option>
                                <option value="close">Close</option>
                              </Select>
                            </Field>
                            <Field label="Résolution" htmlFor={`cr-${c.id}`} help="Obligatoire pour traiter ou clore.">
                              <Textarea id={`cr-${c.id}`} name="resolution" defaultValue={c.resolution ?? ""} maxLength={4000} />
                            </Field>
                            {!c.qualityActionId ? <Checkbox name="createAction" label="Créer une action d'amélioration liée (indicateur 32)" /> : null}
                          </FormDialog>
                        ) : null}
                      </Td>
                    ) : null}
                  </tr>
                );
              })}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucune réclamation" description="Les réclamations, difficultés et aléas signalés par les parties prenantes sont enregistrés ici avec leur traitement." />
        )}
      </Panel>

      <Panel>
        <PanelHeader
          title="Actions qualité (plan d'amélioration)"
          description="Indicateur 32 : une action terminée devient une preuve d'amélioration continue, à examiner par un humain."
          actions={
            <form method="get" className="flex items-end gap-2">
              <input type="hidden" name="reclamation" value={complaintStatus ?? ""} />
              <Select name="statut" defaultValue={actionStatus ?? ""} aria-label="Filtrer par statut" className="h-8 w-40 text-[12px]">
                <option value="">Tous statuts</option>
                <option value="a_faire">À faire</option>
                <option value="en_cours">En cours</option>
                <option value="terminee">Terminées</option>
                <option value="abandonnee">Abandonnées</option>
              </Select>
              <Button type="submit" variant="secondary" size="sm">
                Filtrer
              </Button>
            </form>
          }
        />
        {actions.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Action</Th>
                <Th>Origine</Th>
                <Th>Indicateur</Th>
                <Th>Responsable</Th>
                <Th>Échéance</Th>
                <Th>Statut</Th>
                {canManage ? <Th>Avancement</Th> : null}
              </tr>
            </thead>
            <tbody>
              {actions.map((a) => (
                <tr key={a.id}>
                  <Td className="align-top">
                    {a.title}
                    {a.description ? <p className="max-w-[44ch] whitespace-pre-line text-[12px] text-ink-3">{a.description}</p> : null}
                    {a.analysisId ? (
                      <Link href={`/app/${orgId}/qualite/analyses/${a.analysisId}`} className="text-[12px] underline underline-offset-4">
                        analyse d&apos;origine
                      </Link>
                    ) : null}
                  </Td>
                  <Td className="align-top">{actionOriginLabels[a.origin ?? ""] ?? a.origin ?? "-"}</Td>
                  <Td className="num align-top">{a.indicatorCode?.replace("IND_", "") ?? "-"}</Td>
                  <Td className="align-top">{a.assigneeUserId ? (names.get(a.assigneeUserId) ?? "Membre") : "-"}</Td>
                  <Td className="num align-top whitespace-nowrap">{a.dueDate ? fmtDate(a.dueDate) : "-"}</Td>
                  <Td className="align-top">
                    <StatusBadge status={a.status} />
                  </Td>
                  {canManage ? (
                    <Td className="align-top">
                      {a.status === "a_faire" || a.status === "en_cours" ? (
                        <FormDialog action={updateQualityActionStatusAction} trigger="Avancer" triggerVariant="secondary" triggerSize="sm" title={`Action : ${a.title}`} submitLabel="Enregistrer">
                          <input type="hidden" name="orgId" value={ctx.org.id} />
                          <input type="hidden" name="actionId" value={a.id} />
                          <Field label="Nouveau statut" required htmlFor={`as-${a.id}`}>
                            <Select id={`as-${a.id}`} name="status" defaultValue={a.status === "a_faire" ? "en_cours" : "terminee"}>
                              <option value="en_cours">En cours</option>
                              <option value="terminee">Terminée (preuve indicateur 32)</option>
                              <option value="abandonnee">Abandonnée</option>
                            </Select>
                          </Field>
                          <Field label="Compte rendu" htmlFor={`an-${a.id}`} help="Obligatoire pour terminer ou abandonner : ce qui a été fait, ou pourquoi.">
                            <Textarea id={`an-${a.id}`} name="note" maxLength={1000} />
                          </Field>
                        </FormDialog>
                      ) : null}
                    </Td>
                  ) : null}
                </tr>
              ))}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucune action" description="Créez une action à partir d'un audit, d'une enquête, d'une réclamation, d'une veille ou d'une analyse." />
        )}
      </Panel>
    </FadeIn>
  );
}
