import Link from "next/link";
import { notFound } from "next/navigation";
import { and, asc, desc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { deleteFunderAction, updateFunderAction } from "@/server/actions/finance";
import { funderKindLabels } from "@/server/finance/compute";
import { formatCents } from "@/lib/money";
import { fmtDate } from "@/lib/dates";
import { StatusBadge } from "@/components/ui/badge";
import { KeyValue, PageHeader, Panel, PanelHeader, EmptyState } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { ActionButton, ActionForm } from "@/components/admin/action-form";
import { FunderFields } from "@/components/finance/funder-fields";

export const dynamic = "force-dynamic";

export default async function FunderPage({ params }: { params: Promise<{ orgId: string; funderId: string }> }) {
  const { orgId, funderId } = await params;
  const ctx = await guardOrg(orgId, `/app/${orgId}/financeurs/${funderId}`, "finance.view");
  const canManage = ctx.permissions.has("finance.manage");
  if (!/^[0-9a-f-]{36}$/.test(funderId)) notFound();
  const [f] = await db.select().from(schema.funders).where(and(eq(schema.funders.id, funderId), eq(schema.funders.orgId, orgId))).limit(1);
  if (!f) notFound();
  const [companies, fundings, invoices] = await Promise.all([
    db.select({ id: schema.companies.id, name: schema.companies.name }).from(schema.companies).where(eq(schema.companies.orgId, orgId)).orderBy(asc(schema.companies.name)).limit(500),
    db
      .select({ x: schema.fundings, reference: schema.enrollments.reference, firstName: schema.persons.firstName, lastName: schema.persons.lastName })
      .from(schema.fundings)
      .innerJoin(schema.enrollments, eq(schema.enrollments.id, schema.fundings.enrollmentId))
      .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
      .where(and(eq(schema.fundings.orgId, orgId), eq(schema.fundings.funderId, funderId)))
      .orderBy(desc(schema.fundings.createdAt))
      .limit(200),
    db.select().from(schema.invoices).where(and(eq(schema.invoices.orgId, orgId), eq(schema.invoices.funderId, funderId))).orderBy(desc(schema.invoices.issueDate)).limit(200),
  ]);
  const company = f.companyId ? companies.find((c) => c.id === f.companyId) : null;

  return (
    <>
      <PageHeader
        breadcrumb={[{ label: "Finance" }, { label: "Financeurs", href: `/app/${orgId}/financeurs` }, { label: f.name }]}
        title={f.name}
        description={`${funderKindLabels[f.kind]}${company ? ` · entreprise ${company.name}` : ""}`}
        actions={canManage ? <ActionButton action={deleteFunderAction} fields={{ orgId, funderId: f.id }} label="Supprimer" variant="danger" confirm={{ title: "Supprimer ce financeur ?", description: "Refusé s'il est rattaché à un financement ou une facture.", danger: true, confirmLabel: "Supprimer" }} /> : null}
      />
      <div className="grid gap-6 lg:grid-cols-[1fr_1.2fr]">
        <Panel>
          <PanelHeader title="Coordonnées" description="Utilisées pour pré-remplir le destinataire des factures." />
          <div className="p-5">
            {canManage ? (
              <ActionForm action={updateFunderAction} submitLabel="Enregistrer" footerClassName="mt-5">
                <input type="hidden" name="orgId" value={orgId} />
                <input type="hidden" name="funderId" value={f.id} />
                <div className="space-y-4">
                  <FunderFields f={f} companies={companies} prefix="fe" />
                </div>
              </ActionForm>
            ) : (
              <KeyValue items={[{ k: "Type", v: funderKindLabels[f.kind] }, { k: "Contact", v: f.contactName }, { k: "E-mail", v: f.email }, { k: "Téléphone", v: f.phone }, { k: "Adresse", v: [f.addressLine1, [f.postalCode, f.city].filter(Boolean).join(" ")].filter(Boolean).join(", ") || "-" }, { k: "SIRET", v: f.siret }, { k: "Notes", v: f.notes }]} />
            )}
          </div>
        </Panel>
        <div className="space-y-6">
          <Panel>
            <PanelHeader title="Financements rattachés" description={`${fundings.length} financement(s).`} />
            {fundings.length ? (
              <Table>
                <thead>
                  <tr>
                    <Th>Inscription</Th>
                    <Th>Libellé</Th>
                    <Th>Statut</Th>
                    <Th num>Montant</Th>
                  </tr>
                </thead>
                <tbody>
                  {fundings.map(({ x, reference, firstName, lastName }) => (
                    <tr key={x.id}>
                      <Td>
                        <Link href={`/app/${orgId}/inscriptions/${x.enrollmentId}`} className="num text-ink hover:underline">
                          {reference}
                        </Link>
                        <p className="text-[12px] text-ink-3">
                          {firstName} {lastName}
                        </p>
                      </Td>
                      <Td>
                        <Link href={`/app/${orgId}/financements/${x.id}`} className="hover:underline">
                          {x.label}
                        </Link>
                      </Td>
                      <Td>
                        <StatusBadge status={x.status} />
                      </Td>
                      <Td num>{formatCents(x.amountCents)}</Td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            ) : (
              <EmptyState title="Aucun financement" description="Les financements se créent depuis une inscription ou la page Financements." />
            )}
          </Panel>
          <Panel>
            <PanelHeader title="Factures adressées" />
            {invoices.length ? (
              <Table>
                <thead>
                  <tr>
                    <Th>Numéro</Th>
                    <Th>Date</Th>
                    <Th>Statut</Th>
                    <Th num>TTC</Th>
                    <Th num>Réglé</Th>
                  </tr>
                </thead>
                <tbody>
                  {invoices.map((i) => (
                    <tr key={i.id}>
                      <Td>
                        <Link href={`/app/${orgId}/factures/${i.id}`} className="num text-ink hover:underline">
                          {i.number ?? "Brouillon"}
                        </Link>
                      </Td>
                      <Td>{fmtDate(i.issueDate)}</Td>
                      <Td>
                        <StatusBadge status={i.status} />
                      </Td>
                      <Td num>{formatCents(i.totalTtcCents)}</Td>
                      <Td num>{formatCents(i.paidCents)}</Td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            ) : (
              <EmptyState title="Aucune facture" />
            )}
          </Panel>
        </div>
      </div>
    </>
  );
}
