import type { Metadata } from "next";
import Link from "next/link";
import { asc, eq } from "drizzle-orm";
import { ArrowRight } from "@phosphor-icons/react/dist/ssr";
import { db, schema } from "@/db";
import { PageHero, btnContour, btnPastel } from "@/components/marketing/site";
import { PricingCalculator, PricingGrid } from "@/components/marketing/pricing";
import { breadcrumbJsonLd, faqJsonLd, homeJsonLd, jsonLdScript, pageMeta } from "@/lib/seo";

export const metadata: Metadata = pageMeta("/tarifs", "Tarifs : 90 % du prix de référence Digiforma", "Grille tarifaire Next Formation : plans Indépendant, Équipe, Organisme, Organisme + et Groupe, options, engagement annuel ou sans engagement, calculateur. Chaque prix affiche sa référence publique et sa date de relevé. Essai gratuit 15 jours.");
export const dynamic = "force-dynamic";

const FAQ_TARIFS = [
  { q: "Pourquoi 90 % de la grille Digiforma ?", a: "Pour que la comparaison soit lisible : même périmètre, mêmes paliers d'apprenants, prix public de référence relevé et daté sur chaque ligne, 10 % de moins garantis. Si la référence baisse, nous suivons." },
  { q: "Qu'est-ce qui est inclus dans tous les plans ?", a: "CRM, catalogue, sessions OF et CFA, planning et émargement par demi-journée, documents générés, financements et facturation, qualité explicable, tâches et pilotage, extranets, assistant IA avec validation humaine, hébergement en France et sauvegardes quotidiennes." },
  { q: "Que se passe-t-il à la fin de l'essai ?", a: "Rien ne part automatiquement : vous choisissez un plan ou vous exportez vos données. Aucune carte bancaire n'est demandée pendant l'essai." },
  { q: "Les options sont-elles obligatoires ?", a: "Non. Elles s'ajoutent au mois, au même prix avec ou sans engagement, et peuvent être retirées à la fin de la période en cours." },
  { q: "Comment est calculé le plan Groupe ?", a: "À partir de 90 % du prix de référence public, puis sur devis selon le nombre d'organismes, d'utilisateurs et le niveau d'accompagnement." },
];

export default async function TarifsPage() {
  const plans = await db.select().from(schema.pricingPlans).where(eq(schema.pricingPlans.isActive, true)).orderBy(asc(schema.pricingPlans.sortOrder));
  const ref = plans.find((p) => p.referenceCheckedAt)?.referenceCheckedAt;
  return (
    <article>
      <script type="application/ld+json" dangerouslySetInnerHTML={jsonLdScript([...homeJsonLd(plans).slice(2, 3), breadcrumbJsonLd([{ name: "Accueil", path: "/" }, { name: "Tarifs", path: "/tarifs" }]), faqJsonLd(FAQ_TARIFS)])} />
      <PageHero crumbs={[{ label: "Accueil", href: "/" }, { label: "Tarifs" }]} eyebrow="Tarifs" title="Dix pour cent de moins que la référence, sur chaque ligne." description={`Chaque offre est calculée à 90 % du prix public relevé sur digiforma.com${ref ? ` le ${ref.split("-").reverse().join("/")}` : ""}. Prix hors taxes, engagement annuel ou sans engagement, essai gratuit 15 jours sans carte bancaire.`} filigrane="-10">
        <Link href="/inscription" className={btnPastel}>
          Essai gratuit 15 jours <ArrowRight size={14} />
        </Link>
        <Link href="/demo" className={btnContour}>
          Démonstration instantanée
        </Link>
      </PageHero>

      <section className="conteneur py-16 lg:py-24">
        <PricingGrid plans={plans} detailed />
      </section>

      <section id="calculateur" className="scroll-mt-14 border-t border-line bg-bg-sunken">
        <div className="conteneur py-16 lg:py-24">
          <h2 className="text-[28px] sm:text-[40px]">Calculer mon tarif</h2>
          <p className="mt-4 max-w-[60ch] text-[14.5px] leading-relaxed text-ink-2">Choisissez un plan et vos options : le total mensuel est comparé à la même configuration au prix de référence public, avec ou sans engagement.</p>
          <div className="mt-10">
            <PricingCalculator plans={plans} />
          </div>
        </div>
      </section>

      <section className="conteneur grid gap-12 py-16 lg:grid-cols-[0.8fr_1.2fr] lg:py-24">
        <h2 className="text-[26px] sm:text-[32px]">Questions sur les tarifs</h2>
        <dl className="border-t border-line-strong">
          {FAQ_TARIFS.map((q) => (
            <div key={q.q} className="border-b border-line py-5">
              <dt className="font-display text-[17px] font-medium">{q.q}</dt>
              <dd className="mt-2 max-w-2xl text-[14px] leading-relaxed text-ink-2">{q.a}</dd>
            </div>
          ))}
        </dl>
      </section>
    </article>
  );
}
