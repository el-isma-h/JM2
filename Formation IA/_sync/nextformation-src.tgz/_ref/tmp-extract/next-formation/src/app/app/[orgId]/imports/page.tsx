import Link from "next/link";
import { notFound } from "next/navigation";
import { desc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { IMPORT_KIND_LIST } from "@/server/imports/kinds";
import { fmtDateTime } from "@/lib/dates";
import { NavActionForm } from "@/components/sessions/nav-action-form";
import { StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/field";
import { EmptyState, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FadeIn } from "@/components/ui/motion";
import { uploadImportAction } from "@/server/actions/imports";

export const dynamic = "force-dynamic";

export default async function ImportsPage({ params }: { params: Promise<{ orgId: string }> }) {
  const { orgId } = await params;
  const ctx = await guardOrg(orgId, `/app/${orgId}/imports`, "enrollments.manage");
  if (ctx.trainerOnly) notFound();
  const imports = await db.select().from(schema.dataImports).where(eq(schema.dataImports.orgId, orgId)).orderBy(desc(schema.dataImports.createdAt)).limit(50);
  const base = `/app/${orgId}/imports`;
  const canExport = ctx.permissions.has("exports.run") && ctx.user.elevated;

  return (
    <FadeIn>
      <PageHeader title="Imports et exports" description="Reprise guidée (T03) : dépôt du fichier, association des colonnes, validation ligne par ligne avec doublons listés (jamais fusionnés), puis application. Les historiques d'heures vont dans les anciennes feuilles, jamais dans les présences." />
      <div className="grid gap-6 lg:grid-cols-[1fr_1fr]">
        <Panel>
          <PanelHeader title="Nouvel import" description="CSV (UTF-8, séparateur ; ou ,) ou Excel .xlsx. 5 000 lignes maximum par fichier." />
          <div className="p-5">
            <NavActionForm action={uploadImportAction} submitLabel="Lire le fichier" footerClassName="mt-4">
              <input type="hidden" name="orgId" value={orgId} />
              <div className="space-y-4">
                <Field label="Type de données" required htmlFor="imp-kind">
                  <Select id="imp-kind" name="kind" required defaultValue="">
                    <option value="">Choisir</option>
                    {IMPORT_KIND_LIST.map((k) => (
                      <option key={k.kind} value={k.kind}>
                        {k.label}
                      </option>
                    ))}
                  </Select>
                </Field>
                <Field label="Fichier" required htmlFor="imp-file" help="La première ligne contient les en-têtes de colonnes.">
                  <Input id="imp-file" name="file" type="file" required accept=".csv,.txt,.xlsx" className="py-1.5" />
                </Field>
              </div>
            </NavActionForm>
          </div>
          <div className="border-t border-line px-5 py-4">
            <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">Modèles CSV</p>
            <ul className="mt-2 grid gap-1.5 text-[13.5px] sm:grid-cols-2">
              {IMPORT_KIND_LIST.map((k) => (
                <li key={k.kind}>
                  <a href={`${base}/modeles/${k.kind}`} className="text-accent hover:underline">
                    {k.label}
                  </a>
                  <span className="ml-1 text-[12px] text-ink-3">· doublons : {k.duplicateRule.toLowerCase()}</span>
                </li>
              ))}
            </ul>
          </div>
        </Panel>
        <Panel>
          <PanelHeader title="Exports CSV" description="Mêmes entités, même périmètre de droits que les listes. Action renforcée (exports.run + vérification)." />
          <div className="p-5">
            {canExport ? (
              <ul className="grid gap-2 sm:grid-cols-2">
                {IMPORT_KIND_LIST.map((k) => (
                  <li key={k.kind}>
                    <Button asChild variant="secondary" size="sm">
                      <a href={`${base}/export/${k.kind}`}>Exporter : {k.label}</a>
                    </Button>
                  </li>
                ))}
              </ul>
            ) : (
              <Notice tone="info">
                {ctx.permissions.has("exports.run") ? (
                  <>
                    Les exports demandent une vérification renforcée.{" "}
                    <Link href={`/securite?next=${encodeURIComponent(base)}`} className="underline">
                      Confirmer mon identité
                    </Link>
                  </>
                ) : (
                  "Les exports demandent la permission « Exporter des données » (exports.run), attribuée par le propriétaire dans Utilisateurs et rôles."
                )}
              </Notice>
            )}
          </div>
        </Panel>
      </div>
      <Panel className="mt-6">
        <PanelHeader title="Historique des imports" description="Un import appliqué est conservé comme trace de reprise." />
        {imports.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Fichier</Th>
                <Th>Type</Th>
                <Th>Déposé le</Th>
                <Th num>Lignes</Th>
                <Th num>Erreurs</Th>
                <Th num>Doublons</Th>
                <Th num>Appliquées</Th>
                <Th>État</Th>
              </tr>
            </thead>
            <tbody>
              {imports.map((i) => (
                <tr key={i.id}>
                  <Td>
                    <Link href={`${base}/${i.id}`} className="font-medium hover:underline">
                      {i.fileName}
                    </Link>
                  </Td>
                  <Td>{IMPORT_KIND_LIST.find((k) => k.kind === i.kind)?.label ?? i.kind}</Td>
                  <Td className="num whitespace-nowrap">{fmtDateTime(i.createdAt)}</Td>
                  <Td num>{(i.preview as { total?: number }).total ?? (i.rows as unknown[]).length}</Td>
                  <Td num>{(i.errors as unknown[]).length}</Td>
                  <Td num>{(i.duplicates as unknown[]).length}</Td>
                  <Td num>{i.appliedCount}</Td>
                  <Td>
                    <StatusBadge status={i.status} />
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucun import" description="Déposez un premier fichier ou téléchargez un modèle CSV." />
        )}
      </Panel>
    </FadeIn>
  );
}
