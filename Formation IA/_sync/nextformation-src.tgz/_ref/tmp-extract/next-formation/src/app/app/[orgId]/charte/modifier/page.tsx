/* eslint-disable @next/next/no-img-element -- images privées servies par des routes protégées, non optimisables */
import Link from "next/link";
import { schema } from "@/db";
import { guardOwner } from "@/server/guard";
import { removeLogoAction, removeSignatureImageAction, updateCharteAction, uploadLogoAction, uploadSignatureImageAction } from "@/server/actions/charte";
import { ActionButton, ActionForm } from "@/components/admin/action-form";
import { ColorField } from "@/components/documents/color-field";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea } from "@/components/ui/field";
import { Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { FadeIn } from "@/components/ui/motion";

export const dynamic = "force-dynamic";

/** F10 / S01 : page d'édition réservée au propriétaire actif (guardOwner) ; chaque action vérifie requireOwner. */
export default async function CharteEditPage({ params }: { params: Promise<{ orgId: string }> }) {
  const { orgId } = await params;
  const base = `/app/${orgId}/charte`;
  const ctx = await guardOwner(orgId, `${base}/modifier`);
  const o = ctx.org;
  return (
    <FadeIn>
      <PageHeader
        breadcrumb={[{ label: "Charte institutionnelle", href: base }, { label: "Modifier" }]}
        title="Modifier la charte"
        description="Chaque modification est journalisée (avant / après). Les documents déjà générés conservent l'identité utilisée au moment de leur génération."
        actions={
          <Button asChild variant="secondary">
            <Link href={base}>Retour</Link>
          </Button>
        }
      />
      <div className="grid gap-5 lg:grid-cols-[1fr_360px]">
        <Panel className="p-5">
          <ActionForm action={updateCharteAction} submitLabel="Enregistrer la charte" className="space-y-6" footerClassName="mt-6">
            <input type="hidden" name="orgId" value={orgId} />
            <div>
              <h3 className="mb-3 text-[13px]">Identité</h3>
              <div className="grid gap-4 md:grid-cols-2">
                <Field label="Raison sociale" required htmlFor="legalName">
                  <Input id="legalName" name="legalName" defaultValue={o.legalName} required />
                </Field>
                <Field label="Nom commercial" htmlFor="tradeName">
                  <Input id="tradeName" name="tradeName" defaultValue={o.tradeName ?? ""} />
                </Field>
                <Field label="Forme juridique" htmlFor="legalForm">
                  <Select id="legalForm" name="legalForm" defaultValue={o.legalForm ?? ""}>
                    <option value="">Non renseignée</option>
                    {schema.legalFormEnum.enumValues.map((f) => (
                      <option key={f} value={f}>
                        {f.replace(/_/g, " ")}
                      </option>
                    ))}
                  </Select>
                </Field>
                <Field label="SIREN" htmlFor="siren" help="9 chiffres, contrôle de clé.">
                  <Input id="siren" name="siren" defaultValue={o.siren ?? ""} className="num" />
                </Field>
                <Field label="SIRET" htmlFor="siret" help="14 chiffres ; doit commencer par le SIREN.">
                  <Input id="siret" name="siret" defaultValue={o.siret ?? ""} className="num" />
                </Field>
                <Field label="Numéro de déclaration d'activité (NDA)" htmlFor="nda" help="Mention obligatoire sur les conventions et contrats.">
                  <Input id="nda" name="nda" defaultValue={o.nda ?? ""} className="num" />
                </Field>
                <Field label="Région d'enregistrement du NDA" htmlFor="ndaRegion">
                  <Input id="ndaRegion" name="ndaRegion" defaultValue={o.ndaRegion ?? ""} />
                </Field>
                <Field label="Code UAI (CFA)" htmlFor="uaiCode">
                  <Input id="uaiCode" name="uaiCode" defaultValue={o.uaiCode ?? ""} className="num" />
                </Field>
              </div>
            </div>
            <div>
              <h3 className="mb-3 text-[13px]">Coordonnées</h3>
              <div className="grid gap-4 md:grid-cols-2">
                <Field label="Adresse" htmlFor="addressLine1" className="md:col-span-2">
                  <Input id="addressLine1" name="addressLine1" defaultValue={o.addressLine1 ?? ""} />
                </Field>
                <Field label="Complément" htmlFor="addressLine2" className="md:col-span-2">
                  <Input id="addressLine2" name="addressLine2" defaultValue={o.addressLine2 ?? ""} />
                </Field>
                <Field label="Code postal" htmlFor="postalCode">
                  <Input id="postalCode" name="postalCode" defaultValue={o.postalCode ?? ""} className="num" />
                </Field>
                <Field label="Ville" htmlFor="city">
                  <Input id="city" name="city" defaultValue={o.city ?? ""} />
                </Field>
                <Field label="E-mail" htmlFor="email">
                  <Input id="email" name="email" type="email" defaultValue={o.email ?? ""} />
                </Field>
                <Field label="Téléphone" htmlFor="phone">
                  <Input id="phone" name="phone" defaultValue={o.phone ?? ""} className="num" />
                </Field>
                <Field label="Site web" htmlFor="website" className="md:col-span-2">
                  <Input id="website" name="website" defaultValue={o.website ?? ""} />
                </Field>
              </div>
            </div>
            <div>
              <h3 className="mb-3 text-[13px]">Signataire</h3>
              <div className="grid gap-4 md:grid-cols-2">
                <Field label="Nom du signataire" htmlFor="signatoryName">
                  <Input id="signatoryName" name="signatoryName" defaultValue={o.signatoryName ?? ""} />
                </Field>
                <Field label="Fonction" htmlFor="signatoryTitle">
                  <Input id="signatoryTitle" name="signatoryTitle" defaultValue={o.signatoryTitle ?? ""} />
                </Field>
              </div>
            </div>
            <div>
              <h3 className="mb-3 text-[13px]">Couleurs et textes des documents</h3>
              <div className="grid gap-4 md:grid-cols-2">
                <Field label="Couleur principale" htmlFor="primaryColor" help="Filets et titres des PDF. Format #rrggbb.">
                  <ColorField id="primaryColor" name="primaryColor" defaultValue={o.primaryColor} />
                </Field>
                <Field label="Couleur secondaire" htmlFor="secondaryColor">
                  <ColorField id="secondaryColor" name="secondaryColor" defaultValue={o.secondaryColor} />
                </Field>
                <Field label="En-tête des documents" htmlFor="documentHeader" help="Ligne sous le nom de l'organisme. Vide : SIRET et NDA." className="md:col-span-2">
                  <Input id="documentHeader" name="documentHeader" defaultValue={o.documentHeader ?? ""} />
                </Field>
                <Field label="Pied de page des documents" htmlFor="documentFooter" help="Vide : raison sociale, adresse, SIRET, NDA. La pagination est ajoutée automatiquement." className="md:col-span-2">
                  <Textarea id="documentFooter" name="documentFooter" rows={2} defaultValue={o.documentFooter ?? ""} />
                </Field>
              </div>
            </div>
          </ActionForm>
        </Panel>

        <div className="space-y-5">
          <Panel>
            <PanelHeader title="Logo" description="PNG ou JPEG, 2 Mo maximum, stocké en privé, affiché via une route protégée." />
            <div className="space-y-4 p-5">
              {o.logoKey ? <img src={`${base}/logo`} alt="Logo actuel" className="max-h-24 border border-line bg-white p-2" /> : <p className="text-[13px] text-ink-3">Aucun logo.</p>}
              <ActionForm action={uploadLogoAction} submitLabel="Déposer le logo" submitSize="sm" className="space-y-3">
                <input type="hidden" name="orgId" value={orgId} />
                <Field label="Fichier" htmlFor="logo-file" required>
                  <Input id="logo-file" name="file" type="file" accept=".png,.jpg,.jpeg" required className="py-1.5" />
                </Field>
              </ActionForm>
              {o.logoKey ? <ActionButton action={removeLogoAction} fields={{ orgId }} label="Retirer le logo" variant="ghost" confirm={{ title: "Retirer le logo", description: "Les prochains documents n'auront plus de logo." }} /> : null}
            </div>
          </Panel>
          <Panel>
            <PanelHeader title="Signature du signataire" description="Image PNG ou JPEG (1 Mo max.) disponible pour les documents internes ; jamais apposée automatiquement sur un document à signer." />
            <div className="space-y-4 p-5">
              {o.signatureKey ? <img src={`${base}/signature`} alt="Signature actuelle" className="max-h-20 border border-line bg-white p-2" /> : <p className="text-[13px] text-ink-3">Aucune image de signature.</p>}
              <ActionForm action={uploadSignatureImageAction} submitLabel="Déposer la signature" submitSize="sm" className="space-y-3">
                <input type="hidden" name="orgId" value={orgId} />
                <Field label="Fichier" htmlFor="sig-file" required>
                  <Input id="sig-file" name="file" type="file" accept=".png,.jpg,.jpeg" required className="py-1.5" />
                </Field>
              </ActionForm>
              {o.signatureKey ? <ActionButton action={removeSignatureImageAction} fields={{ orgId }} label="Retirer la signature" variant="ghost" confirm={{ title: "Retirer l'image de signature" }} /> : null}
            </div>
          </Panel>
          <Notice tone="info">
            Aperçu avec la charte :{" "}
            <a href={`${base}/apercu`} target="_blank" rel="noreferrer" className="underline">
              document témoin (PDF)
            </a>
            .
          </Notice>
        </div>
      </div>
    </FadeIn>
  );
}
