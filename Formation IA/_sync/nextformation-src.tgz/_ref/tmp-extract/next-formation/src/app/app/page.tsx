import { redirect } from "next/navigation";
import { requireUser } from "@/server/auth";
import { listAccessibleOrgs, listExtranetMemberships } from "@/server/authz";

/** Point d'entrée : un organisme → son tableau de bord ; plusieurs → la liste ; extranet seul → l'espace correspondant. */
export default async function AppIndex() {
  const user = await requireUser();
  const orgs = await listAccessibleOrgs(user);
  if (orgs.length === 1) redirect(`/app/${orgs[0].id}`);
  if (orgs.length > 1) redirect("/app/organismes");
  const extranet = await listExtranetMemberships(user);
  const roles = extranet.flatMap((m) => (Array.isArray(m.m.roles) ? (m.m.roles as string[]) : []));
  if (roles.includes("learner")) redirect("/moi");
  if (roles.includes("employer")) redirect("/entreprise");
  redirect("/app/organismes");
}
