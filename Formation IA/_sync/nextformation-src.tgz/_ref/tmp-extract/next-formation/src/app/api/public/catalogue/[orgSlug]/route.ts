import { NextResponse } from "next/server";
import { loadPublicCatalogue, publicCatalogueJson } from "@/server/catalog/public";
import { clientIp, hit, tooManyMessage } from "@/server/rate-limit";

export const dynamic = "force-dynamic";

/** Catalogue public au format JSON (site web, plugin WordPress) : programmes publiés avec version active et sessions à venir. */
export async function GET(_req: Request, { params }: { params: Promise<{ orgSlug: string }> }) {
  const ip = await clientIp();
  const rl = await hit("public:catalogue:api", ip, { limit: 120, windowSeconds: 60 * 60 });
  if (!rl.ok) return NextResponse.json({ error: tooManyMessage(rl) }, { status: 429, headers: { "Retry-After": String(rl.retryAfterSeconds) } });
  const { orgSlug } = await params;
  const data = await loadPublicCatalogue(orgSlug);
  if (!data) return NextResponse.json({ error: "Catalogue introuvable." }, { status: 404 });
  return NextResponse.json(publicCatalogueJson(data), {
    headers: { "Cache-Control": "public, max-age=300", "Access-Control-Allow-Origin": "*" },
  });
}
