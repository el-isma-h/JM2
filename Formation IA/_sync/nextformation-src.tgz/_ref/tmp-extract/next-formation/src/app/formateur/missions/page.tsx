import { guardTrainer } from "@/server/extranet/guard";
import { listMissions } from "@/server/missions/queries";
import { NoAttachment } from "@/components/extranet/shell";
import { PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { TrainerMissionList } from "@/components/missions/trainer-missions";

export const dynamic = "force-dynamic";

/** Mes missions : propositions à accepter ou refuser, missions acceptées (date du premier cours), historique. */
export default async function TrainerMissionsPage() {
  const ctx = await guardTrainer("/formateur/missions");
  if (!ctx) return <NoAttachment kind="trainer" />;
  const rows = await listMissions(ctx.org.id, { trainerId: ctx.trainer.id, limit: 100 });
  const open = rows.filter((r) => (r.m.status === "proposee" || r.m.status === "sans_reponse") && !r.m.replacedByMissionId);
  const accepted = rows.filter((r) => r.m.status === "acceptee");
  const past = rows.filter((r) => !open.includes(r) && !accepted.includes(r));
  return (
    <>
      <PageHeader title="Mes missions" description={`Missions proposées par ${ctx.org.tradeName ?? ctx.org.legalName} : thème, dates, heures avec formateur et rémunération. Une fois la mission acceptée, indiquez la date du premier cours.`} />
      <div className="space-y-6">
        <Panel>
          <PanelHeader title="À traiter" description="Propositions en attente de votre réponse." />
          <TrainerMissionList rows={open} emptyTitle="Aucune proposition en attente" emptyDescription="Les nouvelles propositions de mission apparaîtront ici." />
        </Panel>
        <Panel>
          <PanelHeader title="Missions acceptées" />
          <TrainerMissionList rows={accepted} emptyTitle="Aucune mission acceptée en cours" />
        </Panel>
        <Panel>
          <PanelHeader title="Historique" />
          <TrainerMissionList rows={past} emptyTitle="Aucun historique" />
        </Panel>
      </div>
    </>
  );
}
