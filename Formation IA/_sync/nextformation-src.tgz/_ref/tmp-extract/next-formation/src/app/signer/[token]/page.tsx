import { findByToken, tokenState, SIGNER_ROLE_LABELS, signersOf } from "@/server/documents/signatures";
import { fmtDateTime } from "@/lib/dates";
import { SignForm } from "@/components/documents/sign-form";
import { Logo } from "@/components/ui/logo";
import { Badge } from "@/components/ui/badge";
import { Notice, Panel, PanelHeader } from "@/components/ui/surface";

export const dynamic = "force-dynamic";

/** Page publique de signature (sans session) : accès par jeton personnel reçu par e-mail. */
export default async function SignPage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  const tc = await findByToken(token);
  const state = tc ? tokenState(tc) : null;
  return (
    <main className="min-h-dvh bg-bg px-4 py-10">
      <div className="mx-auto max-w-3xl space-y-6">
        <div className="flex items-center justify-between">
          <Logo />
          {tc ? <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">{tc.org.legalName}</span> : null}
        </div>
        {!tc ? (
          <Notice tone="danger" title="Lien invalide">
            Ce lien de signature n&apos;existe pas ou a été remplacé par une relance. Contactez l&apos;organisme qui vous l&apos;a envoyé.
          </Notice>
        ) : (
          <>
            <Panel>
              <PanelHeader title={tc.document.title} description={`Signature électronique demandée par ${tc.org.legalName}. Vous signez en tant que ${tc.signer.name} (${SIGNER_ROLE_LABELS[tc.signer.role] ?? tc.signer.role}).`} />
              <div className="px-5 py-4">
                <ul className="flex flex-wrap gap-3 text-[12.5px]">
                  {signersOf(tc.request).map((s) => (
                    <li key={s.id} className="flex items-center gap-2">
                      <span>{s.name}</span>
                      {s.signedAt ? <Badge tone="ok">Signé le {fmtDateTime(new Date(s.signedAt))}</Badge> : <Badge tone="warn">En attente</Badge>}
                    </li>
                  ))}
                </ul>
              </div>
            </Panel>
            {state === "ok" ? (
              <>
                <Panel>
                  <PanelHeader title="Document à lire" description="Lisez l'intégralité du document avant de signer. Vous pouvez l'ouvrir dans un nouvel onglet." actions={<a href={`/signer/${token}/pdf`} target="_blank" rel="noreferrer" className="font-mono text-[10px] uppercase tracking-[0.2em] text-accent underline">Ouvrir le PDF</a>} />
                  <iframe src={`/signer/${token}/pdf`} title="Document à signer" className="h-[70dvh] w-full border-0 bg-white" />
                </Panel>
                <Panel>
                  <PanelHeader title="Signer" description="Trois étapes : code de confirmation reçu par e-mail, signature manuscrite, consentement. L'heure du serveur, votre adresse IP et votre navigateur sont enregistrés dans la page de preuve." />
                  <div className="p-5">
                    <SignForm token={token} signerEmail={tc.signer.email} />
                  </div>
                </Panel>
              </>
            ) : state === "already_signed" ? (
              <Notice tone="ok" title="Déjà signé">
                Vous avez signé ce document le {tc.signer.signedAt ? fmtDateTime(new Date(tc.signer.signedAt)) : ""}. {tc.request.status === "signee" ? "Tous les signataires ont signé : le document final est disponible auprès de l'organisme." : "Le document sera finalisé quand tous les signataires auront signé."}
              </Notice>
            ) : state === "expired" ? (
              <Notice tone="warn" title="Lien expiré">Ce lien a expiré. Demandez à l&apos;organisme une nouvelle invitation.</Notice>
            ) : (
              <Notice tone="info" title="Demande close">Cette demande de signature est terminée ou a été annulée par l&apos;organisme.</Notice>
            )}
          </>
        )}
        <p className="text-center text-[11px] text-ink-3">Signature électronique interne Next Formation. Aucun compte n&apos;est nécessaire ; ce lien est personnel.</p>
      </div>
    </main>
  );
}
