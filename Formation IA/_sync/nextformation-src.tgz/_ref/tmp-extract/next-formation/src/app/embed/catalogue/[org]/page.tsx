import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { appUrl } from "@/lib/env";
import { fmtDate } from "@/lib/dates";
import { formatCents } from "@/lib/money";
import { catalogueFamilies, familyKey, filterByFamily, loadPublicCatalogueByRef } from "@/server/catalog/public";
import { modalityLabels, programKindLabels } from "@/components/catalog/fields";

export const dynamic = "force-dynamic";

export const metadata: Metadata = { title: "Catalogue des formations", robots: { index: false, follow: false } };

/**
 * Hauteur transmise à la page parente (iframe auto-ajustée) : message { type: "next-formation:height", height }.
 * Le parent filtre sur l'origine de l'instance (voir le plugin WordPress et l'extrait fourni dans l'aide).
 */
const RESIZE_SCRIPT = `(function(){function s(){try{parent.postMessage({type:"next-formation:height",height:(document.getElementById("nf-embed")||document.documentElement).scrollHeight},"*")}catch(e){}}window.addEventListener("load",s);if(window.ResizeObserver){new ResizeObserver(s).observe(document.getElementById("nf-embed")||document.documentElement)}else{setInterval(s,1000)}})();`;

/**
 * Widget embarquable (iframe) : catalogue public d'un organisme, repéré par le slug du tenant ou l'id de l'organisme.
 * Paramètres : ?famille=<catégorie> filtre ; ?entete=0 masque l'en-tête. Les liens ouvrent le catalogue complet
 * (fiche et demande d'information) dans un nouvel onglet.
 */
export default async function EmbedCataloguePage({ params, searchParams }: { params: Promise<{ org: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { org: ref } = await params;
  const sp = await searchParams;
  const famille = typeof sp.famille === "string" ? sp.famille : "";
  const showHeader = sp.entete !== "0";
  const all = await loadPublicCatalogueByRef(ref);
  if (!all) notFound();
  const data = filterByFamily(all, famille);
  const { org, items, tenant } = data;
  const name = org.tradeName ?? org.legalName;
  const accent = /^#[0-9a-f]{6}$/i.test(org.primaryColor) ? org.primaryColor : "#4b2a7f";
  const families = catalogueFamilies(all);
  const familyLabel = families.find((f) => f.key === familyKey(famille))?.label;
  const base = `${appUrl()}/catalogue-public/${tenant.slug}`;

  return (
    <div id="nf-embed" className="bg-bg text-ink" style={{ ["--accent" as string]: accent }}>
      <div className="mx-auto max-w-[960px] px-4 py-5 sm:px-5">
        {showHeader ? (
          <header className="mb-5 flex flex-wrap items-end justify-between gap-3 border-b border-line pb-4">
            <div className="min-w-0">
              <p className="font-mono text-[10px] uppercase tracking-[0.24em]" style={{ color: accent }}>
                {familyLabel ? `Formations : ${familyLabel}` : "Catalogue des formations"}
              </p>
              <h1 className="mt-2 text-[22px] sm:text-[26px]">{name}</h1>
            </div>
            {org.qualiopiNumber ? <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-ink-3">Qualiopi n° {org.qualiopiNumber}</p> : null}
          </header>
        ) : null}
        {org.isDemo ? <p className="mb-4 border border-warn/70 px-3 py-2 text-[12.5px] text-warn-ink">Espace de démonstration : organisme et formations fictifs.</p> : null}
        {items.length ? (
          <ul className="grid gap-4 sm:grid-cols-2">
            {items.map(({ program, version, certification, sessions }) => {
              const next = sessions[0];
              return (
                <li key={program.id} className="flex min-w-0 flex-col border border-line bg-bg-elev">
                  <div className="flex-1 px-4 py-4">
                    <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-ink-3">
                      {programKindLabels[program.kind]}
                      {certification?.rncpCode ? ` · RNCP ${certification.rncpCode}` : certification?.rsCode ? ` · RS ${certification.rsCode}` : ""}
                      {program.cpfEligible ? " · éligible CPF" : ""}
                    </p>
                    <h2 className="mt-2 text-[16px] leading-snug">{program.title}</h2>
                    {version ? (
                      <dl className="mt-3 grid grid-cols-3 gap-x-3 gap-y-0.5 text-[12.5px]">
                        <dt className="font-mono text-[9.5px] uppercase tracking-[0.16em] text-ink-3">Durée</dt>
                        <dt className="font-mono text-[9.5px] uppercase tracking-[0.16em] text-ink-3">Modalité</dt>
                        <dt className="font-mono text-[9.5px] uppercase tracking-[0.16em] text-ink-3">Tarif HT</dt>
                        <dd className="num">{version.durationHours} h</dd>
                        <dd className="truncate">{modalityLabels[version.modality] ?? version.modality}</dd>
                        <dd className="num">{version.priceCents != null ? formatCents(version.priceCents) : "Sur devis"}</dd>
                      </dl>
                    ) : null}
                    <p className="mt-3 text-[12.5px] text-ink-2">{next ? <span className="num">Prochaine session : {fmtDate(next.startDate)}</span> : "Dates à la demande"}</p>
                  </div>
                  <div className="flex flex-wrap gap-4 border-t border-line px-4 py-3">
                    <a href={`${base}#${program.slug}`} target="_blank" rel="noopener noreferrer" className="font-sans text-[11px] font-medium uppercase tracking-[0.18em] underline-offset-4 hover:underline" style={{ color: accent }}>
                      Voir le programme
                    </a>
                    <a href={`${base}?formation=${program.id}#demande`} target="_blank" rel="noopener noreferrer" className="font-sans text-[11px] font-medium uppercase tracking-[0.18em] text-ink-2 underline-offset-4 hover:text-ink hover:underline">
                      Demander des informations
                    </a>
                  </div>
                </li>
              );
            })}
          </ul>
        ) : (
          <p className="border border-line px-4 py-10 text-center text-[13.5px] text-ink-2">{famille ? "Aucune formation publiée dans cette famille pour le moment." : "Aucune formation publiée pour le moment."}</p>
        )}
        <p className="mt-5 font-mono text-[9.5px] uppercase tracking-[0.2em] text-ink-3">
          Catalogue propulsé par{" "}
          <a href={appUrl()} target="_blank" rel="noopener noreferrer" className="hover:text-ink">
            Next Formation
          </a>
        </p>
      </div>
      <script dangerouslySetInnerHTML={{ __html: RESIZE_SCRIPT }} />
    </div>
  );
}
