import Link from "next/link";
import { notFound } from "next/navigation";
import { and, asc, eq, inArray } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { trainerSessionIds } from "@/server/authz";
import { parseMarkdown } from "@/server/documents/markdown";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Field, Select } from "@/components/ui/field";
import { readParam } from "@/components/admin/pagination";
import { ElearningTimer, QuizPlayer, type QuizQuestion } from "@/components/pedagogy/elearning-player";

export const dynamic = "force-dynamic";

function Markdown({ src }: { src: string }) {
  const blocks = parseMarkdown(src);
  return (
    <div className="space-y-3 text-[14px] leading-relaxed text-ink">
      {blocks.map((b, i) => {
        if (b.type === "heading") {
          const Tag = b.level === 1 ? "h2" : "h3";
          return <Tag key={i}>{b.inlines.map((x) => x.text).join("")}</Tag>;
        }
        if (b.type === "list")
          return (
            <ul key={i} className="list-disc space-y-1 pl-5">
              {b.items.map((it, j) => (
                <li key={j}>{it.map((x, k) => (x.bold ? <strong key={k}>{x.text}</strong> : <span key={k}>{x.text}</span>))}</li>
              ))}
            </ul>
          );
        if (b.type === "rule") return <hr key={i} className="border-line" />;
        return <p key={i}>{b.inlines.map((x, k) => (x.bold ? <strong key={k}>{x.text}</strong> : <span key={k}>{x.text}</span>))}</p>;
      })}
    </div>
  );
}

/** Lancement d'un module par le personnel (aperçu, ou au nom d'une inscription choisie). L'extranet apprenant (équipe G) réutilise les mêmes composants. */
export default async function ElearningModulePage({ params, searchParams }: { params: Promise<{ orgId: string; moduleId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId, moduleId } = await params;
  const base = `/app/${orgId}`;
  const ctx = await guardOrg(orgId, `${base}/elearning/${moduleId}`, "catalog.view");
  if (!/^[0-9a-f-]{36}$/.test(moduleId)) notFound();
  const [m] = await db.select().from(schema.elearningModules).where(and(eq(schema.elearningModules.id, moduleId), eq(schema.elearningModules.orgId, orgId))).limit(1);
  if (!m) notFound();
  const sp = await searchParams;
  const enrollmentParam = readParam(sp.enrollment);
  const scope = await trainerSessionIds(ctx);
  const enrollments = m.programVersionId
    ? await db
        .select({ id: schema.enrollments.id, reference: schema.enrollments.reference, firstName: schema.persons.firstName, lastName: schema.persons.lastName })
        .from(schema.enrollments)
        .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
        .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.enrollments.sessionId))
        .where(and(eq(schema.enrollments.orgId, orgId), eq(schema.trainingSessions.programVersionId, m.programVersionId), inArray(schema.enrollments.status, ["inscrit", "en_cours"]), scope ? (scope.length ? inArray(schema.enrollments.sessionId, scope) : eq(schema.enrollments.id, "00000000-0000-0000-0000-000000000000")) : undefined))
        .orderBy(asc(schema.persons.lastName))
    : [];
  const enrollmentId = enrollmentParam && enrollments.some((e) => e.id === enrollmentParam) ? enrollmentParam : null;
  const content = (m.content ?? {}) as { markdown?: string; quiz?: QuizQuestion[] | null; launch?: string; manifestTitle?: string | null; schemaVersion?: string | null; files?: number };
  const canRecord = ctx.permissions.has("dossier.pedagogy.manage");

  return (
    <>
      <PageHeader
        breadcrumb={[{ label: "E-learning", href: `${base}/elearning` }, { label: m.title }]}
        title={m.title}
        description={m.description ?? undefined}
        actions={
          <div className="flex items-center gap-2">
            <Badge>{m.kind}</Badge>
            {!m.isActive ? <Badge tone="warn">Inactif</Badge> : null}
            <Button asChild variant="secondary" size="sm">
              <Link href={`${base}/elearning`}>Retour</Link>
            </Button>
          </div>
        }
      />
      {m.programVersionId ? (
        <Panel className="mb-6 px-5 py-4">
          <form method="get" className="flex flex-wrap items-end gap-3">
            <Field label="Inscription (temps enregistré au nom de)" htmlFor="enr" className="w-80" help={canRecord ? "Sans inscription : simple aperçu, rien n'est enregistré." : "Votre habilitation ne permet pas d'enregistrer un temps."}>
              <Select id="enr" name="enrollment" defaultValue={enrollmentId ?? ""}>
                <option value="">Aperçu seulement</option>
                {enrollments.map((e) => (
                  <option key={e.id} value={e.id}>
                    {e.lastName} {e.firstName} · {e.reference}
                  </option>
                ))}
              </Select>
            </Field>
            <Button type="submit" variant="secondary">
              Appliquer
            </Button>
          </form>
        </Panel>
      ) : (
        <Notice tone="info" className="mb-6">
          Module hors programme : aperçu seulement, aucun temps n&apos;est enregistré.
        </Notice>
      )}
      {enrollmentId && canRecord ? (
        <div className="mb-6">
          <ElearningTimer orgId={orgId} moduleId={m.id} enrollmentId={enrollmentId} />
        </div>
      ) : null}

      {m.kind === "scorm" && m.packageKey && content.launch ? (
        <Panel>
          <PanelHeader title={content.manifestTitle ?? "Paquet SCORM"} description={`SCORM ${content.schemaVersion ?? ""} · ${content.files ?? 0} fichiers · page de lancement ${content.launch}. Lecteur basique : le paquet est servi tel quel, le temps est compté par la page.`} />
          <iframe src={`/api/elearning/${orgId}/${m.id}/${content.launch}`} title={m.title} className="h-[70dvh] w-full border-0 bg-white" sandbox="allow-scripts allow-same-origin allow-forms allow-popups" />
        </Panel>
      ) : m.kind === "moodle" || m.kind === "lien" ? (
        <Panel className="p-6">
          <p className="text-[13.5px] text-ink-2">{m.kind === "moodle" ? `Cours Moodle${m.externalId ? ` n° ${m.externalId}` : ""} : le suivi se fait sur Moodle ; reportez le temps relevé via « Saisir un temps », puis validez-le.` : "Ressource externe."}</p>
          <Button asChild className="mt-4">
            <a href={m.url ?? "#"} target="_blank" rel="noopener noreferrer">
              Ouvrir {m.kind === "moodle" ? "le cours Moodle" : "le lien"}
            </a>
          </Button>
          <p className="num mt-3 break-all text-[12px] text-ink-3">{m.url}</p>
        </Panel>
      ) : (
        <div className="space-y-6">
          {content.markdown?.trim() ? (
            <Panel className="p-6">
              <Markdown src={content.markdown} />
            </Panel>
          ) : null}
          {content.quiz?.length ? (
            <Panel>
              <PanelHeader title="Quiz" description={`${content.quiz.length} question(s), réussite à partir de 50 %.`} />
              <div className="p-5">
                <QuizPlayer orgId={orgId} moduleId={m.id} enrollmentId={canRecord ? enrollmentId : null} questions={content.quiz} />
              </div>
            </Panel>
          ) : null}
          {!content.markdown?.trim() && !content.quiz?.length ? <Notice tone="warn">Ce module n&apos;a pas de contenu.</Notice> : null}
        </div>
      )}
    </>
  );
}
