import Link from "next/link";
import { guardOrg } from "@/server/guard";
import { trainerSessionIds } from "@/server/authz";
import { listPeriods } from "@/server/planning/service";
import { todayParis } from "@/lib/time";
import { fmtDate } from "@/lib/dates";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/ui/badge";
import { EmptyState, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { readParam } from "@/components/admin/pagination";

export const dynamic = "force-dynamic";

const partLabel: Record<string, string> = { matin: "Matin", apres_midi: "Après-midi", journee: "Journée", soir: "Soir" };

function shift(iso: string, days: number) {
  const d = new Date(`${iso}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

export default async function EmargementPage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const base = `/app/${orgId}`;
  const ctx = await guardOrg(orgId, `${base}/emargement`, "attendance.record");
  const sp = await searchParams;
  const today = todayParis();
  const horizon = readParam(sp.horizon) === "passe" ? "passe" : "avenir";
  const range = horizon === "passe" ? { from: shift(today, -30), to: shift(today, -1) } : { from: today, to: shift(today, 14) };
  const scope = await trainerSessionIds(ctx);
  const rows = (await listPeriods(ctx, range)).filter((r) => r.period.status !== "annulee" && r.slot.status !== "annulee");
  const todays = rows.filter((r) => r.slot.date === today);
  const upcoming = rows.filter((r) => r.slot.date !== today);

  const renderRows = (list: typeof rows) => (
    <Table>
      <thead>
        <tr>
          <Th>Date</Th>
          <Th>Période</Th>
          <Th>Session</Th>
          <Th>Formateur</Th>
          <Th>Salle</Th>
          <Th>État</Th>
          <Th />
        </tr>
      </thead>
      <tbody>
        {list.map((r) => (
          <tr key={r.period.id}>
            <Td className="whitespace-nowrap">{fmtDate(r.slot.date, "EEE d MMM yyyy")}</Td>
            <Td>
              <span className="num">
                {r.period.startTime}-{r.period.endTime}
              </span>
              <span className="ml-2 text-[12px] text-ink-3">{partLabel[r.period.part]}</span>
            </Td>
            <Td>
              <span className="font-medium">{r.session.code}</span>
              <p className="text-[12px] text-ink-3">{r.moduleTitle ?? r.session.title}</p>
            </Td>
            <Td>{r.trainerFirst ? `${r.trainerFirst} ${r.trainerLast}` : "-"}</Td>
            <Td>{r.roomName ?? "-"}</Td>
            <Td>
              <StatusBadge status={r.period.status} />
            </Td>
            <Td>
              <Button asChild variant="secondary" size="sm">
                <Link href={`${base}/emargement/${r.period.id}`}>{r.period.status === "cloturee" ? "Consulter" : r.period.status === "ouverte" ? "Feuille" : "Préparer"}</Link>
              </Button>
            </Td>
          </tr>
        ))}
      </tbody>
    </Table>
  );

  return (
    <>
      <PageHeader
        title="Émargement"
        description="Feuilles d'émargement par période (matin / après-midi). La préparation est possible à l'avance ; la saisie des présences n'est acceptée qu'après le début réel, la clôture qu'après la fin réelle (heure serveur, Europe/Paris)."
        actions={
          <div className="flex gap-2">
            <Button asChild variant={horizon === "avenir" ? "primary" : "secondary"} size="sm">
              <Link href={`${base}/emargement`}>Aujourd&apos;hui et à venir</Link>
            </Button>
            <Button asChild variant={horizon === "passe" ? "primary" : "secondary"} size="sm">
              <Link href={`${base}/emargement?horizon=passe`}>30 derniers jours</Link>
            </Button>
          </div>
        }
      />
      {horizon === "avenir" ? (
        <Panel className="mb-6">
          <PanelHeader title={`Aujourd'hui, ${fmtDate(today, "EEEE d MMMM")}`} description={ctx.trainerOnly ? "Seules vos périodes affectées apparaissent." : undefined} />
          {todays.length ? renderRows(todays) : <EmptyState title="Aucune période aujourd'hui" description={scope && !scope.length ? "Vous n'êtes affecté à aucune session." : "Rien à émarger aujourd'hui."} />}
        </Panel>
      ) : null}
      <Panel>
        <PanelHeader title={horizon === "passe" ? "Périodes des 30 derniers jours" : "Périodes à venir (14 jours)"} description={horizon === "passe" ? "Les périodes non clôturées restent ouvertes à la saisie ; les clôturées sont verrouillées." : "Ouvrez la feuille à l'avance pour la préparer."} />
        {upcoming.length ? renderRows(upcoming) : <EmptyState title="Aucune période" description="Planifiez des séances depuis le planning." action={<Button asChild variant="secondary"><Link href={`${base}/planning`}>Ouvrir le planning</Link></Button>} />}
      </Panel>
    </>
  );
}
