import { asc, isNotNull, isNull, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardAdmin } from "@/server/guard";
import { seedTemplatesAction, toggleTemplateActiveAction, updateTemplateBodyAction, verifyTemplateAction } from "@/server/actions/admin-templates";
import { fmtDateTime } from "@/lib/dates";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Field, Input, Textarea } from "@/components/ui/field";
import { EmptyState, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { ActionButton } from "@/components/admin/action-form";
import { FormDialog } from "@/components/admin/form-dialog";

export const dynamic = "force-dynamic";

export default async function TemplatesAdminPage() {
  await guardAdmin("/admin/modeles");
  const [rows, [orgCopies]] = await Promise.all([
    db.select().from(schema.documentTemplates).where(isNull(schema.documentTemplates.orgId)).orderBy(asc(schema.documentTemplates.category), asc(schema.documentTemplates.code)),
    db.select({ n: sql<number>`count(*)::int` }).from(schema.documentTemplates).where(isNotNull(schema.documentTemplates.orgId)),
  ]);

  return (
    <>
      <PageHeader
        title="Modèles de documents"
        description={`Modèles plateforme en Markdown avec variables {{…}} : une modification crée une nouvelle version (jamais de remplacement silencieux) et invalide la vérification humaine. ${orgCopies?.n ?? 0} modèle(s) propre(s) aux organismes ne sont pas touchés.`}
        actions={<ActionButton action={seedTemplatesAction} fields={{}} label="Charger les modèles fournis" />}
      />
      <Panel>
        <PanelHeader title="Modèles plateforme" description="Variable absente au rendu → marqueur « [À COMPLÉTER : …] », jamais une valeur inventée." />
        {rows.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Modèle</Th>
                <Th>Catégorie</Th>
                <Th>Portée</Th>
                <Th num>Version</Th>
                <Th>Vérification</Th>
                <Th>État</Th>
                <Th />
              </tr>
            </thead>
            <tbody>
              {rows.map((t) => (
                <tr key={t.id}>
                  <Td>
                    <span className="font-medium">{t.title}</span>
                    <p className="num text-[11.5px] text-ink-3">{t.code}</p>
                    {t.description ? <p className="max-w-[320px] text-[12px] text-ink-2">{t.description}</p> : null}
                  </Td>
                  <Td>
                    <StatusBadge status={t.category} />
                  </Td>
                  <Td className="text-[12.5px] text-ink-2">
                    {t.scope}, {t.activity === "both" ? "OF et CFA" : t.activity.toUpperCase()}
                  </Td>
                  <Td num>{t.version}</Td>
                  <Td className="text-[12px]">
                    {t.verifiedAt ? (
                      <>
                        <Badge tone="ok">Vérifié</Badge>
                        <p className="text-ink-3">{fmtDateTime(t.verifiedAt)}</p>
                        {t.verifiedNote ? <p className="max-w-[220px] text-ink-2">{t.verifiedNote}</p> : null}
                      </>
                    ) : (
                      <Badge tone="warn">À vérifier</Badge>
                    )}
                  </Td>
                  <Td>{t.isActive ? <Badge tone="ok">Actif</Badge> : <Badge tone="neutral">Inactif</Badge>}</Td>
                  <Td>
                    <div className="flex flex-wrap justify-end gap-1">
                      <FormDialog action={updateTemplateBodyAction} trigger="Modifier" triggerVariant="ghost" triggerSize="sm" title={`Modifier : ${t.title}`} description="Markdown avec variables {{enrollment.person.fullName}}, {{session.title}}, {{org.legalName}}… Enregistrer un corps modifié crée la version suivante." submitLabel="Enregistrer" wide>
                        <input type="hidden" name="id" value={t.id} />
                        <Field label="Titre" htmlFor={`tt-${t.id}`} required>
                          <Input id={`tt-${t.id}`} name="title" defaultValue={t.title} required />
                        </Field>
                        <Field label="Description" htmlFor={`td-${t.id}`}>
                          <Input id={`td-${t.id}`} name="description" defaultValue={t.description ?? ""} />
                        </Field>
                        <Field label="Corps (Markdown)" htmlFor={`tb-${t.id}`} required>
                          <Textarea id={`tb-${t.id}`} name="body" defaultValue={t.body} required className="num min-h-80 text-[12px]" />
                        </Field>
                      </FormDialog>
                      <FormDialog action={verifyTemplateAction} trigger="Vérifier" triggerVariant="ghost" triggerSize="sm" title={`Vérification humaine : ${t.title}`} description="Attestez la relecture de cette version (mentions légales, variables, mise en page)." submitLabel="Attester">
                        <input type="hidden" name="id" value={t.id} />
                        <Field label="Note de vérification" htmlFor={`tv-${t.id}`} required>
                          <Input id={`tv-${t.id}`} name="note" required placeholder="Relu avec le juriste le…" />
                        </Field>
                      </FormDialog>
                      <ActionButton action={toggleTemplateActiveAction} fields={{ id: t.id }} label={t.isActive ? "Désactiver" : "Activer"} variant="ghost" />
                    </div>
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucun modèle plateforme" description="Chargez les modèles fournis (conventions, convocations, attestations…)." />
        )}
      </Panel>
    </>
  );
}
