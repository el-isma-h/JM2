import { asc, desc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardAdmin } from "@/server/guard";
import { backupTenantAction, restoreBackupAction, verifyBackupAction } from "@/server/actions/backup";
import { storageBackend } from "@/server/storage";
import { fmtDateTime } from "@/lib/dates";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Select } from "@/components/ui/field";
import { EmptyState, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { ActionButton, ActionForm } from "@/components/admin/action-form";
import { fmtBytes } from "@/components/admin/utils";

export const dynamic = "force-dynamic";

export default async function BackupsPage() {
  await guardAdmin("/admin/sauvegardes");
  const [rows, tenants] = await Promise.all([
    db
      .select({ b: schema.backups, tenant: schema.tenants.name, isDemo: schema.tenants.isDemo, email: schema.users.email })
      .from(schema.backups)
      .leftJoin(schema.tenants, eq(schema.tenants.id, schema.backups.tenantId))
      .leftJoin(schema.users, eq(schema.users.id, schema.backups.createdBy))
      .orderBy(desc(schema.backups.createdAt))
      .limit(200),
    db.select({ id: schema.tenants.id, name: schema.tenants.name, isDemo: schema.tenants.isDemo }).from(schema.tenants).orderBy(asc(schema.tenants.isDemo), asc(schema.tenants.name)),
  ]);

  return (
    <>
      <PageHeader title="Sauvegardes" description="Sauvegarde par organisation : toutes ses lignes et ses fichiers, compressés, avec empreinte sha256. La restauration crée toujours une nouvelle organisation, sans jamais écraser l'existante." />

      <div className="grid gap-6 lg:grid-cols-[minmax(0,3fr)_minmax(0,1.3fr)]">
        <Panel>
          <PanelHeader title="Sauvegardes disponibles" description={`Stockage : ${storageBackend()}, dossier backups/.`} />
          {rows.length ? (
            <Table>
              <thead>
                <tr>
                  <Th>Organisation</Th>
                  <Th>Date</Th>
                  <Th num>Taille</Th>
                  <Th>Empreinte</Th>
                  <Th />
                </tr>
              </thead>
              <tbody>
                {rows.map(({ b, tenant, isDemo, email }) => (
                  <tr key={b.id}>
                    <Td>
                      {tenant ?? <span className="text-ink-3">Organisation supprimée</span>}
                      {isDemo ? (
                        <Badge tone="warn" className="ml-2">
                          Démo
                        </Badge>
                      ) : null}
                      <p className="text-[12px] text-ink-3">{email ? `par ${email}` : "tâche automatique"}</p>
                    </Td>
                    <Td className="whitespace-nowrap text-ink-2">{fmtDateTime(b.createdAt)}</Td>
                    <Td num>{fmtBytes(b.sizeBytes)}</Td>
                    <Td className="num text-[12px] text-ink-3" title={b.sha256 ?? ""}>
                      {b.sha256?.slice(0, 12)}…
                    </Td>
                    <Td>
                      <div className="flex flex-wrap justify-end gap-1">
                        <Button asChild variant="ghost" size="sm">
                          <a href={`/admin/sauvegardes/${b.id}/telecharger`}>Télécharger</a>
                        </Button>
                        <ActionButton action={verifyBackupAction} fields={{ backupId: b.id }} label="Vérifier" variant="ghost" />
                        <ActionButton
                          action={restoreBackupAction}
                          fields={{ backupId: b.id }}
                          label="Restaurer"
                          confirm={{
                            title: "Restaurer dans une nouvelle organisation",
                            description: "L'empreinte sha256 est vérifiée, puis une copie complète est créée avec de nouveaux identifiants. L'organisation d'origine n'est pas modifiée. Les invitations en attente sont révoquées dans la copie.",
                            phrase: "RESTAURER",
                            input: { name: "name", label: "Nom de la nouvelle organisation", help: "Facultatif. Par défaut : nom d'origine suivi de la date de restauration." },
                            confirmLabel: "Restaurer",
                          }}
                        />
                      </div>
                    </Td>
                  </tr>
                ))}
              </tbody>
            </Table>
          ) : (
            <EmptyState title="Aucune sauvegarde" description="Créez une première sauvegarde d'organisation, ou planifiez la tâche backup:tenant." />
          )}
        </Panel>

        <div className="space-y-6 self-start">
          <Panel>
            <PanelHeader title="Nouvelle sauvegarde" />
            <ActionForm action={backupTenantAction} submitLabel="Sauvegarder" className="px-5 py-4" footerClassName="mt-4">
              <Field label="Organisation" htmlFor="b-tenant">
                <Select id="b-tenant" name="tenantId" required defaultValue="">
                  <option value="" disabled>
                    Choisir
                  </option>
                  {tenants.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name}
                      {t.isDemo ? " (démo)" : ""}
                    </option>
                  ))}
                </Select>
              </Field>
            </ActionForm>
          </Panel>
          <Notice tone="info" title="Sauvegarde complète de la base">
            Ces sauvegardes couvrent une organisation. Pour la base entière (pg_dump) et le dossier de stockage, suivez la procédure de docs/sauvegarde.md.
          </Notice>
        </div>
      </div>
    </>
  );
}
