"use client";

import { ActionForm } from "@/components/admin/action-form";
import { Field, Input } from "@/components/ui/field";
import { bulkReassignAction } from "@/server/actions/tasks";
import { AssigneeSelect, type StaffOption } from "../_components/task-actions";

/** Réaffectation en masse : les cases à cocher du tableau sont rattachées à ce formulaire (attribut form). */
export function BulkReassign({ orgId, staff }: { orgId: string; staff: StaffOption[] }) {
  return (
    <div className="border-b border-line px-5 py-3">
      <form id="bulk-form" className="hidden" />
      <ActionForm action={bulkReassignAction} submitLabel="Réaffecter la sélection" submitVariant="secondary" submitSize="sm" className="flex flex-wrap items-end gap-3" footerClassName="mb-0.5">
        <input type="hidden" name="orgId" value={orgId} />
        <Field label="Nouveau responsable des tâches cochées" htmlFor="bulk-target" className="w-72">
          <AssigneeSelect id="bulk-target" name="target" staff={staff} allowNone />
        </Field>
        <Field label="Motif" htmlFor="bulk-note" className="w-64">
          <Input id="bulk-note" name="note" placeholder="Absence, relais…" />
        </Field>
        <BulkIds />
      </ActionForm>
    </div>
  );
}

/** Copie les cases cochées (form="bulk-form") dans le formulaire d'action au moment de l'envoi. */
function BulkIds() {
  return (
    <input
      type="hidden"
      name="_bulk"
      value=""
      ref={(el) => {
        if (!el) return;
        const form = el.form;
        if (!form || form.dataset.bulkBound) return;
        form.dataset.bulkBound = "1";
        form.addEventListener("formdata", (ev) => {
          const boxes = document.querySelectorAll<HTMLInputElement>('input[name="taskIds"][form="bulk-form"]:checked');
          boxes.forEach((b) => ev.formData.append("taskIds", b.value));
        });
      }}
    />
  );
}
