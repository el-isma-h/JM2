import { guardOrg } from "@/server/guard";
import { createWatchItemAction } from "@/server/actions/quality";
import { listWatchItems, memberNames } from "@/server/quality/queries";
import { watchKindIndicator, watchKindLabels } from "@/server/quality/labels";
import { fmtDate } from "@/lib/dates";
import { todayParis } from "@/lib/time";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox, Field, Input, Select, Textarea } from "@/components/ui/field";
import { EmptyState, PageHeader, Panel, PanelHeader, Stat } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FormDialog } from "@/components/admin/form-dialog";
import { readParam } from "@/components/admin/pagination";
import { FadeIn } from "@/components/ui/motion";

export const dynamic = "force-dynamic";

export default async function VeillePage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const path = `/app/${orgId}/qualite/veille`;
  const ctx = await guardOrg(orgId, path, "quality.view");
  const canManage = ctx.permissions.has("quality.manage");
  const sp = await searchParams;
  const kind = readParam(sp.type);
  const today = todayParis();
  const [items, all, names] = await Promise.all([listWatchItems(ctx.org.id, kind), listWatchItems(ctx.org.id), memberNames(ctx.org.id)]);
  const counts = Object.fromEntries(Object.keys(watchKindLabels).map((k) => [k, all.filter((i) => i.kind === k).length]));

  return (
    <FadeIn>
      <PageHeader
        breadcrumb={[{ label: "Qualité", href: `/app/${orgId}/qualite` }, { label: "Veille" }]}
        title="Veille"
        description="Veille réglementaire (indicateur 23), métiers et compétences (24), pédagogique et technologique (25), handicap (26). Chaque entrée partagée est une preuve organisationnelle reliée à l'indicateur correspondant."
        actions={
          canManage ? (
            <FormDialog action={createWatchItemAction} trigger="Nouvelle entrée de veille" title="Nouvelle entrée de veille" description="Source, résumé et enseignement exploité : la preuve est créée avec la date de l'entrée." submitLabel="Enregistrer">
              <input type="hidden" name="orgId" value={ctx.org.id} />
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Type" required htmlFor="w-kind">
                  <Select id="w-kind" name="kind" defaultValue="reglementaire">
                    {Object.entries(watchKindLabels).map(([k, v]) => (
                      <option key={k} value={k}>
                        {v} ({watchKindIndicator[k].replace("IND_", "ind. ")})
                      </option>
                    ))}
                  </Select>
                </Field>
                <Field label="Date" required htmlFor="w-date">
                  <Input id="w-date" name="date" type="date" defaultValue={today} max={today} required />
                </Field>
              </div>
              <Field label="Titre" required htmlFor="w-title">
                <Input id="w-title" name="title" required maxLength={200} />
              </Field>
              <Field label="Source (adresse)" htmlFor="w-url">
                <Input id="w-url" name="url" type="url" placeholder="https://" maxLength={500} />
              </Field>
              <Field label="Résumé" htmlFor="w-summary">
                <Textarea id="w-summary" name="summary" maxLength={4000} />
              </Field>
              <Field label="Enseignement exploité / impact pour l'organisme" htmlFor="w-impact" help="Ce que l'organisme en fait (mise à jour d'un programme, d'une procédure, action qualité…).">
                <Textarea id="w-impact" name="impact" maxLength={2000} />
              </Field>
              <Checkbox name="sharedWithTeam" defaultChecked label="Partager à l'équipe (direction, responsables, qualité) par notification" />
            </FormDialog>
          ) : null
        }
      />

      <Panel className="mb-6">
        <div className="grid grid-cols-2 gap-6 px-5 py-5 lg:grid-cols-4">
          {Object.entries(watchKindLabels).map(([k, v]) => (
            <Stat key={k} label={v} value={<span className="num">{counts[k]}</span>} hint={watchKindIndicator[k].replace("IND_", "Indicateur ")} />
          ))}
        </div>
      </Panel>

      <Panel>
        <PanelHeader
          title="Entrées"
          actions={
            <form method="get" className="flex items-end gap-2">
              <Select name="type" defaultValue={kind ?? ""} aria-label="Filtrer par type" className="h-8 w-56 text-[12px]">
                <option value="">Tous les types</option>
                {Object.entries(watchKindLabels).map(([k, v]) => (
                  <option key={k} value={k}>
                    {v}
                  </option>
                ))}
              </Select>
              <Button type="submit" variant="secondary" size="sm">
                Filtrer
              </Button>
            </form>
          }
        />
        {items.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Date</Th>
                <Th>Type</Th>
                <Th>Entrée</Th>
                <Th>Enseignement exploité</Th>
                <Th>Auteur</Th>
                <Th>Partage</Th>
              </tr>
            </thead>
            <tbody>
              {items.map((i) => (
                <tr key={i.id}>
                  <Td className="num align-top whitespace-nowrap">{fmtDate(i.date)}</Td>
                  <Td className="align-top whitespace-nowrap">
                    {watchKindLabels[i.kind] ?? i.kind}
                    <p className="num text-[11px] text-ink-3">{watchKindIndicator[i.kind] ?? ""}</p>
                  </Td>
                  <Td className="align-top">
                    {i.url ? (
                      <a href={i.url} target="_blank" rel="noreferrer" className="text-ink underline-offset-4 hover:underline">
                        {i.title}
                      </a>
                    ) : (
                      i.title
                    )}
                    {i.summary ? <p className="max-w-[44ch] text-[12px] text-ink-3">{i.summary}</p> : null}
                  </Td>
                  <Td className="max-w-[36ch] align-top text-[12.5px]">{i.impact ?? "-"}</Td>
                  <Td className="align-top">{i.authorId ? (names.get(i.authorId) ?? "Membre") : "-"}</Td>
                  <Td className="align-top">{i.sharedWithTeam ? <Badge tone="ok">Partagée</Badge> : <Badge tone="neutral">Personnelle</Badge>}</Td>
                </tr>
              ))}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucune entrée de veille" description="Ajoutez les textes, publications et innovations suivis par l'organisme : chacune devient une preuve organisationnelle." />
        )}
      </Panel>
    </FadeIn>
  );
}
