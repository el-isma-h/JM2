import type { MetadataRoute } from "next";
import { appUrl } from "@/lib/env";
import { FEATURES, SOLUTIONS } from "@/lib/marketing-data";
import { db, schema } from "@/db";
import { and, eq, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

/** Pages publiques indexables (les espaces privés sont exclus et marqués noindex dans src/proxy.ts). */
export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = appUrl();
  const updated = new Date("2026-10-23");
  const pages: [string, number, MetadataRoute.Sitemap[number]["changeFrequency"]][] = [
    ["", 1, "weekly"],
    ["/tarifs", 0.9, "weekly"],
    ["/demo", 0.9, "monthly"],
    ["/comparatif/digiforma", 0.9, "monthly"],
    ["/fonctionnalites", 0.8, "monthly"],
    ...FEATURES.map((f): [string, number, MetadataRoute.Sitemap[number]["changeFrequency"]] => [`/fonctionnalites/${f.slug}`, 0.8, "monthly"]),
    ["/solutions", 0.8, "monthly"],
    ...SOLUTIONS.map((s): [string, number, MetadataRoute.Sitemap[number]["changeFrequency"]] => [`/solutions/${s.slug}`, 0.8, "monthly"]),
    ["/securite-conformite", 0.7, "monthly"],
    ["/inscription", 0.7, "monthly"],
    ["/contact", 0.6, "yearly"],
    ["/a-propos", 0.5, "yearly"],
    ["/cgu", 0.2, "yearly"],
    ["/confidentialite", 0.2, "yearly"],
    ["/mentions-legales", 0.1, "yearly"],
  ];
  const out: MetadataRoute.Sitemap = pages.map(([p, priority, changeFrequency]) => ({ url: `${base}${p}`, lastModified: updated, changeFrequency, priority }));
  // Catalogues publics des organismes clients (hors démonstration, au moins une formation publiée).
  try {
    const rows = await db
      .selectDistinct({ slug: schema.tenants.slug })
      .from(schema.tenants)
      .innerJoin(schema.organismes, eq(schema.organismes.tenantId, schema.tenants.id))
      .innerJoin(schema.programs, and(eq(schema.programs.orgId, schema.organismes.id), eq(schema.programs.isPublished, true)))
      .where(and(eq(schema.tenants.isDemo, false), eq(schema.organismes.isDemo, false), sql`coalesce(${schema.tenants.settings}->>'archive', '') = ''`));
    for (const r of rows) out.push({ url: `${base}/catalogue-public/${r.slug}`, lastModified: new Date(), changeFrequency: "weekly", priority: 0.7 });
  } catch {
    // base indisponible : sitemap des pages marketing seul
  }
  return out;
}
