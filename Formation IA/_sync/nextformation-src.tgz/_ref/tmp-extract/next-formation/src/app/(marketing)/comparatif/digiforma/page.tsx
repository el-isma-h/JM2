import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight } from "@phosphor-icons/react/dist/ssr";
import { PageHero, btnContour, btnEncre, btnOsContour, btnPastel } from "@/components/marketing/site";
import { ComparatifTable } from "@/components/marketing/comparatif";
import { FEATURES } from "@/lib/marketing-data";
import { breadcrumbJsonLd, faqJsonLd, jsonLdScript, pageMeta } from "@/lib/seo";

export const metadata: Metadata = pageMeta("/comparatif/digiforma", "Next Formation vs Digiforma : comparatif factuel", "Périmètre, règles d'heures, verrouillage de l'émargement, qualité explicable, droits par rôle, multi-organismes et prix : ce que Next Formation garantit, ce que Digiforma publie, ce que font les logiciels historiques.");

const ENGAGEMENTS = [
  { t: "Les heures ne s'additionnent pas", d: "Prévues, programmées, effectuées, justifiées, validées : cinq statuts qui restent distincts. Une attestation ne cite que des heures validées." },
  { t: "Une période clôturée est immuable", d: "Aucune modification directe. Une correction exceptionnelle passe par une demande, une décision et une application qui crée une nouvelle ligne." },
  { t: "Un pourcentage n'est pas une attestation", d: "L'analyse qualité est une photographie datée ; les contrôles qui exigent une appréciation humaine restent marqués « à examiner »." },
  { t: "Le cumul de rôles ne fait pas un propriétaire", d: "Sécurité, charte institutionnelle et gestion du RIB exigent le propriétaire actif, quelles que soient les permissions accumulées." },
  { t: "Rien ne part sans validation humaine", d: "Les propositions de l'assistant IA sont enregistrées puis validées, modifiées ou refusées par une personne habilitée." },
  { t: "Le prix est public et daté", d: "Chaque ligne tarifaire affiche son prix de référence, sa source et sa date de relevé. Dix pour cent de moins, garanti." },
];

const FAQ_COMP = [
  { q: "Next Formation est-il compatible avec mes exports Digiforma ?", a: "Les exports Excel et CSV sont repris par l'import guidé : entreprises, contacts, apprenants, inscriptions et historiques d'heures, avec rapport d'erreurs et détection des doublons avant validation." },
  { q: "D'où viennent les informations sur Digiforma ?", a: "Uniquement de ses pages publiques (digiforma.com, grille tarifaire relevée le 23/10/2026). Ce qui n'y figure pas est indiqué « non documenté publiquement ». Nous vous invitons à vérifier auprès de l'éditeur." },
  { q: "Qu'entendez-vous par logiciel historique ?", a: "Les outils de gestion de formation installés depuis plusieurs années, souvent déployés sur site, comme Galaxy. Les constats sont généraux et dépendent de chaque installation." },
];

export default function ComparatifPage() {
  return (
    <article>
      <script type="application/ld+json" dangerouslySetInnerHTML={jsonLdScript([breadcrumbJsonLd([{ name: "Accueil", path: "/" }, { name: "Comparatif Digiforma", path: "/comparatif/digiforma" }]), faqJsonLd(FAQ_COMP)])} />
      <PageHero crumbs={[{ label: "Accueil", href: "/" }, { label: "Comparatif" }, { label: "Digiforma" }]} eyebrow="Comparatif factuel" title="Next Formation vs Digiforma." description="Même périmètre, règles métier plus strictes, dix pour cent de moins. Ce tableau ne contient que des faits publiquement vérifiables ou des engagements de Next Formation sur sa propre colonne." filigrane="VS">
        <Link href="/inscription" className={btnPastel}>
          Essai gratuit 15 jours <ArrowRight size={14} />
        </Link>
        <Link href="/tarifs" className={btnContour}>
          Voir les tarifs
        </Link>
      </PageHero>

      <section className="conteneur py-16 lg:py-24">
        <ComparatifTable />
      </section>

      <section className="sombre bg-[#0a0b0d] text-[#f3f0e8]">
        <div className="conteneur py-16 lg:py-24">
          <p className="etiquette">Six engagements</p>
          <h2 className="mt-5 max-w-3xl text-[28px] sm:text-[40px]">Ce que Next Formation garantit, par le serveur.</h2>
          <ol className="mt-12 grid gap-px border border-[#f3f0e8]/15 bg-[#f3f0e8]/15 sm:grid-cols-2 lg:grid-cols-3">
            {ENGAGEMENTS.map((e, i) => (
              <li key={e.t} className="bg-[#0a0b0d] p-6">
                <span className="num font-mono text-[11px] tracking-[0.2em] text-[#c9b8f0]">{String(i + 1).padStart(2, "0")}</span>
                <h3 className="mt-5 text-[19px]">{e.t}</h3>
                <p className="mt-3 text-[13.5px] leading-relaxed text-[#f3f0e8]/60">{e.d}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className="conteneur grid gap-12 py-16 lg:grid-cols-[0.8fr_1.2fr] lg:py-24">
        <div>
          <h2 className="text-[26px] sm:text-[32px]">Questions fréquentes</h2>
          <p className="mt-6 font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">Fonctions comparées</p>
          <ul className="mt-3 flex flex-wrap gap-2">
            {FEATURES.slice(0, 7).map((f) => (
              <li key={f.slug}>
                <Link href={`/fonctionnalites/${f.slug}`} className="inline-flex min-h-[36px] items-center border border-line-strong px-3 font-mono text-[10px] uppercase tracking-[0.16em] text-ink-2 transition-colors hover:border-ink hover:text-ink">
                  {f.short}
                </Link>
              </li>
            ))}
          </ul>
        </div>
        <dl className="border-t border-line-strong">
          {FAQ_COMP.map((q) => (
            <div key={q.q} className="border-b border-line py-5">
              <dt className="font-display text-[17px] font-medium">{q.q}</dt>
              <dd className="mt-2 max-w-2xl text-[14px] leading-relaxed text-ink-2">{q.a}</dd>
            </div>
          ))}
        </dl>
      </section>

      <section className="border-t border-line bg-bg-sunken">
        <div className="conteneur flex flex-wrap items-center justify-between gap-6 py-14">
          <div>
            <h2 className="text-[26px] sm:text-[32px]">Jugez sur vos dossiers, pas sur un tableau.</h2>
            <p className="mt-2 text-[14px] text-ink-2">Démonstration sans compte en quelques secondes, essai gratuit de quinze jours avec vos données.</p>
          </div>
          <div className="flex flex-wrap gap-3">
            <Link href="/demo" className={btnEncre}>
              Explorer la démonstration <ArrowRight size={14} />
            </Link>
            <Link href="/inscription" className={btnOsContour}>
              Commencer l&apos;essai
            </Link>
          </div>
        </div>
      </section>
    </article>
  );
}
