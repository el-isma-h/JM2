import { guardTrainer } from "@/server/extranet/guard";
import { listLearnersForSessions, recentAttendances } from "@/server/extranet/queries";
import { NoAttachment } from "@/components/extranet/shell";
import { partLabels } from "@/components/extranet/ui";
import { readParam } from "@/components/admin/pagination";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Select } from "@/components/ui/field";
import { EmptyState, Notice, PageHeader, Panel } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { fmtDate } from "@/lib/dates";

export const dynamic = "force-dynamic";

/**
 * Apprenants de mes sessions : nom, groupe, présences récentes. Aucune pièce administrative, aucune information
 * interne, aucune donnée financière (CDC §8, formateur seul).
 */
export default async function TrainerLearners({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const ctx = await guardTrainer("/formateur/apprenants");
  if (!ctx) return <NoAttachment kind="trainer" />;
  const sp = await searchParams;
  const sessionParam = readParam(sp.session);
  const sessionIds = sessionParam && ctx.sessionIds.includes(sessionParam) ? [sessionParam] : ctx.sessionIds;
  const learners = await listLearnersForSessions(ctx.org.id, sessionIds);
  const recent = await recentAttendances(ctx.org.id, learners.map((l) => l.enrollmentId), 30);
  const byEnrollment = new Map<string, typeof recent>();
  for (const r of recent) byEnrollment.set(r.enrollmentId, [...(byEnrollment.get(r.enrollmentId) ?? []), r]);
  return (
    <>
      <PageHeader title="Mes apprenants" description="Apprenants des sessions qui vous sont affectées, avec leurs présences des 30 derniers jours. Les informations administratives et financières ne sont pas accessibles depuis cet espace." />
      <Panel>
        <form method="get" className="flex flex-wrap items-end gap-3 border-b border-line px-5 py-3">
          <Field label="Session" htmlFor="session" className="w-full max-w-sm">
            <Select id="session" name="session" defaultValue={sessionParam ?? ""}>
              <option value="">Toutes mes sessions</option>
              {ctx.sessions.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.code} · {s.title}
                </option>
              ))}
            </Select>
          </Field>
          <Button type="submit" variant="secondary">
            Filtrer
          </Button>
        </form>
        {learners.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Apprenant</Th>
                <Th>Session</Th>
                <Th>Groupe</Th>
                <Th>Inscription</Th>
                <Th>Présences récentes</Th>
              </tr>
            </thead>
            <tbody>
              {learners.map((l) => {
                const atts = byEnrollment.get(l.enrollmentId) ?? [];
                const absent = atts.filter((a) => a.status === "absent").length;
                return (
                  <tr key={l.enrollmentId}>
                    <Td>
                      <span className="font-medium text-ink">
                        {l.firstName} {l.lastName}
                      </span>
                      {l.hasAccommodations ? <Badge tone="info" className="ml-2">Aménagements</Badge> : null}
                    </Td>
                    <Td>{l.sessionTitle}</Td>
                    <Td>{l.groupName ?? "-"}</Td>
                    <Td>
                      <StatusBadge status={l.status} />
                    </Td>
                    <Td>
                      {atts.length ? (
                        <div className="flex flex-wrap gap-1">
                          {atts.slice(0, 8).map((a, i) => (
                            <span key={i} title={`${fmtDate(a.date)} ${partLabels[a.part] ?? a.part}`}>
                              <StatusBadge status={a.status} />
                            </span>
                          ))}
                          {absent ? <span className="num ml-1 text-[12px] text-danger-ink">{absent} absence{absent > 1 ? "s" : ""}</span> : null}
                        </div>
                      ) : (
                        <span className="text-[12.5px] text-ink-3">Aucune présence sur 30 jours</span>
                      )}
                    </Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucun apprenant" description={ctx.sessionIds.length ? "Aucune inscription active sur ces sessions." : "Aucune session ne vous est affectée."} />
        )}
      </Panel>
      {learners.some((l) => l.hasAccommodations) ? (
        <Notice tone="info" className="mt-6">
          Le badge « Aménagements » signale un besoin d&apos;adaptation déclaré. Le détail est communiqué par le référent handicap de l&apos;organisme, pas depuis cet espace.
        </Notice>
      ) : null}
    </>
  );
}
