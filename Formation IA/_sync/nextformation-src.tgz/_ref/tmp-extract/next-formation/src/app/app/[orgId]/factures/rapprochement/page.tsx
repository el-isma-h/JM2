import Link from "next/link";
import { and, desc, eq, inArray } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { importBankStatementAction, reconcilePaymentAction } from "@/server/actions/finance";
import { proposeMatches, type BankRow } from "@/server/finance/compute";
import { OPEN_INVOICE_STATUSES } from "@/server/finance/service";
import { formatCents } from "@/lib/money";
import { fmtDate, fmtDateTime } from "@/lib/dates";
import { Badge } from "@/components/ui/badge";
import { Field, Input, Select } from "@/components/ui/field";
import { EmptyState, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { ActionForm } from "@/components/admin/action-form";
import { readParam } from "@/components/admin/pagination";

export const dynamic = "force-dynamic";

export default async function ReconciliationPage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  await guardOrg(orgId, `/app/${orgId}/factures/rapprochement`, "finance.view", "finance.manage");
  const sp = await searchParams;
  const releve = readParam(sp.releve);

  const statements = await db
    .select({ id: schema.documents.id, title: schema.documents.title, createdAt: schema.documents.createdAt })
    .from(schema.documents)
    .where(and(eq(schema.documents.orgId, orgId), eq(schema.documents.sourceType, "bank_statement")))
    .orderBy(desc(schema.documents.createdAt))
    .limit(20);
  const current = releve && /^[0-9a-f-]{36}$/i.test(releve) ? await db.select().from(schema.documents).where(and(eq(schema.documents.id, releve), eq(schema.documents.orgId, orgId), eq(schema.documents.sourceType, "bank_statement"))).limit(1).then((r) => r[0] ?? null) : null;

  let proposals: ReturnType<typeof proposeMatches> = [];
  let errors: string[] = [];
  let reconciledLines = new Set<number>();
  let openInvoices: { id: string; number: string; totalTtcCents: number; paidCents: number; billToName: string }[] = [];
  if (current) {
    const gd = (current.generationData ?? {}) as { rows?: BankRow[]; errors?: string[] };
    errors = gd.errors ?? [];
    const rows = gd.rows ?? [];
    const inv = await db
      .select({ id: schema.invoices.id, number: schema.invoices.number, totalTtcCents: schema.invoices.totalTtcCents, paidCents: schema.invoices.paidCents, billTo: schema.invoices.billTo })
      .from(schema.invoices)
      .where(and(eq(schema.invoices.orgId, orgId), inArray(schema.invoices.status, OPEN_INVOICE_STATUSES), inArray(schema.invoices.kind, ["facture", "acompte"])));
    openInvoices = inv.map((i) => ({ id: i.id, number: i.number ?? "", totalTtcCents: i.totalTtcCents, paidCents: i.paidCents, billToName: (i.billTo as { name?: string })?.name ?? "" }));
    const done = await db.select({ note: schema.payments.note }).from(schema.payments).where(and(eq(schema.payments.orgId, orgId)));
    reconciledLines = new Set(done.map((p) => p.note ?? "").filter((n) => n.startsWith(`RELEVE:${current.id}:`)).map((n) => Number(n.split(":")[2])));
    proposals = proposeMatches(rows, openInvoices);
  }

  return (
    <>
      <PageHeader
        breadcrumb={[{ label: "Finance" }, { label: "Factures", href: `/app/${orgId}/factures` }, { label: "Rapprochement bancaire" }]}
        title="Rapprochement bancaire"
        description="Importez un relevé CSV (date ; libellé ; montant ; référence). Le système propose une correspondance par numéro de facture puis par montant ; chaque ligne est validée par un humain avant de créer le règlement."
      />
      <div className="grid gap-6 lg:grid-cols-[1fr_2fr]">
        <div className="space-y-6">
          <Panel>
            <PanelHeader title="Importer un relevé" description="CSV exporté de votre banque, 2 Mo maximum. Le fichier est conservé comme document interne." />
            <div className="p-5">
              <ActionForm action={importBankStatementAction} submitLabel="Importer" submitVariant="secondary">
                <input type="hidden" name="orgId" value={orgId} />
                <Field label="Fichier CSV" htmlFor="bank-file" className="mb-3">
                  <Input id="bank-file" name="file" type="file" accept=".csv,text/csv" required className="py-1.5" />
                </Field>
              </ActionForm>
            </div>
          </Panel>
          <Panel>
            <PanelHeader title="Relevés importés" />
            {statements.length ? (
              <ul className="divide-y divide-line text-[13px]">
                {statements.map((s) => (
                  <li key={s.id} className="px-5 py-2.5">
                    <Link href={`/app/${orgId}/factures/rapprochement?releve=${s.id}`} className={s.id === current?.id ? "font-medium text-accent" : "hover:underline"}>
                      {s.title}
                    </Link>
                    <p className="num text-[11px] text-ink-3">{fmtDateTime(s.createdAt)}</p>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="px-5 py-6 text-[13px] text-ink-3">Aucun relevé importé.</p>
            )}
          </Panel>
        </div>
        <Panel>
          <PanelHeader title={current ? current.title : "Propositions"} description={current ? `${proposals.length} ligne(s) lue(s) ; ${reconciledLines.size} déjà rapprochée(s).` : "Sélectionnez ou importez un relevé."} />
          {errors.length ? <Notice tone="warn" className="m-5">{errors.slice(0, 5).join(" ")}</Notice> : null}
          {current && proposals.length ? (
            <Table>
              <thead>
                <tr>
                  <Th>Ligne</Th>
                  <Th>Libellé</Th>
                  <Th num>Montant</Th>
                  <Th>Proposition</Th>
                  <Th>Validation</Th>
                </tr>
              </thead>
              <tbody>
                {proposals.map((p) => {
                  const done = reconciledLines.has(p.row.line);
                  return (
                    <tr key={p.row.line}>
                      <Td className="whitespace-nowrap">
                        <span className="num">{fmtDate(p.row.date)}</span>
                        <p className="num text-[11px] text-ink-3">l. {p.row.line}</p>
                      </Td>
                      <Td className="max-w-[260px] text-[12.5px]">
                        {p.row.label}
                        {p.row.reference ? <p className="num text-ink-3">{p.row.reference}</p> : null}
                      </Td>
                      <Td num>{formatCents(p.row.amountCents)}</Td>
                      <Td className="text-[12.5px]">
                        {done ? (
                          <Badge tone="ok">Rapprochée</Badge>
                        ) : p.invoice ? (
                          <>
                            <Badge tone={p.confidence === "reference" ? "ok" : "warn"}>{p.confidence === "reference" ? "Référence" : "Montant"}</Badge>
                            <p className="mt-1">
                              <Link href={`/app/${orgId}/factures/${p.invoice.id}`} className="num underline">
                                {p.invoice.number}
                              </Link>{" "}
                              · {p.invoice.billToName} · reste {formatCents(p.invoice.totalTtcCents - p.invoice.paidCents)}
                            </p>
                            <p className="text-ink-3">{p.reason}</p>
                          </>
                        ) : (
                          <span className="text-ink-3">{p.reason}</span>
                        )}
                      </Td>
                      <Td>
                        {!done && p.row.amountCents > 0 ? (
                          <ActionForm action={reconcilePaymentAction} submitLabel="Valider" submitSize="sm" submitVariant={p.invoice ? "primary" : "secondary"} footerClassName="mt-2">
                            <input type="hidden" name="orgId" value={orgId} />
                            <input type="hidden" name="documentId" value={current.id} />
                            <input type="hidden" name="line" value={String(p.row.line)} />
                            <input type="hidden" name="amount" value={(p.row.amountCents / 100).toFixed(2)} />
                            <input type="hidden" name="date" value={p.row.date} />
                            <input type="hidden" name="reference" value={`${p.row.reference || p.row.label}`.slice(0, 200)} />
                            <Select name="invoiceId" defaultValue={p.invoice?.id ?? ""} aria-label={`Facture pour la ligne ${p.row.line}`} className="h-8 text-[12px]" required>
                              <option value="">Choisir une facture</option>
                              {openInvoices.map((i) => (
                                <option key={i.id} value={i.id}>
                                  {i.number} · {i.billToName} · {formatCents(i.totalTtcCents - i.paidCents)}
                                </option>
                              ))}
                            </Select>
                          </ActionForm>
                        ) : null}
                      </Td>
                    </tr>
                  );
                })}
              </tbody>
            </Table>
          ) : (
            <EmptyState title={current ? "Relevé vide" : "Aucun relevé sélectionné"} description="Importez un relevé CSV pour obtenir des propositions de rapprochement." />
          )}
        </Panel>
      </div>
    </>
  );
}
