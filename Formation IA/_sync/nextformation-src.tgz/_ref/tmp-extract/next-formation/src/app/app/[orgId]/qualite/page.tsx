import Link from "next/link";
import { guardOrg } from "@/server/guard";
import { runAnalysisAction } from "@/server/actions/quality";
import { activeReferential, analysisEvidences, analysisIsStale, latestAnalysis, listAnalyses } from "@/server/quality/analysis";
import type { Control, Summary } from "@/server/quality/engine";
import { evidenceCounts, memberNames, openQualityActions, openQualityTasks } from "@/server/quality/queries";
import { levelShort, scopeLabels } from "@/server/quality/labels";
import { fmtDate, fmtDateTime } from "@/lib/dates";
import { todayParis } from "@/lib/time";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/field";
import { EmptyState, KeyValue, Notice, PageHeader, Panel, PanelHeader, Stat } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FormDialog } from "@/components/admin/form-dialog";
import { FadeIn } from "@/components/ui/motion";
import { AnalysisSummary, ControlsTable, StaleNotice } from "@/components/quality/analysis-view";

export const dynamic = "force-dynamic";

export default async function QualitePage({ params }: { params: Promise<{ orgId: string }> }) {
  const { orgId } = await params;
  const path = `/app/${orgId}/qualite`;
  const ctx = await guardOrg(orgId, path, "quality.view");
  const canManage = ctx.permissions.has("quality.manage");
  const today = todayParis();

  const [ref, latest, history, actions, tasks, counts, names] = await Promise.all([
    activeReferential(ctx.org.id, today),
    latestAnalysis(ctx.org.id, "organisme", null),
    listAnalyses(ctx.org.id, 20),
    openQualityActions(ctx.org.id),
    openQualityTasks(ctx.org.id),
    evidenceCounts(ctx.org.id),
    memberNames(ctx.org.id),
  ]);
  const [evidences, stale] = latest ? await Promise.all([analysisEvidences(ctx.org.id, latest), analysisIsStale(ctx.org.id, latest)]) : [new Map(), false];
  const validByLevel = { individuel: 0, collectif: 0, organisationnel: 0 };
  let invalidated = 0;
  for (const c of counts) {
    if (c.status === "valide") validByLevel[c.level] += c.n;
    else invalidated += c.n;
  }

  return (
    <FadeIn>
      <PageHeader
        title="Conformité qualité"
        description="Preuves reliées aux actions réelles, analyses conservées comme des photographies immuables, contrôles « à examiner » explicites. Un pourcentage de preuves n'est pas une attestation de conformité."
        actions={
          canManage && ref ? (
            <FormDialog action={runAnalysisAction} trigger="Nouvelle analyse" title="Nouvelle analyse de l'organisme" description="Le moteur parcourt les indicateurs applicables du référentiel actif et enregistre une nouvelle photographie. La précédente reste inchangée." submitLabel="Lancer l'analyse">
              <input type="hidden" name="orgId" value={ctx.org.id} />
              <input type="hidden" name="scope" value="organisme" />
              <Field label="Date de référence" htmlFor="ref-date" help="Seules les preuves datées au plus tard à cette date sont retenues. Jamais dans le futur.">
                <Input id="ref-date" name="referenceDate" type="date" defaultValue={today} max={today} required />
              </Field>
            </FormDialog>
          ) : null
        }
      />

      {!ref ? (
        <Panel className="mb-6">
          <EmptyState
            title="Aucun référentiel applicable"
            description="Aucune analyse n'est possible tant qu'un responsable habilité n'a pas copié puis validé un référentiel (version, dates d'effet, périmètre). Un libellé présent dans le logiciel ne rend jamais un référentiel applicable."
            action={
              <Button asChild variant="primary">
                <Link href={`${path}/referentiel`}>{canManage ? "Valider un référentiel" : "Consulter les référentiels"}</Link>
              </Button>
            }
          />
        </Panel>
      ) : (
        <Panel className="mb-6">
          <PanelHeader
            title="Référentiel applicable"
            description={`${ref.title}, version « ${ref.version} », validé le ${fmtDate(ref.validatedAt)} par ${ref.validatedBy ? (names.get(ref.validatedBy) ?? "un responsable habilité") : "un responsable habilité"}.`}
            actions={
              <Button asChild variant="secondary" size="sm">
                <Link href={`${path}/referentiel`}>Gérer le référentiel</Link>
              </Button>
            }
          />
          <div className="px-5 py-4">
            <KeyValue
              items={[
                { k: "Source", v: ref.source ?? "-" },
                { k: "Effet", v: <span className="num">{ref.effectiveFrom ? fmtDate(ref.effectiveFrom) : "-"} au {ref.effectiveTo ? fmtDate(ref.effectiveTo) : "(sans fin)"}</span> },
                { k: "Périmètre", v: ref.scope === "both" ? "OF et CFA" : ref.scope.toUpperCase() },
                { k: "Statut", v: <StatusBadge status={ref.status} /> },
              ]}
            />
          </div>
        </Panel>
      )}

      <div className="mb-6 grid gap-6 lg:grid-cols-3">
        <Panel className="lg:col-span-2">
          <PanelHeader title="Dernière analyse de l'organisme" description={latest ? `Périmètre ${scopeLabels[latest.scope]}, photographie du ${fmtDateTime(latest.createdAt)}.` : "Aucune photographie enregistrée."} actions={latest ? <Button asChild variant="secondary" size="sm"><Link href={`${path}/analyses/${latest.id}`}>Vue complète</Link></Button> : null} />
          {latest ? (
            <>
              {stale ? (
                <div className="px-5 pt-4">
                  <StaleNotice orgId={ctx.org.id} />
                </div>
              ) : null}
              <AnalysisSummary summary={latest.summary as Summary} referenceDate={latest.referenceDate} engineVersion={latest.engineVersion} analysedAt={latest.createdAt} />
            </>
          ) : (
            <EmptyState title="Aucune analyse" description={ref ? "Lancez une première analyse pour obtenir une photographie des preuves par indicateur." : "Validez d'abord un référentiel."} />
          )}
        </Panel>
        <Panel>
          <PanelHeader title="Preuves valides" description="Par niveau, toutes sessions confondues." actions={<Button asChild variant="secondary" size="sm"><Link href={`${path}/preuves`}>Registre</Link></Button>} />
          <div className="grid grid-cols-3 gap-4 px-5 py-5">
            <Stat label={levelShort.individuel} value={<span className="num">{validByLevel.individuel}</span>} />
            <Stat label={levelShort.collectif} value={<span className="num">{validByLevel.collectif}</span>} />
            <Stat label={levelShort.organisationnel} value={<span className="num">{validByLevel.organisationnel}</span>} />
          </div>
          <p className="border-t border-line px-5 py-3 text-[12.5px] text-ink-2">
            <span className="num">{invalidated}</span> preuve(s) invalidée(s) ou remplacée(s), conservées avec motif et auteur.
          </p>
        </Panel>
      </div>

      {latest ? (
        <Panel className="mb-6">
          <PanelHeader title="Contrôles de la dernière analyse" description="Chaque indicateur affiche son statut, ses preuves reliées et l'explication du moteur. Les contrôles « à examiner » attendent une appréciation humaine." />
          <ControlsTable controls={latest.controls as Control[]} evidences={evidences} orgId={ctx.org.id} />
        </Panel>
      ) : null}

      <div className="mb-6 grid gap-6 lg:grid-cols-2">
        <Panel>
          <PanelHeader title="Alertes : indicateurs absents" description="Chaque alerte est une tâche affectée à un responsable identifiable (une par indicateur et par analyse)." actions={<Button asChild variant="secondary" size="sm"><Link href={`/app/${orgId}/taches`}>Mes tâches</Link></Button>} />
          {tasks.length ? (
            <Table>
              <thead>
                <tr>
                  <Th>Indicateur</Th>
                  <Th>Tâche</Th>
                  <Th>Responsable</Th>
                  <Th>Statut</Th>
                </tr>
              </thead>
              <tbody>
                {tasks.map((t) => (
                  <tr key={t.id}>
                    <Td className="num">{t.indicatorCode?.replace("IND_", "") ?? "-"}</Td>
                    <Td>
                      {t.href ? (
                        <Link href={t.href} className="text-ink hover:underline">
                          {t.title}
                        </Link>
                      ) : (
                        t.title
                      )}
                    </Td>
                    <Td>{t.assigneeUserId ? (names.get(t.assigneeUserId) ?? "Membre") : (t.assigneeRole ?? "-")}</Td>
                    <Td>
                      <StatusBadge status={t.status} />
                    </Td>
                  </tr>
                ))}
              </tbody>
            </Table>
          ) : (
            <EmptyState title="Aucune alerte ouverte" description="Les indicateurs absents de la prochaine analyse créeront des tâches ici." />
          )}
        </Panel>
        <Panel>
          <PanelHeader title="Actions qualité ouvertes" description="Plan d'amélioration : actions issues d'audits, d'enquêtes, de réclamations, de veilles ou d'analyses." actions={<Button asChild variant="secondary" size="sm"><Link href={`${path}/actions`}>Actions et réclamations</Link></Button>} />
          {actions.length ? (
            <Table>
              <thead>
                <tr>
                  <Th>Action</Th>
                  <Th>Responsable</Th>
                  <Th>Échéance</Th>
                  <Th>Statut</Th>
                </tr>
              </thead>
              <tbody>
                {actions.map((a) => (
                  <tr key={a.id}>
                    <Td>
                      {a.title}
                      {a.indicatorCode ? <span className="num ml-2 text-[11px] text-ink-3">{a.indicatorCode.replace("IND_", "ind. ")}</span> : null}
                    </Td>
                    <Td>{a.assigneeUserId ? (names.get(a.assigneeUserId) ?? "Membre") : "-"}</Td>
                    <Td className="num whitespace-nowrap">{a.dueDate ? fmtDate(a.dueDate) : "-"}</Td>
                    <Td>
                      <StatusBadge status={a.status} />
                    </Td>
                  </tr>
                ))}
              </tbody>
            </Table>
          ) : (
            <EmptyState title="Aucune action ouverte" />
          )}
        </Panel>
      </div>

      <Panel>
        <PanelHeader title="Historique des photographies" description="Lecture seule : chaque analyse est conservée telle quelle, avec sa version de moteur et sa date de référence, pour comparaison." />
        {history.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Photographie</Th>
                <Th>Périmètre</Th>
                <Th>Date de référence</Th>
                <Th>Moteur</Th>
                <Th num>Prouvés</Th>
                <Th num>Absents</Th>
                <Th num>À examiner</Th>
                <Th num>Non appl.</Th>
                <Th>État</Th>
              </tr>
            </thead>
            <tbody>
              {history.map((a) => {
                const s = a.summary as Summary;
                return (
                  <tr key={a.id}>
                    <Td className="whitespace-nowrap">
                      <Link href={`${path}/analyses/${a.id}`} className="text-ink hover:underline">
                        {fmtDateTime(a.createdAt)}
                      </Link>
                    </Td>
                    <Td>{scopeLabels[a.scope]}</Td>
                    <Td className="num">{fmtDate(a.referenceDate)}</Td>
                    <Td className="num">{a.engineVersion}</Td>
                    <Td num>{s.proven}</Td>
                    <Td num>{s.missing}</Td>
                    <Td num>{s.humanReview}</Td>
                    <Td num>{s.notApplicable}</Td>
                    <Td>{a.supersededById ? <Badge tone="neutral">Remplacée</Badge> : <Badge tone="ok">Dernière du périmètre</Badge>}</Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucune analyse" />
        )}
      </Panel>
      {!canManage ? (
        <Notice tone="info" className="mt-6">
          Accès en lecture seule : les analyses, preuves et actions ne peuvent être créées que par un membre disposant de l&apos;habilitation « gérer la qualité ».
        </Notice>
      ) : null}
    </FadeIn>
  );
}
