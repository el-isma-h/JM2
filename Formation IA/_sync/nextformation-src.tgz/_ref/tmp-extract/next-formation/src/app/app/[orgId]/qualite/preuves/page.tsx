import Link from "next/link";
import { guardOrg } from "@/server/guard";
import { createEvidenceAction, invalidateEvidenceAction, replaceEvidenceAction } from "@/server/actions/quality";
import { activeReferential, referentialCriteria } from "@/server/quality/analysis";
import { listEvidences, memberNames, orgDocuments, orgEnrollments, orgPrograms, orgSessions } from "@/server/quality/queries";
import { flattenIndicators, QUALIOPI_INDICATORS } from "@/server/quality/referential-data";
import { evidenceSourceLabels, levelShort } from "@/server/quality/labels";
import { fmtDate, fmtDateTime } from "@/lib/dates";
import { todayParis } from "@/lib/time";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/field";
import { EmptyState, Notice, PageHeader, Panel } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { ActionButton } from "@/components/admin/action-form";
import { FormDialog } from "@/components/admin/form-dialog";
import { Pagination, readPage, readParam } from "@/components/admin/pagination";
import { FadeIn } from "@/components/ui/motion";
import { EvidenceFields } from "@/components/quality/evidence-fields";

export const dynamic = "force-dynamic";
const PAGE = 50;

export default async function PreuvesPage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const path = `/app/${orgId}/qualite/preuves`;
  const ctx = await guardOrg(orgId, path, "quality.view");
  const canManage = ctx.permissions.has("quality.manage");
  const sp = await searchParams;
  const filters = { indicator: readParam(sp.indicator), level: readParam(sp.level), sessionId: readParam(sp.session), enrollmentId: readParam(sp.enrollment), status: readParam(sp.status) };
  const highlight = readParam(sp.evidence);
  const page = readPage(sp.page);
  const today = todayParis();

  const [ref, { rows, total }, sessions, enrollments, programs, documents, names] = await Promise.all([
    activeReferential(ctx.org.id, today),
    listEvidences(ctx.org.id, filters, page, PAGE),
    orgSessions(ctx.org.id),
    orgEnrollments(ctx.org.id),
    orgPrograms(ctx.org.id),
    orgDocuments(ctx.org.id),
    memberNames(ctx.org.id),
  ]);
  const indicators = ref ? flattenIndicators(referentialCriteria(ref)) : QUALIOPI_INDICATORS;
  const indicatorByCode = new Map(indicators.map((i) => [i.code, i]));
  const sessionById = new Map(sessions.map((s) => [s.id, s]));
  const enrollmentById = new Map(enrollments.map((e) => [e.id, e]));
  const fieldsProps = { indicators, sessions, enrollments, programs, documents, today };

  return (
    <FadeIn>
      <PageHeader
        breadcrumb={[{ label: "Qualité", href: `/app/${orgId}/qualite` }, { label: "Preuves" }]}
        title="Registre des preuves"
        description="Chaque preuve est reliée à une action réelle (document, séance, enquête, veille, réclamation). Une correction invalide ou remplace la preuve avec motif et auteur ; rien n'est jamais supprimé."
        actions={
          canManage ? (
            <FormDialog action={createEvidenceAction} trigger="Ajouter une preuve" title="Nouvelle preuve" description="Reliez la preuve à un document existant ou déposez le fichier qui la constitue." submitLabel="Enregistrer la preuve" wide>
              <input type="hidden" name="orgId" value={ctx.org.id} />
              <EvidenceFields {...fieldsProps} />
            </FormDialog>
          ) : null
        }
      />

      <Panel>
        <form method="get" className="flex flex-wrap items-end gap-3 border-b border-line px-5 py-3">
          <Field label="Indicateur" htmlFor="f-ind" className="w-56">
            <Select id="f-ind" name="indicator" defaultValue={filters.indicator ?? ""}>
              <option value="">Tous</option>
              {indicators.map((i) => (
                <option key={i.code} value={i.code}>
                  {i.number}. {i.label.slice(0, 50)}…
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Niveau" htmlFor="f-level" className="w-44">
            <Select id="f-level" name="level" defaultValue={filters.level ?? ""}>
              <option value="">Tous</option>
              <option value="individuel">Individuel</option>
              <option value="collectif">Collectif</option>
              <option value="organisationnel">Organisationnel</option>
            </Select>
          </Field>
          <Field label="Session" htmlFor="f-session" className="w-56">
            <Select id="f-session" name="session" defaultValue={filters.sessionId ?? ""}>
              <option value="">Toutes</option>
              {sessions.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.code} : {s.title}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Inscription" htmlFor="f-enr" className="w-56">
            <Select id="f-enr" name="enrollment" defaultValue={filters.enrollmentId ?? ""}>
              <option value="">Toutes</option>
              {enrollments.map((e) => (
                <option key={e.id} value={e.id}>
                  {e.lastName.toUpperCase()} {e.firstName}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Statut" htmlFor="f-status" className="w-40">
            <Select id="f-status" name="status" defaultValue={filters.status ?? ""}>
              <option value="">Tous</option>
              <option value="valide">Valide</option>
              <option value="invalidee">Invalidée</option>
              <option value="remplacee">Remplacée</option>
            </Select>
          </Field>
          <Button type="submit" variant="secondary">
            Filtrer
          </Button>
        </form>
        {rows.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Indicateur</Th>
                <Th>Preuve</Th>
                <Th>Niveau</Th>
                <Th>Rattachement</Th>
                <Th>Source</Th>
                <Th>Date</Th>
                <Th>Statut</Th>
                {canManage ? <Th>Actions</Th> : null}
              </tr>
            </thead>
            <tbody>
              {rows.map((e) => {
                const ind = indicatorByCode.get(e.indicatorCode);
                const s = e.sessionId ? sessionById.get(e.sessionId) : null;
                const en = e.enrollmentId ? enrollmentById.get(e.enrollmentId) : null;
                return (
                  <tr key={e.id} id={e.id} className={highlight === e.id ? "bg-accent-soft/40" : undefined}>
                    <Td className="align-top">
                      <span className="num">{e.indicatorCode.replace("IND_", "")}</span>
                      <p className="max-w-[26ch] text-[11.5px] text-ink-3">{ind?.label.slice(0, 80)}{ind && ind.label.length > 80 ? "…" : ""}</p>
                    </Td>
                    <Td className="align-top">
                      {e.title}
                      {e.note ? <p className="max-w-[36ch] text-[12px] text-ink-3">{e.note}</p> : null}
                      {e.status !== "valide" ? (
                        <p className="mt-1 max-w-[36ch] text-[12px] text-danger-ink">
                          {e.status === "invalidee" ? "Invalidée" : "Remplacée"} le {fmtDateTime(e.invalidatedAt)} par {e.invalidatedBy ? (names.get(e.invalidatedBy) ?? "membre") : "-"} : {e.invalidationReason}
                          {e.replacedById ? (
                            <>
                              {" "}
                              <Link href={`${path}?evidence=${e.replacedById}`} className="underline underline-offset-4">
                                voir la nouvelle preuve
                              </Link>
                            </>
                          ) : null}
                        </p>
                      ) : null}
                    </Td>
                    <Td className="align-top whitespace-nowrap">
                      <Badge tone={e.level === "individuel" ? "info" : e.level === "collectif" ? "accent" : "neutral"}>{levelShort[e.level]}</Badge>
                    </Td>
                    <Td className="align-top text-[12.5px]">
                      {en ? (
                        <Link href={`/app/${orgId}/inscriptions/${en.id}`} className="hover:underline">
                          {en.lastName.toUpperCase()} {en.firstName}
                        </Link>
                      ) : null}
                      {s ? (
                        <p>
                          <Link href={`/app/${orgId}/sessions/${s.id}`} className="hover:underline">
                            {s.code}
                          </Link>
                        </p>
                      ) : null}
                      {!en && !s && !e.programId ? "Organisme" : null}
                    </Td>
                    <Td className="align-top text-[12.5px]">
                      {evidenceSourceLabels[e.sourceType ?? ""] ?? e.sourceType ?? "-"}
                      {e.documentId ? (
                        <p>
                          <Link href={`/app/${orgId}/documents/${e.documentId}`} className="underline underline-offset-4">
                            document
                          </Link>
                        </p>
                      ) : null}
                    </Td>
                    <Td className="num align-top whitespace-nowrap">{e.evidenceDate ? fmtDate(e.evidenceDate) : fmtDate(e.createdAt)}</Td>
                    <Td className="align-top">
                      <StatusBadge status={e.status} />
                    </Td>
                    {canManage ? (
                      <Td className="align-top">
                        {e.status === "valide" ? (
                          <div className="flex flex-col gap-1">
                            <ActionButton
                              action={invalidateEvidenceAction}
                              fields={{ orgId: ctx.org.id, evidenceId: e.id }}
                              label="Invalider"
                              variant="danger"
                              confirm={{ title: "Invalider la preuve", description: "La preuve est conservée avec son événement d'invalidation (motif, auteur, date). Les analyses passées restent inchangées.", confirmLabel: "Invalider", danger: true, input: { name: "reason", label: "Motif (obligatoire)" } }}
                            />
                            <FormDialog action={replaceEvidenceAction} trigger="Remplacer" triggerVariant="secondary" triggerSize="sm" title="Remplacer la preuve" description="Une nouvelle preuve est créée ; l'originale passe en « remplacée » avec motif et auteur." submitLabel="Remplacer" wide>
                              <input type="hidden" name="orgId" value={ctx.org.id} />
                              <input type="hidden" name="evidenceId" value={e.id} />
                              <Field label="Motif du remplacement" required htmlFor={`rp-${e.id}`}>
                                <Input id={`rp-${e.id}`} name="reason" required minLength={5} maxLength={500} />
                              </Field>
                              <EvidenceFields {...fieldsProps} idPrefix={`rp-${e.id}`} defaults={{ indicatorCode: e.indicatorCode, level: e.level, sessionId: e.sessionId, enrollmentId: e.enrollmentId, programId: e.programId, title: e.title }} />
                            </FormDialog>
                          </div>
                        ) : null}
                      </Td>
                    ) : null}
                  </tr>
                );
              })}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucune preuve" description="Les preuves sont créées automatiquement par les actions réelles (documents signés, périodes clôturées, enquêtes, veille, réclamations) ou ajoutées ici à partir d'un document." />
        )}
        <Pagination basePath={path} params={{ indicator: filters.indicator, level: filters.level, session: filters.sessionId, enrollment: filters.enrollmentId, status: filters.status }} page={page} pageSize={PAGE} total={total} />
      </Panel>
      {!ref ? (
        <Notice tone="warn" className="mt-6">
          Aucun référentiel validé : la liste des indicateurs affichée est celle du référentiel proposé. <Link href={`/app/${orgId}/qualite/referentiel`} className="underline underline-offset-4">Valider un référentiel</Link>.
        </Notice>
      ) : null}
    </FadeIn>
  );
}
