import { SiteFooter, SiteHeader } from "@/components/marketing/site";

/** Pages publiques d'information légale : conditions générales, confidentialité, mentions légales. */
export default function LegalLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-[100dvh] flex-col bg-bg text-ink">
      <SiteHeader />
      <main className="conteneur flex-1 pb-24 pt-14">
        <div className="max-w-[760px]">{children}</div>
      </main>
      <SiteFooter />
    </div>
  );
}
