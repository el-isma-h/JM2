"use client";

import { useState, useTransition } from "react";
import { resendVerificationAction } from "@/server/actions/auth";
import { Button } from "@/components/ui/button";
import { Notice } from "@/components/ui/surface";

export function ResendButton() {
  const [pending, start] = useTransition();
  const [msg, setMsg] = useState<string | null>(null);
  return (
    <div className="space-y-3">
      <Button
        type="button"
        variant="secondary"
        loading={pending}
        onClick={() => start(async () => setMsg((await resendVerificationAction()).message ?? null))}
      >
        Renvoyer l&apos;e-mail
      </Button>
      {msg ? <Notice tone="info">{msg}</Notice> : null}
    </div>
  );
}
