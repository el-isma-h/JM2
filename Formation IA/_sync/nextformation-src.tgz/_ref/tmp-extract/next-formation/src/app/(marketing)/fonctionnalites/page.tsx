import type { Metadata } from "next";
import Link from "next/link";
import { ArrowUpRight } from "@phosphor-icons/react/dist/ssr";
import { PageHero } from "@/components/marketing/site";
import { FEATURES } from "@/lib/marketing-data";
import { pageMeta } from "@/lib/seo";

export const metadata: Metadata = pageMeta("/fonctionnalites", "Fonctionnalités", "Les douze fonctions de Next Formation : CRM et devis, catalogue versionné, sessions OF et CFA, émargement par demi-journée, documents et signature, financements et BPF, Qualiopi explicable, extranets, e-learning, IA avec validation humaine, API et pilotage.");

export default function FeaturesIndex() {
  return (
    <article>
      <PageHero crumbs={[{ label: "Accueil", href: "/" }, { label: "Fonctionnalités" }]} eyebrow="Douze fonctions" title="Tout le périmètre, avec des règles que le serveur fait respecter." description="Chaque fonction a sa page : promesse, bénéfices, fonctionnement en quelques étapes, règles garanties et questions fréquentes." filigrane="12" />
      <section className="conteneur py-16 lg:py-24">
        <ul className="grid gap-px border border-line-strong bg-line-strong sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f, i) => (
            <li key={f.slug} className="group bg-bg transition-colors duration-300 hover:bg-ink hover:text-bg">
              <Link href={`/fonctionnalites/${f.slug}`} className="flex h-full flex-col p-6">
                <span className="flex items-center justify-between font-mono text-[11px] tracking-[0.2em] text-accent group-hover:text-[#c9b8f0]">
                  {String(i + 1).padStart(2, "0")}
                  <ArrowUpRight size={14} className="opacity-0 transition-opacity group-hover:opacity-100" />
                </span>
                <h2 className="mt-6 text-[22px] leading-[1]">{f.title}</h2>
                <p className="mt-3 flex-1 text-[13.5px] leading-relaxed text-ink-2 group-hover:text-bg/70">{f.promise}</p>
              </Link>
            </li>
          ))}
        </ul>
      </section>
    </article>
  );
}
