import Link from "next/link";
import { notFound } from "next/navigation";
import { and, asc, eq, ilike, or, sql, type SQL } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { trainerSessionIds } from "@/server/authz";
import { fmtDate } from "@/lib/dates";
import { StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/field";
import { EmptyState, Notice, PageHeader, Panel } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { Pagination, readPage, readParam } from "@/components/admin/pagination";
import { FadeIn } from "@/components/ui/motion";

export const dynamic = "force-dynamic";
const PAGE = 50;

export default async function LearnersPage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const ctx = await guardOrg(orgId, `/app/${orgId}/apprenants`, "org.view");
  if (!ctx.permissions.has("enrollments.view") && !(ctx.trainerOnly && ctx.permissions.has("dossier.pedagogy.view"))) notFound();
  const sp = await searchParams;
  const q = readParam(sp.q);
  const status = readParam(sp.statut);
  const page = readPage(sp.page);
  const base = `/app/${orgId}/apprenants`;
  const scope = await trainerSessionIds(ctx);

  const scopeSql = scope ? (scope.length ? sql`and e.session_id in (${sql.join(scope.map((id) => sql`${id}`), sql`, `)})` : sql`and false`) : sql``;
  const conds: SQL[] = [eq(schema.persons.orgId, orgId), sql`exists (select 1 from ${schema.enrollments} e where e.person_id = ${schema.persons.id} ${scopeSql})`];
  if (q) conds.push(or(ilike(schema.persons.lastName, `%${q}%`), ilike(schema.persons.firstName, `%${q}%`), ilike(schema.persons.email, `%${q}%`), sql`(${schema.persons.firstName} || ' ' || ${schema.persons.lastName}) ilike ${`%${q}%`}`)!);
  if (status && (schema.personStatusEnum.enumValues as readonly string[]).includes(status)) conds.push(eq(schema.persons.status, status as "apprenant"));
  const where = and(...conds);

  const [rows, [{ total }]] = await Promise.all([
    db
      .select({
        p: schema.persons,
        enrollments: sql<number>`(select count(*)::int from ${schema.enrollments} e where e.person_id = ${schema.persons.id} ${scopeSql})`,
        active: sql<number>`(select count(*)::int from ${schema.enrollments} e where e.person_id = ${schema.persons.id} and e.status in ('preinscrit','inscrit','en_cours') ${scopeSql})`,
        last: sql<string | null>`(select max(e.start_date)::text from ${schema.enrollments} e where e.person_id = ${schema.persons.id} ${scopeSql})`,
        companyName: schema.companies.name,
      })
      .from(schema.persons)
      .leftJoin(schema.companies, eq(schema.companies.id, schema.persons.companyId))
      .where(where)
      .orderBy(asc(schema.persons.lastName), asc(schema.persons.firstName))
      .limit(PAGE)
      .offset((page - 1) * PAGE),
    db.select({ total: sql<number>`count(*)::int` }).from(schema.persons).where(where),
  ]);
  const canExport = ctx.permissions.has("exports.run") && ctx.user.elevated;
  const exportHref = `${base}/export?${new URLSearchParams({ ...(q ? { q } : {}), ...(status ? { statut: status } : {}) }).toString()}`;

  return (
    <FadeIn>
      <PageHeader
        title="Apprenants"
        description={ctx.trainerOnly ? "Les apprenants des sessions auxquelles vous êtes affecté(e)." : "Personnes ayant au moins une inscription. Chaque inscription reste distincte ; la fiche est unique."}
        actions={
          !ctx.trainerOnly ? (
            canExport ? (
              <Button asChild variant="secondary">
                <a href={exportHref}>Exporter en CSV</a>
              </Button>
            ) : (
              <Button asChild variant="secondary">
                <Link href={`/securite?next=${encodeURIComponent(base)}`}>Exporter en CSV</Link>
              </Button>
            )
          ) : null
        }
      />
      {!ctx.trainerOnly && !canExport ? (
        <Notice tone="info" className="mb-5">
          {ctx.permissions.has("exports.run") ? "L'export CSV est une action renforcée : confirmez votre identité (code d'authentification) via le bouton « Exporter »." : "L'export CSV demande la permission « Exporter des données » (exports.run), attribuée par le propriétaire dans Utilisateurs et rôles."}
        </Notice>
      ) : null}
      <Panel>
        <form method="get" className="flex flex-wrap items-end gap-3 border-b border-line px-5 py-3">
          <Field label="Recherche" htmlFor="q" className="w-full max-w-xs">
            <Input id="q" name="q" defaultValue={q} placeholder="Nom, prénom ou e-mail" />
          </Field>
          <Field label="Statut" htmlFor="statut" className="w-44">
            <Select id="statut" name="statut" defaultValue={status ?? ""}>
              <option value="">Tous</option>
              <option value="candidat">Candidat</option>
              <option value="apprenant">Apprenant</option>
              <option value="ancien">Ancien apprenant</option>
              <option value="inactif">Inactif</option>
            </Select>
          </Field>
          <Button type="submit" variant="secondary">
            Filtrer
          </Button>
        </form>
        {rows.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Apprenant</Th>
                <Th>Contact</Th>
                <Th>Employeur</Th>
                <Th num>Inscriptions</Th>
                <Th num>Actives</Th>
                <Th>Dernier parcours</Th>
                <Th>Statut</Th>
              </tr>
            </thead>
            <tbody>
              {rows.map(({ p, enrollments, active, last, companyName }) => (
                <tr key={p.id}>
                  <Td>
                    <Link href={`${base}/${p.id}`} className="font-medium text-ink hover:underline">
                      {p.lastName.toUpperCase()} {p.firstName}
                    </Link>
                    {p.birthDate ? <p className="num text-[12px] text-ink-3">née le {fmtDate(p.birthDate)}</p> : null}
                  </Td>
                  <Td>
                    {p.email ?? "-"}
                    {p.phone ? <p className="num text-[12px] text-ink-3">{p.phone}</p> : null}
                  </Td>
                  <Td>{companyName ?? "-"}</Td>
                  <Td num>{enrollments}</Td>
                  <Td num>{active}</Td>
                  <Td className="num">{last ? fmtDate(last) : "-"}</Td>
                  <Td>
                    <StatusBadge status={p.anonymizedAt ? "inactif" : p.status} />
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucun apprenant" description={q ? "Aucune personne inscrite ne correspond." : "Les personnes apparaissent ici dès leur première inscription."} />
        )}
        <Pagination basePath={base} params={{ q, statut: status }} page={page} pageSize={PAGE} total={total} />
      </Panel>
    </FadeIn>
  );
}
