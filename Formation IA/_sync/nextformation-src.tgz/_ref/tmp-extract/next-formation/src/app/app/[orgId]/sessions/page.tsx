import Link from "next/link";
import { and, asc, desc, eq, gte, ilike, inArray, lte, or, sql, type SQL } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { trainerSessionIds } from "@/server/authz";
import { sessionFilters } from "@/server/sessions/queries";
import { sessionStatusLabels, sessionKindLabels } from "@/server/sessions/rules";
import { fmtDate } from "@/lib/dates";
import { StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/field";
import { EmptyState, PageHeader, Panel } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { Pagination, readPage, readParam } from "@/components/admin/pagination";
import { FadeIn } from "@/components/ui/motion";

export const dynamic = "force-dynamic";
const PAGE = 40;

export default async function SessionsPage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const ctx = await guardOrg(orgId, `/app/${orgId}/sessions`, "sessions.view");
  const sp = await searchParams;
  const q = readParam(sp.q);
  const status = readParam(sp.statut);
  const programId = readParam(sp.programme);
  const siteId = readParam(sp.site);
  const activity = readParam(sp.activite);
  const from = readParam(sp.du);
  const to = readParam(sp.au);
  const page = readPage(sp.page);
  const base = `/app/${orgId}/sessions`;

  const scope = await trainerSessionIds(ctx);
  const conds: SQL[] = [eq(schema.trainingSessions.orgId, orgId)];
  if (scope) conds.push(scope.length ? inArray(schema.trainingSessions.id, scope) : sql`false`);
  if (q) conds.push(or(ilike(schema.trainingSessions.title, `%${q}%`), ilike(schema.trainingSessions.code, `%${q}%`), ilike(schema.programs.title, `%${q}%`))!);
  if (status && (schema.sessionStatusEnum.enumValues as readonly string[]).includes(status)) conds.push(eq(schema.trainingSessions.status, status as "ouverte"));
  if (programId) conds.push(eq(schema.programs.id, programId));
  if (siteId) conds.push(eq(schema.trainingSessions.siteId, siteId));
  if (activity === "of") conds.push(eq(schema.trainingSessions.isApprenticeship, false));
  if (activity === "cfa") conds.push(eq(schema.trainingSessions.isApprenticeship, true));
  if (from && /^\d{4}-\d{2}-\d{2}$/.test(from)) conds.push(gte(schema.trainingSessions.endDate, from));
  if (to && /^\d{4}-\d{2}-\d{2}$/.test(to)) conds.push(lte(schema.trainingSessions.startDate, to));
  const where = and(...conds);

  const baseQuery = () =>
    db
      .select({
        s: schema.trainingSessions,
        programTitle: schema.programs.title,
        siteName: schema.sites.name,
        enrolled: sql<number>`(select count(*)::int from ${schema.enrollments} e where e.session_id = ${schema.trainingSessions.id} and e.status in ('preinscrit','inscrit','en_cours'))`,
      })
      .from(schema.trainingSessions)
      .innerJoin(schema.programVersions, eq(schema.programVersions.id, schema.trainingSessions.programVersionId))
      .innerJoin(schema.programs, eq(schema.programs.id, schema.programVersions.programId))
      .leftJoin(schema.sites, eq(schema.sites.id, schema.trainingSessions.siteId))
      .where(where);

  const [rows, [{ total }], filters] = await Promise.all([
    baseQuery().orderBy(desc(schema.trainingSessions.startDate), asc(schema.trainingSessions.code)).limit(PAGE).offset((page - 1) * PAGE),
    db
      .select({ total: sql<number>`count(*)::int` })
      .from(schema.trainingSessions)
      .innerJoin(schema.programVersions, eq(schema.programVersions.id, schema.trainingSessions.programVersionId))
      .innerJoin(schema.programs, eq(schema.programs.id, schema.programVersions.programId))
      .where(where),
    sessionFilters(orgId),
  ]);
  const canManage = ctx.permissions.has("sessions.manage") && !ctx.trainerOnly;

  return (
    <FadeIn>
      <PageHeader
        title="Sessions"
        description={ctx.trainerOnly ? "Les sessions auxquelles vous êtes affecté(e)." : "Sessions et cycles : dates, site, capacité, rythme, responsables et inscrits. Les statuts suivent un cycle contrôlé."}
        actions={
          canManage ? (
            <Button asChild>
              <Link href={`${base}/nouvelle`}>Nouvelle session</Link>
            </Button>
          ) : null
        }
      />
      <Panel>
        <form method="get" className="flex flex-wrap items-end gap-3 border-b border-line px-5 py-3">
          <Field label="Recherche" htmlFor="q" className="w-full max-w-xs">
            <Input id="q" name="q" defaultValue={q} placeholder="Intitulé, code, formation" />
          </Field>
          <Field label="Statut" htmlFor="statut" className="w-40">
            <Select id="statut" name="statut" defaultValue={status ?? ""}>
              <option value="">Tous</option>
              {schema.sessionStatusEnum.enumValues.map((s) => (
                <option key={s} value={s}>
                  {sessionStatusLabels[s]}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Formation" htmlFor="programme" className="w-56">
            <Select id="programme" name="programme" defaultValue={programId ?? ""}>
              <option value="">Toutes</option>
              {filters.programs.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.title}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Site" htmlFor="site" className="w-44">
            <Select id="site" name="site" defaultValue={siteId ?? ""}>
              <option value="">Tous</option>
              {filters.sites.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Activité" htmlFor="activite" className="w-36">
            <Select id="activite" name="activite" defaultValue={activity ?? ""}>
              <option value="">OF et CFA</option>
              <option value="of">OF</option>
              <option value="cfa">CFA</option>
            </Select>
          </Field>
          <Field label="Du" htmlFor="du" className="w-40">
            <Input id="du" name="du" type="date" defaultValue={from} className="num" />
          </Field>
          <Field label="Au" htmlFor="au" className="w-40">
            <Input id="au" name="au" type="date" defaultValue={to} className="num" />
          </Field>
          <Button type="submit" variant="secondary">
            Filtrer
          </Button>
        </form>
        {rows.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Session</Th>
                <Th>Formation</Th>
                <Th>Dates</Th>
                <Th>Site</Th>
                <Th>Type</Th>
                <Th num>Inscrits / places</Th>
                <Th>Statut</Th>
              </tr>
            </thead>
            <tbody>
              {rows.map(({ s, programTitle, siteName, enrolled }) => (
                <tr key={s.id}>
                  <Td>
                    <Link href={`${base}/${s.id}`} className="font-medium text-ink hover:underline">
                      {s.title}
                    </Link>
                    <p className="num text-[12px] text-ink-3">{s.code}</p>
                  </Td>
                  <Td>{programTitle}</Td>
                  <Td className="num whitespace-nowrap">
                    {fmtDate(s.startDate)} au {fmtDate(s.endDate)}
                  </Td>
                  <Td>{siteName ?? "-"}</Td>
                  <Td>
                    {sessionKindLabels[s.kind] ?? s.kind}
                    <span className="ml-1 text-ink-3">{s.isApprenticeship ? "· CFA" : "· OF"}</span>
                  </Td>
                  <Td num>
                    {enrolled} / {s.capacity}
                  </Td>
                  <Td>
                    <StatusBadge status={s.status} />
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
        ) : (
          <EmptyState
            title="Aucune session"
            description={q || status || programId ? "Aucune session ne correspond à ces filtres." : "Créez une première session à partir d'une version de programme du catalogue."}
            action={
              canManage ? (
                <Button asChild variant="secondary">
                  <Link href={`${base}/nouvelle`}>Nouvelle session</Link>
                </Button>
              ) : undefined
            }
          />
        )}
        <Pagination basePath={base} params={{ q, statut: status, programme: programId, site: siteId, activite: activity, du: from, au: to }} page={page} pageSize={PAGE} total={total} />
      </Panel>
    </FadeIn>
  );
}
