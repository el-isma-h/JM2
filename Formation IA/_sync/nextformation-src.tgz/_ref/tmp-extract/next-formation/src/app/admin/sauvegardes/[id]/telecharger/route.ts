import { NextResponse, type NextRequest } from "next/server";
import { eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { AuthError } from "@/server/auth";
import { requirePlatformAdmin } from "@/server/authz";
import { audit } from "@/server/audit";
import { getObject } from "@/server/storage";

export const dynamic = "force-dynamic";

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  let admin;
  try {
    admin = await requirePlatformAdmin();
  } catch (e) {
    return NextResponse.json({ error: "Accès réservé aux administrateurs plateforme." }, { status: e instanceof AuthError && e.code === "unauthenticated" ? 401 : 403 });
  }
  const { id } = await params;
  if (!/^[0-9a-f-]{36}$/.test(id)) return NextResponse.json({ error: "Introuvable." }, { status: 404 });
  const [b] = await db.select().from(schema.backups).where(eq(schema.backups.id, id)).limit(1);
  if (!b) return NextResponse.json({ error: "Introuvable." }, { status: 404 });
  const data = await getObject(b.storageKey);
  await audit({ action: "admin.backup.download", userId: admin.id, tenantId: b.tenantId, entityType: "backup", entityId: b.id });
  return new NextResponse(new Uint8Array(data), {
    headers: {
      "Content-Type": "application/gzip",
      "Content-Disposition": `attachment; filename="${b.storageKey.split("/").pop()}"`,
      "Cache-Control": "no-store",
      "X-Content-SHA256": b.sha256 ?? "",
    },
  });
}
