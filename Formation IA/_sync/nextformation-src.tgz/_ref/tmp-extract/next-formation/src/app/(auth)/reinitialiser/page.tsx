import type { Metadata } from "next";
import { peekToken } from "@/server/auth";
import { Notice } from "@/components/ui/surface";
import Link from "next/link";
import { ResetForm } from "./reset-form";

export const metadata: Metadata = { title: "Nouveau mot de passe" };

export default async function ResetPage({ searchParams }: { searchParams: Promise<{ token?: string }> }) {
  const { token } = await searchParams;
  const valid = token ? await peekToken("reset_password", token) : null;
  return (
    <div>
      <h1 className="text-[30px] text-ink">Nouveau mot de passe</h1>
      {!valid || !token ? (
        <div className="mt-6 space-y-4">
          <Notice tone="danger">Ce lien est invalide ou a expiré.</Notice>
          <Link href="/mot-de-passe-oublie" className="text-[14px] font-medium text-accent hover:underline">
            Demander un nouveau lien
          </Link>
        </div>
      ) : (
        <ResetForm token={token} />
      )}
    </div>
  );
}
