import { NextResponse } from "next/server";
import { destroySession } from "@/server/auth";
import { appUrl } from "@/lib/env";

export async function POST() {
  await destroySession();
  return NextResponse.redirect(`${appUrl()}/connexion`, { status: 303 });
}
export const GET = POST;
