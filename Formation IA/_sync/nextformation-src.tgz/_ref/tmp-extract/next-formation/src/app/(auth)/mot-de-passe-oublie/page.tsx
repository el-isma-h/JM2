"use client";

import Link from "next/link";
import { useActionState } from "react";
import { forgotPasswordAction, type ActionState } from "@/server/actions/auth";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/field";
import { Notice } from "@/components/ui/surface";

export default function ForgotPasswordPage() {
  const [state, action, pending] = useActionState<ActionState, FormData>(forgotPasswordAction, {});
  return (
    <div>
      <h1 className="text-[30px] text-ink">Mot de passe oublié</h1>
      <p className="mt-3 text-[14px] text-ink-2">Saisissez votre adresse : vous recevrez un lien valable 30 minutes.</p>
      <form action={action} className="mt-6 space-y-4">
        <Field label="Adresse e-mail" htmlFor="email" required>
          <Input id="email" name="email" type="email" autoComplete="email" required />
        </Field>
        {state.error ? <Notice tone="danger">{state.error}</Notice> : null}
        {state.message ? <Notice tone="ok">{state.message}</Notice> : null}
        <Button type="submit" size="lg" className="w-full" loading={pending}>
          Envoyer le lien
        </Button>
      </form>
      <p className="mt-6 text-center text-[13px]">
        <Link href="/connexion" className="text-ink-2 hover:underline">
          Retour à la connexion
        </Link>
      </p>
    </div>
  );
}
