"use client";

import * as React from "react";
import { ActionButton, ActionForm } from "@/components/admin/action-form";
import { FormDialog } from "@/components/admin/form-dialog";
import { Checkbox, Field, Input, Select, Textarea } from "@/components/ui/field";
import { commentTaskAction, postponeTaskAction, reassignTaskAction, setTaskStatusAction, takeTaskAction } from "@/server/actions/tasks";
import { TASK_TRANSITIONS, taskStatusLabels, type TaskStatus } from "@/server/tasks/rules";

export type StaffOption = { id: string; name: string; roles: string[] };

export function roleOptions(): { value: string; label: string }[] {
  return [
    { value: "role:direction", label: "Rôle : Direction" },
    { value: "role:agency_manager", label: "Rôle : Responsable d'agence" },
    { value: "role:pedagogy_manager", label: "Rôle : Responsable pédagogique" },
    { value: "role:admin_staff", label: "Rôle : Administratif" },
    { value: "role:finance", label: "Rôle : Finance" },
    { value: "role:quality", label: "Rôle : Qualité" },
    { value: "role:sales", label: "Rôle : Commercial" },
    { value: "role:trainer", label: "Rôle : Formateur" },
  ];
}

export function AssigneeSelect({ name, staff, defaultValue, id, allowNone, allowMe }: { name: string; staff: StaffOption[]; defaultValue?: string; id: string; allowNone?: boolean; allowMe?: boolean }) {
  return (
    <Select id={id} name={name} defaultValue={defaultValue ?? ""}>
      {allowNone ? <option value="">Sans responsable (à affecter)</option> : null}
      {allowMe ? <option value="me">Moi-même</option> : null}
      <optgroup label="Membres">
        {staff.map((s) => (
          <option key={s.id} value={s.id}>
            {s.name}
          </option>
        ))}
      </optgroup>
      <optgroup label="Rôles (sans responsable nommé)">
        {roleOptions().map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </optgroup>
    </Select>
  );
}

/** Barre d'actions d'une tâche : prise en charge, statut, réaffectation, report, commentaire. */
export function TaskActions({ orgId, taskId, status, isMine, hasPendingPrerequisites, dueDate, staff, canAct }: { orgId: string; taskId: string; status: TaskStatus; isMine: boolean; hasPendingPrerequisites: boolean; dueDate: string | null; staff: StaffOption[]; canAct: boolean }) {
  const [to, setTo] = React.useState<TaskStatus>(TASK_TRANSITIONS[status][0] ?? "a_faire");
  const transitions = TASK_TRANSITIONS[status] ?? [];
  const needsNote = to === "bloquee" || to === "annulee";
  return (
    <div className="flex flex-wrap items-start gap-2">
      {!isMine ? <ActionButton action={takeTaskAction} fields={{ orgId, taskId }} label="Prendre en charge" variant="primary" /> : null}
      {canAct && transitions.length ? (
        <FormDialog action={setTaskStatusAction} trigger="Changer le statut" triggerVariant="secondary" title="Changer le statut" description="Une tâche bloquée exige un motif ; une tâche terminée exige ses prérequis, sauf dérogation motivée." submitLabel="Appliquer">
          <input type="hidden" name="orgId" value={orgId} />
          <input type="hidden" name="taskId" value={taskId} />
          <Field label="Nouveau statut" htmlFor="ts-to">
            <Select id="ts-to" name="to" value={to} onChange={(e) => setTo(e.target.value as TaskStatus)}>
              {transitions.map((s) => (
                <option key={s} value={s}>
                  {taskStatusLabels[s]}
                </option>
              ))}
            </Select>
          </Field>
          <Field label={to === "bloquee" ? "Ce qui bloque" : to === "terminee" ? "Note de résolution" : "Motif ou commentaire"} htmlFor="ts-note" required={needsNote} help={to === "bloquee" ? "Décrivez la donnée manquante, la pièce attendue ou la décision requise." : undefined}>
            <Textarea id="ts-note" name="note" required={needsNote} className="min-h-20" />
          </Field>
          {to === "terminee" && hasPendingPrerequisites ? <Checkbox name="override" label="Clôturer malgré des prérequis non satisfaits (dérogation motivée, conservée dans l'historique)" /> : null}
        </FormDialog>
      ) : null}
      {canAct ? (
        <FormDialog action={reassignTaskAction} trigger="Réaffecter" triggerVariant="secondary" title="Réaffecter la tâche" description="La trace de la réaffectation est conservée dans l'historique." submitLabel="Réaffecter">
          <input type="hidden" name="orgId" value={orgId} />
          <input type="hidden" name="taskId" value={taskId} />
          <Field label="Nouveau responsable" htmlFor="tr-target">
            <AssigneeSelect id="tr-target" name="target" staff={staff} allowNone />
          </Field>
          <Field label="Motif" htmlFor="tr-note">
            <Input id="tr-note" name="note" placeholder="Absence, relais, répartition de charge…" />
          </Field>
        </FormDialog>
      ) : null}
      {canAct ? (
        <FormDialog action={postponeTaskAction} trigger="Reporter l'échéance" triggerVariant="secondary" title="Reporter l'échéance" submitLabel="Reporter">
          <input type="hidden" name="orgId" value={orgId} />
          <input type="hidden" name="taskId" value={taskId} />
          <Field label="Nouvelle échéance" htmlFor="tp-date" required>
            <Input id="tp-date" name="dueDate" type="date" defaultValue={dueDate ?? ""} required className="num" />
          </Field>
          <Field label="Motif du report" htmlFor="tp-reason" required>
            <Input id="tp-reason" name="reason" required />
          </Field>
        </FormDialog>
      ) : null}
    </div>
  );
}

export function CommentForm({ orgId, taskId }: { orgId: string; taskId: string }) {
  return (
    <ActionForm action={commentTaskAction} submitLabel="Commenter" submitVariant="secondary" submitSize="sm" footerClassName="mt-3">
      <input type="hidden" name="orgId" value={orgId} />
      <input type="hidden" name="taskId" value={taskId} />
      <Field label="Commentaire" htmlFor="tc-note">
        <Textarea id="tc-note" name="note" className="min-h-20" required />
      </Field>
    </ActionForm>
  );
}
