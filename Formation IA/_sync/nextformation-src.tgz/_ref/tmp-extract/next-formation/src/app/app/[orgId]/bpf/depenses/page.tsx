import { and, desc, eq, sql, type SQL } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { createExpenseAction, deleteExpenseAction, updateExpenseAction } from "@/server/actions/finance";
import { EXPENSE_CATEGORIES } from "@/server/finance/bpf";
import { formatCents } from "@/lib/money";
import { fmtDate } from "@/lib/dates";
import { todayParis } from "@/lib/time";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/field";
import { EmptyState, PageHeader, Panel, Stat } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { ActionButton } from "@/components/admin/action-form";
import { FormDialog } from "@/components/admin/form-dialog";
import { Pagination, readPage, readParam } from "@/components/admin/pagination";

export const dynamic = "force-dynamic";
const PAGE = 50;

function ExpenseFields({ x, sessions, prefix }: { x?: typeof schema.expenses.$inferSelect; sessions: { id: string; code: string; title: string }[]; prefix: string }) {
  const id = (k: string) => `${prefix}-${k}`;
  return (
    <>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Date" required htmlFor={id("date")}>
          <Input id={id("date")} name="date" type="date" required defaultValue={x?.date ?? todayParis()} />
        </Field>
        <Field label="Catégorie" htmlFor={id("cat")}>
          <Select id={id("cat")} name="category" defaultValue={x?.category ?? "sous_traitance"}>
            {Object.entries(EXPENSE_CATEGORIES).map(([k, v]) => (
              <option key={k} value={k}>
                {v}
              </option>
            ))}
          </Select>
        </Field>
      </div>
      <Field label="Libellé" required htmlFor={id("label")}>
        <Input id={id("label")} name="label" required defaultValue={x?.label ?? ""} placeholder="Intervention formateur externe, location salle…" />
      </Field>
      <Field label="Fournisseur" htmlFor={id("sup")}>
        <Input id={id("sup")} name="supplier" defaultValue={x?.supplier ?? ""} />
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Montant HT (€)" required htmlFor={id("ht")}>
          <Input id={id("ht")} name="amountHt" className="num" required defaultValue={x ? (x.amountHtCents / 100).toFixed(2).replace(".", ",") : ""} inputMode="decimal" />
        </Field>
        <Field label="TVA (€)" htmlFor={id("vat")}>
          <Input id={id("vat")} name="vat" className="num" defaultValue={x ? (x.vatCents / 100).toFixed(2).replace(".", ",") : "0,00"} inputMode="decimal" />
        </Field>
      </div>
      <Field label="Session rattachée" htmlFor={id("session")} help="Facultatif : permet d'imputer la charge à une session.">
        <Select id={id("session")} name="sessionId" defaultValue={x?.sessionId ?? ""}>
          <option value="">Aucune</option>
          {sessions.map((s) => (
            <option key={s.id} value={s.id}>
              {s.code} · {s.title}
            </option>
          ))}
        </Select>
      </Field>
    </>
  );
}

export default async function ExpensesPage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const ctx = await guardOrg(orgId, `/app/${orgId}/bpf/depenses`, "finance.view");
  const canManage = ctx.permissions.has("finance.manage");
  const sp = await searchParams;
  const currentYear = Number(todayParis().slice(0, 4));
  const y = Number(readParam(sp.year));
  const year = Number.isInteger(y) && y >= 2000 ? y : currentYear;
  const category = readParam(sp.category);
  const page = readPage(sp.page);

  const conds: SQL[] = [eq(schema.expenses.orgId, orgId), sql`extract(year from ${schema.expenses.date}) = ${year}`];
  if (category && category in EXPENSE_CATEGORIES) conds.push(eq(schema.expenses.category, category));
  const where = and(...conds);
  const [rows, [{ total, sumHt, sumVat }], sessions] = await Promise.all([
    db.select({ x: schema.expenses, sessionCode: schema.trainingSessions.code }).from(schema.expenses).leftJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.expenses.sessionId)).where(where).orderBy(desc(schema.expenses.date)).limit(PAGE).offset((page - 1) * PAGE),
    db.select({ total: sql<number>`count(*)::int`, sumHt: sql<number>`coalesce(sum(${schema.expenses.amountHtCents}),0)::int`, sumVat: sql<number>`coalesce(sum(${schema.expenses.vatCents}),0)::int` }).from(schema.expenses).where(where),
    db.select({ id: schema.trainingSessions.id, code: schema.trainingSessions.code, title: schema.trainingSessions.title }).from(schema.trainingSessions).where(eq(schema.trainingSessions.orgId, orgId)).orderBy(desc(schema.trainingSessions.startDate)).limit(300),
  ]);
  const years = Array.from({ length: 6 }, (_, i) => currentYear - 4 + i);

  return (
    <>
      <PageHeader
        breadcrumb={[{ label: "Finance" }, { label: "BPF", href: `/app/${orgId}/bpf?year=${year}` }, { label: "Dépenses" }]}
        title="Dépenses"
        description="Charges de l'activité de formation (sous-traitance, salaires, locaux…) saisies pour le BPF. Les montants sont HT ; la TVA est indiquée à part."
        actions={
          canManage ? (
            <FormDialog action={createExpenseAction} trigger="Nouvelle dépense" title="Nouvelle dépense" submitLabel="Enregistrer">
              <input type="hidden" name="orgId" value={orgId} />
              <ExpenseFields sessions={sessions} prefix="xn" />
            </FormDialog>
          ) : null
        }
      />
      <Panel className="mb-6 grid grid-cols-2 gap-6 p-5 md:grid-cols-3">
        <Stat label={`Charges HT ${year}`} value={formatCents(sumHt)} hint={category ? EXPENSE_CATEGORIES[category] : "Toutes catégories"} />
        <Stat label="TVA déductible" value={formatCents(sumVat)} />
        <Stat label="Lignes" value={total} />
      </Panel>
      <Panel>
        <form method="get" className="flex flex-wrap items-end gap-3 border-b border-line px-5 py-3">
          <Field label="Année" htmlFor="year" className="w-32">
            <Select id="year" name="year" defaultValue={String(year)}>
              {years.map((yy) => (
                <option key={yy} value={yy}>
                  {yy}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Catégorie" htmlFor="category" className="w-64">
            <Select id="category" name="category" defaultValue={category ?? ""}>
              <option value="">Toutes</option>
              {Object.entries(EXPENSE_CATEGORIES).map(([k, v]) => (
                <option key={k} value={k}>
                  {v}
                </option>
              ))}
            </Select>
          </Field>
          <Button type="submit" variant="secondary">
            Filtrer
          </Button>
        </form>
        {rows.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Date</Th>
                <Th>Libellé</Th>
                <Th>Catégorie</Th>
                <Th>Fournisseur</Th>
                <Th>Session</Th>
                <Th num>HT</Th>
                <Th num>TVA</Th>
                {canManage ? <Th></Th> : null}
              </tr>
            </thead>
            <tbody>
              {rows.map(({ x, sessionCode }) => (
                <tr key={x.id}>
                  <Td className="whitespace-nowrap">{fmtDate(x.date)}</Td>
                  <Td>{x.label}</Td>
                  <Td>{EXPENSE_CATEGORIES[x.category] ?? x.category}</Td>
                  <Td>{x.supplier ?? "-"}</Td>
                  <Td>{sessionCode ?? "-"}</Td>
                  <Td num>{formatCents(x.amountHtCents)}</Td>
                  <Td num>{formatCents(x.vatCents)}</Td>
                  {canManage ? (
                    <Td>
                      <div className="flex items-center gap-2">
                        <FormDialog action={updateExpenseAction} trigger="Modifier" triggerVariant="ghost" triggerSize="sm" title="Modifier la dépense" submitLabel="Enregistrer">
                          <input type="hidden" name="orgId" value={orgId} />
                          <input type="hidden" name="expenseId" value={x.id} />
                          <ExpenseFields x={x} sessions={sessions} prefix={`xe-${x.id.slice(0, 8)}`} />
                        </FormDialog>
                        <ActionButton action={deleteExpenseAction} fields={{ orgId, expenseId: x.id }} label="Supprimer" variant="ghost" confirm={{ title: "Supprimer cette dépense ?", danger: true, confirmLabel: "Supprimer" }} />
                      </div>
                    </Td>
                  ) : null}
                </tr>
              ))}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucune dépense" description={`Aucune dépense enregistrée pour ${year}${category ? ` dans cette catégorie` : ""}.`} />
        )}
        <Pagination basePath={`/app/${orgId}/bpf/depenses`} params={{ year: String(year), category }} page={page} pageSize={PAGE} total={total} />
      </Panel>
    </>
  );
}
