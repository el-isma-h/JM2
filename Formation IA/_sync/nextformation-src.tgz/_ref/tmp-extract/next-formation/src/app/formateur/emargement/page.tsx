import { guardTrainer } from "@/server/extranet/guard";
import { listSlotsForSessions } from "@/server/extranet/queries";
import { NoAttachment } from "@/components/extranet/shell";
import { SlotTable } from "@/components/extranet/ui";
import { Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { todayParis } from "@/lib/time";

export const dynamic = "force-dynamic";

/** Émargement : renvoie vers les feuilles par période de l'application (/app/[orgId]/emargement/[periodId], périmètre formateur géré). */
export default async function TrainerAttendance() {
  const ctx = await guardTrainer("/formateur/emargement");
  if (!ctx) return <NoAttachment kind="trainer" />;
  const today = todayParis();
  const all = (await listSlotsForSessions(ctx.org.id, ctx.sessionIds)).filter((s) => !s.slot.trainerId || s.slot.trainerId === ctx.trainer.id);
  const current = all.filter((s) => s.slot.date <= today && s.slot.status !== "annulee" && s.periods.some((p) => p.status !== "cloturee" && p.status !== "annulee")).reverse();
  const closed = all.filter((s) => s.slot.date <= today && s.periods.length && s.periods.every((p) => p.status === "cloturee" || p.status === "annulee")).reverse();
  const periodHref = (periodId: string) => `/app/${ctx.org.id}/emargement/${periodId}`;
  return (
    <>
      <PageHeader title="Émargement" description="Une période (matin / après-midi) a ses propres présences, sa signature de fin et sa clôture. Une période clôturée est verrouillée : toute correction passe par une demande tracée." />
      <Notice tone="info" className="mb-6">
        La feuille d&apos;émargement s&apos;ouvre dans l&apos;application : le lien « Émargement » de chaque période y mène. Seules vos séances y sont accessibles.
      </Notice>
      <div className="space-y-6">
        <Panel>
          <PanelHeader title="Périodes à traiter" description="Séances passées ou du jour avec au moins une période non clôturée." />
          <SlotTable slots={current} periodHref={periodHref} emptyTitle="Rien à traiter" emptyDescription="Toutes vos périodes passées sont clôturées." />
        </Panel>
        <Panel>
          <PanelHeader title="Périodes clôturées (30 dernières)" />
          <SlotTable slots={closed.slice(0, 30)} periodHref={periodHref} emptyTitle="Aucune période clôturée" emptyDescription="" />
        </Panel>
      </div>
    </>
  );
}
