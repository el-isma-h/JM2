import Link from "next/link";
import { notFound } from "next/navigation";
import { and, desc, eq } from "drizzle-orm";
import { LockKey } from "@phosphor-icons/react/dist/ssr";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { audit } from "@/server/audit";
import { addInteractionAction, createNeedAction, updateConfidentialNotesAction, updatePersonAction, uploadCvAction } from "@/server/actions/crm";
import { isOverdue, listStaffUsers, nextActionFor, userNames } from "@/server/crm/queries";
import { ACCEPT_ATTR, ALLOWED_LABEL } from "@/server/documents/upload-rules";
import { todayParis } from "@/lib/time";
import { fmtDate } from "@/lib/dates";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Field, Input, Textarea } from "@/components/ui/field";
import { EmptyState, KeyValue, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FormDialog } from "@/components/admin/form-dialog";
import { ActionForm } from "@/components/admin/action-form";
import { InteractionFields, NeedFields, PersonFields, interactionKindLabels, placementStatusLabels } from "@/components/crm/fields";
import { NextActionBanner } from "@/components/crm/next-action";
import { DocumentList } from "@/components/crm/documents";
import { FadeIn } from "@/components/ui/motion";

export const dynamic = "force-dynamic";

export default async function PersonPage({ params }: { params: Promise<{ orgId: string; personId: string }> }) {
  const { orgId, personId } = await params;
  const base = `/app/${orgId}`;
  const ctx = await guardOrg(orgId, `${base}/candidats/${personId}`, "crm.view");
  if (!/^[0-9a-f-]{36}$/i.test(personId)) notFound();
  const [person] = await db.select().from(schema.persons).where(and(eq(schema.persons.id, personId), eq(schema.persons.orgId, ctx.org.id))).limit(1);
  if (!person) notFound();
  const canManage = ctx.permissions.has("crm.manage");
  const canCv = ctx.permissions.has("candidates.cv.view");
  const today = todayParis();

  const [employer, placements, enrollments, interactions, docs, companies, staff, programs, action] = await Promise.all([
    person.companyId ? db.select().from(schema.companies).where(and(eq(schema.companies.id, person.companyId), eq(schema.companies.orgId, ctx.org.id))).limit(1).then((r) => r[0] ?? null) : null,
    db
      .select({ pl: schema.placements, n: schema.needs, companyName: schema.companies.name })
      .from(schema.placements)
      .innerJoin(schema.needs, eq(schema.needs.id, schema.placements.needId))
      .leftJoin(schema.companies, eq(schema.companies.id, schema.needs.companyId))
      .where(and(eq(schema.placements.orgId, ctx.org.id), eq(schema.placements.personId, person.id)))
      .orderBy(desc(schema.placements.proposedAt)),
    db
      .select({ e: schema.enrollments, s: schema.trainingSessions })
      .from(schema.enrollments)
      .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.enrollments.sessionId))
      .where(and(eq(schema.enrollments.orgId, ctx.org.id), eq(schema.enrollments.personId, person.id)))
      .orderBy(desc(schema.enrollments.createdAt)),
    db.select().from(schema.interactions).where(and(eq(schema.interactions.orgId, ctx.org.id), eq(schema.interactions.personId, person.id))).orderBy(desc(schema.interactions.at)).limit(50),
    db.select().from(schema.documents).where(and(eq(schema.documents.orgId, ctx.org.id), eq(schema.documents.personId, person.id))).orderBy(desc(schema.documents.createdAt)),
    db.select({ id: schema.companies.id, name: schema.companies.name }).from(schema.companies).where(eq(schema.companies.orgId, ctx.org.id)).orderBy(schema.companies.name).limit(500),
    listStaffUsers(ctx.org.id),
    db.select({ id: schema.programs.id, name: schema.programs.title }).from(schema.programs).where(and(eq(schema.programs.orgId, ctx.org.id), eq(schema.programs.status, "actif"))).orderBy(schema.programs.title),
    nextActionFor(ctx.org.id, { personId: person.id }),
  ]);
  const names = await userNames(interactions.map((i) => i.userId));
  const cvDocs = docs.filter((d) => d.category === "cv" || d.visibility === "confidentiel");
  const otherDocs = docs.filter((d) => !(d.category === "cv" || d.visibility === "confidentiel"));
  if (canCv && (person.confidentialNotes || cvDocs.length)) {
    await audit({ action: "person.sensitive.view", userId: ctx.user.id, orgId: ctx.org.id, entityType: "person", entityId: person.id });
  }
  const identifiers = Object.entries((person.identifiers ?? {}) as Record<string, string>);

  return (
    <FadeIn>
      <PageHeader
        breadcrumb={[{ label: "Commercial" }, { label: "Candidats", href: `${base}/candidats` }, { label: `${person.firstName} ${person.lastName}` }]}
        title={`${person.firstName} ${person.lastName}`}
        description={[person.situation, person.city, person.birthDate ? `né(e) le ${fmtDate(person.birthDate)}` : null, person.source ? `source : ${person.source}` : null].filter(Boolean).join(" · ") || "Identité à compléter."}
        actions={
          <>
            <StatusBadge status={person.status} />
            {canManage ? (
              <FormDialog action={updatePersonAction} trigger="Modifier" triggerVariant="secondary" title="Modifier la fiche" submitLabel="Enregistrer" wide>
                <PersonFields orgId={ctx.org.id} person={person} companies={companies} prefix="ep" />
              </FormDialog>
            ) : null}
          </>
        }
      />
      <NextActionBanner action={action} base={base} />

      <div className="grid gap-6 lg:grid-cols-[minmax(0,2fr)_minmax(0,1fr)]">
        <div className="space-y-6">
          <Panel>
            <PanelHeader title="Identité et coordonnées" />
            <div className="grid gap-6 p-5 md:grid-cols-2">
              <KeyValue
                items={[
                  { k: "Civilité", v: person.civility === "M" ? "M." : person.civility },
                  { k: "Nom de naissance", v: person.birthName },
                  { k: "Naissance", v: person.birthDate ? `${fmtDate(person.birthDate)}${person.birthPlace ? ` à ${person.birthPlace}` : ""}` : null },
                  { k: "Nationalité", v: person.nationality },
                  { k: "Niveau d'études", v: person.educationLevel },
                  { k: "Situation", v: person.situation },
                ]}
              />
              <KeyValue
                items={[
                  { k: "E-mail", v: person.email },
                  { k: "Téléphone", v: person.phone ? <span className="num">{person.phone}</span> : null },
                  { k: "Adresse", v: [person.addressLine1, person.addressLine2, [person.postalCode, person.city].filter(Boolean).join(" ")].filter(Boolean).join(", ") || null },
                  { k: "Employeur", v: employer ? <Link href={`${base}/entreprises/${employer.id}`} className="hover:underline">{employer.name}</Link> : null },
                  { k: "Aménagements", v: person.hasAccommodations ? person.accommodations || "Oui (à préciser)" : "Aucun déclaré" },
                  { k: "Consentement RGPD", v: person.gdprConsentAt ? fmtDate(person.gdprConsentAt) : "Non enregistré" },
                ]}
              />
            </div>
            {identifiers.length || (person.tags as string[]).length ? (
              <div className="border-t border-line px-5 py-4">
                {identifiers.length ? (
                  <KeyValue items={identifiers.map(([k, v]) => ({ k, v: <span className="num">{v}</span> }))} />
                ) : null}
                {(person.tags as string[]).length ? (
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    {(person.tags as string[]).map((t) => (
                      <Badge key={t}>{t}</Badge>
                    ))}
                  </div>
                ) : null}
              </div>
            ) : null}
          </Panel>

          <Panel>
            <PanelHeader
              title="CV et notes sensibles"
              description="Réservés à l'habilitation « Consulter les CV et notes sensibles » : jamais diffusés à tous les commerciaux."
              actions={canCv ? <Badge tone="accent">Accès attribué</Badge> : <Badge tone="warn">Accès non attribué</Badge>}
            />
            {canCv ? (
              <div className="space-y-5 p-5">
                <DocumentList orgId={ctx.org.id} docs={cvDocs} emptyTitle="Aucun CV déposé" emptyDescription="Déposez le CV : il est stocké en visibilité confidentielle." />
                {canManage ? (
                  <ActionForm action={uploadCvAction} submitLabel="Déposer le CV" submitVariant="secondary" submitSize="sm" className="border-t border-line pt-4">
                    <input type="hidden" name="orgId" value={ctx.org.id} />
                    <input type="hidden" name="personId" value={person.id} />
                    <Field label="Fichier" htmlFor="cv-file" help={`Formats : ${ALLOWED_LABEL}. Un nouveau dépôt crée une nouvelle version.`} className="mb-3 max-w-md">
                      <Input id="cv-file" name="file" type="file" accept={ACCEPT_ATTR} required className="py-1.5" />
                    </Field>
                  </ActionForm>
                ) : null}
                {canManage ? (
                  <ActionForm action={updateConfidentialNotesAction} submitLabel="Enregistrer les notes" submitVariant="secondary" submitSize="sm" className="border-t border-line pt-4">
                    <input type="hidden" name="orgId" value={ctx.org.id} />
                    <input type="hidden" name="personId" value={person.id} />
                    <Field label="Notes sensibles (recrutement)" htmlFor="conf-notes" className="mb-3">
                      <Textarea id="conf-notes" name="confidentialNotes" defaultValue={person.confidentialNotes ?? ""} rows={4} />
                    </Field>
                  </ActionForm>
                ) : (
                  <div className="border-t border-line pt-4">
                    <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">Notes sensibles</p>
                    <p className="mt-2 whitespace-pre-line text-[13.5px] text-ink-2">{person.confidentialNotes || "Aucune note."}</p>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-3 px-5 py-6 text-[13.5px] text-ink-2">
                <LockKey size={20} />
                <span>Accès non attribué : le CV et les notes sensibles de cette personne sont masqués. Demandez l&apos;habilitation « Consulter les CV et notes sensibles » au propriétaire de l&apos;organisme.</span>
              </div>
            )}
          </Panel>

          <Panel>
            <PanelHeader
              title="Placements"
              description="Besoins sur lesquels la personne a été proposée."
              actions={
                canManage ? (
                  <FormDialog action={createNeedAction} trigger="Besoin individuel" triggerVariant="secondary" triggerSize="sm" title="Nouveau besoin pour cette personne" submitLabel="Créer le besoin" wide>
                    <NeedFields orgId={ctx.org.id} companies={companies} contacts={[]} persons={[{ id: person.id, name: `${person.firstName} ${person.lastName}` }]} programs={programs} staff={staff} personId={person.id} />
                  </FormDialog>
                ) : null
              }
            />
            {placements.length ? (
              <Table>
                <thead>
                  <tr>
                    <Th>Besoin</Th>
                    <Th>Entreprise</Th>
                    <Th>Statut</Th>
                    <Th>Proposé le</Th>
                  </tr>
                </thead>
                <tbody>
                  {placements.map(({ pl, n, companyName }) => (
                    <tr key={pl.id}>
                      <Td>
                        <Link href={`${base}/besoins/${n.id}`} className="font-medium text-ink hover:underline">
                          {n.title}
                        </Link>
                      </Td>
                      <Td>{companyName ?? "-"}</Td>
                      <Td>
                        <StatusBadge status={pl.status} />
                        <span className="sr-only">{placementStatusLabels[pl.status]}</span>
                      </Td>
                      <Td className="num whitespace-nowrap">{fmtDate(pl.proposedAt)}</Td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            ) : (
              <EmptyState title="Aucun placement" description="Proposez cette personne sur un besoin depuis la fiche du besoin." className="py-8" />
            )}
          </Panel>

          <Panel>
            <PanelHeader title="Inscriptions" description="Une personne peut avoir plusieurs inscriptions ; chacune ouvre son dossier central." />
            {enrollments.length ? (
              <Table>
                <thead>
                  <tr>
                    <Th>Référence</Th>
                    <Th>Session</Th>
                    <Th>Inscription</Th>
                    <Th>Progression</Th>
                    <Th>Financement</Th>
                  </tr>
                </thead>
                <tbody>
                  {enrollments.map(({ e, s }) => (
                    <tr key={e.id}>
                      <Td>
                        <Link href={`${base}/inscriptions/${e.id}`} className="num font-medium text-ink hover:underline">
                          {e.reference}
                        </Link>
                      </Td>
                      <Td>
                        {s.title}
                        <span className="num block text-[12px] text-ink-3">
                          {fmtDate(s.startDate)} au {fmtDate(s.endDate)}
                        </span>
                      </Td>
                      <Td>
                        <StatusBadge status={e.status} />
                      </Td>
                      <Td>
                        <StatusBadge status={e.progression} />
                      </Td>
                      <Td>
                        <StatusBadge status={e.fundingState} />
                      </Td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            ) : (
              <EmptyState title="Aucune inscription" description="Les inscriptions se créent depuis un placement retenu ou depuis le module Inscriptions." className="py-8" />
            )}
          </Panel>

          {otherDocs.length ? (
            <Panel>
              <PanelHeader title="Autres documents" />
              <DocumentList orgId={ctx.org.id} docs={otherDocs} />
            </Panel>
          ) : null}
        </div>

        <Panel className="self-start">
          <PanelHeader
            title="Échanges"
            actions={
              canManage ? (
                <FormDialog action={addInteractionAction} trigger="Ajouter" triggerVariant="secondary" triggerSize="sm" title="Nouvel échange" submitLabel="Enregistrer">
                  <InteractionFields orgId={ctx.org.id} personId={person.id} today={today} />
                </FormDialog>
              ) : null
            }
          />
          {interactions.length ? (
            <ol className="divide-y divide-line">
              {interactions.map((i) => (
                <li key={i.id} className="px-5 py-3.5 text-[13.5px]">
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge>{interactionKindLabels[i.kind] ?? i.kind}</Badge>
                    <span className="num text-[12px] text-ink-3">{fmtDate(i.at)}</span>
                    {i.userId ? <span className="text-[12px] text-ink-3">{names.get(i.userId)}</span> : null}
                  </div>
                  <p className="mt-1.5 font-medium text-ink">{i.subject}</p>
                  {i.body ? <p className="mt-1 whitespace-pre-line text-ink-2">{i.body}</p> : null}
                  {i.nextActionAt ? (
                    <p className={`mt-1.5 text-[12.5px] ${isOverdue(i.nextActionAt, today) ? "font-medium text-danger-ink" : "text-ink-2"}`}>
                      Prochaine action : {i.nextAction} le <span className="num">{fmtDate(i.nextActionAt)}</span>
                    </p>
                  ) : null}
                </li>
              ))}
            </ol>
          ) : (
            <EmptyState title="Aucun échange" className="py-8" />
          )}
          {person.anonymizedAt ? (
            <Notice tone="warn" className="m-4">
              Fiche anonymisée le {fmtDate(person.anonymizedAt)}.
            </Notice>
          ) : null}
        </Panel>
      </div>
    </FadeIn>
  );
}
