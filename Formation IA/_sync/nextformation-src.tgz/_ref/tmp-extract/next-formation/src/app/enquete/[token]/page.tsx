import Link from "next/link";
import { Logo } from "@/components/ui/logo";
import { Notice } from "@/components/ui/surface";
import { parseQuestions } from "@/server/quality/indicator-math";
import { findResponseByToken } from "@/server/quality/surveys";
import { fmtDateTime } from "@/lib/dates";
import { SurveyPublicForm } from "@/components/quality/survey-public-form";

export const dynamic = "force-dynamic";

/** Page publique d'enquête : accès par jeton individuel, sans session, une seule soumission. */
export default async function PublicSurveyPage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  const found = await findResponseByToken(token);
  const orgName = found ? (found.org.tradeName ?? found.org.legalName) : null;

  let body: React.ReactNode;
  if (!found) {
    body = (
      <Notice tone="danger" title="Lien invalide">
        Ce lien d&apos;enquête n&apos;est pas reconnu. Vérifiez l&apos;adresse reçue par e-mail ou contactez l&apos;organisme de formation.
      </Notice>
    );
  } else if (found.response.submittedAt) {
    body = (
      <Notice tone="ok" title="Questionnaire déjà soumis">
        Vos réponses ont été enregistrées le {fmtDateTime(found.response.submittedAt)}. Merci pour votre participation.
      </Notice>
    );
  } else if (found.survey.status !== "active") {
    body = (
      <Notice tone="warn" title="Enquête fermée">
        Cette enquête n&apos;accepte plus de réponses.
      </Notice>
    );
  } else {
    body = <SurveyPublicForm token={token} questions={parseQuestions(found.survey.questions)} />;
  }

  return (
    <div className="min-h-[100dvh] bg-bg text-ink">
      <header className="border-b border-line">
        <div className="mx-auto flex max-w-[760px] items-center justify-between px-5 py-5">
          <Logo />
          {orgName ? <span className="etiquette text-ink-3">{orgName}</span> : null}
        </div>
      </header>
      <main className="mx-auto max-w-[760px] px-5 py-12">
        {found ? (
          <div className="mb-10">
            <p className="etiquette text-ink-3">Questionnaire</p>
            <h1 className="mt-3 text-[28px] sm:text-[34px]">{found.survey.title}</h1>
            {found.survey.description ? <p className="mt-4 max-w-[60ch] text-[14px] text-ink-2">{found.survey.description}</p> : null}
            <p className="mt-2 text-[12.5px] text-ink-3">Vos réponses sont transmises à {orgName} pour améliorer ses formations (recueil des appréciations, Qualiopi indicateur 30). Elles sont rattachées à votre inscription.</p>
          </div>
        ) : null}
        {body}
        <p className="mt-16 flex flex-wrap gap-4 font-mono text-[10px] uppercase tracking-[0.16em] text-ink-3">
          <Link href="/confidentialite" className="hover:text-ink">
            Confidentialité
          </Link>
          <Link href="/mentions-legales" className="hover:text-ink">
            Mentions légales
          </Link>
        </p>
      </main>
    </div>
  );
}
