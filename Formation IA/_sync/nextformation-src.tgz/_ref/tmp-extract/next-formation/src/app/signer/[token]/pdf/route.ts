import { NextResponse } from "next/server";
import { findByToken, tokenState } from "@/server/documents/signatures";
import { getObject } from "@/server/storage";

/** Rendu du PDF à signer pour le porteur du jeton (lecture seule, inline, jamais mis en cache). */
export async function GET(_req: Request, { params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  const tc = await findByToken(token);
  if (!tc) return new NextResponse("Lien invalide.", { status: 404 });
  const state = tokenState(tc);
  if (state === "expired" || state === "closed") return new NextResponse("Lien expiré ou demande close.", { status: 410 });
  const data = await getObject(tc.document.storageKey);
  return new NextResponse(new Uint8Array(data), {
    headers: { "Content-Type": "application/pdf", "Content-Disposition": `inline; filename*=UTF-8''${encodeURIComponent(tc.document.fileName)}`, "Cache-Control": "private, no-store", "X-Robots-Tag": "noindex" },
  });
}
