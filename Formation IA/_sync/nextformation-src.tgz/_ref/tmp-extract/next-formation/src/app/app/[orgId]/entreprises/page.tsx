import Link from "next/link";
import { and, desc, eq, ilike, or, sql, type SQL } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { createCompanyAction } from "@/server/actions/crm";
import { isOverdue, listStaffUsers, userNames } from "@/server/crm/queries";
import { todayParis } from "@/lib/time";
import { StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/field";
import { EmptyState, PageHeader, Panel } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FormDialog } from "@/components/admin/form-dialog";
import { Pagination, readPage, readParam } from "@/components/admin/pagination";
import { CompanyFields, companyStatusLabels } from "@/components/crm/fields";
import { NextActionCell } from "@/components/crm/next-action";

export const dynamic = "force-dynamic";
const PAGE = 40;

export default async function CompaniesPage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const base = `/app/${orgId}`;
  const ctx = await guardOrg(orgId, `${base}/entreprises`, "crm.view");
  const sp = await searchParams;
  const q = readParam(sp.q);
  const status = readParam(sp.status);
  const assigned = readParam(sp.assigned);
  const page = readPage(sp.page);
  const today = todayParis();

  const conds: SQL[] = [eq(schema.companies.orgId, ctx.org.id)];
  if (status && (schema.companyStatusEnum.enumValues as readonly string[]).includes(status)) conds.push(eq(schema.companies.status, status as "prospect"));
  if (assigned && /^[0-9a-f-]{36}$/i.test(assigned)) conds.push(eq(schema.companies.assignedUserId, assigned));
  if (q) {
    const digits = q.replace(/\s/g, "");
    conds.push(or(ilike(schema.companies.name, `%${q}%`), ilike(schema.companies.city, `%${q}%`), /^\d{3,}$/.test(digits) ? ilike(schema.companies.siret, `${digits}%`) : undefined)!);
  }
  const where = and(...conds);

  const nextAction = sql<string | null>`(select i.next_action_at::text from ${schema.interactions} i where i.company_id = "companies"."id" and i.next_action_at is not null order by i.at desc limit 1)`;
  const nextLabel = sql<string | null>`(select i.next_action from ${schema.interactions} i where i.company_id = "companies"."id" and i.next_action_at is not null order by i.at desc limit 1)`;
  const [rows, [{ total }], staff] = await Promise.all([
    db
      .select({
        c: schema.companies,
        contacts: sql<number>`(select count(*)::int from ${schema.contacts} ct where ct.company_id = "companies"."id")`,
        openNeeds: sql<number>`(select count(*)::int from ${schema.needs} n where n.company_id = "companies"."id" and n.stage not in ('gagne','perdu'))`,
        nextAt: nextAction,
        nextLabel,
      })
      .from(schema.companies)
      .where(where)
      .orderBy(desc(schema.companies.updatedAt))
      .limit(PAGE)
      .offset((page - 1) * PAGE),
    db.select({ total: sql<number>`count(*)::int` }).from(schema.companies).where(where),
    listStaffUsers(ctx.org.id),
  ]);
  const names = await userNames(rows.map((r) => r.c.assignedUserId));
  const canManage = ctx.permissions.has("crm.manage");

  return (
    <>
      <PageHeader
        title="Entreprises"
        description="Clients, prospects et entreprises d'accueil. Les relances dépassées apparaissent en rouge."
        actions={
          canManage ? (
            <FormDialog action={createCompanyAction} trigger="Nouvelle entreprise" title="Nouvelle entreprise" description="Les doublons (SIRET ou nom identique) sont signalés, jamais fusionnés automatiquement." submitLabel="Créer l'entreprise" wide>
              <CompanyFields orgId={ctx.org.id} staff={staff} />
            </FormDialog>
          ) : null
        }
      />
      <Panel>
        <form method="get" className="flex flex-wrap items-end gap-3 border-b border-line px-5 py-3">
          <Field label="Recherche" htmlFor="q" className="w-full max-w-xs">
            <Input id="q" name="q" defaultValue={q} placeholder="Nom, ville ou SIRET" />
          </Field>
          <Field label="Statut" htmlFor="status" className="w-44">
            <Select id="status" name="status" defaultValue={status ?? ""}>
              <option value="">Tous</option>
              {Object.entries(companyStatusLabels).map(([v, l]) => (
                <option key={v} value={v}>
                  {l}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Commercial référent" htmlFor="assigned" className="w-56">
            <Select id="assigned" name="assigned" defaultValue={assigned ?? ""}>
              <option value="">Tous</option>
              {staff.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </Select>
          </Field>
          <Button type="submit" variant="secondary">
            Filtrer
          </Button>
        </form>
        {rows.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Entreprise</Th>
                <Th>Statut</Th>
                <Th>Référent</Th>
                <Th num>Contacts</Th>
                <Th num>Besoins ouverts</Th>
                <Th>Prochaine action</Th>
              </tr>
            </thead>
            <tbody>
              {rows.map(({ c, contacts, openNeeds, nextAt, nextLabel }) => (
                <tr key={c.id}>
                  <Td>
                    <Link href={`${base}/entreprises/${c.id}`} className="font-medium text-ink hover:underline">
                      {c.name}
                    </Link>
                    <p className="text-[12px] text-ink-3">
                      {[c.city, c.siret ? `SIRET ${c.siret}` : null].filter(Boolean).join(" · ") || "Adresse non renseignée"}
                    </p>
                  </Td>
                  <Td>
                    <StatusBadge status={c.status} />
                  </Td>
                  <Td>{c.assignedUserId ? names.get(c.assignedUserId) ?? "-" : <span className="text-ink-3">Non attribué</span>}</Td>
                  <Td num>{contacts}</Td>
                  <Td num>{openNeeds}</Td>
                  <Td>
                    <NextActionCell date={nextAt} label={nextLabel} overdue={isOverdue(nextAt, today)} />
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucune entreprise" description={q || status || assigned ? "Aucun résultat pour ces filtres." : "Créez votre première fiche entreprise ou importez votre base depuis « Imports et exports »."} />
        )}
        <Pagination basePath={`${base}/entreprises`} params={{ q, status, assigned }} page={page} pageSize={PAGE} total={total} />
      </Panel>
    </>
  );
}
