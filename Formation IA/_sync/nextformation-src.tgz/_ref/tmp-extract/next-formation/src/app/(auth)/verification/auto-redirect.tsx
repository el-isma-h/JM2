"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";

/** Redirige après un court délai (le temps de lire le message affiché). */
export function AutoRedirect({ href, delayMs }: { href: string; delayMs: number }) {
  const router = useRouter();
  useEffect(() => {
    const t = setTimeout(() => router.replace(href), delayMs);
    return () => clearTimeout(t);
  }, [router, href, delayMs]);
  return null;
}
