import { NextResponse, type NextRequest } from "next/server";
import { and, asc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireOrg } from "@/server/authz";
import { audit } from "@/server/audit";
import { AuthError } from "@/server/auth";
import { isImportKind, toCsv } from "@/server/imports/kinds";
import { fmtMinutes } from "@/lib/time";

export const dynamic = "force-dynamic";

/** Export CSV des entités importables (entreprises, contacts, personnes, inscriptions, heures historiques). Permission renforcée. */
export async function GET(req: NextRequest, { params }: { params: Promise<{ orgId: string; kind: string }> }) {
  const { orgId, kind } = await params;
  const back = `/app/${orgId}/imports`;
  let ctx;
  try {
    ctx = await requireOrg(orgId, "enrollments.view", "exports.run");
  } catch (e) {
    if (e instanceof AuthError && e.code === "elevation_required") return NextResponse.redirect(new URL(`/securite?next=${encodeURIComponent(back)}`, req.url));
    if (e instanceof AuthError && e.code === "unauthenticated") return NextResponse.redirect(new URL(`/connexion?next=${encodeURIComponent(back)}`, req.url));
    return new NextResponse("Accès refusé", { status: 403 });
  }
  if (ctx.trainerOnly) return new NextResponse("Accès refusé", { status: 403 });
  if (!isImportKind(kind)) return new NextResponse("Export inconnu", { status: 404 });
  if ((kind === "entreprises" || kind === "contacts") && !ctx.permissions.has("crm.view")) return new NextResponse("Accès refusé (CRM)", { status: 403 });

  let headers: string[] = [];
  let rows: (string | number | null | undefined)[][] = [];
  if (kind === "entreprises") {
    const r = await db.select().from(schema.companies).where(eq(schema.companies.orgId, orgId)).orderBy(asc(schema.companies.name)).limit(20000);
    headers = ["Raison sociale", "SIRET", "SIREN", "Code APE", "OPCO", "Adresse", "Code postal", "Ville", "E-mail", "Téléphone", "Statut", "Identifiant"];
    rows = r.map((c) => [c.name, c.siret, c.siren, c.apeCode, c.opco, c.addressLine1, c.postalCode, c.city, c.email, c.phone, c.status, c.id]);
  } else if (kind === "contacts") {
    const r = await db.select({ c: schema.contacts, company: schema.companies }).from(schema.contacts).leftJoin(schema.companies, eq(schema.companies.id, schema.contacts.companyId)).where(eq(schema.contacts.orgId, orgId)).orderBy(asc(schema.contacts.lastName)).limit(20000);
    headers = ["Nom", "Prénom", "E-mail", "Téléphone", "Fonction", "SIRET de l'entreprise", "Raison sociale de l'entreprise", "Tuteur", "Signataire", "Identifiant"];
    rows = r.map(({ c, company }) => [c.lastName, c.firstName, c.email, c.phone, c.jobTitle, company?.siret, company?.name, c.isTutor ? "oui" : "non", c.isSignatory ? "oui" : "non", c.id]);
  } else if (kind === "personnes") {
    const r = await db.select({ p: schema.persons, company: schema.companies }).from(schema.persons).leftJoin(schema.companies, eq(schema.companies.id, schema.persons.companyId)).where(eq(schema.persons.orgId, orgId)).orderBy(asc(schema.persons.lastName)).limit(20000);
    headers = ["Nom", "Prénom", "Date de naissance", "Civilité", "E-mail", "Téléphone", "Adresse", "Code postal", "Ville", "Statut", "SIRET employeur", "Identifiant d'origine", "Identifiant"];
    rows = r.map(({ p, company }) => [p.lastName, p.firstName, p.birthDate, p.civility, p.email, p.phone, p.addressLine1, p.postalCode, p.city, p.status, company?.siret, (p.identifiers as { externalId?: string })?.externalId ?? "", p.id]);
  } else if (kind === "inscriptions") {
    const r = await db
      .select({ e: schema.enrollments, p: schema.persons, s: schema.trainingSessions, company: schema.companies })
      .from(schema.enrollments)
      .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
      .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.enrollments.sessionId))
      .leftJoin(schema.companies, eq(schema.companies.id, schema.enrollments.companyId))
      .where(eq(schema.enrollments.orgId, orgId))
      .orderBy(asc(schema.enrollments.reference))
      .limit(20000);
    headers = ["E-mail de la personne", "Nom", "Prénom", "Date de naissance", "Code de la session", "Référence d'inscription", "Statut", "Type de contrat", "Début du parcours", "Fin du parcours", "Heures prévues", "SIRET entreprise", "Solde d'heures historique", "Progression", "Financement", "Examen", "Identifiant"];
    rows = r.map(({ e, p, s, company }) => [p.email, p.lastName, p.firstName, p.birthDate, s.code, e.reference, e.status, e.contractKind, e.startDate, e.endDate, e.hoursPlanned, company?.siret, e.legacyHours, e.progression, e.fundingState, e.examState, e.id]);
  } else {
    const r = await db
      .select({ l: schema.legacyAttendanceSheets, reference: schema.enrollments.reference, email: schema.persons.email, code: schema.trainingSessions.code })
      .from(schema.legacyAttendanceSheets)
      .innerJoin(schema.enrollments, eq(schema.enrollments.id, schema.legacyAttendanceSheets.enrollmentId))
      .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
      .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.enrollments.sessionId))
      .where(and(eq(schema.legacyAttendanceSheets.orgId, orgId)))
      .orderBy(asc(schema.enrollments.reference), asc(schema.legacyAttendanceSheets.date))
      .limit(50000);
    headers = ["Référence d'inscription", "E-mail de la personne", "Code de la session", "Date", "Heures", "Durée", "Signée", "Source", "Note", "Réconciliée"];
    rows = r.map(({ l, reference, email, code }) => [reference, email, code, l.date, (l.hours / 60).toFixed(2).replace(".", ","), fmtMinutes(l.hours), l.signed ? "oui" : "non", l.source, l.note, l.reconciled ? "oui" : "non"]);
  }
  await audit({ action: "export.run", userId: ctx.user.id, orgId, entityType: "export", after: { kind, rows: rows.length } });
  return new NextResponse(toCsv(headers, rows), { headers: { "content-type": "text/csv; charset=utf-8", "content-disposition": `attachment; filename="${kind}-${new Date().toISOString().slice(0, 10)}.csv"` } });
}
