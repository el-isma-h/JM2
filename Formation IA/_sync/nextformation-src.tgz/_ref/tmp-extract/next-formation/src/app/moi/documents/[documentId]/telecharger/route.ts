import { getLearnerContext } from "@/server/extranet/context";
import { extranetDownload } from "@/server/extranet/download";

export async function GET(_req: Request, { params }: { params: Promise<{ documentId: string }> }) {
  const { documentId } = await params;
  return extranetDownload(getLearnerContext, (ctx) => ({ scope: { enrollmentIds: ctx.enrollmentIds, personId: ctx.person.id }, visibilities: ["apprenant", "public"] }), documentId, "/moi/documents");
}
