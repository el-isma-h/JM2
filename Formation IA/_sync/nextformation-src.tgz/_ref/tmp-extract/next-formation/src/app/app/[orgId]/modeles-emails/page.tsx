import Link from "next/link";
import { guardOrg } from "@/server/guard";
import { listProposalsForEntity } from "@/server/ai/store";
import { aiStatus } from "@/server/ai/provider";
import { MAIL_TEMPLATE_VARIABLES } from "@/server/mail-templates/defaults";
import { listOrgMailTemplates, renderOrgMailTemplate } from "@/server/mail-templates/service";
import { listMarkers } from "@/server/documents/render";
import { draftMailTemplateWithAiAction, resetMailTemplateAction, setGoogleReviewUrlAction, updateMailTemplateAction } from "@/server/actions/mail-templates";
import { integrations } from "@/lib/env";
import { fmtDateTime } from "@/lib/dates";
import { Badge } from "@/components/ui/badge";
import { Field, Input, Textarea } from "@/components/ui/field";
import { Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { ActionButton, ActionForm } from "@/components/admin/action-form";
import { FormDialog } from "@/components/admin/form-dialog";

export const dynamic = "force-dynamic";

const recipientLabels = { apprenant: "Apprenant", formateur: "Formateur", entreprise: "Entreprise" } as const;

/** Modèles d'e-mails de l'organisme : textes par défaut, personnalisation versionnée, rédaction IA validée par un humain. */
export default async function MailTemplatesPage({ params }: { params: Promise<{ orgId: string }> }) {
  const { orgId } = await params;
  const ctx = await guardOrg(orgId, `/app/${orgId}/modeles-emails`, "documents.generate");
  const templates = await listOrgMailTemplates(ctx.org.id);
  const ai = aiStatus();
  const previews = await Promise.all(templates.map((t) => renderOrgMailTemplate(ctx, t.def.code)));
  const pending = await Promise.all(templates.map((t) => (t.row ? listProposalsForEntity(ctx.org.id, "mail_template", t.row.id) : Promise.resolve([]))));

  return (
    <>
      <PageHeader
        title="Modèles d'e-mails"
        description="Textes types envoyés aux apprenants et aux formateurs. Les variables {{…}} sont remplacées à l'envoi ; une information absente apparaît en « [À COMPLÉTER : …] », jamais inventée. Chaque modification crée une nouvelle version."
        breadcrumb={[{ label: "Paramètres", href: `/app/${orgId}/parametres` }, { label: "Modèles d'e-mails" }]}
      />
      {!integrations.mail() ? (
        <Notice tone="warn" className="mb-6" title="Envoi d'e-mails coupé sur cette installation">
          Les e-mails préparés à partir de ces modèles restent dans la boîte d&apos;envoi et les liens s&apos;affichent à l&apos;écran. L&apos;activation se fait par l&apos;administrateur de la plateforme (Admin, Clés API : RESEND_API_KEY et MAIL_ENABLED=true).
        </Notice>
      ) : null}

      <Panel className="mb-6">
        <PanelHeader title="Lien d'avis Google" description="Utilisé par la variable {{org.googleReviewUrl}} du modèle d'évaluation de fin de formation. Copiez le lien « Demander des avis » de votre fiche d'établissement Google." />
        <div className="px-5 py-4">
          <ActionForm action={setGoogleReviewUrlAction} submitLabel="Enregistrer le lien" submitSize="sm" className="max-w-xl space-y-3">
            <input type="hidden" name="orgId" value={orgId} />
            <Field label="Lien d'avis Google" htmlFor="google-review-url" help="Laissez vide pour retirer le lien : le modèle affichera alors un marqueur à compléter.">
              <Input id="google-review-url" name="googleReviewUrl" type="url" defaultValue={ctx.org.googleReviewUrl ?? ""} placeholder="https://g.page/r/…/review" className="num" />
            </Field>
          </ActionForm>
        </div>
      </Panel>

      {!ai.configured ? (
        <Notice tone="info" className="mb-6" title="Rédaction par l'IA indisponible">
          {ai.explanation} La clé se renseigne par l&apos;administrateur de la plateforme (Admin, Clés API).
        </Notice>
      ) : null}

      <div className="space-y-6">
        {templates.map((t, i) => {
          const preview = previews[i];
          const waiting = pending[i].filter((p) => p.status === "proposee");
          const fixedMarkers = listMarkers(t.body);
          return (
            <Panel key={t.def.code} id={t.def.code}>
              <PanelHeader
                title={t.def.title}
                description={t.def.purpose}
                actions={
                  <>
                    <Badge>{recipientLabels[t.def.recipient]}</Badge>
                    <Badge tone={t.isDefault ? "neutral" : "accent"}>{t.isDefault ? "Texte par défaut" : "Personnalisé"}</Badge>
                    <Badge>v{t.version}</Badge>
                  </>
                }
              />
              <div className="grid gap-0 lg:grid-cols-[1fr_300px]">
                <div className="px-5 py-4">
                  <p className="etiquette mb-2">Aperçu avec les données de l&apos;organisme</p>
                  <p className="font-medium text-ink">{preview.subject}</p>
                  <div className="mt-2 max-h-80 overflow-y-auto border border-line bg-bg px-4 py-3">
                    <p className="whitespace-pre-line text-[13.5px] leading-relaxed text-ink">{preview.text}</p>
                  </div>
                  {fixedMarkers.length ? (
                    <p className="mt-2 text-[12.5px] text-warn-ink">
                      Texte à rédiger par l&apos;organisme avant usage : {fixedMarkers.join(" ; ")}.
                    </p>
                  ) : null}
                </div>
                <aside className="border-t border-line px-5 py-4 lg:border-l lg:border-t-0">
                  <p className="etiquette mb-2">Variables disponibles</p>
                  <ul className="space-y-1 text-[12px] text-ink-2">
                    {t.def.variables.map((v) => (
                      <li key={v}>
                        <code className="num text-[11.5px] text-ink">{`{{${v}}}`}</code> {MAIL_TEMPLATE_VARIABLES[v] ?? ""}
                      </li>
                    ))}
                  </ul>
                  {t.updatedAt && !t.isDefault ? <p className="mt-3 text-[12px] text-ink-3">Modifié le {fmtDateTime(t.updatedAt)}</p> : null}
                </aside>
              </div>
              {waiting.length ? (
                <Notice tone="info" className="mx-5 mb-4">
                  {waiting.length} rédaction(s) IA en attente de validation.{" "}
                  <Link href={`/app/${orgId}/assistant/propositions?p=${waiting[0].id}&back=${encodeURIComponent(`/app/${orgId}/modeles-emails`)}`} className="font-medium underline underline-offset-4">
                    Examiner
                  </Link>
                </Notice>
              ) : null}
              <div className="flex flex-wrap items-start gap-2 border-t border-line px-5 py-4">
                <FormDialog action={updateMailTemplateAction} trigger="Modifier" triggerVariant="secondary" triggerSize="sm" title={`Modifier : ${t.def.title}`} description="Texte brut, paragraphes séparés par une ligne vide. Variables {{…}} de la liste ; sections conditionnelles {{#if variable}} … {{/if}}." submitLabel="Enregistrer" wide>
                  <input type="hidden" name="orgId" value={orgId} />
                  <input type="hidden" name="code" value={t.def.code} />
                  <Field label="Objet" htmlFor={`subject-${t.def.code}`} required>
                    <Input id={`subject-${t.def.code}`} name="subject" defaultValue={t.subject} required maxLength={200} />
                  </Field>
                  <Field label="Corps" htmlFor={`body-${t.def.code}`} required>
                    <Textarea id={`body-${t.def.code}`} name="body" defaultValue={t.body} required className="num min-h-80 text-[12.5px]" />
                  </Field>
                </FormDialog>
                {ai.configured ? (
                  <FormDialog action={draftMailTemplateWithAiAction} trigger="Rédiger avec l'IA" triggerVariant="secondary" triggerSize="sm" title={`Rédiger avec l'IA : ${t.def.title}`} description="L'IA propose un objet et un corps à partir de la version actuelle. La proposition ne modifie rien tant qu'un humain ne l'a pas validée ; validée, elle crée une nouvelle version du modèle. Aucun e-mail n'est envoyé." submitLabel="Proposer une rédaction">
                    <input type="hidden" name="orgId" value={orgId} />
                    <input type="hidden" name="code" value={t.def.code} />
                    <Field label="Consigne" htmlFor={`instr-${t.def.code}`} help="Ex. plus court, ton plus chaleureux, ajouter un rappel sur le règlement intérieur. Les informations inconnues resteront en « [À COMPLÉTER] ».">
                      <Textarea id={`instr-${t.def.code}`} name="instructions" rows={4} maxLength={1500} />
                    </Field>
                  </FormDialog>
                ) : null}
                {!t.isDefault ? (
                  <ActionButton
                    action={resetMailTemplateAction}
                    fields={{ orgId, code: t.def.code }}
                    label="Rétablir le texte par défaut"
                    variant="ghost"
                    confirm={{ title: "Rétablir le texte par défaut ?", description: "Le texte par défaut devient la version suivante du modèle. La version actuelle reste tracée dans le journal d'audit.", confirmLabel: "Rétablir" }}
                  />
                ) : null}
              </div>
            </Panel>
          );
        })}
      </div>
    </>
  );
}
