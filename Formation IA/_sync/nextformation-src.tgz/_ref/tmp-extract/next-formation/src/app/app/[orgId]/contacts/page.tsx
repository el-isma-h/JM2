import Link from "next/link";
import { and, eq, ilike, or, sql, type SQL } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { createContactAction, updateContactAction } from "@/server/actions/crm";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/field";
import { EmptyState, PageHeader, Panel } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FormDialog } from "@/components/admin/form-dialog";
import { Pagination, readPage, readParam } from "@/components/admin/pagination";
import { ContactFields } from "@/components/crm/fields";

export const dynamic = "force-dynamic";
const PAGE = 50;

export default async function ContactsPage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const base = `/app/${orgId}`;
  const ctx = await guardOrg(orgId, `${base}/contacts`, "crm.view");
  const sp = await searchParams;
  const q = readParam(sp.q);
  const role = readParam(sp.role);
  const companyId = readParam(sp.company);
  const page = readPage(sp.page);

  const conds: SQL[] = [eq(schema.contacts.orgId, ctx.org.id)];
  if (q) conds.push(or(ilike(schema.contacts.lastName, `%${q}%`), ilike(schema.contacts.firstName, `%${q}%`), ilike(schema.contacts.email, `%${q}%`), ilike(schema.companies.name, `%${q}%`))!);
  if (role === "tuteur") conds.push(eq(schema.contacts.isTutor, true));
  if (role === "signataire") conds.push(eq(schema.contacts.isSignatory, true));
  if (role === "facturation") conds.push(eq(schema.contacts.isBilling, true));
  if (companyId && /^[0-9a-f-]{36}$/i.test(companyId)) conds.push(eq(schema.contacts.companyId, companyId));
  const where = and(...conds);

  const [rows, [{ total }], companies] = await Promise.all([
    db
      .select({ c: schema.contacts, companyName: schema.companies.name })
      .from(schema.contacts)
      .leftJoin(schema.companies, eq(schema.companies.id, schema.contacts.companyId))
      .where(where)
      .orderBy(schema.contacts.lastName, schema.contacts.firstName)
      .limit(PAGE)
      .offset((page - 1) * PAGE),
    db.select({ total: sql<number>`count(*)::int` }).from(schema.contacts).leftJoin(schema.companies, eq(schema.companies.id, schema.contacts.companyId)).where(where),
    db.select({ id: schema.companies.id, name: schema.companies.name }).from(schema.companies).where(eq(schema.companies.orgId, ctx.org.id)).orderBy(schema.companies.name).limit(500),
  ]);
  const canManage = ctx.permissions.has("crm.manage");

  return (
    <>
      <PageHeader
        title="Contacts"
        description="Interlocuteurs des entreprises : dirigeants, RH, tuteurs, signataires et contacts de facturation."
        actions={
          canManage ? (
            <FormDialog action={createContactAction} trigger="Nouveau contact" title="Nouveau contact" submitLabel="Créer le contact" wide>
              <ContactFields orgId={ctx.org.id} companies={companies} companyId={companyId} />
            </FormDialog>
          ) : null
        }
      />
      <Panel>
        <form method="get" className="flex flex-wrap items-end gap-3 border-b border-line px-5 py-3">
          <Field label="Recherche" htmlFor="q" className="w-full max-w-xs">
            <Input id="q" name="q" defaultValue={q} placeholder="Nom, e-mail ou entreprise" />
          </Field>
          <Field label="Rôle" htmlFor="role" className="w-44">
            <Select id="role" name="role" defaultValue={role ?? ""}>
              <option value="">Tous</option>
              <option value="tuteur">Tuteurs</option>
              <option value="signataire">Signataires</option>
              <option value="facturation">Facturation</option>
            </Select>
          </Field>
          <Field label="Entreprise" htmlFor="company" className="w-60">
            <Select id="company" name="company" defaultValue={companyId ?? ""}>
              <option value="">Toutes</option>
              {companies.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </Select>
          </Field>
          <Button type="submit" variant="secondary">
            Filtrer
          </Button>
        </form>
        {rows.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Contact</Th>
                <Th>Entreprise</Th>
                <Th>Fonction</Th>
                <Th>Coordonnées</Th>
                <Th>Rôles</Th>
                {canManage ? <Th /> : null}
              </tr>
            </thead>
            <tbody>
              {rows.map(({ c, companyName }) => (
                <tr key={c.id}>
                  <Td>
                    <span className="font-medium text-ink">
                      {c.firstName} {c.lastName}
                    </span>
                  </Td>
                  <Td>
                    {c.companyId ? (
                      <Link href={`${base}/entreprises/${c.companyId}`} className="hover:underline">
                        {companyName}
                      </Link>
                    ) : (
                      <span className="text-ink-3">Indépendant</span>
                    )}
                  </Td>
                  <Td>{c.jobTitle ?? "-"}</Td>
                  <Td>
                    {c.email ? <span className="block">{c.email}</span> : null}
                    {c.phone || c.mobile ? <span className="num block text-[12.5px] text-ink-2">{[c.phone, c.mobile].filter(Boolean).join(" · ")}</span> : null}
                  </Td>
                  <Td>
                    <div className="flex flex-wrap gap-1">
                      {c.isTutor ? <Badge tone="info">Tuteur</Badge> : null}
                      {c.isSignatory ? <Badge tone="accent">Signataire</Badge> : null}
                      {c.isBilling ? <Badge>Facturation</Badge> : null}
                    </div>
                  </Td>
                  {canManage ? (
                    <Td>
                      <FormDialog action={updateContactAction} trigger="Modifier" triggerVariant="ghost" triggerSize="sm" title={`${c.firstName} ${c.lastName}`} submitLabel="Enregistrer" wide>
                        <ContactFields orgId={ctx.org.id} contact={c} companies={companies} prefix={`ct-${c.id.slice(0, 8)}`} />
                      </FormDialog>
                    </Td>
                  ) : null}
                </tr>
              ))}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucun contact" description={q || role || companyId ? "Aucun résultat pour ces filtres." : "Ajoutez vos interlocuteurs ou créez-les depuis une fiche entreprise."} />
        )}
        <Pagination basePath={`${base}/contacts`} params={{ q, role, company: companyId }} page={page} pageSize={PAGE} total={total} />
      </Panel>
    </>
  );
}
