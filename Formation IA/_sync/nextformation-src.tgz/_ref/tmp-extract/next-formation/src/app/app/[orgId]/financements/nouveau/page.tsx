import Link from "next/link";
import { and, asc, desc, eq, ilike, or } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { createFundingAction } from "@/server/actions/finance";
import { formatCents } from "@/lib/money";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/field";
import { EmptyState, KeyValue, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { readParam } from "@/components/admin/pagination";
import { FundingForm } from "@/components/finance/funding-form";

export const dynamic = "force-dynamic";

export default async function NewFundingPage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  await guardOrg(orgId, `/app/${orgId}/financements/nouveau`, "finance.view", "finance.manage");
  const sp = await searchParams;
  const enrollmentId = readParam(sp.enrollment);
  const q = readParam(sp.q);

  if (!enrollmentId || !/^[0-9a-f-]{36}$/i.test(enrollmentId)) {
    const conds = [eq(schema.enrollments.orgId, orgId)];
    if (q) conds.push(or(ilike(schema.enrollments.reference, `%${q}%`), ilike(schema.persons.lastName, `%${q}%`), ilike(schema.persons.firstName, `%${q}%`), ilike(schema.trainingSessions.code, `%${q}%`))!);
    const rows = await db
      .select({ e: schema.enrollments, person: { firstName: schema.persons.firstName, lastName: schema.persons.lastName }, session: { code: schema.trainingSessions.code, title: schema.trainingSessions.title } })
      .from(schema.enrollments)
      .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
      .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.enrollments.sessionId))
      .where(and(...conds))
      .orderBy(desc(schema.enrollments.createdAt))
      .limit(50);
    return (
      <>
        <PageHeader breadcrumb={[{ label: "Finance" }, { label: "Financements", href: `/app/${orgId}/financements` }, { label: "Nouveau" }]} title="Nouveau financement" description="Choisissez d'abord l'inscription concernée : un financement se rattache toujours à une inscription." />
        <Panel>
          <form method="get" className="flex flex-wrap items-end gap-3 border-b border-line px-5 py-3">
            <Field label="Rechercher une inscription" htmlFor="q" className="w-full max-w-sm">
              <Input id="q" name="q" defaultValue={q} placeholder="Référence, nom, code session" />
            </Field>
            <Button type="submit" variant="secondary">
              Rechercher
            </Button>
          </form>
          {rows.length ? (
            <Table>
              <thead>
                <tr>
                  <Th>Référence</Th>
                  <Th>Apprenant</Th>
                  <Th>Session</Th>
                  <Th>État financement</Th>
                  <Th></Th>
                </tr>
              </thead>
              <tbody>
                {rows.map(({ e, person, session }) => (
                  <tr key={e.id}>
                    <Td className="num">{e.reference}</Td>
                    <Td>
                      {person.firstName} {person.lastName}
                    </Td>
                    <Td>
                      {session.code} · {session.title}
                    </Td>
                    <Td>{e.fundingState}</Td>
                    <Td>
                      <Button asChild size="sm" variant="secondary">
                        <Link href={`/app/${orgId}/financements/nouveau?enrollment=${e.id}`}>Choisir</Link>
                      </Button>
                    </Td>
                  </tr>
                ))}
              </tbody>
            </Table>
          ) : (
            <EmptyState title="Aucune inscription" description="Créez d'abord l'inscription dans le module Formation." />
          )}
        </Panel>
      </>
    );
  }

  const [row] = await db
    .select({ e: schema.enrollments, person: { firstName: schema.persons.firstName, lastName: schema.persons.lastName }, session: { code: schema.trainingSessions.code, title: schema.trainingSessions.title, isApprenticeship: schema.trainingSessions.isApprenticeship }, companyName: schema.companies.name })
    .from(schema.enrollments)
    .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
    .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.enrollments.sessionId))
    .leftJoin(schema.companies, eq(schema.companies.id, schema.enrollments.companyId))
    .where(and(eq(schema.enrollments.id, enrollmentId), eq(schema.enrollments.orgId, orgId)))
    .limit(1);
  if (!row) {
    return (
      <>
        <PageHeader title="Nouveau financement" />
        <Notice tone="danger">Inscription introuvable dans cet organisme.</Notice>
      </>
    );
  }
  const funders = await db.select({ id: schema.funders.id, name: schema.funders.name, kind: schema.funders.kind }).from(schema.funders).where(eq(schema.funders.orgId, orgId)).orderBy(asc(schema.funders.name));
  const defaultKind = row.e.contractKind === "contrat_apprentissage" ? "opco" : row.e.contractKind === "cpf" ? "cpf" : row.e.contractKind === "contrat_particulier" ? "particulier" : row.e.companyId ? "entreprise" : "opco";

  return (
    <>
      <PageHeader breadcrumb={[{ label: "Finance" }, { label: "Financements", href: `/app/${orgId}/financements?enrollment=${row.e.id}` }, { label: "Nouveau" }]} title="Nouveau financement" description="Le financement est créé en prévision ou en demande ; l'accord se saisit ensuite avec sa référence de prise en charge." />
      <Panel className="mb-6">
        <PanelHeader title={`Inscription ${row.e.reference}`} actions={<Button asChild variant="secondary" size="sm"><Link href={`/app/${orgId}/inscriptions/${row.e.id}`}>Ouvrir le dossier</Link></Button>} />
        <div className="p-5">
          <KeyValue items={[{ k: "Apprenant", v: `${row.person.firstName} ${row.person.lastName}` }, { k: "Session", v: `${row.session.code} · ${row.session.title}${row.session.isApprenticeship ? " (apprentissage)" : ""}` }, { k: "Entreprise", v: row.companyName }, { k: "Contrat", v: row.e.contractKind }, { k: "Prix du parcours", v: row.e.priceCents !== null ? formatCents(row.e.priceCents) : "non renseigné" }]} />
        </div>
      </Panel>
      <Panel className="p-5">
        <FundingForm
          orgId={orgId}
          action={createFundingAction}
          funders={funders}
          submitLabel="Créer le financement"
          withSchedule={false}
          initial={{ enrollmentId: row.e.id, kind: defaultKind, funderId: null, label: `Prise en charge : ${row.session.title}`, amountCents: row.e.priceCents ?? 0, status: "prevu", rateNote: null, notes: null, agreementRef: null, agreementSource: null, agreementDate: null, validFrom: null, validUntil: null, schedule: [] }}
        />
      </Panel>
    </>
  );
}
