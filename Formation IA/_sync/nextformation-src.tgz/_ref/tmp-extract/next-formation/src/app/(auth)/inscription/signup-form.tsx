"use client";

import Link from "next/link";
import { useActionState } from "react";
import { signupAction, type ActionState } from "@/server/actions/auth";
import { Button } from "@/components/ui/button";
import { Checkbox, Field, Input, Select } from "@/components/ui/field";
import { Notice } from "@/components/ui/surface";

export function SignupForm() {
  const [state, action, pending] = useActionState<ActionState, FormData>(signupAction, {});
  return (
    <form action={action} className="mt-6 space-y-4">
      <div className="grid grid-cols-2 gap-3">
        <Field label="Prénom" htmlFor="firstName" required>
          <Input id="firstName" name="firstName" autoComplete="given-name" required />
        </Field>
        <Field label="Nom" htmlFor="lastName" required>
          <Input id="lastName" name="lastName" autoComplete="family-name" required />
        </Field>
      </div>
      <Field label="Adresse e-mail professionnelle" htmlFor="email" required>
        <Input id="email" name="email" type="email" autoComplete="email" required />
      </Field>
      <Field label="Mot de passe" htmlFor="password" required help="12 caractères minimum, avec majuscule, minuscule et chiffre.">
        <Input id="password" name="password" type="password" autoComplete="new-password" required minLength={12} />
      </Field>
      <div className="grid grid-cols-[1fr_auto] gap-3">
        <Field label="Organisme de formation ou CFA" htmlFor="orgName" required>
          <Input id="orgName" name="orgName" autoComplete="organization" required />
        </Field>
        <Field label="Type" htmlFor="orgKind">
          <Select id="orgKind" name="orgKind" defaultValue="of">
            <option value="of">Organisme de formation</option>
            <option value="cfa">CFA</option>
            <option value="of_cfa">Organisme de formation et CFA</option>
          </Select>
        </Field>
      </div>
      <Checkbox
        name="consent"
        required
        label={
          <span className="text-[13px] text-ink-2">
            J&apos;accepte les{" "}
            <Link href="/cgu" target="_blank" className="text-accent hover:underline">
              conditions générales
            </Link>{" "}
            et la{" "}
            <Link href="/confidentialite" target="_blank" className="text-accent hover:underline">
              politique de confidentialité
            </Link>
            . Les données des apprenants ne sont jamais réutilisées pour entraîner des modèles.
          </span>
        }
      />
      {state.error ? <Notice tone="danger">{state.error}</Notice> : null}
      <Button type="submit" size="lg" className="w-full" loading={pending}>
        Créer mon compte
      </Button>
    </form>
  );
}
