import Link from "next/link";
import { and, asc, desc, eq, inArray, sql, type SQL } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { runOverdueAction } from "@/server/actions/finance";
import { FUNDING_STATUSES, funderKindLabels, nextScheduleLine, overdueScheduleLines } from "@/server/finance/compute";
import { financeSummaryForSession, readSchedule } from "@/server/finance/service";
import { formatCents } from "@/lib/money";
import { fmtDate, fmtDateTime } from "@/lib/dates";
import { todayParis } from "@/lib/time";
import { Badge, StatusBadge, statusMeta } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/field";
import { EmptyState, Notice, PageHeader, Panel, Stat } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { ActionButton } from "@/components/admin/action-form";
import { Pagination, readPage, readParam } from "@/components/admin/pagination";
import { RibLink } from "@/components/finance/rib-link";

export const dynamic = "force-dynamic";
const PAGE = 50;
const isUuid = (s?: string) => Boolean(s && /^[0-9a-f-]{36}$/i.test(s));

export default async function FundingsPage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const ctx = await guardOrg(orgId, `/app/${orgId}/financements`, "finance.view");
  const canManage = ctx.permissions.has("finance.manage");
  const sp = await searchParams;
  const enrollment = isUuid(readParam(sp.enrollment)) ? readParam(sp.enrollment) : undefined;
  const session = isUuid(readParam(sp.session)) ? readParam(sp.session) : undefined;
  const funder = isUuid(readParam(sp.funder)) ? readParam(sp.funder) : undefined;
  const status = readParam(sp.status);
  const from = readParam(sp.from);
  const to = readParam(sp.to);
  const page = readPage(sp.page);
  const today = todayParis();

  const conds: SQL[] = [eq(schema.fundings.orgId, orgId)];
  if (enrollment) conds.push(eq(schema.fundings.enrollmentId, enrollment));
  if (session) conds.push(eq(schema.enrollments.sessionId, session));
  if (funder) conds.push(eq(schema.fundings.funderId, funder));
  if (status === "a_confirmer") conds.push(inArray(schema.fundings.status, ["prevu", "demande"]));
  else if (status && (FUNDING_STATUSES as readonly string[]).includes(status)) conds.push(eq(schema.fundings.status, status as (typeof FUNDING_STATUSES)[number]));
  if (from && /^\d{4}-\d{2}-\d{2}$/.test(from)) conds.push(sql`${schema.fundings.createdAt} >= ${from}::date`);
  if (to && /^\d{4}-\d{2}-\d{2}$/.test(to)) conds.push(sql`${schema.fundings.createdAt} < (${to}::date + interval '1 day')`);
  const where = and(...conds);

  const baseQuery = () =>
    db
      .select({ f: schema.fundings, e: { id: schema.enrollments.id, reference: schema.enrollments.reference, sessionId: schema.enrollments.sessionId, fundingState: schema.enrollments.fundingState }, person: { firstName: schema.persons.firstName, lastName: schema.persons.lastName }, sessionCode: schema.trainingSessions.code, sessionTitle: schema.trainingSessions.title, funderName: schema.funders.name })
      .from(schema.fundings)
      .innerJoin(schema.enrollments, eq(schema.enrollments.id, schema.fundings.enrollmentId))
      .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
      .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.enrollments.sessionId))
      .leftJoin(schema.funders, eq(schema.funders.id, schema.fundings.funderId));

  const [rows, [{ total }], funders, sessions, totals, sessionSummary, enrollmentRow] = await Promise.all([
    baseQuery().where(where).orderBy(desc(schema.fundings.createdAt)).limit(PAGE).offset((page - 1) * PAGE),
    db.select({ total: sql<number>`count(*)::int` }).from(schema.fundings).innerJoin(schema.enrollments, eq(schema.enrollments.id, schema.fundings.enrollmentId)).where(where),
    db.select({ id: schema.funders.id, name: schema.funders.name }).from(schema.funders).where(eq(schema.funders.orgId, orgId)).orderBy(asc(schema.funders.name)),
    db.select({ id: schema.trainingSessions.id, code: schema.trainingSessions.code, title: schema.trainingSessions.title }).from(schema.trainingSessions).where(eq(schema.trainingSessions.orgId, orgId)).orderBy(desc(schema.trainingSessions.startDate)).limit(300),
    db
      .select({
        planned: sql<number>`coalesce(sum(case when ${schema.fundings.status} not in ('annule','refuse') then ${schema.fundings.amountCents} else 0 end), 0)::int`,
        granted: sql<number>`coalesce(sum(case when ${schema.fundings.status} in ('accorde','facture','solde') then ${schema.fundings.amountCents} else 0 end), 0)::int`,
        demanded: sql<number>`coalesce(sum(case when ${schema.fundings.status} = 'demande' then ${schema.fundings.amountCents} else 0 end), 0)::int`,
      })
      .from(schema.fundings)
      .innerJoin(schema.enrollments, eq(schema.enrollments.id, schema.fundings.enrollmentId))
      .where(where)
      .then((r) => r[0]),
    session ? financeSummaryForSession(orgId, session) : Promise.resolve(null),
    enrollment ? db.select({ reference: schema.enrollments.reference, fundingState: schema.enrollments.fundingState }).from(schema.enrollments).where(and(eq(schema.enrollments.id, enrollment), eq(schema.enrollments.orgId, orgId))).limit(1).then((r) => r[0] ?? null) : Promise.resolve(null),
  ]);
  const sessionInfo = session ? sessions.find((s) => s.id === session) : null;
  const filterParams = { enrollment, session, funder, status, from, to };

  return (
    <>
      <PageHeader
        title="Financements"
        description="Prévision, demande, accord, facturation et solde de chaque financement d'inscription. L'état de financement de l'inscription en découle et reste indépendant de la clôture pédagogique."
        actions={
          <>
            <RibLink orgId={orgId} manage={canManage || ctx.isOwner} />
            {canManage ? <ActionButton action={runOverdueAction} fields={{ orgId }} label="Recalculer retards et échéances" /> : null}
            {canManage && enrollment ? (
              <Button asChild>
                <Link href={`/app/${orgId}/financements/nouveau?enrollment=${enrollment}`}>Nouveau financement</Link>
              </Button>
            ) : canManage ? (
              <Button asChild>
                <Link href={`/app/${orgId}/financements/nouveau`}>Nouveau financement</Link>
              </Button>
            ) : null}
          </>
        }
      />

      {enrollmentRow ? (
        <Notice tone="info" className="mb-6">
          Financements de l&apos;inscription <span className="num">{enrollmentRow.reference}</span> (état : {statusMeta[enrollmentRow.fundingState]?.label ?? enrollmentRow.fundingState}).{" "}
          <Link href={`/app/${orgId}/inscriptions/${enrollment}`} className="underline">
            Retour au dossier
          </Link>
        </Notice>
      ) : null}

      <Panel className="mb-6 grid grid-cols-2 gap-6 p-5 md:grid-cols-4">
        <Stat label="Prévu (hors annulés)" value={formatCents(totals.planned)} hint="Financements filtrés" />
        <Stat label="En demande" value={formatCents(totals.demanded)} />
        <Stat label="Accordé" value={formatCents(totals.granted)} hint="Accordés, facturés et soldés" />
        {sessionSummary ? (
          <Stat label={`Session ${sessionInfo?.code ?? ""}`} value={formatCents(sessionSummary.billedCents)} hint={`Facturé · encaissé ${formatCents(sessionSummary.paidCents)} · ${sessionSummary.enrollments} inscription(s) · calcul ${fmtDateTime(new Date(sessionSummary.computedAt))}`} />
        ) : (
          <Stat label="Lignes" value={total} hint="Filtrez par session pour la vue prévu / accordé / facturé / encaissé" />
        )}
      </Panel>

      <Panel>
        <form method="get" className="flex flex-wrap items-end gap-3 border-b border-line px-5 py-3">
          {enrollment ? <input type="hidden" name="enrollment" value={enrollment} /> : null}
          <Field label="Session" htmlFor="session" className="w-64">
            <Select id="session" name="session" defaultValue={session ?? ""}>
              <option value="">Toutes</option>
              {sessions.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.code} · {s.title}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Financeur" htmlFor="funder" className="w-56">
            <Select id="funder" name="funder" defaultValue={funder ?? ""}>
              <option value="">Tous</option>
              {funders.map((f) => (
                <option key={f.id} value={f.id}>
                  {f.name}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Statut" htmlFor="status" className="w-44">
            <Select id="status" name="status" defaultValue={status ?? ""}>
              <option value="">Tous</option>
              {FUNDING_STATUSES.map((s) => (
                <option key={s} value={s}>
                  {statusMeta[s]?.label ?? s}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Créé du" htmlFor="from" className="w-40">
            <Input id="from" name="from" type="date" defaultValue={from ?? ""} />
          </Field>
          <Field label="au" htmlFor="to" className="w-40">
            <Input id="to" name="to" type="date" defaultValue={to ?? ""} />
          </Field>
          <Button type="submit" variant="secondary">
            Filtrer
          </Button>
        </form>
        {rows.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Inscription</Th>
                <Th>Financement</Th>
                <Th>Financeur</Th>
                <Th>Statut</Th>
                <Th>Accord</Th>
                <Th>Prochaine échéance</Th>
                <Th num>Montant</Th>
              </tr>
            </thead>
            <tbody>
              {rows.map(({ f, e, person, sessionCode, funderName }) => {
                const sched = readSchedule(f.schedule);
                const next = nextScheduleLine(sched);
                const late = overdueScheduleLines(sched, today).length;
                return (
                  <tr key={f.id}>
                    <Td>
                      <Link href={`/app/${orgId}/inscriptions/${e.id}`} className="num text-ink hover:underline">
                        {e.reference}
                      </Link>
                      <p className="text-[12px] text-ink-3">
                        {person.firstName} {person.lastName} · {sessionCode}
                      </p>
                    </Td>
                    <Td>
                      <Link href={`/app/${orgId}/financements/${f.id}`} className="font-medium text-ink hover:underline">
                        {f.label}
                      </Link>
                      <p className="text-[12px] text-ink-3">{funderKindLabels[f.kind]}</p>
                    </Td>
                    <Td>{funderName ?? "-"}</Td>
                    <Td>
                      <StatusBadge status={f.status} />
                    </Td>
                    <Td className="text-[12.5px]">
                      {f.agreementRef ? (
                        <>
                          <span className="num">{f.agreementRef}</span>
                          <p className="text-ink-3">{f.validUntil ? `valide jusqu'au ${fmtDate(f.validUntil)}` : "validité non renseignée"}</p>
                        </>
                      ) : (
                        <span className="text-ink-3">-</span>
                      )}
                    </Td>
                    <Td className="text-[12.5px]">
                      {next ? (
                        <>
                          {fmtDate(next.dueDate)} · <span className="num">{formatCents(next.amountCents)}</span>
                          {late ? <Badge tone="danger" className="ml-2">{late} dépassée(s)</Badge> : null}
                        </>
                      ) : sched.length ? (
                        <span className="text-ink-3">Tout facturé</span>
                      ) : (
                        <span className="text-ink-3">Sans échéancier</span>
                      )}
                    </Td>
                    <Td num>{formatCents(f.amountCents)}</Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        ) : (
          <EmptyState
            title="Aucun financement"
            description={enrollment ? "Cette inscription n'a pas encore de financement : son état reste « à définir »." : "Les financements se créent par inscription : prévision, demande, accord avec référence de prise en charge, puis facturation."}
            action={canManage ? <Button asChild><Link href={`/app/${orgId}/financements/nouveau${enrollment ? `?enrollment=${enrollment}` : ""}`}>Créer un financement</Link></Button> : undefined}
          />
        )}
        <Pagination basePath={`/app/${orgId}/financements`} params={filterParams} page={page} pageSize={PAGE} total={total} />
      </Panel>
    </>
  );
}
