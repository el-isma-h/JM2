import Link from "next/link";
import { notFound } from "next/navigation";
import { and, asc, desc, eq, gte, ilike, inArray, lte, or, sql, type SQL } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { trainerSessionIds } from "@/server/authz";
import { contractKindLabels, enrollmentStatusLabels, fundingStateLabels, examStateLabels } from "@/server/enrollments/rules";
import { fmtDate } from "@/lib/dates";
import { StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox, Field, Input, Select } from "@/components/ui/field";
import { EmptyState, PageHeader, Panel } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { Pagination, readPage, readParam } from "@/components/admin/pagination";
import { FadeIn } from "@/components/ui/motion";

export const dynamic = "force-dynamic";
const PAGE = 40;

export default async function EnrollmentsPage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const ctx = await guardOrg(orgId, `/app/${orgId}/inscriptions`, "org.view");
  if (!ctx.permissions.has("enrollments.view") && !(ctx.trainerOnly && ctx.permissions.has("dossier.pedagogy.view"))) notFound();
  const sp = await searchParams;
  const q = readParam(sp.q);
  const sessionId = readParam(sp.session);
  const status = readParam(sp.statut);
  const funding = readParam(sp.financement);
  const exam = readParam(sp.examen);
  const missing = readParam(sp.manquantes) === "1";
  const page = readPage(sp.page);
  const base = `/app/${orgId}/inscriptions`;

  const scope = await trainerSessionIds(ctx);
  const missingSql = sql<number>`(select count(*)::int from ${schema.pieceSubmissions} ps join ${schema.requiredPieces} rp on rp.id = ps.required_piece_id where ps.enrollment_id = ${schema.enrollments.id} and ps.status in ('attendue','refusee') and rp.is_required)`;
  const conds: SQL[] = [eq(schema.enrollments.orgId, orgId)];
  if (scope) conds.push(scope.length ? inArray(schema.enrollments.sessionId, scope) : sql`false`);
  if (q) conds.push(or(ilike(schema.persons.lastName, `%${q}%`), ilike(schema.persons.firstName, `%${q}%`), ilike(schema.persons.email, `%${q}%`), ilike(schema.enrollments.reference, `%${q}%`))!);
  if (sessionId && /^[0-9a-f-]{36}$/i.test(sessionId)) conds.push(eq(schema.enrollments.sessionId, sessionId));
  if (status === "actives") conds.push(inArray(schema.enrollments.status, ["inscrit", "en_cours"]));
  else if (status && (schema.enrollmentStatusEnum.enumValues as readonly string[]).includes(status)) conds.push(eq(schema.enrollments.status, status as "inscrit"));
  // Liens du pilotage : entrées en formation sur une période (date de début du parcours).
  const du = readParam(sp.du);
  const au = readParam(sp.au);
  if (du && /^\d{4}-\d{2}-\d{2}$/.test(du)) conds.push(gte(schema.enrollments.startDate, du));
  if (au && /^\d{4}-\d{2}-\d{2}$/.test(au)) conds.push(lte(schema.enrollments.startDate, au));
  if (funding && (schema.fundingStateEnum.enumValues as readonly string[]).includes(funding)) conds.push(eq(schema.enrollments.fundingState, funding as "a_definir"));
  if (exam && (schema.examStateEnum.enumValues as readonly string[]).includes(exam)) conds.push(eq(schema.enrollments.examState, exam as "a_inscrire"));
  if (missing) conds.push(sql`${missingSql} > 0`);
  const where = and(...conds);

  const from = () =>
    db
      .select({ e: schema.enrollments, p: schema.persons, sessionTitle: schema.trainingSessions.title, sessionCode: schema.trainingSessions.code, companyName: schema.companies.name, missing: missingSql })
      .from(schema.enrollments)
      .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
      .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.enrollments.sessionId))
      .leftJoin(schema.companies, eq(schema.companies.id, schema.enrollments.companyId))
      .where(where);

  const [rows, [{ total }], sessions] = await Promise.all([
    from().orderBy(desc(schema.enrollments.createdAt)).limit(PAGE).offset((page - 1) * PAGE),
    db.select({ total: sql<number>`count(*)::int` }).from(schema.enrollments).innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId)).where(where),
    db
      .select({ id: schema.trainingSessions.id, code: schema.trainingSessions.code, title: schema.trainingSessions.title })
      .from(schema.trainingSessions)
      .where(and(eq(schema.trainingSessions.orgId, orgId), scope ? (scope.length ? inArray(schema.trainingSessions.id, scope) : sql`false`) : sql`true`))
      .orderBy(desc(schema.trainingSessions.startDate), asc(schema.trainingSessions.code))
      .limit(300),
  ]);
  const canManage = ctx.permissions.has("enrollments.manage") && !ctx.trainerOnly;

  return (
    <FadeIn>
      <PageHeader
        title="Inscriptions"
        description="Une inscription = une personne sur une session. Les statuts d'inscription, de progression, de financement et d'examen sont distincts."
        actions={
          canManage ? (
            <Button asChild>
              <Link href={`${base}/nouvelle`}>Nouvelle inscription</Link>
            </Button>
          ) : null
        }
      />
      <Panel>
        <form method="get" className="flex flex-wrap items-end gap-3 border-b border-line px-5 py-3">
          <Field label="Personne ou référence" htmlFor="q" className="w-full max-w-xs">
            <Input id="q" name="q" defaultValue={q} placeholder="Nom, e-mail, INS-2026-0012" />
          </Field>
          <Field label="Session" htmlFor="session" className="w-64">
            <Select id="session" name="session" defaultValue={sessionId ?? ""}>
              <option value="">Toutes</option>
              {sessions.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.code} · {s.title}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Inscription" htmlFor="statut" className="w-40">
            <Select id="statut" name="statut" defaultValue={status ?? ""}>
              <option value="">Tous</option>
              {schema.enrollmentStatusEnum.enumValues.map((s) => (
                <option key={s} value={s}>
                  {enrollmentStatusLabels[s]}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Financement" htmlFor="financement" className="w-40">
            <Select id="financement" name="financement" defaultValue={funding ?? ""}>
              <option value="">Tous</option>
              {schema.fundingStateEnum.enumValues.map((s) => (
                <option key={s} value={s}>
                  {fundingStateLabels[s]}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Examen" htmlFor="examen" className="w-40">
            <Select id="examen" name="examen" defaultValue={exam ?? ""}>
              <option value="">Tous</option>
              {schema.examStateEnum.enumValues.map((s) => (
                <option key={s} value={s}>
                  {examStateLabels[s]}
                </option>
              ))}
            </Select>
          </Field>
          <Checkbox name="manquantes" value="1" defaultChecked={missing} label="Pièces obligatoires manquantes" className="mb-2" />
          <Button type="submit" variant="secondary">
            Filtrer
          </Button>
        </form>
        {rows.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Personne</Th>
                <Th>Référence</Th>
                <Th>Session</Th>
                <Th>Contrat</Th>
                <Th>Dates</Th>
                <Th>Inscription</Th>
                <Th>Financement</Th>
                <Th>Examen</Th>
                <Th num>Pièces</Th>
              </tr>
            </thead>
            <tbody>
              {rows.map(({ e, p, sessionTitle, sessionCode, companyName, missing: m }) => (
                <tr key={e.id}>
                  <Td>
                    <Link href={`${base}/${e.id}`} className="font-medium text-ink hover:underline">
                      {p.lastName.toUpperCase()} {p.firstName}
                    </Link>
                    {companyName ? <p className="text-[12px] text-ink-3">{companyName}</p> : null}
                  </Td>
                  <Td className="num">{e.reference}</Td>
                  <Td>
                    <Link href={`/app/${orgId}/sessions/${e.sessionId}`} className="hover:underline">
                      {sessionTitle}
                    </Link>
                    <p className="num text-[12px] text-ink-3">{sessionCode}</p>
                  </Td>
                  <Td>{contractKindLabels[e.contractKind]}</Td>
                  <Td className="num whitespace-nowrap">
                    {fmtDate(e.startDate)} au {fmtDate(e.endDate)}
                  </Td>
                  <Td>
                    <StatusBadge status={e.status} />
                  </Td>
                  <Td>
                    <StatusBadge status={e.fundingState} />
                  </Td>
                  <Td>
                    <StatusBadge status={e.examState} />
                  </Td>
                  <Td num className={m ? "text-warn-ink" : undefined}>
                    {m ? `${m} manquante(s)` : "complet"}
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
        ) : (
          <EmptyState
            title="Aucune inscription"
            description={q || status || sessionId || missing ? "Aucune inscription ne correspond à ces filtres." : "Inscrivez un candidat ou un apprenant sur une session ouverte."}
            action={
              canManage ? (
                <Button asChild variant="secondary">
                  <Link href={`${base}/nouvelle`}>Nouvelle inscription</Link>
                </Button>
              ) : undefined
            }
          />
        )}
        <Pagination basePath={base} params={{ q, session: sessionId, statut: status, financement: funding, examen: exam, manquantes: missing ? "1" : undefined, du, au }} page={page} pageSize={PAGE} total={total} />
      </Panel>
    </FadeIn>
  );
}
