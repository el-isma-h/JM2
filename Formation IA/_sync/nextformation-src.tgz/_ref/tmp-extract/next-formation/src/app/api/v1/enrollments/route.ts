import { NextResponse, type NextRequest } from "next/server";
import { and, asc, eq, sql, type SQL } from "drizzle-orm";
import { db, schema } from "@/db";
import { authenticateApiKey, readPagination } from "@/server/integrations/api-auth";
import { audit } from "@/server/audit";

export const dynamic = "force-dynamic";

/** GET /api/v1/enrollments?sessionId=…&status=… : inscriptions (scope enrollments.read, données personnelles minimales, accès journalisé). */
export async function GET(req: NextRequest) {
  const a = await authenticateApiKey(req, "enrollments.read");
  if (!a.ok) return a.response;
  const { limit, offset } = readPagination(req);
  const sp = req.nextUrl.searchParams;
  const c: SQL[] = [eq(schema.enrollments.orgId, a.auth.orgId)];
  const sessionId = sp.get("sessionId");
  if (sessionId && /^[0-9a-f-]{36}$/i.test(sessionId)) c.push(eq(schema.enrollments.sessionId, sessionId));
  const status = sp.get("status");
  if (status && (schema.enrollmentStatusEnum.enumValues as readonly string[]).includes(status)) c.push(eq(schema.enrollments.status, status as (typeof schema.enrollmentStatusEnum.enumValues)[number]));
  const where = and(...c);
  const [rows, [{ total }]] = await Promise.all([
    db
      .select({ id: schema.enrollments.id, reference: schema.enrollments.reference, status: schema.enrollments.status, progression: schema.enrollments.progression, fundingState: schema.enrollments.fundingState, sessionId: schema.enrollments.sessionId, sessionCode: schema.trainingSessions.code, startDate: schema.enrollments.startDate, endDate: schema.enrollments.endDate, firstName: schema.persons.firstName, lastName: schema.persons.lastName, email: schema.persons.email, updatedAt: schema.enrollments.updatedAt })
      .from(schema.enrollments)
      .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
      .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.enrollments.sessionId))
      .where(where)
      .orderBy(asc(schema.enrollments.reference))
      .limit(limit)
      .offset(offset),
    db.select({ total: sql<number>`count(*)::int` }).from(schema.enrollments).where(where),
  ]);
  await audit({ action: "api.enrollments.read", orgId: a.auth.orgId, entityType: "api_key", entityId: a.auth.keyId, after: { rows: rows.length, sessionId, status } });
  return NextResponse.json({ data: rows, total, limit, offset }, { headers: { "Cache-Control": "no-store" } });
}
