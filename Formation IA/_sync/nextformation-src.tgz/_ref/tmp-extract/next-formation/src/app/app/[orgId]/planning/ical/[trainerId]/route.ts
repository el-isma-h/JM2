import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { AuthError } from "@/server/auth";
import { requireOrg } from "@/server/authz";
import { audit } from "@/server/audit";
import { buildTrainerIcs, periodsForTrainer } from "@/server/planning/service";
import { todayParis } from "@/lib/time";

/** Agenda iCal d'un formateur (6 mois glissants autour d'aujourd'hui). Un formateur seul n'exporte que son propre agenda. */
export async function GET(_req: Request, { params }: { params: Promise<{ orgId: string; trainerId: string }> }) {
  const { orgId, trainerId } = await params;
  try {
    const ctx = await requireOrg(orgId, "planning.view");
    if (ctx.trainerOnly && ctx.trainerId !== trainerId) return new NextResponse("Accès refusé.", { status: 403 });
    const [trainer] = await db.select().from(schema.trainers).where(and(eq(schema.trainers.id, trainerId), eq(schema.trainers.orgId, orgId))).limit(1);
    if (!trainer) return new NextResponse("Formateur introuvable.", { status: 404 });
    const today = todayParis();
    const from = new Date(`${today}T00:00:00Z`);
    from.setUTCMonth(from.getUTCMonth() - 2);
    const to = new Date(`${today}T00:00:00Z`);
    to.setUTCMonth(to.getUTCMonth() + 6);
    const rows = await periodsForTrainer(orgId, trainerId, { from: from.toISOString().slice(0, 10), to: to.toISOString().slice(0, 10) });
    const ics = buildTrainerIcs({
      calendarName: `${trainer.firstName} ${trainer.lastName} : séances`,
      items: rows.map((r) => ({
        uid: r.period.id,
        date: r.slot.date,
        startTime: r.period.startTime,
        endTime: r.period.endTime,
        summary: `${r.session.code} : ${r.slot.title ?? r.session.title}`,
        description: `Période ${r.period.part} (${r.period.status})`,
        cancelled: r.period.status === "annulee" || r.slot.status === "annulee",
      })),
    });
    await audit({ action: "planning.ical.export", userId: ctx.user.id, orgId, entityType: "trainer", entityId: trainerId, after: { events: rows.length } });
    return new NextResponse(ics, {
      headers: { "Content-Type": "text/calendar; charset=utf-8", "Content-Disposition": `attachment; filename="agenda-${trainer.lastName.toLowerCase()}.ics"`, "Cache-Control": "private, no-store" },
    });
  } catch (e) {
    if (e instanceof AuthError) return new NextResponse("Accès refusé.", { status: e.code === "unauthenticated" ? 401 : 403 });
    throw e;
  }
}
