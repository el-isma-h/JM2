import type { Metadata } from "next";
import { eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { loadPeriod } from "@/server/planning/service";
import { canRecordAttendance } from "@/server/planning/hours";
import { serverNow } from "@/lib/time";
import { fmtDate } from "@/lib/dates";
import { Logo } from "@/components/ui/logo";
import { Field, Input } from "@/components/ui/field";
import { Notice, Panel } from "@/components/ui/surface";
import { ActionForm } from "@/components/admin/action-form";
import { SignaturePad } from "@/components/pedagogy/signature-pad";
import { publicSignAction } from "@/server/actions/attendance";
import { readParam } from "@/components/admin/pagination";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Émargement", robots: { index: false, follow: false } };

/** Page publique de signature (QR code + code tournant, ou lien e-mail personnel). Aucune donnée nominative affichée avant signature. */
export default async function EmargerPage({ params, searchParams }: { params: Promise<{ token: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { token } = await params;
  const sp = await searchParams;
  const e = readParam(sp.e);
  const k = readParam(sp.k);
  const [period] = /^[A-Za-z0-9_-]{8,64}$/.test(token) ? await db.select().from(schema.periods).where(eq(schema.periods.publicToken, token)).limit(1) : [];
  const row = period ? await loadPeriod(period.orgId, period.id) : null;
  const [org] = row ? await db.select({ name: schema.organismes.tradeName, legal: schema.organismes.legalName }).from(schema.organismes).where(eq(schema.organismes.id, row.period.orgId)).limit(1) : [];
  const rule = row ? canRecordAttendance({ date: row.slot.date, startTime: row.period.startTime, endTime: row.period.endTime, status: row.period.status }, serverNow()) : null;

  return (
    <main className="mx-auto flex min-h-[100dvh] w-full max-w-md flex-col justify-center px-5 py-10">
      <div className="mb-8">
        <Logo />
      </div>
      {!row ? (
        <Notice tone="danger" title="Lien inconnu">
          Ce lien d&apos;émargement n&apos;existe pas ou n&apos;est plus valide.
        </Notice>
      ) : (
        <Panel className="p-6">
          <p className="etiquette">{org?.name ?? org?.legal}</p>
          <h1 className="mt-2 text-[22px]">Signer ma présence</h1>
          <p className="mt-2 text-[13.5px] text-ink-2">
            {row.session.title} · {fmtDate(row.slot.date, "EEEE d MMMM yyyy")} · {row.period.startTime} à {row.period.endTime}
          </p>
          {row.period.status === "cloturee" ? (
            <Notice tone="warn" className="mt-5">
              Cette période est clôturée : la signature n&apos;est plus possible. Rapprochez-vous de votre formateur.
            </Notice>
          ) : row.period.status !== "ouverte" ? (
            <Notice tone="info" className="mt-5">
              La feuille d&apos;émargement n&apos;est pas encore ouverte par le formateur.
            </Notice>
          ) : rule && !rule.ok ? (
            <Notice tone="info" className="mt-5">
              {rule.reason}
            </Notice>
          ) : (
            <div className="mt-6">
              <ActionForm action={publicSignAction} submitLabel="Signer ma présence" footerClassName="mt-5">
                <input type="hidden" name="token" value={token} />
                {e && k ? (
                  <>
                    <input type="hidden" name="e" value={e} />
                    <input type="hidden" name="k" value={k} />
                    <p className="mb-4 text-[13px] text-ink-2">Lien personnel reçu par e-mail : signez ci-dessous pour confirmer votre présence.</p>
                  </>
                ) : (
                  <div className="space-y-4">
                    <Field label="Votre adresse e-mail" required htmlFor="email" help="Celle de votre dossier d'inscription.">
                      <Input id="email" name="email" type="email" required autoComplete="email" inputMode="email" />
                    </Field>
                    <Field label="Code affiché en salle" required htmlFor="code" help="6 chiffres, renouvelés toutes les 2 minutes.">
                      <Input id="code" name="code" inputMode="numeric" pattern="[0-9]{6}" maxLength={6} required className="num text-[20px] tracking-[0.3em]" />
                    </Field>
                  </div>
                )}
                <div className="mt-4">
                  <SignaturePad label="Signature (facultative)" height={120} />
                </div>
              </ActionForm>
            </div>
          )}
          <p className="mt-6 text-[11px] text-ink-3">L&apos;heure de signature est celle du serveur (Europe/Paris). Votre adresse IP est conservée avec la signature à des fins de preuve.</p>
        </Panel>
      )}
    </main>
  );
}
