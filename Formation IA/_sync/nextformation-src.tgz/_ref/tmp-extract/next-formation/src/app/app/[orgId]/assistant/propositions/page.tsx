import Link from "next/link";
import { guardOrg } from "@/server/guard";
import { listProposals } from "@/server/ai/store";
import { AGENT_LABELS, type AgentName } from "@/server/ai/proposals";
import { readParam } from "@/components/admin/pagination";
import { ProposalCard, type ProposalView } from "@/components/ai/proposal-card";
import { Button } from "@/components/ui/button";
import { Field, Select } from "@/components/ui/field";
import { EmptyState, Notice, PageHeader, Panel } from "@/components/ui/surface";
import type { OrgContext, Permission } from "@/server/authz";

export const dynamic = "force-dynamic";

const DECIDE_PERMS: Record<string, Permission> = { documents: "documents.generate", pieces: "dossier.admin_docs.manage", relances: "tasks.manage", qualite: "quality.manage", programme: "catalog.manage", planning: "planning.manage", dossier: "tasks.manage", modeles: "documents.generate" };

function entityHref(base: string, type: string | null, id: string | null): string | null {
  if (!type || !id) return null;
  if (type === "mail_template") return `${base}/modeles-emails`;
  const map: Record<string, string> = { enrollment: "inscriptions", session: "sessions", company: "entreprises", document: "documents", invoice: "factures", program: "catalogue" };
  return map[type] ? `${base}/${map[type]}/${id}` : null;
}

/** Propositions des agents : en attente (validation / refus motivé), puis historique. */
export default async function ProposalsPage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const ctx: OrgContext = await guardOrg(orgId, `/app/${orgId}/assistant/propositions`);
  const sp = await searchParams;
  const highlight = readParam(sp.p);
  const back = readParam(sp.back);
  const filter = readParam(sp.status) ?? "proposee";
  const statuses = filter === "historique" ? (["validee", "appliquee", "refusee", "expiree"] as const) : (["proposee"] as const);
  const rows = await listProposals(ctx.org.id, [...statuses], 100);
  const base = `/app/${orgId}`;
  const views: ProposalView[] = rows.map((r) => ({
    id: r.id,
    agent: r.agent,
    agentLabel: AGENT_LABELS[r.agent as AgentName] ?? r.agent,
    kind: r.kind,
    title: r.title,
    summary: r.summary,
    status: r.status,
    entityType: r.entityType,
    entityId: r.entityId,
    entityHref: entityHref(base, r.entityType, r.entityId),
    payload: (r.payload ?? {}) as Record<string, unknown>,
    rationale: (r.rationale ?? {}) as ProposalView["rationale"],
    provider: r.provider,
    model: r.model,
    createdAt: r.createdAt.toISOString(),
    decisionNote: r.decisionNote,
    decidedAt: r.decidedAt?.toISOString() ?? null,
    appliedAt: r.appliedAt?.toISOString() ?? null,
    canDecide: ctx.isOwner || !DECIDE_PERMS[r.agent] || ctx.permissions.has(DECIDE_PERMS[r.agent]),
  }));
  const ordered = highlight ? [...views.filter((v) => v.id === highlight), ...views.filter((v) => v.id !== highlight)] : views;

  return (
    <>
      <PageHeader
        breadcrumb={[{ label: "Assistant IA", href: `${base}/assistant` }, { label: "Propositions" }]}
        title="Propositions à valider"
        description="Chaque proposition explique ses sources et son niveau de certitude. Valider déclenche l'effet (envoi, création en brouillon, tâche) ; refuser conserve le motif. Rien ne s'applique sans votre décision."
        actions={
          <div className="flex flex-wrap items-center gap-2">
            {back && back.startsWith("/") ? (
              <Button asChild variant="secondary">
                <Link href={back}>Retour au dossier</Link>
              </Button>
            ) : null}
            <form method="get" className="flex items-end gap-2">
              {highlight ? <input type="hidden" name="p" value={highlight} /> : null}
              <Field label="Afficher" htmlFor="status" className="w-44">
                <Select id="status" name="status" defaultValue={filter}>
                  <option value="proposee">En attente</option>
                  <option value="historique">Historique</option>
                </Select>
              </Field>
              <Button type="submit" variant="secondary">
                Filtrer
              </Button>
            </form>
          </div>
        }
      />
      {highlight && !views.some((v) => v.id === highlight) ? (
        <Notice tone="info" className="mb-6">
          La proposition demandée n&apos;est pas dans cette liste (déjà décidée ou introuvable).{" "}
          <Link href={`${base}/assistant/propositions?status=historique&p=${highlight}`} className="font-medium underline underline-offset-4">
            Voir l&apos;historique
          </Link>
        </Notice>
      ) : null}
      {ordered.length ? (
        <div className="space-y-6">
          {ordered.map((v) => (
            <ProposalCard key={v.id} p={v} orgId={orgId} highlighted={v.id === highlight} />
          ))}
        </div>
      ) : (
        <Panel>
          <EmptyState
            title={filter === "historique" ? "Aucune proposition décidée" : "Aucune proposition en attente"}
            description="Lancez un agent depuis un dossier (« Analyser avec l'assistant ») ou depuis l'assistant."
            action={
              <Button asChild variant="secondary" size="sm">
                <Link href={`${base}/assistant`}>Ouvrir l&apos;assistant</Link>
              </Button>
            }
          />
        </Panel>
      )}
    </>
  );
}
