"use client";

import { ActionButton, ActionForm } from "@/components/admin/action-form";
import { FormDialog } from "@/components/admin/form-dialog";
import { Checkbox, Field, Input } from "@/components/ui/field";
import { createApiKeyAction, generateEdofExportAction, saveMicrosoftAction, saveMoodleAction, saveWebhookAction, testMoodleAction, testWebhookAction } from "@/server/actions/integrations";

export function MoodleForm({ orgId, url, hasToken }: { orgId: string; url: string; hasToken: boolean }) {
  return (
    <div className="space-y-3">
      <ActionForm action={saveMoodleAction} submitLabel="Enregistrer" submitVariant="secondary" submitSize="sm" className="space-y-3" footerClassName="pt-1">
        <input type="hidden" name="orgId" value={orgId} />
        <Field label="Adresse Moodle" htmlFor="md-url" required help="Exemple : https://moodle.exemple.fr">
          <Input id="md-url" name="url" type="url" defaultValue={url} required />
        </Field>
        <Field label="Jeton de service web" htmlFor="md-token" help={hasToken ? "Un jeton est enregistré (chiffré). Laissez vide pour le conserver." : "Administration du site, Serveur, Services web, Gérer les jetons. Stocké chiffré, jamais réaffiché."}>
          <Input id="md-token" name="token" type="password" autoComplete="off" placeholder={hasToken ? "••••••••" : ""} />
        </Field>
      </ActionForm>
      <ActionButton action={testMoodleAction} fields={{ orgId }} label="Tester la connexion" variant="primary" size="sm" />
    </div>
  );
}

export function MicrosoftForm({ orgId, tenantId, clientId, siteUrl, hasSecret }: { orgId: string; tenantId: string; clientId: string; siteUrl: string; hasSecret: boolean }) {
  return (
    <ActionForm action={saveMicrosoftAction} submitLabel="Enregistrer" submitVariant="secondary" submitSize="sm" className="space-y-3" footerClassName="pt-1">
      <input type="hidden" name="orgId" value={orgId} />
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Identifiant du tenant (Entra ID)" htmlFor="ms-tenant" required>
          <Input id="ms-tenant" name="tenantId" defaultValue={tenantId} required className="num" />
        </Field>
        <Field label="Identifiant d'application (client id)" htmlFor="ms-client" required>
          <Input id="ms-client" name="clientId" defaultValue={clientId} required className="num" />
        </Field>
      </div>
      <Field label="Secret client" htmlFor="ms-secret" help={hasSecret ? "Un secret est enregistré (chiffré). Laissez vide pour le conserver." : "Stocké chiffré, jamais réaffiché."}>
        <Input id="ms-secret" name="clientSecret" type="password" autoComplete="off" placeholder={hasSecret ? "••••••••" : ""} />
      </Field>
      <Field label="Site SharePoint (facultatif)" htmlFor="ms-site">
        <Input id="ms-site" name="siteUrl" type="url" defaultValue={siteUrl} placeholder="https://organisme.sharepoint.com/sites/formation" />
      </Field>
    </ActionForm>
  );
}

export function WebhookForm({ orgId, kind, url, events, allEvents, hasSecret, isDemo }: { orgId: string; kind: "webhook" | "zapier"; url: string; events: string[]; allEvents: { key: string; label: string }[]; hasSecret: boolean; isDemo: boolean }) {
  return (
    <div className="space-y-3">
      <ActionForm action={saveWebhookAction} submitLabel="Enregistrer" submitVariant="secondary" submitSize="sm" className="space-y-3" footerClassName="pt-1">
        <input type="hidden" name="orgId" value={orgId} />
        <input type="hidden" name="kind" value={kind} />
        <Field label={kind === "zapier" ? "Adresse du « Catch Hook » Zapier" : "Adresse du webhook (https)"} htmlFor={`wh-url-${kind}`} required>
          <Input id={`wh-url-${kind}`} name="url" type="url" defaultValue={url} required />
        </Field>
        <Field label="Secret de signature" htmlFor={`wh-secret-${kind}`} help={hasSecret ? "Un secret est enregistré. Laissez vide pour le conserver." : "Vide : un secret est généré et affiché une seule fois."}>
          <Input id={`wh-secret-${kind}`} name="secret" type="password" autoComplete="off" placeholder={hasSecret ? "••••••••" : ""} />
        </Field>
        <Field label="Événements envoyés" htmlFor={`wh-ev-${kind}`}>
          <div id={`wh-ev-${kind}`} className="grid gap-1.5 sm:grid-cols-2">
            {allEvents.map((e) => (
              <Checkbox key={e.key} name="events" value={e.key} defaultChecked={events.includes(e.key)} label={e.label} />
            ))}
          </div>
        </Field>
      </ActionForm>
      {url && hasSecret && !isDemo ? <ActionButton action={testWebhookAction} fields={{ orgId, kind }} label="Envoyer un test" variant="primary" size="sm" /> : null}
    </div>
  );
}

export function EdofButtons({ orgId, canExport }: { orgId: string; canExport: boolean }) {
  if (!canExport) return null;
  return (
    <div className="flex flex-wrap gap-2">
      <ActionButton action={generateEdofExportAction} fields={{ orgId, format: "xml" }} label="Générer le XML" variant="primary" size="sm" />
      <ActionButton action={generateEdofExportAction} fields={{ orgId, format: "csv" }} label="Générer le CSV" variant="secondary" size="sm" />
    </div>
  );
}

export function CreateApiKeyDialog({ orgId, scopes }: { orgId: string; scopes: { key: string; label: string }[] }) {
  return (
    <FormDialog action={createApiKeyAction} trigger="Nouvelle clé API" triggerVariant="secondary" triggerSize="sm" title="Nouvelle clé API" description="La clé complète n'est affichée qu'une seule fois à la création ; seule son empreinte est conservée." submitLabel="Créer la clé">
      <input type="hidden" name="orgId" value={orgId} />
      <Field label="Nom" htmlFor="ak-name" required help="Exemple : site WordPress, connecteur CRM.">
        <Input id="ak-name" name="name" required />
      </Field>
      <Field label="Portées" htmlFor="ak-scopes">
        <div id="ak-scopes" className="space-y-1.5">
          {scopes.map((s) => (
            <Checkbox key={s.key} name="scopes" value={s.key} defaultChecked={s.key === "catalog.read"} label={s.label} />
          ))}
        </div>
      </Field>
    </FormDialog>
  );
}
