import Link from "next/link";
import { and, asc, desc, eq, inArray } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { trainerSessionIds } from "@/server/authz";
import { listModules } from "@/server/elearning/service";
import { createElearningModuleAction, recordProgressAction, toggleElearningModuleAction, validateProgressAction } from "@/server/actions/elearning";
import { fmtDateTime } from "@/lib/dates";
import { fmtMinutes } from "@/lib/time";
import { Button } from "@/components/ui/button";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Checkbox, Field, Input, Select, Textarea } from "@/components/ui/field";
import { EmptyState, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FormDialog } from "@/components/admin/form-dialog";
import { ActionButton } from "@/components/admin/action-form";
import { readParam } from "@/components/admin/pagination";

export const dynamic = "force-dynamic";

const KIND_LABELS: Record<string, string> = { contenu: "Contenu propre", quiz: "Quiz", moodle: "Cours Moodle", lien: "Lien externe", scorm: "Paquet SCORM", xapi: "xAPI", video: "Vidéo" };

export default async function ElearningPage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const base = `/app/${orgId}`;
  const ctx = await guardOrg(orgId, `${base}/elearning`, "catalog.view");
  const sp = await searchParams;
  const versionFilter = readParam(sp.version);
  const canManage = ctx.permissions.has("catalog.manage");
  const canValidate = ctx.permissions.has("dossier.pedagogy.manage") && !ctx.trainerOnly;
  const scope = await trainerSessionIds(ctx);

  const [modulesList, versions, progress] = await Promise.all([
    listModules(orgId, versionFilter),
    db
      .select({ id: schema.programVersions.id, version: schema.programVersions.version, programTitle: schema.programs.title })
      .from(schema.programVersions)
      .innerJoin(schema.programs, eq(schema.programs.id, schema.programVersions.programId))
      .where(and(eq(schema.programVersions.orgId, orgId), inArray(schema.programVersions.status, ["brouillon", "active"])))
      .orderBy(asc(schema.programs.title), desc(schema.programVersions.version)),
    db
      .select({ p: schema.elearningProgress, moduleTitle: schema.elearningModules.title, counts: schema.elearningModules.countsAsHours, reference: schema.enrollments.reference, sessionId: schema.enrollments.sessionId, firstName: schema.persons.firstName, lastName: schema.persons.lastName })
      .from(schema.elearningProgress)
      .innerJoin(schema.elearningModules, eq(schema.elearningModules.id, schema.elearningProgress.elearningModuleId))
      .innerJoin(schema.enrollments, eq(schema.enrollments.id, schema.elearningProgress.enrollmentId))
      .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
      .where(and(eq(schema.elearningProgress.orgId, orgId), scope ? (scope.length ? inArray(schema.enrollments.sessionId, scope) : eq(schema.enrollments.id, "00000000-0000-0000-0000-000000000000")) : undefined))
      .orderBy(desc(schema.elearningProgress.updatedAt))
      .limit(100),
  ]);
  const programModules = await db.select({ id: schema.modules.id, title: schema.modules.title, programVersionId: schema.modules.programVersionId }).from(schema.modules).where(eq(schema.modules.orgId, orgId)).orderBy(asc(schema.modules.position));
  const activeEnrollments = canValidate
    ? await db
        .select({ id: schema.enrollments.id, reference: schema.enrollments.reference, firstName: schema.persons.firstName, lastName: schema.persons.lastName })
        .from(schema.enrollments)
        .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
        .where(and(eq(schema.enrollments.orgId, orgId), inArray(schema.enrollments.status, ["inscrit", "en_cours"])))
        .orderBy(asc(schema.persons.lastName))
        .limit(300)
    : [];
  const toValidate = progress.filter((r) => !r.p.validatedAt && r.p.timeSpentMinutes > 0);

  return (
    <>
      <PageHeader
        title="E-learning"
        description="Modules à distance : contenu propre (Markdown, quiz), cours Moodle, paquets SCORM. Le temps passé n'est jamais compté en heures sans validation humaine."
        actions={
          canManage ? (
            <FormDialog action={createElearningModuleAction} trigger="Nouveau module" title="Module e-learning" description="Choisissez le type puis remplissez la partie correspondante ; les autres champs sont ignorés." submitLabel="Créer le module" wide>
              <input type="hidden" name="orgId" value={orgId} />
              <div className="grid grid-cols-2 gap-3">
                <Field label="Type" required htmlFor="el-kind">
                  <Select id="el-kind" name="kind" defaultValue="contenu">
                    <option value="contenu">Contenu propre (Markdown et / ou quiz)</option>
                    <option value="quiz">Quiz seul</option>
                    <option value="moodle">Cours Moodle</option>
                    <option value="scorm">Paquet SCORM (.zip)</option>
                    <option value="lien">Lien externe</option>
                  </Select>
                </Field>
                <Field label="Durée indicative (min)" htmlFor="el-dur">
                  <Input id="el-dur" name="durationMinutes" type="number" min={0} defaultValue={30} className="num" />
                </Field>
              </div>
              <Field label="Titre" required htmlFor="el-title">
                <Input id="el-title" name="title" required maxLength={160} />
              </Field>
              <Field label="Description" htmlFor="el-desc">
                <Textarea id="el-desc" name="description" className="min-h-16" />
              </Field>
              <div className="grid grid-cols-2 gap-3">
                <Field label="Version de programme" htmlFor="el-version" help="Détermine les apprenants qui y accèdent.">
                  <Select id="el-version" name="programVersionId" defaultValue={versionFilter ?? ""}>
                    <option value="">Hors programme (accès personnel seulement)</option>
                    {versions.map((v) => (
                      <option key={v.id} value={v.id}>
                        {v.programTitle} (v{v.version})
                      </option>
                    ))}
                  </Select>
                </Field>
                <Field label="Module du programme" htmlFor="el-module">
                  <Select id="el-module" name="moduleId" defaultValue="">
                    <option value="">Aucun</option>
                    {versions.map((v) => {
                      const list = programModules.filter((m) => m.programVersionId === v.id);
                      return list.length ? (
                        <optgroup key={v.id} label={`${v.programTitle} v${v.version}`}>
                          {list.map((m) => (
                            <option key={m.id} value={m.id}>
                              {m.title}
                            </option>
                          ))}
                        </optgroup>
                      ) : null;
                    })}
                  </Select>
                </Field>
              </div>
              <Checkbox name="countsAsHours" value="1" label="Le temps validé compte comme heures réalisées à distance" />
              <Field label="Contenu Markdown (contenu propre)" htmlFor="el-md">
                <Textarea id="el-md" name="markdown" className="min-h-28" placeholder={"# Titre\nParagraphe…\n- point"} />
              </Field>
              <Field label="Quiz JSON (contenu propre / quiz)" htmlFor="el-quiz" help='[{"question":"…","choices":["A","B"],"answer":0}]'>
                <Textarea id="el-quiz" name="quiz" className="min-h-20 font-mono text-[12px]" />
              </Field>
              <div className="grid grid-cols-2 gap-3">
                <Field label="URL (Moodle / lien)" htmlFor="el-url">
                  <Input id="el-url" name="url" type="url" placeholder="https://moodle.exemple.fr/course/view.php?id=12" />
                </Field>
                <Field label="Identifiant du cours Moodle" htmlFor="el-ext">
                  <Input id="el-ext" name="externalId" placeholder="12" />
                </Field>
              </div>
              <Field label="Paquet SCORM (.zip)" htmlFor="el-pkg" help="Le manifeste imsmanifest.xml est lu pour le titre et la page de lancement ; pas de lecteur SCORM complet.">
                <Input id="el-pkg" name="package" type="file" accept=".zip,application/zip" className="py-1.5" />
              </Field>
            </FormDialog>
          ) : null
        }
      />

      <Panel className="mb-6">
        <form method="get" className="flex flex-wrap items-end gap-3 border-b border-line px-5 py-3">
          <Field label="Version de programme" htmlFor="f-version" className="w-72">
            <Select id="f-version" name="version" defaultValue={versionFilter ?? ""}>
              <option value="">Toutes</option>
              {versions.map((v) => (
                <option key={v.id} value={v.id}>
                  {v.programTitle} (v{v.version})
                </option>
              ))}
            </Select>
          </Field>
          <Button type="submit" variant="secondary">
            Filtrer
          </Button>
        </form>
        {modulesList.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Module</Th>
                <Th>Type</Th>
                <Th>Programme</Th>
                <Th num>Durée</Th>
                <Th>Heures</Th>
                <Th>État</Th>
                <Th>Actions</Th>
              </tr>
            </thead>
            <tbody>
              {modulesList.map(({ m, versionLabel, version }) => (
                <tr key={m.id}>
                  <Td>
                    <Link href={`${base}/elearning/${m.id}`} className="font-medium hover:underline">
                      {m.title}
                    </Link>
                    {m.description ? <p className="text-[12px] text-ink-3">{m.description}</p> : null}
                  </Td>
                  <Td>
                    <Badge>{KIND_LABELS[m.kind] ?? m.kind}</Badge>
                  </Td>
                  <Td>{versionLabel ? `${versionLabel} (v${version})` : "Hors programme"}</Td>
                  <Td num>{m.durationMinutes ? fmtMinutes(m.durationMinutes) : "-"}</Td>
                  <Td>{m.countsAsHours ? <Badge tone="info">Comptées après validation</Badge> : <span className="text-[12px] text-ink-3">Non comptées</span>}</Td>
                  <Td>{m.isActive ? <Badge tone="ok">Actif</Badge> : <Badge>Inactif</Badge>}</Td>
                  <Td>
                    <div className="flex flex-wrap gap-2">
                      <Button asChild variant="secondary" size="sm">
                        <Link href={`${base}/elearning/${m.id}`}>Ouvrir</Link>
                      </Button>
                      {canManage ? <ActionButton action={toggleElearningModuleAction} fields={{ orgId, moduleId: m.id }} label={m.isActive ? "Désactiver" : "Activer"} variant="ghost" /> : null}
                    </div>
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucun module e-learning" description={canManage ? "Créez un contenu propre, reliez un cours Moodle ou importez un paquet SCORM." : "Aucun module n'a encore été créé."} />
        )}
      </Panel>

      <Panel>
        <PanelHeader
          title="Progressions et validation du temps à distance"
          description={`${toValidate.length} progression(s) avec du temps non validé. Seule la validation humaine permet de compter des heures.`}
          actions={
            canValidate && modulesList.length ? (
              <FormDialog action={recordProgressAction} trigger="Saisir un temps" triggerVariant="secondary" triggerSize="sm" title="Temps à distance (saisie manuelle)" description="Par exemple d'après un relevé Moodle. Reste à valider ensuite." submitLabel="Enregistrer">
                <input type="hidden" name="orgId" value={orgId} />
                <Field label="Module" required htmlFor="pr-module">
                  <Select id="pr-module" name="moduleId" required defaultValue="">
                    <option value="">Choisir</option>
                    {modulesList.map(({ m }) => (
                      <option key={m.id} value={m.id}>
                        {m.title}
                      </option>
                    ))}
                  </Select>
                </Field>
                <Field label="Inscription" required htmlFor="pr-enr">
                  <Select id="pr-enr" name="enrollmentId" required defaultValue="">
                    <option value="">Choisir</option>
                    {activeEnrollments.map((e) => (
                      <option key={e.id} value={e.id}>
                        {e.lastName} {e.firstName} · {e.reference}
                      </option>
                    ))}
                  </Select>
                </Field>
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Minutes à ajouter" required htmlFor="pr-min">
                    <Input id="pr-min" name="minutes" type="number" min={0} max={240} required className="num" />
                  </Field>
                  <Field label="Statut" htmlFor="pr-status">
                    <Select id="pr-status" name="status" defaultValue="">
                      <option value="">Inchangé</option>
                      <option value="en_cours">En cours</option>
                      <option value="termine">Terminé</option>
                      <option value="echoue">Échoué</option>
                    </Select>
                  </Field>
                </div>
              </FormDialog>
            ) : null
          }
        />
        {progress.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Apprenant</Th>
                <Th>Module</Th>
                <Th>Statut</Th>
                <Th num>Temps</Th>
                <Th num>Score</Th>
                <Th>Dernier accès</Th>
                <Th>Validation</Th>
              </tr>
            </thead>
            <tbody>
              {progress.map((r) => (
                <tr key={r.p.id}>
                  <Td>
                    {r.lastName.toUpperCase()} {r.firstName}
                    <p className="num text-[12px] text-ink-3">{r.reference}</p>
                  </Td>
                  <Td>{r.moduleTitle}</Td>
                  <Td>
                    <StatusBadge status={r.p.status} />
                  </Td>
                  <Td num>{fmtMinutes(r.p.timeSpentMinutes)}</Td>
                  <Td num>{r.p.score != null ? `${r.p.score}${r.p.maxScore ? ` / ${r.p.maxScore}` : ""}` : "-"}</Td>
                  <Td className="whitespace-nowrap">{r.p.lastAccessAt ? fmtDateTime(r.p.lastAccessAt) : "-"}</Td>
                  <Td>
                    {r.p.validatedAt ? (
                      <Badge tone="ok">Validé {fmtDateTime(r.p.validatedAt)}</Badge>
                    ) : r.p.timeSpentMinutes && canValidate ? (
                      <ActionButton action={validateProgressAction} fields={{ orgId, progressId: r.p.id }} label="Valider le temps" variant="primary" confirm={{ title: "Valider ce temps à distance ?", description: `${r.p.timeSpentMinutes} min seront ${r.counts ? "comptées comme heures réalisées à distance" : "validées (module non compté en heures)"}.` }} />
                    ) : (
                      <span className="text-[12px] text-ink-3">{r.p.timeSpentMinutes ? "À valider" : "-"}</span>
                    )}
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucune progression" description="Les temps passés par les apprenants apparaissent ici, en attente de validation." />
        )}
      </Panel>
      {ctx.trainerOnly ? (
        <Notice tone="info" className="mt-6">
          Formateur : seules les progressions de vos sessions affectées sont visibles ; la validation du temps revient au responsable pédagogique.
        </Notice>
      ) : null}
    </>
  );
}
