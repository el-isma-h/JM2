import { ImageResponse } from "next/og";

export const size = { width: 180, height: 180 };
export const contentType = "image/png";

/** Icône d'écran d'accueil iOS : monogramme N sur fond encre, signal violet. */
export default function AppleIcon() {
  return new ImageResponse(
    (
      <div style={{ width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center", background: "#0A0B0D" }}>
        <svg width="120" height="120" viewBox="0 0 32 32">
          <path d="M8 26V6l16 20V6" fill="none" stroke="#F3F0E8" strokeWidth="2.4" strokeLinecap="square" />
          <rect x="21.5" y="5" width="3" height="3" fill="#C9B8F0" />
        </svg>
      </div>
    ),
    size,
  );
}
