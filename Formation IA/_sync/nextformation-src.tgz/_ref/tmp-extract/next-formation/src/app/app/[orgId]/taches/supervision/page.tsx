import Link from "next/link";
import { guardOrg } from "@/server/guard";
import { allTasks, orgStaff, readTaskFilters } from "@/server/tasks/queries";
import { isOpen, isOverdue, taskFamilyLabels, type TaskFamily } from "@/server/tasks/rules";
import { roleLabels, type OrgRole } from "@/server/authz";
import { todayParis } from "@/lib/time";
import { Button } from "@/components/ui/button";
import { Field, Select } from "@/components/ui/field";
import { PageHeader, Panel, PanelHeader, Stat } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FadeIn } from "@/components/ui/motion";
import { TaskTable } from "../_components/task-table";
import { TaskFiltersForm } from "../_components/task-filters";
import { CreateTaskDialog } from "../_components/create-task-dialog";
import { BulkReassign } from "./bulk-reassign";

export const dynamic = "force-dynamic";

export default async function SupervisionPage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const ctx = await guardOrg(orgId, `/app/${orgId}/taches/supervision`, "tasks.view_all");
  const sp = await searchParams;
  const f = readTaskFilters(sp);
  const today = todayParis();
  const [tasks, staff, allOpen] = await Promise.all([allTasks(orgId, f), orgStaff(orgId), allTasks(orgId, { status: "ouvertes" }, 5000)]);
  const staffMap = new Map(staff.map((s) => [s.id, s.name]));

  // Charge par personne et par rôle (tâches ouvertes, sans filtre) : retards visibles.
  const byPerson = new Map<string, { name: string; open: number; late: number; blocked: number }>();
  const byRole = new Map<string, { open: number; late: number }>();
  let unassigned = 0;
  for (const t of allOpen) {
    if (!isOpen(t.status)) continue;
    const late = isOverdue(t, today);
    if (t.assigneeUserId) {
      const e = byPerson.get(t.assigneeUserId) ?? { name: staffMap.get(t.assigneeUserId) ?? "Membre inactif", open: 0, late: 0, blocked: 0 };
      e.open++;
      if (late) e.late++;
      if (t.status === "bloquee") e.blocked++;
      byPerson.set(t.assigneeUserId, e);
    } else if (t.assigneeRole) {
      const e = byRole.get(t.assigneeRole) ?? { open: 0, late: 0 };
      e.open++;
      if (late) e.late++;
      byRole.set(t.assigneeRole, e);
    } else unassigned++;
  }
  const totalLate = allOpen.filter((t) => isOverdue(t, today)).length;
  const families = new Map<string, number>();
  for (const t of allOpen) families.set(t.family, (families.get(t.family) ?? 0) + 1);

  return (
    <FadeIn>
      <PageHeader
        title="Supervision des tâches"
        description="Vue par personne et par rôle, retards, charge et tâches sans responsable. Réaffectez en masse sans perdre la trace : chaque réaffectation est historisée sur la tâche."
        actions={
          <>
            <Button asChild variant="secondary">
              <Link href={`/app/${orgId}/taches`}>Mes tâches</Link>
            </Button>
            {ctx.permissions.has("tasks.manage") ? <CreateTaskDialog orgId={orgId} staff={staff} /> : null}
          </>
        }
      />
      <Panel className="mb-6">
        <div className="grid grid-cols-2 gap-x-6 gap-y-5 px-5 py-5 md:grid-cols-4">
          <Stat label="Ouvertes" value={allOpen.length} hint={`au ${today.split("-").reverse().join("/")}`} />
          <Stat label="En retard" value={<Link href={`/app/${orgId}/taches/supervision?late=1`} className={totalLate ? "text-danger-ink hover:underline" : "hover:underline"}>{totalLate}</Link>} />
          <Stat label="Bloquées" value={<Link href={`/app/${orgId}/taches/supervision?status=bloquee`} className="hover:underline">{allOpen.filter((t) => t.status === "bloquee").length}</Link>} />
          <Stat label="À affecter" value={<Link href={`/app/${orgId}/taches/supervision?unassigned=1`} className={unassigned ? "text-warn-ink hover:underline" : "hover:underline"}>{unassigned}</Link>} hint="sans responsable ni rôle" />
        </div>
      </Panel>

      <div className="mb-6 grid gap-6 lg:grid-cols-2">
        <Panel>
          <PanelHeader title="Par personne" description="Tâches ouvertes affectées nommément." />
          {byPerson.size ? (
            <Table>
              <thead>
                <tr>
                  <Th>Membre</Th>
                  <Th num>Ouvertes</Th>
                  <Th num>Retard</Th>
                  <Th num>Bloquées</Th>
                </tr>
              </thead>
              <tbody>
                {[...byPerson.entries()]
                  .sort((a, b) => b[1].open - a[1].open)
                  .map(([id, e]) => (
                    <tr key={id}>
                      <Td>
                        <Link href={`/app/${orgId}/taches/supervision?assignee=${id}`} className="hover:underline">
                          {e.name}
                        </Link>
                      </Td>
                      <Td num>{e.open}</Td>
                      <Td num className={e.late ? "text-danger-ink" : undefined}>{e.late}</Td>
                      <Td num>{e.blocked}</Td>
                    </tr>
                  ))}
              </tbody>
            </Table>
          ) : (
            <p className="px-5 py-4 text-[13.5px] text-ink-2">Aucune tâche affectée nommément.</p>
          )}
        </Panel>
        <Panel>
          <PanelHeader title="Par rôle et par activité" description="Relais en attente de prise en charge, et répartition par famille." />
          <Table>
            <tbody>
              {[...byRole.entries()].map(([role, e]) => (
                <tr key={role}>
                  <Td>
                    <Link href={`/app/${orgId}/taches/supervision?role=${role}`} className="hover:underline">
                      Rôle : {roleLabels[role as OrgRole] ?? role}
                    </Link>
                  </Td>
                  <Td num>{e.open}</Td>
                  <Td num className={e.late ? "text-danger-ink" : undefined}>{e.late ? `${e.late} en retard` : "-"}</Td>
                </tr>
              ))}
              {[...families.entries()].map(([fam, n]) => (
                <tr key={fam}>
                  <Td>
                    <Link href={`/app/${orgId}/taches/supervision?family=${fam}`} className="hover:underline">
                      Activité : {taskFamilyLabels[fam as TaskFamily] ?? fam}
                    </Link>
                  </Td>
                  <Td num>{n}</Td>
                  <Td />
                </tr>
              ))}
              {!byRole.size && !families.size ? (
                <tr>
                  <Td className="text-ink-2">Aucune tâche ouverte.</Td>
                </tr>
              ) : null}
            </tbody>
          </Table>
        </Panel>
      </div>

      <Panel>
        <TaskFiltersForm
          f={f}
          extra={
            <>
              <Field label="Responsable" htmlFor="tf-assignee" className="w-48">
                <Select id="tf-assignee" name="assignee" defaultValue={f.assignee ?? ""}>
                  <option value="">Tous</option>
                  {staff.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name}
                    </option>
                  ))}
                </Select>
              </Field>
              <Field label="Rôle" htmlFor="tf-role" className="w-44">
                <Select id="tf-role" name="role" defaultValue={f.role ?? ""}>
                  <option value="">Tous</option>
                  {Object.entries(roleLabels)
                    .filter(([k]) => k !== "learner" && k !== "employer")
                    .map(([k, v]) => (
                      <option key={k} value={k}>
                        {v}
                      </option>
                    ))}
                </Select>
              </Field>
              <input type="hidden" name="unassigned" value={f.unassigned ? "1" : ""} />
            </>
          }
        />
        {ctx.permissions.has("tasks.manage") ? <BulkReassign orgId={orgId} staff={staff} /> : null}
        <TaskTable tasks={tasks} orgId={orgId} staff={staffMap} today={today} selectable={ctx.permissions.has("tasks.manage")} emptyTitle="Aucune tâche" emptyDescription="Aucune tâche ne correspond à ces filtres." />
      </Panel>
    </FadeIn>
  );
}
