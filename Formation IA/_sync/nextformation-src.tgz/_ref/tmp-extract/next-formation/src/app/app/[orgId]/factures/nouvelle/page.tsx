import { and, asc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { createInvoiceAction } from "@/server/actions/finance";
import { readBillTo, readSchedule } from "@/server/finance/service";
import { fmtDate } from "@/lib/dates";
import { Notice, PageHeader, Panel } from "@/components/ui/surface";
import { readParam } from "@/components/admin/pagination";
import { InvoiceForm, type EditableLine, type InvoiceFormValues } from "@/components/finance/invoice-form";
import { centsToInput } from "@/server/finance/compute";

export const dynamic = "force-dynamic";
const isUuid = (s?: string) => Boolean(s && /^[0-9a-f-]{36}$/i.test(s));

function companyBillTo(c: typeof schema.companies.$inferSelect): InvoiceFormValues["billTo"] {
  return { kind: "entreprise", name: c.name, addressLine1: c.addressLine1 ?? "", addressLine2: c.addressLine2 ?? "", postalCode: c.postalCode ?? "", city: c.city ?? "", siret: c.siret ?? "", vatNumber: "", email: c.email ?? "" };
}
function funderBillTo(f: typeof schema.funders.$inferSelect): InvoiceFormValues["billTo"] {
  return { kind: f.kind === "entreprise" ? "entreprise" : f.kind === "particulier" ? "particulier" : "financeur", name: f.name, addressLine1: f.addressLine1 ?? "", addressLine2: "", postalCode: f.postalCode ?? "", city: f.city ?? "", siret: f.siret ?? "", vatNumber: "", email: f.email ?? "" };
}
function personBillTo(p: typeof schema.persons.$inferSelect): InvoiceFormValues["billTo"] {
  return { kind: "particulier", name: `${p.firstName} ${p.lastName}`, addressLine1: p.addressLine1 ?? "", addressLine2: p.addressLine2 ?? "", postalCode: p.postalCode ?? "", city: p.city ?? "", siret: "", vatNumber: "", email: p.email ?? "" };
}

export default async function NewInvoicePage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  await guardOrg(orgId, `/app/${orgId}/factures/nouvelle`, "finance.view", "finance.manage");
  const sp = await searchParams;
  const fundingId = isUuid(readParam(sp.funding)) ? readParam(sp.funding) : undefined;
  const enrollmentId = isUuid(readParam(sp.enrollment)) ? readParam(sp.enrollment) : undefined;
  const companyId = isUuid(readParam(sp.company)) ? readParam(sp.company) : undefined;
  const creditOf = isUuid(readParam(sp.creditOf)) ? readParam(sp.creditOf) : undefined;
  const scheduleIdxRaw = readParam(sp.schedule);
  const scheduleIndex = scheduleIdxRaw && /^\d+$/.test(scheduleIdxRaw) ? Number(scheduleIdxRaw) : null;

  const initial: InvoiceFormValues = { kind: "facture", billTo: { kind: "entreprise", name: "", addressLine1: "", addressLine2: "", postalCode: "", city: "", siret: "", vatNumber: "", email: "" }, vatExempt: true, lines: [], scheduleIndex: null };
  const links: { label: string; value: string }[] = [];
  const warnings: string[] = [];

  const applyEnrollment = async (eid: string) => {
    const [r] = await db
      .select({ e: schema.enrollments, p: schema.persons, s: schema.trainingSessions, c: schema.companies })
      .from(schema.enrollments)
      .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
      .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.enrollments.sessionId))
      .leftJoin(schema.companies, eq(schema.companies.id, schema.enrollments.companyId))
      .where(and(eq(schema.enrollments.id, eid), eq(schema.enrollments.orgId, orgId)))
      .limit(1);
    if (!r) {
      warnings.push("Inscription introuvable dans cet organisme : liaison ignorée.");
      return null;
    }
    initial.enrollmentId = r.e.id;
    initial.sessionId = r.s.id;
    initial.personId = r.p.id;
    initial.servicePeriodStart = r.e.startDate ?? r.s.startDate;
    initial.servicePeriodEnd = r.e.endDate ?? r.s.endDate;
    links.push({ label: "Inscription", value: `${r.e.reference} · ${r.p.firstName} ${r.p.lastName}` }, { label: "Session", value: `${r.s.code} · ${r.s.title}` });
    if (r.c) {
      initial.companyId = r.c.id;
      initial.billTo = companyBillTo(r.c);
    } else {
      initial.billTo = personBillTo(r.p);
    }
    return r;
  };

  if (creditOf) {
    const [orig] = await db.select().from(schema.invoices).where(and(eq(schema.invoices.id, creditOf), eq(schema.invoices.orgId, orgId))).limit(1);
    if (!orig || orig.status === "brouillon") warnings.push("Facture d'origine introuvable ou non émise : l'avoir n'est pas rattaché.");
    else {
      const lines = await db.select().from(schema.invoiceLines).where(eq(schema.invoiceLines.invoiceId, orig.id)).orderBy(asc(schema.invoiceLines.position));
      Object.assign(initial, { kind: "avoir", creditOfInvoiceId: orig.id, enrollmentId: orig.enrollmentId, sessionId: orig.sessionId, companyId: orig.companyId, funderId: orig.funderId, personId: orig.personId, fundingId: orig.fundingId, billTo: readBillTo(orig.billTo), vatExempt: orig.vatExempt, vatMention: orig.vatMention, servicePeriodStart: orig.servicePeriodStart, servicePeriodEnd: orig.servicePeriodEnd, paymentTerms: orig.paymentTerms, notes: `Avoir sur la facture ${orig.number} du ${fmtDate(orig.issueDate)}.` });
      initial.lines = lines.map<EditableLine>((l) => ({ label: l.label, description: l.description ?? "", quantity: (l.quantity / 1000).toString().replace(".", ","), unit: l.unit, unitPrice: centsToInput(l.unitCents), vatRate: (l.vatRateBp / 100).toString() }));
      links.push({ label: "Facture d'origine", value: `${orig.number} · ${fmtDate(orig.issueDate)}` });
    }
  } else if (fundingId) {
    const [f] = await db.select().from(schema.fundings).where(and(eq(schema.fundings.id, fundingId), eq(schema.fundings.orgId, orgId))).limit(1);
    if (!f) warnings.push("Financement introuvable dans cet organisme.");
    else {
      const r = await applyEnrollment(f.enrollmentId);
      initial.fundingId = f.id;
      if (f.funderId) {
        const [fu] = await db.select().from(schema.funders).where(and(eq(schema.funders.id, f.funderId), eq(schema.funders.orgId, orgId))).limit(1);
        if (fu) {
          initial.funderId = fu.id;
          initial.billTo = funderBillTo(fu);
          if (fu.companyId) initial.companyId = fu.companyId;
        }
      } else if (f.kind === "particulier" && r) {
        initial.billTo = personBillTo(r.p);
      }
      links.push({ label: "Financement", value: `${f.label} · ${(f.amountCents / 100).toLocaleString("fr-FR", { style: "currency", currency: "EUR" })}${f.agreementRef ? ` · réf. ${f.agreementRef}` : ""}` });
      if (!["accorde", "facture", "solde"].includes(f.status)) warnings.push("Ce financement n'est pas « accordé » : la création sera refusée tant que l'accord (référence, source, validité) n'est pas saisi.");
      const sched = readSchedule(f.schedule);
      const sessionTitle = r ? `${r.s.title} (${r.s.code})` : f.label;
      const learner = r ? `${r.p.firstName} ${r.p.lastName}` : "";
      const period = r ? `du ${fmtDate(r.e.startDate ?? r.s.startDate)} au ${fmtDate(r.e.endDate ?? r.s.endDate)}` : "";
      if (scheduleIndex !== null && sched[scheduleIndex]) {
        const line = sched[scheduleIndex];
        if (line.invoiceId) warnings.push("Cette échéance est déjà facturée.");
        initial.kind = "acompte";
        initial.scheduleIndex = scheduleIndex;
        initial.dueDate = line.dueDate;
        initial.lines = [{ label: `${line.label} : ${sessionTitle}`, description: `${learner} · ${period}${f.agreementRef ? ` · prise en charge ${f.agreementRef}` : ""}`, quantity: "1", unit: "forfait", unitPrice: centsToInput(line.amountCents), vatRate: "0" }];
      } else {
        const billed = sched.filter((l) => l.invoiceId).reduce((a, l) => a + l.amountCents, 0);
        initial.lines = [{ label: `Action de formation : ${sessionTitle}`, description: `${learner} · ${period}${f.agreementRef ? ` · prise en charge ${f.agreementRef}` : ""}${billed ? ` · déduction des acomptes facturés ${(billed / 100).toFixed(2)} €` : ""}`, quantity: "1", unit: "forfait", unitPrice: centsToInput(f.amountCents - billed), vatRate: "0" }];
      }
    }
  } else if (enrollmentId) {
    const r = await applyEnrollment(enrollmentId);
    if (r) initial.lines = [{ label: `Action de formation : ${r.s.title} (${r.s.code})`, description: `${r.p.firstName} ${r.p.lastName} · du ${fmtDate(r.e.startDate ?? r.s.startDate)} au ${fmtDate(r.e.endDate ?? r.s.endDate)}`, quantity: "1", unit: "forfait", unitPrice: centsToInput(r.e.priceCents ?? 0), vatRate: "0" }];
  } else if (companyId) {
    const [c] = await db.select().from(schema.companies).where(and(eq(schema.companies.id, companyId), eq(schema.companies.orgId, orgId))).limit(1);
    if (c) {
      initial.companyId = c.id;
      initial.billTo = companyBillTo(c);
      links.push({ label: "Entreprise", value: c.name });
    } else warnings.push("Entreprise introuvable dans cet organisme.");
  }

  return (
    <>
      <PageHeader breadcrumb={[{ label: "Finance" }, { label: "Factures", href: `/app/${orgId}/factures` }, { label: initial.kind === "avoir" ? "Nouvel avoir" : "Nouvelle facture" }]} title={initial.kind === "avoir" ? "Nouvel avoir" : "Nouvelle facture"} description="Le document est créé en brouillon (sans numéro). Les totaux sont recalculés côté serveur ; le destinataire et les montants sont figés à l'émission." />
      {warnings.map((w) => (
        <Notice key={w} tone="warn" className="mb-4">
          {w}
        </Notice>
      ))}
      <Panel className="p-5">
        <InvoiceForm orgId={orgId} action={createInvoiceAction} initial={initial} submitLabel="Créer le brouillon" readOnlyLinks={links} />
      </Panel>
    </>
  );
}
