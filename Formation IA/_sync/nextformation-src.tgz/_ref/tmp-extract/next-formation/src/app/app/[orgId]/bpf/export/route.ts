import { NextResponse } from "next/server";
import { guardOrg } from "@/server/guard";
import { audit } from "@/server/audit";
import { computeBpf } from "@/server/finance/bpf";
import { renderBpfPdf } from "@/server/finance/pdf";
import { toCsv } from "@/server/finance/compute";
import { todayParis } from "@/lib/time";

export const dynamic = "force-dynamic";

/** BPF : export CSV des rubriques (format=csv) ou récapitulatif PDF (format=pdf). Export : permission exports.run. */
export async function GET(req: Request, { params }: { params: Promise<{ orgId: string }> }) {
  const { orgId } = await params;
  const url = new URL(req.url);
  const ctx = await guardOrg(orgId, `/app/${orgId}/bpf/export?${url.searchParams.toString()}`, "finance.view", "exports.run");
  const y = Number(url.searchParams.get("year"));
  const year = Number.isInteger(y) && y >= 2000 && y <= 2100 ? y : Number(todayParis().slice(0, 4)) - 1;
  const format = url.searchParams.get("format") === "pdf" ? "pdf" : "csv";
  const report = await computeBpf(ctx.org.id, year);
  await audit({ action: "bpf.export", userId: ctx.user.id, orgId: ctx.org.id, entityType: "bpf", after: { year, format } });
  if (format === "pdf") {
    const pdf = await renderBpfPdf({ org: ctx.org, year, computedAt: report.computedAt, sections: report.sections.map((s) => ({ title: s.title, rows: s.indicators.map((i) => ({ label: i.label, value: i.display, note: `${i.definition} Dénominateur : ${i.denominator} Exclusions : ${i.exclusions}` })) })) });
    return new NextResponse(new Uint8Array(pdf), { headers: { "Content-Type": "application/pdf", "Content-Disposition": `attachment; filename="bpf-${year}.pdf"`, "Cache-Control": "no-store" } });
  }
  const rows = report.sections.flatMap((s) => s.indicators.map((i) => [s.title, i.code, i.label, i.unit === "euros" ? (i.value / 100).toFixed(2).replace(".", ",") : i.unit === "heures" ? (i.value / 60).toFixed(2).replace(".", ",") : String(i.value), i.unit, i.count, i.definition, i.denominator, i.exclusions, report.computedAt]));
  const csv = toCsv(["rubrique", "code", "indicateur", "valeur", "unite", "elements", "definition", "denominateur", "exclusions", "calcule_le"], rows);
  return new NextResponse("﻿" + csv, { headers: { "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": `attachment; filename="bpf-${year}.csv"`, "Cache-Control": "no-store" } });
}
