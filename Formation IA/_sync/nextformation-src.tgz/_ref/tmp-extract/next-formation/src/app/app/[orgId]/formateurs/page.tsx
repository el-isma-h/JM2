import Link from "next/link";
import { and, eq, ilike, or, sql, type SQL } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { createTrainerAction } from "@/server/actions/trainers";
import { formatCents } from "@/lib/money";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/field";
import { EmptyState, PageHeader, Panel } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FormDialog } from "@/components/admin/form-dialog";
import { Pagination, readPage, readParam } from "@/components/admin/pagination";
import { TrainerFields, trainerKindLabels } from "@/components/catalog/trainer-fields";

export const dynamic = "force-dynamic";
const PAGE = 50;

export default async function TrainersPage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const base = `/app/${orgId}`;
  const ctx = await guardOrg(orgId, `${base}/formateurs`, "sessions.view");
  const sp = await searchParams;
  const q = readParam(sp.q);
  const kind = readParam(sp.kind);
  const inactive = readParam(sp.inactifs) === "1";
  const page = readPage(sp.page);

  const conds: SQL[] = [eq(schema.trainers.orgId, ctx.org.id)];
  if (!inactive) conds.push(eq(schema.trainers.isActive, true));
  if (kind && (schema.trainerKindEnum.enumValues as readonly string[]).includes(kind)) conds.push(eq(schema.trainers.kind, kind as "interne"));
  if (q) conds.push(or(ilike(schema.trainers.lastName, `%${q}%`), ilike(schema.trainers.firstName, `%${q}%`), ilike(schema.trainers.email, `%${q}%`), sql`${schema.trainers.skills}::text ilike ${`%${q}%`}`)!);
  // Formateur seul : il ne voit que sa propre fiche.
  if (ctx.trainerOnly) conds.push(ctx.trainerId ? eq(schema.trainers.id, ctx.trainerId) : sql`false`);
  const where = and(...conds);

  const [rows, [{ total }]] = await Promise.all([
    db
      .select({
        t: schema.trainers,
        sessions: sql<number>`(select count(distinct st.session_id)::int from ${schema.sessionTrainers} st join ${schema.trainingSessions} s on s.id = st.session_id where st.trainer_id = "trainers"."id" and s.status in ('ouverte','confirmee','en_cours'))`,
        docs: sql<number>`(select count(*)::int from ${schema.documents} d where d.trainer_id = "trainers"."id" and d.category in ('cv','diplome'))`,
      })
      .from(schema.trainers)
      .where(where)
      .orderBy(schema.trainers.lastName, schema.trainers.firstName)
      .limit(PAGE)
      .offset((page - 1) * PAGE),
    db.select({ total: sql<number>`count(*)::int` }).from(schema.trainers).where(where),
  ]);
  const canManage = ctx.permissions.has("sessions.manage");

  return (
    <>
      <PageHeader
        title="Formateurs"
        description="Formateurs internes, externes et sous-traitants : qualifications, documents (CV, diplômes), affectations et disponibilités."
        actions={
          canManage ? (
            <FormDialog action={createTrainerAction} trigger="Nouveau formateur" title="Nouveau formateur" submitLabel="Créer la fiche" wide>
              <TrainerFields orgId={ctx.org.id} />
            </FormDialog>
          ) : null
        }
      />
      <Panel>
        <form method="get" className="flex flex-wrap items-end gap-3 border-b border-line px-5 py-3">
          <Field label="Recherche" htmlFor="q" className="w-full max-w-xs">
            <Input id="q" name="q" defaultValue={q} placeholder="Nom, e-mail ou domaine" />
          </Field>
          <Field label="Statut" htmlFor="kind" className="w-52">
            <Select id="kind" name="kind" defaultValue={kind ?? ""}>
              <option value="">Tous</option>
              {Object.entries(trainerKindLabels).map(([v, l]) => (
                <option key={v} value={v}>
                  {l}
                </option>
              ))}
            </Select>
          </Field>
          <label className="mb-2 inline-flex items-center gap-2 text-sm">
            <input type="checkbox" name="inactifs" value="1" defaultChecked={inactive} className="h-4 w-4 rounded-none" />
            Inclure les inactifs
          </label>
          <Button type="submit" variant="secondary">
            Filtrer
          </Button>
        </form>
        {rows.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Formateur</Th>
                <Th>Statut</Th>
                <Th>Domaines</Th>
                <Th num>Tarif horaire</Th>
                <Th num>Sessions en cours</Th>
                <Th>Qualifications</Th>
                <Th>Compte</Th>
              </tr>
            </thead>
            <tbody>
              {rows.map(({ t, sessions, docs }) => (
                <tr key={t.id}>
                  <Td>
                    <Link href={`${base}/formateurs/${t.id}`} className="font-medium text-ink hover:underline">
                      {t.firstName} {t.lastName}
                    </Link>
                    <p className="text-[12px] text-ink-3">{[t.email, t.companyName].filter(Boolean).join(" · ")}</p>
                  </Td>
                  <Td>
                    <div className="flex gap-1">
                      <Badge>{trainerKindLabels[t.kind]}</Badge>
                      {!t.isActive ? <Badge tone="neutral">Inactif</Badge> : null}
                    </div>
                  </Td>
                  <Td>{Array.isArray(t.skills) && (t.skills as string[]).length ? (t.skills as string[]).join(", ") : "-"}</Td>
                  <Td num>{formatCents(t.hourlyRateCents)}</Td>
                  <Td num>{sessions}</Td>
                  <Td>{docs ? <Badge tone="ok">{docs} document(s)</Badge> : <Badge tone="warn">Aucun CV / diplôme</Badge>}</Td>
                  <Td>{t.userId ? <Badge tone="ok">Espace formateur</Badge> : <span className="text-[12px] text-ink-3">Non invité</span>}</Td>
                </tr>
              ))}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucun formateur" description={q || kind ? "Aucun résultat pour ces filtres." : "Créez les fiches de vos formateurs pour les affecter aux sessions."} />
        )}
        <Pagination basePath={`${base}/formateurs`} params={{ q, kind, inactifs: inactive ? "1" : undefined }} page={page} pageSize={PAGE} total={total} />
      </Panel>
    </>
  );
}
