import Link from "next/link";
import { guardOrg } from "@/server/guard";
import { audit } from "@/server/audit";
import { canManageRib, canViewRib, getRibDocument, listRibHistory, ribDetails } from "@/server/documents/rib";
import { deleteRibAction, refuseRibAction, ribDownloadLinkAction, uploadRibAction, validateRibAction } from "@/server/actions/rib";
import { fmtDateTime } from "@/lib/dates";
import { fmtBytes } from "@/components/admin/utils";
import { ActionButton } from "@/components/admin/action-form";
import { FormDialog } from "@/components/admin/form-dialog";
import { DownloadButton } from "@/components/documents/download-button";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/field";
import { EmptyState, KeyValue, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FadeIn } from "@/components/ui/motion";

export const dynamic = "force-dynamic";

/**
 * F12 : RIB central. Lecture : propriétaire ou finance.view (auditée rib.view). Gestion : propriétaire ou finance.manage.
 * `finance.view` seul voit la page en lecture seule ; les actions sont refusées côté serveur même par appel direct.
 */
export default async function RibPage({ params }: { params: Promise<{ orgId: string }> }) {
  const { orgId } = await params;
  const path = `/app/${orgId}/finance/rib`;
  const ctx = await guardOrg(orgId, path, "org.view");
  const view = canViewRib(ctx);
  const manage = canManageRib(ctx);
  if (!view) {
    return (
      <FadeIn>
        <PageHeader title="RIB central" />
        <Notice tone="danger" title="Habilitation nécessaire">
          La consultation du RIB central est réservée au propriétaire et à l&apos;habilitation « consulter la finance ».
        </Notice>
      </FadeIn>
    );
  }
  const [doc, history] = await Promise.all([getRibDocument(orgId), listRibHistory(orgId)]);
  const details = ribDetails(ctx.org, false);
  if (doc) await audit({ action: "rib.view", userId: ctx.user.id, orgId, entityType: "document", entityId: doc.id, after: { mode: "page" } });
  const refusal = (doc?.generationData as { refusal?: { reason: string; at: string } } | null)?.refusal;

  const uploadDialog = manage ? (
    <FormDialog action={uploadRibAction} trigger={doc ? "Remplacer le RIB" : "Déposer le RIB"} title={doc ? "Remplacer le RIB central" : "Déposer le RIB central"} description="L'IBAN est vérifié (clé) puis chiffré ; seul le masque est affiché. Le fichier (PDF, PNG ou JPEG) est stocké en privé, catégorie RIB, confidentiel." submitLabel={doc ? "Remplacer" : "Déposer"}>
      <input type="hidden" name="orgId" value={orgId} />
      <Field label="Titulaire du compte" required htmlFor="rib-holder">
        <Input id="rib-holder" name="holder" defaultValue={details.holder ?? ctx.org.legalName} required />
      </Field>
      <Field label="IBAN" required htmlFor="rib-iban">
        <Input id="rib-iban" name="iban" required className="num" placeholder="FR76 …" autoComplete="off" />
      </Field>
      <Field label="BIC" htmlFor="rib-bic">
        <Input id="rib-bic" name="bic" defaultValue={details.bic ?? ""} className="num" autoComplete="off" />
      </Field>
      <Field label="Fichier du RIB" required htmlFor="rib-file">
        <Input id="rib-file" name="file" type="file" accept=".pdf,.png,.jpg,.jpeg" required className="py-1.5" />
      </Field>
    </FormDialog>
  ) : null;

  return (
    <FadeIn>
      <PageHeader
        title="RIB central"
        description="Coordonnées bancaires de l'organisme utilisées sur les factures et les conventions. Un seul RIB courant ; chaque remplacement conserve l'historique."
        actions={
          <>
            <Button asChild variant="secondary">
              <Link href={`/app/${orgId}/factures`}>Factures et règlements</Link>
            </Button>
            {uploadDialog}
          </>
        }
      />
      <Notice tone={manage ? "info" : "warn"} className="mb-5" title={manage ? "Gestion autorisée" : "Lecture seule"}>
        {manage
          ? `Vous pouvez déposer, remplacer, valider, refuser ou supprimer le RIB (${ctx.isOwner ? "propriétaire" : "habilitation « gérer la finance »"}). Chaque lecture et chaque action sont journalisées.`
          : "Votre habilitation « consulter la finance » permet la lecture et le téléchargement ; le dépôt, le remplacement, la validation, le refus et la suppression sont réservés au propriétaire et à l'habilitation « gérer la finance ». Toute tentative d'action est refusée côté serveur."}
      </Notice>

      {doc ? (
        <div className="grid gap-5 lg:grid-cols-[1fr_360px]">
          <Panel>
            <PanelHeader
              title="RIB courant"
              description={`Version ${doc.version}, déposée le ${fmtDateTime(doc.createdAt)}.`}
              actions={
                <>
                  <StatusBadge status={doc.status} />
                  <DownloadButton action={ribDownloadLinkAction} fields={{ orgId }} label="Télécharger" />
                </>
              }
            />
            <div className="p-5">
              <KeyValue
                items={[
                  { k: "Titulaire", v: details.holder ?? "-" },
                  { k: "IBAN", v: <span className="num">{details.ibanMasked ?? "-"}</span> },
                  { k: "BIC", v: <span className="num">{details.bic ?? "-"}</span> },
                  { k: "Fichier", v: <span className="num">{doc.fileName} · {fmtBytes(doc.sizeBytes)}</span> },
                  { k: "Validé", v: doc.validatedAt ? fmtDateTime(doc.validatedAt) : <span className="text-ink-3">Non validé</span> },
                  { k: "Visibilité", v: <Badge tone="warn">Confidentiel</Badge> },
                ]}
              />
              {doc.status === "invalide" && refusal ? (
                <Notice tone="danger" className="mt-4" title="RIB refusé">
                  {refusal.reason} ({fmtDateTime(new Date(refusal.at))}). Déposez un nouveau fichier.
                </Notice>
              ) : null}
            </div>
          </Panel>
          <div className="space-y-5">
            <Panel>
              <PanelHeader title="Contrôle" description="Validation après vérification du fichier et de l'IBAN ; refus motivé ; suppression définitive (fichier et coordonnées)." />
              <div className="space-y-3 p-5">
                {manage ? (
                  <>
                    {doc.status !== "valide" ? <ActionButton action={validateRibAction} fields={{ orgId }} label="Valider le RIB" variant="primary" confirm={{ title: "Valider le RIB central", description: "Confirme que le fichier et l'IBAN ont été vérifiés." }} /> : <p className="text-[13px] text-ok-ink">RIB validé.</p>}
                    {doc.status !== "invalide" ? <ActionButton action={refuseRibAction} fields={{ orgId }} label="Refuser" variant="secondary" confirm={{ title: "Refuser le RIB", description: "Le RIB passe en « invalidé » ; un nouveau dépôt sera nécessaire.", input: { name: "reason", label: "Motif du refus" }, confirmLabel: "Refuser" }} /> : null}
                    <ActionButton action={deleteRibAction} fields={{ orgId }} label="Supprimer" variant="danger" confirm={{ title: "Supprimer le RIB central", description: "Le fichier et les coordonnées bancaires sont supprimés définitivement ; l'historique d'audit est conservé.", phrase: "SUPPRIMER", confirmLabel: "Supprimer définitivement", danger: true }} />
                  </>
                ) : (
                  <p className="text-[13px] text-ink-3">Actions réservées au propriétaire ou à « gérer la finance ».</p>
                )}
              </div>
            </Panel>
          </div>
        </div>
      ) : (
        <Panel>
          <EmptyState title="Aucun RIB central" description={manage ? "Déposez le RIB de l'organisme : il sera disponible sur les factures et conventions après validation." : "Aucun RIB n'a été déposé par un gestionnaire."} action={uploadDialog ?? undefined} />
        </Panel>
      )}

      {history.length > 1 ? (
        <Panel className="mt-5">
          <PanelHeader title="Historique" description="Versions précédentes (archivées) : conservées, jamais supprimées silencieusement." />
          <Table>
            <thead>
              <tr>
                <Th num>Version</Th>
                <Th>Statut</Th>
                <Th>Fichier</Th>
                <Th>Déposé</Th>
              </tr>
            </thead>
            <tbody>
              {history.map((h) => (
                <tr key={h.id}>
                  <Td num>v{h.version}</Td>
                  <Td>
                    <StatusBadge status={h.status} />
                  </Td>
                  <Td className="num text-[12px]">{h.fileName}</Td>
                  <Td className="whitespace-nowrap text-[12.5px]">{fmtDateTime(h.createdAt)}</Td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Panel>
      ) : null}
    </FadeIn>
  );
}
