import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Logo } from "@/components/ui/logo";

export default function NotFound() {
  return (
    <main className="flex min-h-[100dvh] flex-col items-start justify-center gap-6 bg-bg px-5 text-ink sm:px-16">
      <Link href="/" aria-label="Next Formation">
        <Logo />
      </Link>
      <p className="etiquette mt-10">Erreur 404</p>
      <h1 className="titre-geant text-[44px] sm:text-[72px]">Page introuvable.</h1>
      <p className="max-w-[52ch] font-serif text-[22px] italic text-ink-2">
        Cette adresse n&apos;existe pas, ou votre rôle n&apos;ouvre pas le dossier, la session ou la page qu&apos;elle désigne.
      </p>
      <div className="flex flex-wrap gap-3">
        <Button asChild>
          <Link href="/app">Mon espace</Link>
        </Button>
        <Button asChild variant="secondary">
          <Link href="/">Accueil</Link>
        </Button>
        <Button asChild variant="ghost">
          <Link href="/demo">Démonstration</Link>
        </Button>
      </div>
    </main>
  );
}
