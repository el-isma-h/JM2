import { NextResponse } from "next/server";
import { requireOrg } from "@/server/authz";
import { loadOrgSignature } from "@/server/documents/brand";
import { imageKind } from "@/server/documents/pdf";

/** Image de signature du signataire (stockage privé) : lecture réservée aux membres avec org.view. */
export async function GET(_req: Request, { params }: { params: Promise<{ orgId: string }> }) {
  const { orgId } = await params;
  let ctx;
  try {
    ctx = await requireOrg(orgId, "org.view");
  } catch {
    return new NextResponse("Accès refusé.", { status: 403 });
  }
  const img = await loadOrgSignature(ctx.org);
  const kind = imageKind(img);
  if (!img || !kind) return new NextResponse("Aucune signature.", { status: 404 });
  return new NextResponse(new Uint8Array(img), { headers: { "Content-Type": kind === "png" ? "image/png" : "image/jpeg", "Cache-Control": "private, no-store" } });
}
