import Link from "next/link";
import { notFound } from "next/navigation";
import { and, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { TEMPLATE_VARIABLES, type TemplateQuestion } from "@/server/documents/templates-data";
import { CATEGORY_LABELS } from "@/server/documents/queries";
import { updateTemplateAction } from "@/server/actions/documents";
import { ActionForm } from "@/components/admin/action-form";
import { TemplateEditor } from "@/components/documents/template-editor";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/field";
import { Notice, PageHeader, Panel } from "@/components/ui/surface";
import { FadeIn } from "@/components/ui/motion";

export const dynamic = "force-dynamic";

export default async function TemplateEditPage({ params }: { params: Promise<{ orgId: string; templateId: string }> }) {
  const { orgId, templateId } = await params;
  const base = `/app/${orgId}/documents`;
  const ctx = await guardOrg(orgId, `${base}/modeles/${templateId}`, "documents.generate");
  if (ctx.trainerOnly || !/^[0-9a-f-]{36}$/i.test(templateId)) notFound();
  const [t] = await db.select().from(schema.documentTemplates).where(and(eq(schema.documentTemplates.id, templateId), eq(schema.documentTemplates.orgId, orgId))).limit(1);
  if (!t) notFound();
  const questions = (t.questions as TemplateQuestion[]) ?? [];
  return (
    <FadeIn>
      <PageHeader
        breadcrumb={[{ label: "Documents", href: base }, { label: "Modèles", href: `${base}/modeles` }, { label: t.title }]}
        title={t.title}
        description={`${CATEGORY_LABELS[t.category]} · code ${t.code} · version ${t.version}. Modèle propre à l'organisme : il remplace le modèle plateforme de même code.`}
        actions={
          <Button asChild variant="secondary">
            <Link href={`${base}/modeles`}>Retour aux modèles</Link>
          </Button>
        }
      />
      <Notice tone="info" className="mb-4">
        Les mentions légales du modèle plateforme ont été relues ; toute modification engage l&apos;organisme. Une variable inconnue produit un marqueur « À COMPLÉTER » plutôt qu&apos;une valeur inventée.
        {questions.length ? ` Questions posées à la génération : ${questions.map((q) => `${q.label} ({{answers.${q.key}}})`).join(", ")}.` : ""}
      </Notice>
      <Panel className="p-5">
        <ActionForm action={updateTemplateAction} submitLabel="Enregistrer le modèle" className="space-y-5" footerClassName="mt-5">
          <input type="hidden" name="orgId" value={orgId} />
          <input type="hidden" name="templateId" value={t.id} />
          <div className="grid gap-4 md:grid-cols-2">
            <Field label="Titre" required htmlFor="title">
              <Input id="title" name="title" defaultValue={t.title} required />
            </Field>
            <Field label="Description" htmlFor="description">
              <Input id="description" name="description" defaultValue={t.description ?? ""} />
            </Field>
          </div>
          <TemplateEditor defaultBody={t.body} variables={TEMPLATE_VARIABLES} questionKeys={questions.map((q) => q.key)} />
        </ActionForm>
      </Panel>
    </FadeIn>
  );
}
