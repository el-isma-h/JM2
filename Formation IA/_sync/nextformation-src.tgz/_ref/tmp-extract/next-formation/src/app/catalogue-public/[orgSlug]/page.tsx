import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { loadPublicCatalogue } from "@/server/catalog/public";
import { publicInfoRequestAction } from "@/server/actions/crm";
import { fmtDate } from "@/lib/dates";
import { formatCents } from "@/lib/money";
import { ActionForm } from "@/components/admin/action-form";
import { Checkbox, Field, Input, Select, Textarea } from "@/components/ui/field";
import { modalityLabels, programKindLabels } from "@/components/catalog/fields";
import { jsonLdScript } from "@/lib/seo";
import { appUrl } from "@/lib/env";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ orgSlug: string }> }): Promise<Metadata> {
  const { orgSlug } = await params;
  const data = await loadPublicCatalogue(orgSlug);
  if (!data) return { title: "Catalogue introuvable", robots: { index: false } };
  const name = data.org.tradeName ?? data.org.legalName;
  return { title: `Catalogue des formations · ${name}`, description: `Formations proposées par ${name} : programmes, durées, modalités et sessions à venir.`, alternates: { canonical: `/catalogue-public/${orgSlug}` }, openGraph: { type: "website", title: `Catalogue des formations · ${name}`, url: `/catalogue-public/${orgSlug}` }, robots: { index: !data.org.isDemo, follow: true } };
}

const sessionKindLabels: Record<string, string> = { inter: "Inter-entreprises", intra: "Intra-entreprise", cycle: "Cycle", individuel: "Individuel" };

/** Catalogue public d'un organisme (sans session) : identité et charte de l'organisme, programmes publiés, sessions à venir, demande d'information. */
export default async function PublicCataloguePage({ params, searchParams }: { params: Promise<{ orgSlug: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgSlug } = await params;
  const data = await loadPublicCatalogue(orgSlug);
  if (!data) notFound();
  const { org, items } = data;
  const sp = await searchParams;
  const preselect = typeof sp.formation === "string" ? sp.formation : "";
  const name = org.tradeName ?? org.legalName;
  const accent = /^#[0-9a-f]{6}$/i.test(org.primaryColor) ? org.primaryColor : "#4b2a7f";
  const secondary = /^#[0-9a-f]{6}$/i.test(org.secondaryColor) ? org.secondaryColor : "#0a0b0d";

  const provider = { "@type": "EducationalOrganization", name, ...(org.website ? { url: org.website } : {}), ...(org.city ? { address: { "@type": "PostalAddress", addressLocality: org.city, addressCountry: org.country ?? "FR" } } : {}) };
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "ItemList",
    name: `Catalogue des formations · ${name}`,
    url: `${appUrl()}/catalogue-public/${orgSlug}`,
    numberOfItems: items.length,
    itemListElement: items.map((it, i) => ({
      "@type": "ListItem",
      position: i + 1,
      item: { "@type": "Course", name: it.program.title, description: (it.version?.content ?? it.version?.objectives ?? it.program.title).slice(0, 300), provider, ...(it.certification ? { educationalCredentialAwarded: it.certification.title } : {}) },
    })),
  };

  return (
    <div className="min-h-[100dvh] bg-bg text-ink" style={{ ["--accent" as string]: accent, ["--accent-strong" as string]: secondary }}>
      <script type="application/ld+json" dangerouslySetInnerHTML={jsonLdScript(jsonLd)} />
      <header className="border-b border-line">
        <div className="mx-auto flex max-w-[1080px] flex-wrap items-end justify-between gap-6 px-5 py-10">
          <div>
            <p className="font-mono text-[10px] uppercase tracking-[0.24em]" style={{ color: accent }}>
              Catalogue des formations
            </p>
            <h1 className="mt-3 text-[32px] sm:text-[40px]">{name}</h1>
            <p className="mt-3 max-w-[60ch] text-[14px] text-ink-2">
              {[org.city ? `${org.kind === "cfa" ? "CFA" : org.kind === "of_cfa" ? "Organisme de formation et CFA" : "Organisme de formation"} à ${org.city}` : null, org.nda ? `Déclaration d'activité n° ${org.nda}` : null, org.qualiopiNumber ? `Certifié Qualiopi n° ${org.qualiopiNumber}` : null].filter(Boolean).join(" · ")}
            </p>
          </div>
          <div className="text-right text-[13px] text-ink-2">
            {org.phone ? <p className="num">{org.phone}</p> : null}
            {org.email ? <p>{org.email}</p> : null}
            {org.website ? (
              <p>
                <a href={org.website} className="underline-offset-4 hover:underline" rel="noreferrer">
                  {org.website.replace(/^https?:\/\//, "")}
                </a>
              </p>
            ) : null}
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-[1080px] px-5 py-10">
        {org.isDemo ? <p className="mb-8 border border-warn/70 px-4 py-3 text-[13px] text-warn-ink">Espace de démonstration : organisme et formations fictifs.</p> : null}
        {items.length ? (
          <ol className="space-y-6">
            {items.map(({ program, version, certification, sessions }) => (
              <li key={program.id} id={program.slug} className="border border-line bg-bg-elev">
                <div className="flex flex-wrap items-start justify-between gap-4 border-b border-line px-6 py-5">
                  <div className="min-w-0">
                    <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">
                      {programKindLabels[program.kind]}
                      {certification ? ` · ${certification.rncpCode ? `RNCP ${certification.rncpCode}` : certification.rsCode ? `RS ${certification.rsCode}` : certification.title}` : ""}
                      {program.cpfEligible ? " · éligible CPF" : ""}
                    </p>
                    <h2 className="mt-2 text-[22px]">{program.title}</h2>
                  </div>
                  {version ? (
                    <dl className="grid grid-cols-2 gap-x-6 gap-y-1 text-[13px] sm:grid-cols-3">
                      <dt className="font-mono text-[10px] uppercase tracking-[0.18em] text-ink-3">Durée</dt>
                      <dt className="font-mono text-[10px] uppercase tracking-[0.18em] text-ink-3">Modalité</dt>
                      <dt className="hidden font-mono text-[10px] uppercase tracking-[0.18em] text-ink-3 sm:block">Tarif HT</dt>
                      <dd className="num">
                        {version.durationHours} h{version.durationDays ? ` (${version.durationDays} j)` : ""}
                      </dd>
                      <dd>{modalityLabels[version.modality] ?? version.modality}</dd>
                      <dd className="num hidden sm:block">{version.priceCents != null ? formatCents(version.priceCents) : "Sur devis"}</dd>
                    </dl>
                  ) : null}
                </div>
                {version ? (
                  <div className="grid gap-6 px-6 py-5 text-[13.5px] md:grid-cols-2">
                    {(
                      [
                        ["Objectifs", version.objectives],
                        ["Public et prérequis", [version.audience, version.prerequisites].filter(Boolean).join("\n")],
                        ["Contenu", version.content],
                        ["Méthodes et évaluation", [version.methods, version.evaluationMethods].filter(Boolean).join("\n")],
                        ["Accessibilité", version.accessibility],
                        ["Délai d'accès", version.accessDelay],
                      ] as [string, string | null][]
                    )
                      .filter(([, v]) => v)
                      .map(([k, v]) => (
                        <div key={k}>
                          <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">{k}</p>
                          <p className="mt-1.5 whitespace-pre-line text-ink-2">{v}</p>
                        </div>
                      ))}
                  </div>
                ) : null}
                <div className="border-t border-line px-6 py-4">
                  <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">Prochaines sessions</p>
                  {sessions.length ? (
                    <ul className="mt-2 divide-y divide-line">
                      {sessions.map((s) => (
                        <li key={s.id} className="flex flex-wrap items-center justify-between gap-3 py-2 text-[13.5px]">
                          <span>
                            <span className="num">
                              {fmtDate(s.startDate)} au {fmtDate(s.endDate)}
                            </span>
                            <span className="ml-3 text-ink-3">
                              {sessionKindLabels[s.kind] ?? s.kind} · {modalityLabels[s.modality] ?? s.modality}
                            </span>
                          </span>
                          <span className="num text-ink-2">{s.priceCents != null ? `${formatCents(s.priceCents)} HT` : ""}</span>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="mt-1.5 text-[13.5px] text-ink-2">Dates à la demande : contactez-nous via le formulaire ci-dessous.</p>
                  )}
                  <Link href={`?formation=${program.id}#demande`} className="mt-3 inline-block font-sans text-[11px] font-medium uppercase tracking-[0.18em] underline-offset-4 hover:underline" style={{ color: accent }}>
                    Demander des informations
                  </Link>
                </div>
              </li>
            ))}
          </ol>
        ) : (
          <p className="border border-line px-6 py-12 text-center text-[14px] text-ink-2">Aucune formation publiée pour le moment.</p>
        )}

        <section id="demande" className="mt-12 border border-line bg-bg-elev">
          <div className="border-b border-line px-6 py-5">
            <h2 className="text-[20px]">Demande d&apos;information</h2>
            <p className="mt-1 text-[13px] text-ink-2">Un conseiller de {name} vous recontacte. Aucune inscription n&apos;est engagée par cette demande.</p>
          </div>
          <div className="px-6 py-5">
            <ActionForm action={publicInfoRequestAction} submitLabel="Envoyer la demande" className="space-y-4" footerClassName="pt-2">
              <input type="hidden" name="orgId" value={org.id} />
              <input type="text" name="website_url" tabIndex={-1} autoComplete="off" className="hidden" aria-hidden />
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Prénom" required htmlFor="pub-fn">
                  <Input id="pub-fn" name="firstName" required />
                </Field>
                <Field label="Nom" required htmlFor="pub-ln">
                  <Input id="pub-ln" name="lastName" required />
                </Field>
                <Field label="E-mail" required htmlFor="pub-email">
                  <Input id="pub-email" name="email" type="email" required />
                </Field>
                <Field label="Téléphone" htmlFor="pub-phone">
                  <Input id="pub-phone" name="phone" />
                </Field>
                <Field label="Entreprise" htmlFor="pub-company" help="Laissez vide si vous êtes un particulier.">
                  <Input id="pub-company" name="company" />
                </Field>
                <Field label="Formation" htmlFor="pub-program">
                  <Select id="pub-program" name="programId" defaultValue={preselect}>
                    <option value="">Je ne sais pas encore</option>
                    {items.map(({ program }) => (
                      <option key={program.id} value={program.id}>
                        {program.title}
                      </option>
                    ))}
                  </Select>
                </Field>
              </div>
              <Field label="Votre message" htmlFor="pub-msg">
                <Textarea id="pub-msg" name="message" rows={3} />
              </Field>
              <Checkbox name="consent" required label={`J'accepte que ${name} traite ces informations pour répondre à ma demande.`} />
            </ActionForm>
          </div>
        </section>
      </main>
      <footer className="border-t border-line">
        <div className="mx-auto flex max-w-[1080px] flex-wrap items-center justify-between gap-3 px-5 py-6 font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">
          <span>
            {org.legalName}
            {org.siret ? ` · SIRET ${org.siret}` : ""}
          </span>
          <span>
            Catalogue propulsé par{" "}
            <Link href="/" className="hover:text-ink">
              Next Formation
            </Link>
          </span>
        </div>
      </footer>
    </div>
  );
}
