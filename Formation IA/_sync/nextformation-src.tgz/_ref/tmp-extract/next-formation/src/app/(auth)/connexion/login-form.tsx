"use client";

import Link from "next/link";
import { useActionState } from "react";
import { loginAction, type ActionState } from "@/server/actions/auth";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/field";
import { Notice } from "@/components/ui/surface";

export function LoginForm({ next, resetDone }: { next?: string; resetDone?: boolean }) {
  const [state, action, pending] = useActionState<ActionState, FormData>(loginAction, {});
  const needCode = state.data?.needCode === "1";
  return (
    <form action={action} className="mt-6 space-y-4">
      {next ? <input type="hidden" name="next" value={next} /> : null}
      {resetDone ? <Notice tone="ok">Mot de passe modifié. Connectez-vous avec le nouveau.</Notice> : null}
      <Field label="Adresse e-mail" htmlFor="email" required>
        <Input id="email" name="email" type="email" autoComplete="email" required readOnly={needCode} />
      </Field>
      <Field label="Mot de passe" htmlFor="password" required>
        <Input id="password" name="password" type="password" autoComplete="current-password" required readOnly={needCode} />
      </Field>
      {needCode ? (
        <Field label="Code de vérification" htmlFor="code" help="Code à 6 chiffres de votre application d'authentification, ou un code de secours." required>
          <Input id="code" name="code" inputMode="numeric" autoComplete="one-time-code" autoFocus required className="num" />
        </Field>
      ) : null}
      {state.error ? <Notice tone="danger">{state.error}</Notice> : null}
      <Button type="submit" size="lg" className="w-full" loading={pending}>
        {needCode ? "Vérifier et se connecter" : "Se connecter"}
      </Button>
      <p className="text-center text-[13px]">
        <Link href="/mot-de-passe-oublie" className="text-ink-2 hover:text-ink hover:underline">
          Mot de passe oublié ?
        </Link>
      </p>
    </form>
  );
}
