import Link from "next/link";
import { notFound } from "next/navigation";
import { and, desc, eq, inArray, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg, handleAuthError } from "@/server/guard";
import { trainerSessionIds } from "@/server/authz";
import { AuthError } from "@/server/auth";
import { contractKindLabels } from "@/server/enrollments/rules";
import { fmtDate, fmtDateTime } from "@/lib/dates";
import { ActionButton } from "@/components/admin/action-form";
import { FormDialog } from "@/components/admin/form-dialog";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/field";
import { EmptyState, KeyValue, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FadeIn } from "@/components/ui/motion";
import { anonymizePersonAction, inviteLearnerAction } from "@/server/actions/enrollments";

export const dynamic = "force-dynamic";

export default async function LearnerPage({ params }: { params: Promise<{ orgId: string; personId: string }> }) {
  const { orgId, personId } = await params;
  const path = `/app/${orgId}/apprenants/${personId}`;
  const ctx = await guardOrg(orgId, path, "org.view");
  if (!ctx.permissions.has("enrollments.view") && !(ctx.trainerOnly && ctx.permissions.has("dossier.pedagogy.view"))) notFound();
  if (!/^[0-9a-f-]{36}$/i.test(personId)) notFound();
  const [p] = await db.select().from(schema.persons).where(and(eq(schema.persons.id, personId), eq(schema.persons.orgId, orgId))).limit(1);
  if (!p) notFound();
  const scope = await trainerSessionIds(ctx);
  const enrollments = await db
    .select({ e: schema.enrollments, s: schema.trainingSessions, programTitle: schema.programs.title, version: schema.programVersions.version, companyName: schema.companies.name })
    .from(schema.enrollments)
    .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.enrollments.sessionId))
    .leftJoin(schema.programVersions, eq(schema.programVersions.id, schema.enrollments.programVersionId))
    .leftJoin(schema.programs, eq(schema.programs.id, schema.programVersions.programId))
    .leftJoin(schema.companies, eq(schema.companies.id, schema.enrollments.companyId))
    .where(and(eq(schema.enrollments.orgId, orgId), eq(schema.enrollments.personId, p.id), scope ? (scope.length ? inArray(schema.enrollments.sessionId, scope) : sql`false`) : sql`true`))
    .orderBy(desc(schema.enrollments.startDate));
  // Formateur seul : la fiche n'est visible que si l'une de ses sessions concerne cette personne.
  if (ctx.trainerOnly && !enrollments.length) handleAuthError(new AuthError("forbidden"), path);
  const docs = ctx.trainerOnly
    ? []
    : (await db.select().from(schema.documents).where(and(eq(schema.documents.orgId, orgId), eq(schema.documents.personId, p.id))).orderBy(desc(schema.documents.createdAt)).limit(100)).filter((d) => ctx.permissions.has("candidates.cv.view") || d.category !== "cv");
  const [employer] = p.companyId ? await db.select({ id: schema.companies.id, name: schema.companies.name }).from(schema.companies).where(eq(schema.companies.id, p.companyId)).limit(1) : [null];
  const canManage = ctx.permissions.has("enrollments.manage") && !ctx.trainerOnly;
  const canAnonymize = (ctx.isOwner || ctx.roles.includes("direction")) && !ctx.trainerOnly;
  const anonymized = Boolean(p.anonymizedAt);
  const hasActive = enrollments.some((x) => ["preinscrit", "inscrit", "en_cours"].includes(x.e.status));

  return (
    <FadeIn>
      <PageHeader
        title={`${p.lastName.toUpperCase()} ${p.firstName}`}
        breadcrumb={[{ label: "Apprenants", href: `/app/${orgId}/apprenants` }, { label: p.firstName }]}
        description={
          <span className="flex flex-wrap items-center gap-2">
            <StatusBadge status={anonymized ? "inactif" : p.status} />
            {anonymized ? <Badge tone="neutral">Anonymisée le {fmtDate(p.anonymizedAt)}</Badge> : null}
            {p.userId ? <Badge tone="ok">Espace apprenant actif</Badge> : null}
            <span>
              {enrollments.length} inscription(s){employer ? ` · ${employer.name}` : ""}
            </span>
          </span>
        }
        actions={
          canManage && !anonymized ? (
            <>
              <Button asChild>
                <Link href={`/app/${orgId}/inscriptions/nouvelle?personId=${p.id}`}>Nouvelle inscription</Link>
              </Button>
              {!p.userId ? (
                <FormDialog action={inviteLearnerAction} trigger="Inviter à l'espace apprenant" triggerVariant="secondary" title="Inviter à l'espace apprenant" description="Un lien d'activation valable 7 jours est envoyé ; le compte sera rattaché à cette fiche (rôle apprenant)." submitLabel="Envoyer l'invitation">
                  <input type="hidden" name="orgId" value={orgId} />
                  <input type="hidden" name="personId" value={p.id} />
                  <Field label="Adresse e-mail" required htmlFor="inv-email" help={p.email ? undefined : "Aucun e-mail sur la fiche : il sera enregistré."}>
                    <Input id="inv-email" name="email" type="email" required defaultValue={p.email ?? ""} />
                  </Field>
                </FormDialog>
              ) : null}
            </>
          ) : null
        }
      />
      {anonymized ? <Notice tone="info" className="mb-5">Données nominatives remplacées (RGPD). Les heures, les inscriptions et les documents financiers sont conservés.</Notice> : null}

      <div className="grid gap-6 lg:grid-cols-[2fr_1fr]">
        <div className="space-y-6">
          <Panel>
            <PanelHeader title="Inscriptions" description="Chaque inscription garde ses statuts, ses heures et ses pièces propres." />
            {enrollments.length ? (
              <Table>
                <thead>
                  <tr>
                    <Th>Référence</Th>
                    <Th>Session</Th>
                    <Th>Contrat</Th>
                    <Th>Dates</Th>
                    <Th>Inscription</Th>
                    <Th>Progression</Th>
                    <Th>Financement</Th>
                    <Th>Examen</Th>
                  </tr>
                </thead>
                <tbody>
                  {enrollments.map(({ e, s, programTitle, version, companyName }) => (
                    <tr key={e.id}>
                      <Td className="num">
                        <Link href={`/app/${orgId}/inscriptions/${e.id}`} className="font-medium hover:underline">
                          {e.reference}
                        </Link>
                      </Td>
                      <Td>
                        <Link href={`/app/${orgId}/sessions/${s.id}`} className="hover:underline">
                          {s.title}
                        </Link>
                        <p className="text-[12px] text-ink-3">
                          {programTitle ?? "-"}
                          {version ? ` v${version}` : ""}
                          {companyName ? ` · ${companyName}` : ""}
                        </p>
                      </Td>
                      <Td>{contractKindLabels[e.contractKind]}</Td>
                      <Td className="num whitespace-nowrap">
                        {fmtDate(e.startDate)} au {fmtDate(e.endDate)}
                      </Td>
                      <Td>
                        <StatusBadge status={e.status} />
                      </Td>
                      <Td>
                        <StatusBadge status={e.progression} />
                      </Td>
                      <Td>
                        <StatusBadge status={e.fundingState} />
                      </Td>
                      <Td>
                        <StatusBadge status={e.examState} />
                      </Td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            ) : (
              <EmptyState title="Aucune inscription" />
            )}
          </Panel>
          {!ctx.trainerOnly ? (
            <Panel>
              <PanelHeader title="Documents" description="Documents rattachés à la personne (hors documents d'inscription)." actions={<Button asChild variant="secondary" size="sm"><Link href={`/app/${orgId}/documents?person=${p.id}`}>Tous les documents</Link></Button>} />
              {docs.length ? (
                <Table>
                  <thead>
                    <tr>
                      <Th>Document</Th>
                      <Th>Catégorie</Th>
                      <Th>Statut</Th>
                      <Th>Date</Th>
                    </tr>
                  </thead>
                  <tbody>
                    {docs.map((d) => (
                      <tr key={d.id}>
                        <Td>
                          <Link href={`/app/${orgId}/documents/${d.id}`} className="font-medium hover:underline">
                            {d.title}
                          </Link>
                        </Td>
                        <Td>{d.category}</Td>
                        <Td>
                          <StatusBadge status={d.status} />
                        </Td>
                        <Td className="whitespace-nowrap">{fmtDate(d.createdAt)}</Td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
              ) : (
                <EmptyState title="Aucun document" />
              )}
            </Panel>
          ) : null}
        </div>
        <div className="space-y-6">
          <Panel>
            <PanelHeader title="Identité et contact" />
            <div className="p-5">
              <KeyValue
                items={[
                  { k: "Civilité", v: p.civility ?? "-" },
                  { k: "Naissance", v: p.birthDate ? `${fmtDate(p.birthDate)}${p.birthPlace ? ` à ${p.birthPlace}` : ""}` : "-" },
                  { k: "E-mail", v: p.email ?? "-" },
                  { k: "Téléphone", v: p.phone ?? "-" },
                  { k: "Adresse", v: [p.addressLine1, p.addressLine2, p.postalCode, p.city].filter(Boolean).join(", ") || "-" },
                  { k: "Employeur", v: employer ? <Link href={`/app/${orgId}/entreprises/${employer.id}`} className="hover:underline">{employer.name}</Link> : "-" },
                  { k: "Niveau", v: p.educationLevel ?? "-" },
                  { k: "Situation", v: p.situation ?? "-" },
                  { k: "Aménagements", v: p.hasAccommodations ? (ctx.permissions.has("dossier.internal.view") || ctx.permissions.has("dossier.pedagogy.view") ? p.accommodations ?? "Oui" : "Oui (détail réservé)") : "Aucun déclaré" },
                  { k: "Fiche créée", v: fmtDateTime(p.createdAt) },
                ]}
              />
              {ctx.permissions.has("crm.view") && !ctx.trainerOnly ? (
                <p className="mt-4 text-[12.5px]">
                  <Link href={`/app/${orgId}/candidats/${p.id}`} className="text-accent hover:underline">
                    Fiche candidat (CV, notes de recrutement)
                  </Link>
                </p>
              ) : null}
            </div>
          </Panel>
          {canAnonymize && !anonymized ? (
            <Panel>
              <PanelHeader title="Protection des données" description="Anonymisation RGPD (T04) : remplace les données nominatives par « Anonymisé », supprime les notes et archive les pièces personnelles. Les heures, les inscriptions et les documents financiers sont conservés." />
              <div className="p-5">
                {hasActive ? <Notice tone="warn" className="mb-3">Une inscription active empêche l&apos;anonymisation : clôturez-la d&apos;abord.</Notice> : null}
                <ActionButton action={anonymizePersonAction} fields={{ orgId, personId: p.id }} label="Anonymiser cette personne" variant="danger" confirm={{ title: "Anonymiser définitivement", description: "Irréversible. Les données nominatives sont remplacées ; les heures et documents financiers restent attachés aux inscriptions.", phrase: "ANONYMISER", checkbox: { name: "understood", label: "Je confirme que la durée de conservation est atteinte ou que la demande de la personne est légitime." }, danger: true, confirmLabel: "Anonymiser" }} />
              </div>
            </Panel>
          ) : null}
        </div>
      </div>
    </FadeIn>
  );
}
