import Link from "next/link";
import { and, desc, eq, ilike, or, sql, type SQL } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { isOverdue } from "@/server/crm/queries";
import { todayParis } from "@/lib/time";
import { fmtDate } from "@/lib/dates";
import { formatCents } from "@/lib/money";
import { StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/field";
import { EmptyState, PageHeader, Panel, Stat } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { Pagination, readPage, readParam } from "@/components/admin/pagination";

export const dynamic = "force-dynamic";
const PAGE = 50;
const STATUS_LABELS: Record<string, string> = { brouillon: "Brouillon", envoye: "Envoyé", accepte: "Accepté", refuse: "Refusé", expire: "Expiré" };

export default async function QuotesPage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const base = `/app/${orgId}`;
  const ctx = await guardOrg(orgId, `${base}/devis`, "crm.view");
  const sp = await searchParams;
  const q = readParam(sp.q);
  const status = readParam(sp.status);
  const page = readPage(sp.page);
  const today = todayParis();

  const conds: SQL[] = [eq(schema.quotes.orgId, ctx.org.id)];
  if (status && (schema.quoteStatusEnum.enumValues as readonly string[]).includes(status)) conds.push(eq(schema.quotes.status, status as "brouillon"));
  if (q) conds.push(or(ilike(schema.quotes.number, `%${q}%`), ilike(schema.quotes.title, `%${q}%`), ilike(schema.companies.name, `%${q}%`), ilike(schema.persons.lastName, `%${q}%`))!);
  const where = and(...conds);
  const from = () => db.select({ q: schema.quotes, companyName: schema.companies.name, personFirst: schema.persons.firstName, personLast: schema.persons.lastName }).from(schema.quotes).leftJoin(schema.companies, eq(schema.companies.id, schema.quotes.companyId)).leftJoin(schema.persons, eq(schema.persons.id, schema.quotes.personId));

  const [rows, [{ total }], stats] = await Promise.all([
    from().where(where).orderBy(desc(schema.quotes.issueDate), desc(schema.quotes.createdAt)).limit(PAGE).offset((page - 1) * PAGE),
    db.select({ total: sql<number>`count(*)::int` }).from(schema.quotes).leftJoin(schema.companies, eq(schema.companies.id, schema.quotes.companyId)).leftJoin(schema.persons, eq(schema.persons.id, schema.quotes.personId)).where(where),
    db
      .select({ status: schema.quotes.status, n: sql<number>`count(*)::int`, sum: sql<number>`coalesce(sum(total_ht_cents),0)::int` })
      .from(schema.quotes)
      .where(eq(schema.quotes.orgId, ctx.org.id))
      .groupBy(schema.quotes.status),
  ]);
  const stat = (s: string) => stats.find((x) => x.status === s) ?? { n: 0, sum: 0 };
  const canManage = ctx.permissions.has("crm.manage");

  return (
    <>
      <PageHeader
        title="Devis"
        description="Propositions commerciales numérotées par organisme. Un devis accepté fait passer son besoin en « gagné »."
        actions={
          canManage ? (
            <Button asChild>
              <Link href={`${base}/devis/nouveau`}>Nouveau devis</Link>
            </Button>
          ) : null
        }
      />
      <Panel className="mb-6 grid gap-6 p-5 sm:grid-cols-3">
        <Stat label="En attente de réponse" value={<span className="num">{formatCents(stat("envoye").sum)}</span>} hint={`${stat("envoye").n} devis envoyé(s), HT`} />
        <Stat label="Acceptés" value={<span className="num">{formatCents(stat("accepte").sum)}</span>} hint={`${stat("accepte").n} devis, HT`} />
        <Stat label="Brouillons" value={<span className="num">{stat("brouillon").n}</span>} hint="à finaliser et envoyer" />
      </Panel>
      <Panel>
        <form method="get" className="flex flex-wrap items-end gap-3 border-b border-line px-5 py-3">
          <Field label="Recherche" htmlFor="q" className="w-full max-w-xs">
            <Input id="q" name="q" defaultValue={q} placeholder="Numéro, objet, entreprise" />
          </Field>
          <Field label="Statut" htmlFor="status" className="w-44">
            <Select id="status" name="status" defaultValue={status ?? ""}>
              <option value="">Tous</option>
              {Object.entries(STATUS_LABELS).map(([v, l]) => (
                <option key={v} value={v}>
                  {l}
                </option>
              ))}
            </Select>
          </Field>
          <Button type="submit" variant="secondary">
            Filtrer
          </Button>
        </form>
        {rows.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Numéro</Th>
                <Th>Objet</Th>
                <Th>Destinataire</Th>
                <Th>Statut</Th>
                <Th num>Total HT</Th>
                <Th num>Total TTC</Th>
                <Th>Émis le</Th>
                <Th>Validité</Th>
              </tr>
            </thead>
            <tbody>
              {rows.map(({ q: quote, companyName, personFirst, personLast }) => {
                const late = quote.status === "envoye" && isOverdue(quote.validUntil, today);
                return (
                  <tr key={quote.id}>
                    <Td>
                      <Link href={`${base}/devis/${quote.id}`} className="num font-medium text-ink hover:underline">
                        {quote.number}
                      </Link>
                    </Td>
                    <Td>{quote.title}</Td>
                    <Td>{companyName ?? (personFirst ? `${personFirst} ${personLast}` : "-")}</Td>
                    <Td>
                      <StatusBadge status={quote.status} />
                    </Td>
                    <Td num>{formatCents(quote.totalHtCents)}</Td>
                    <Td num>{formatCents(quote.totalTtcCents)}</Td>
                    <Td className="num whitespace-nowrap">{fmtDate(quote.issueDate)}</Td>
                    <Td className={`num whitespace-nowrap ${late ? "font-medium text-danger-ink" : ""}`}>
                      {quote.validUntil ? fmtDate(quote.validUntil) : "-"}
                      {late ? " (dépassée)" : ""}
                    </Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucun devis" description={q || status ? "Aucun résultat pour ces filtres." : "Créez un devis depuis un besoin, une fiche entreprise ou ici."} action={canManage ? <Button asChild variant="secondary"><Link href={`${base}/devis/nouveau`}>Nouveau devis</Link></Button> : undefined} />
        )}
        <Pagination basePath={`${base}/devis`} params={{ q, status }} page={page} pageSize={PAGE} total={total} />
      </Panel>
    </>
  );
}
