import { guardLearner } from "@/server/extranet/guard";
import { listSlotsForSessions } from "@/server/extranet/queries";
import { NoAttachment } from "@/components/extranet/shell";
import { SlotTable } from "@/components/extranet/ui";
import { PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { todayParis } from "@/lib/time";

export const dynamic = "force-dynamic";

export default async function LearnerPlanning() {
  const ctx = await guardLearner("/moi/planning");
  if (!ctx) return <NoAttachment kind="learner" />;
  const sessionIds = [...new Set(ctx.enrollments.map((e) => e.session.id))];
  const all = await listSlotsForSessions(ctx.org.id, sessionIds);
  const today = todayParis();
  const upcoming = all.filter((s) => s.slot.date >= today);
  const past = all.filter((s) => s.slot.date < today).reverse();
  return (
    <>
      <PageHeader title="Mon planning" description="Séances de vos sessions, par période (matin / après-midi). Les horaires sont ceux de l'organisme, heure de Paris." />
      <div className="space-y-6">
        <Panel>
          <PanelHeader title="Séances à venir" description={`${upcoming.length} séance${upcoming.length > 1 ? "s" : ""} planifiée${upcoming.length > 1 ? "s" : ""}`} />
          <SlotTable slots={upcoming} emptyTitle="Aucune séance à venir" emptyDescription="Le planning sera visible ici dès que l'organisme l'aura publié." />
        </Panel>
        <Panel>
          <PanelHeader title="Séances passées" />
          <SlotTable slots={past} emptyTitle="Aucune séance passée" emptyDescription="Votre formation n'a pas encore commencé." />
        </Panel>
      </div>
    </>
  );
}
