import { NextResponse, type NextRequest } from "next/server";
import { and, asc, eq, gte, sql, type SQL } from "drizzle-orm";
import { db, schema } from "@/db";
import { authenticateApiKey, readPagination } from "@/server/integrations/api-auth";

export const dynamic = "force-dynamic";

/** GET /api/v1/sessions?from=YYYY-MM-DD&status=ouverte : sessions de l'organisme (scope sessions.read). */
export async function GET(req: NextRequest) {
  const a = await authenticateApiKey(req, "sessions.read");
  if (!a.ok) return a.response;
  const { limit, offset } = readPagination(req);
  const sp = req.nextUrl.searchParams;
  const c: SQL[] = [eq(schema.trainingSessions.orgId, a.auth.orgId)];
  const from = sp.get("from");
  if (from && /^\d{4}-\d{2}-\d{2}$/.test(from)) c.push(gte(schema.trainingSessions.endDate, from));
  const status = sp.get("status");
  if (status && (schema.sessionStatusEnum.enumValues as readonly string[]).includes(status)) c.push(eq(schema.trainingSessions.status, status as (typeof schema.sessionStatusEnum.enumValues)[number]));
  const where = and(...c);
  const [rows, [{ total }]] = await Promise.all([
    db
      .select({ id: schema.trainingSessions.id, code: schema.trainingSessions.code, title: schema.trainingSessions.title, kind: schema.trainingSessions.kind, status: schema.trainingSessions.status, startDate: schema.trainingSessions.startDate, endDate: schema.trainingSessions.endDate, modality: schema.trainingSessions.modality, capacity: schema.trainingSessions.capacity, isPublished: schema.trainingSessions.isPublished, programCode: schema.programs.code, programTitle: schema.programs.title, updatedAt: schema.trainingSessions.updatedAt })
      .from(schema.trainingSessions)
      .innerJoin(schema.programVersions, eq(schema.programVersions.id, schema.trainingSessions.programVersionId))
      .innerJoin(schema.programs, eq(schema.programs.id, schema.programVersions.programId))
      .where(where)
      .orderBy(asc(schema.trainingSessions.startDate))
      .limit(limit)
      .offset(offset),
    db.select({ total: sql<number>`count(*)::int` }).from(schema.trainingSessions).where(where),
  ]);
  return NextResponse.json({ data: rows, total, limit, offset }, { headers: { "Cache-Control": "no-store" } });
}
