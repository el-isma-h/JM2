import type { Metadata } from "next";
import { eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { getCurrentUser, peekToken } from "@/server/auth";
import { roleLabels } from "@/server/authz";
import { Notice } from "@/components/ui/surface";
import { InvitationForm } from "./form";

export const metadata: Metadata = { title: "Invitation" };

export default async function InvitationPage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  const row = await peekToken("invite", token);
  const payload = row?.payload as { invitationId?: string } | undefined;
  const [inv] = payload?.invitationId
    ? await db.select().from(schema.invitations).where(eq(schema.invitations.id, payload.invitationId)).limit(1)
    : [];
  const user = await getCurrentUser();
  if (!row || !inv || inv.status !== "pending") {
    return (
      <div>
        <h1 className="text-[30px] text-ink">Invitation</h1>
        <Notice tone="danger" className="mt-6">
          Cette invitation est invalide, expirée ou déjà utilisée.
        </Notice>
      </div>
    );
  }
  const [company] = inv.orgId ? await db.select().from(schema.organismes).where(eq(schema.organismes.id, inv.orgId)).limit(1) : [];
  return (
    <div>
      <h1 className="text-[30px] text-ink">Vous êtes invité</h1>
      <p className="mt-3 text-[14px] text-ink-2">
        Rejoignez <span className="font-medium text-ink">{company?.legalName ?? "l'organisation"}</span> avec le(s) rôle(s){" "}
        <span className="font-medium text-ink">{(Array.isArray(inv.roles) ? (inv.roles as string[]) : []).map((r) => roleLabels[r as keyof typeof roleLabels] ?? r).join(", ") || "membre"}</span>, pour l&apos;adresse {inv.email}.
      </p>
      <InvitationForm token={token} isLoggedIn={Boolean(user)} />
    </div>
  );
}
