import Link from "next/link";
import { notFound } from "next/navigation";
import { and, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { sendSurveyAction, setSurveyStatusAction, updateSurveyAction } from "@/server/actions/surveys";
import { surveyResponses } from "@/server/quality/queries";
import { responseRate, satisfactionRate } from "@/server/quality/indicators";
import { aggregateAnswers, parseQuestions, type SurveyAnswers } from "@/server/quality/indicator-math";
import { readAutomation } from "@/server/quality/jobs-rules";
import { formatQuestionLines, surveyTemplate } from "@/server/quality/survey-templates";
import { surveyKindLabels } from "@/server/quality/labels";
import { fmtDate, fmtDateTime } from "@/lib/dates";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox, Field, Input, Textarea } from "@/components/ui/field";
import { EmptyState, KeyValue, Notice, PageHeader, Panel, PanelHeader, Stat } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { ActionButton, ActionForm } from "@/components/admin/action-form";
import { FadeIn } from "@/components/ui/motion";
import { SurveyStatusBadge } from "@/components/quality/survey-badge";

export const dynamic = "force-dynamic";

export default async function SurveyPage({ params }: { params: Promise<{ orgId: string; surveyId: string }> }) {
  const { orgId, surveyId } = await params;
  const path = `/app/${orgId}/enquetes/${surveyId}`;
  const ctx = await guardOrg(orgId, path, "quality.view");
  if (!/^[0-9a-f-]{36}$/i.test(surveyId)) notFound();
  const [survey] = await db.select().from(schema.surveys).where(and(eq(schema.surveys.id, surveyId), eq(schema.surveys.orgId, ctx.org.id))).limit(1);
  if (!survey) notFound();
  const canManage = ctx.permissions.has("quality.manage");
  const questions = parseQuestions(survey.questions);
  const tpl = surveyTemplate(survey.kind);
  const auto = readAutomation(survey.automation);
  const [responses, session, satisfaction, retour] = await Promise.all([
    surveyResponses(ctx.org.id, survey.id),
    survey.sessionId ? db.select({ id: schema.trainingSessions.id, code: schema.trainingSessions.code, title: schema.trainingSessions.title, endDate: schema.trainingSessions.endDate }).from(schema.trainingSessions).where(eq(schema.trainingSessions.id, survey.sessionId)).limit(1).then((r) => r[0] ?? null) : null,
    satisfactionRate(ctx.org.id, { surveyId: survey.id }),
    responseRate(ctx.org.id, { surveyId: survey.id }),
  ]);
  const submitted = responses.filter((r) => r.r.submittedAt);
  const aggregates = aggregateAnswers(submitted.map((r) => r.r.answers as SurveyAnswers), questions);
  const lastSubmission = submitted[0]?.r.submittedAt ?? null;

  return (
    <FadeIn>
      <PageHeader
        breadcrumb={[{ label: "Enquêtes", href: `/app/${orgId}/enquetes` }, { label: surveyKindLabels[survey.kind] ?? survey.kind }]}
        title={survey.title}
        description={survey.description ?? tpl?.description}
        actions={
          canManage ? (
            <>
              {survey.status === "brouillon" ? <ActionButton action={setSurveyStatusAction} fields={{ orgId: ctx.org.id, surveyId: survey.id, status: "active" }} label="Activer" variant="primary" size="md" /> : null}
              {survey.status === "active" && survey.sessionId ? (
                <ActionButton action={sendSurveyAction} fields={{ orgId: ctx.org.id, surveyId: survey.id }} label="Envoyer aux inscrits" variant="primary" size="md" confirm={{ title: "Envoyer l'enquête", description: `Un lien personnel est émis pour chaque inscrit de la session non encore invité.${ctx.org.isDemo ? " En démonstration, aucun e-mail ne part : les liens seront affichés." : ""}`, confirmLabel: "Envoyer" }} />
              ) : null}
              {survey.status === "active" ? (
                <ActionButton action={setSurveyStatusAction} fields={{ orgId: ctx.org.id, surveyId: survey.id, status: "cloturee" }} label="Clôturer" variant="secondary" size="md" confirm={{ title: "Clôturer l'enquête", description: "Plus aucune réponse ne sera acceptée. Une enquête clôturée ne se rouvre pas.", confirmLabel: "Clôturer" }} />
              ) : null}
              {submitted.length ? (
                <Button asChild variant="secondary">
                  <a href={`${path}/export`}>Exporter les réponses (CSV)</a>
                </Button>
              ) : null}
            </>
          ) : null
        }
      />

      <div className="mb-6 grid gap-6 lg:grid-cols-3">
        <Panel className="lg:col-span-1">
          <PanelHeader title="Enquête" />
          <div className="px-5 py-4">
            <KeyValue
              items={[
                { k: "Statut", v: <SurveyStatusBadge status={survey.status} /> },
                { k: "Type", v: surveyKindLabels[survey.kind] ?? survey.kind },
                { k: "Session", v: session ? <Link href={`/app/${orgId}/sessions/${session.id}`} className="underline underline-offset-4">{session.code} : {session.title}</Link> : <Badge tone="neutral">Modèle d&apos;organisme</Badge> },
                { k: "Automatisation", v: auto.trigger === "session_end" ? `Fin de session + ${auto.delayDays} jour(s)` : auto.fromSurveyId ? "Créée par l'envoi automatique" : "Envoi manuel" },
                { k: "Preuve", v: `Chaque réponse reçue : ${(tpl?.qualiopiIndicator ?? "IND_30").replace("IND_", "indicateur ")}, niveau collectif (session)` },
              ]}
            />
          </div>
        </Panel>
        <Panel className="lg:col-span-2">
          <PanelHeader title="Indicateurs de cette enquête" description={lastSubmission ? `Dernière réponse le ${fmtDateTime(lastSubmission)}.` : "Aucune réponse reçue."} />
          <div className="grid gap-6 px-5 py-5 md:grid-cols-2">
            {[
              { label: "Taux de satisfaction", ind: satisfaction },
              { label: "Taux de retour", ind: retour },
            ].map(({ label, ind }) => (
              <div key={label}>
                <Stat label={label} value={<span className="num">{ind.value === null ? "n.c." : `${ind.value} %`}</span>} hint={<span className="num">{ind.numerator} / {ind.denominator}</span>} />
                <p className="mt-2 text-[12px] text-ink-2">{ind.definition}</p>
                <p className="text-[12px] text-ink-3">Exclusions : {ind.exclusions}</p>
                <p className="num text-[11px] text-ink-3">Calculé le {fmtDateTime(ind.computedAt)}</p>
              </div>
            ))}
          </div>
          {tpl?.indicators.length ? (
            <div className="border-t border-line px-5 py-3 text-[12px] text-ink-2">
              <p className="etiquette mb-1 text-ink-3">Définitions du modèle</p>
              <ul className="space-y-0.5">
                {tpl.indicators.map((i) => (
                  <li key={i.name}>
                    <span className="font-medium text-ink">{i.name}</span> : {i.definition} Exclusions : {i.exclusions}
                  </li>
                ))}
              </ul>
            </div>
          ) : null}
        </Panel>
      </div>

      <Panel className="mb-6">
        <PanelHeader title={`Questions (${questions.length})`} description={survey.status === "brouillon" ? "Modifiables tant que l'enquête est en brouillon. La question marquée #satisfaction sert au taux de satisfaction." : "Figées : les réponses reçues doivent rester comparables."} />
        {canManage && survey.status === "brouillon" ? (
          <div className="px-5 py-5">
            <ActionForm action={updateSurveyAction} submitLabel="Enregistrer" footerClassName="mt-4">
              <input type="hidden" name="orgId" value={ctx.org.id} />
              <input type="hidden" name="surveyId" value={survey.id} />
              <div className="space-y-4">
                <Field label="Titre" required htmlFor="sv-title">
                  <Input id="sv-title" name="title" defaultValue={survey.title} required maxLength={200} />
                </Field>
                <Field label="Description" htmlFor="sv-desc">
                  <Input id="sv-desc" name="description" defaultValue={survey.description ?? ""} maxLength={1000} />
                </Field>
                <Field label="Questions (une par ligne)" required htmlFor="sv-q" help="Format : [*]type: Libellé. Types : echelle5, echelle10, texte, ouinon, choix (options après « | », séparées par « ; »). « * » = obligatoire ; « #satisfaction » marque la question globale.">
                  <Textarea id="sv-q" name="questions" defaultValue={formatQuestionLines(questions)} className="num min-h-64 text-[12.5px]" required />
                </Field>
                <div className="grid gap-4 sm:grid-cols-2">
                  <Checkbox name="automation" defaultChecked={auto.trigger === "session_end"} label="Envoi automatique à la fin de session" className="mt-6" />
                  <Field label="Délai après la fin (jours)" htmlFor="sv-delay">
                    <Input id="sv-delay" name="delayDays" type="number" min={0} max={365} defaultValue={auto.delayDays ?? 0} />
                  </Field>
                </div>
              </div>
            </ActionForm>
          </div>
        ) : (
          <Table>
            <thead>
              <tr>
                <Th className="w-10">N°</Th>
                <Th>Question</Th>
                <Th>Type</Th>
                <Th num>Réponses</Th>
                <Th>Résultat agrégé</Th>
              </tr>
            </thead>
            <tbody>
              {aggregates.map((a, i) => (
                <tr key={a.question.key}>
                  <Td className="num align-top">{i + 1}</Td>
                  <Td className="align-top">
                    {a.question.label}
                    {a.question.required ? <span className="ml-1 text-accent">*</span> : null}
                    {a.question.indicator ? <Badge tone="accent" className="ml-2">{a.question.indicator}</Badge> : null}
                  </Td>
                  <Td className="align-top whitespace-nowrap text-[12.5px]">{a.question.type === "scale" ? `Échelle 1 à ${a.question.max}` : a.question.type === "text" ? "Texte" : a.question.type === "yesno" ? "Oui / non" : "Choix"}</Td>
                  <Td num className="align-top">
                    {a.n}
                  </Td>
                  <Td className="align-top text-[12.5px]">
                    {a.question.type === "scale" ? (
                      <>
                        Moyenne <span className="num">{a.mean ?? "-"}</span> / {a.question.max}
                        <span className="num ml-2 text-ink-3">{Object.entries(a.distribution).sort(([x], [y]) => Number(x) - Number(y)).map(([k, v]) => `${k}:${v}`).join("  ")}</span>
                      </>
                    ) : a.question.type === "text" ? (
                      a.texts.length ? (
                        <ul className="max-w-[48ch] list-disc space-y-0.5 pl-4">
                          {a.texts.slice(0, 8).map((t, j) => (
                            <li key={j}>{t}</li>
                          ))}
                          {a.texts.length > 8 ? <li className="text-ink-3">… {a.texts.length - 8} autre(s) dans l&apos;export</li> : null}
                        </ul>
                      ) : (
                        "-"
                      )
                    ) : (
                      <span className="num">{Object.entries(a.distribution).map(([k, v]) => `${k} : ${v}`).join("  ·  ") || "-"}</span>
                    )}
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
        )}
      </Panel>

      <Panel>
        <PanelHeader title="Destinataires et réponses" description={`${responses.length} jeton(s) émis, ${submitted.length} réponse(s) reçue(s). Un jeton = un destinataire = une seule soumission.`} />
        {responses.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Destinataire</Th>
                <Th>Inscription</Th>
                <Th>Envoyé le</Th>
                <Th>Répondu le</Th>
                <Th num>Score global</Th>
              </tr>
            </thead>
            <tbody>
              {responses.map(({ r, firstName, lastName, reference }) => (
                <tr key={r.id}>
                  <Td>{lastName ? `${lastName.toUpperCase()} ${firstName}` : "-"}</Td>
                  <Td className="num">{reference ?? "-"}</Td>
                  <Td className="num whitespace-nowrap">{r.sentAt ? fmtDateTime(r.sentAt) : "-"}</Td>
                  <Td className="num whitespace-nowrap">{r.submittedAt ? fmtDateTime(r.submittedAt) : <span className="text-ink-3">en attente</span>}</Td>
                  <Td num>{r.score ?? "-"}</Td>
                </tr>
              ))}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucun destinataire" description={survey.sessionId ? "Activez l'enquête puis envoyez-la aux inscrits de la session, ou laissez l'envoi automatique la diffuser à la fin de la session." : "Enquête modèle : l'envoi automatique crée une enquête par session terminée."} />
        )}
      </Panel>
      {session?.endDate ? (
        <Notice tone="info" className="mt-6">
          Session terminée le <span className="num">{fmtDate(session.endDate)}</span>. Le score global d&apos;une réponse est la moyenne de ses échelles ramenée sur 100 ; il ne remplace pas le taux de satisfaction défini ci-dessus.
        </Notice>
      ) : null}
    </FadeIn>
  );
}
