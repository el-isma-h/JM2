import Link from "next/link";
import { notFound } from "next/navigation";
import { and, desc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { getVisibleDocument, listVersions, CATEGORY_LABELS, VISIBILITY_LABELS } from "@/server/documents/queries";
import { listRequestsForDocument, SIGNER_ROLE_LABELS, SIGNER_ROLES, signersOf, type Signer } from "@/server/documents/signatures";
import { archiveDocumentAction, downloadDocumentAction, replaceDocumentAction, transmitDocumentAction, validateDocumentAction } from "@/server/actions/documents";
import { cancelSignatureRequestAction, createSignatureRequestAction, resendSignatureAction } from "@/server/actions/signatures";
import { ACCEPT_ATTR } from "@/server/documents/upload-rules";
import { integrations } from "@/lib/env";
import { fmtDateTime } from "@/lib/dates";
import { fmtBytes } from "@/components/admin/utils";
import { ActionButton, ActionForm } from "@/components/admin/action-form";
import { FormDialog } from "@/components/admin/form-dialog";
import { DownloadButton } from "@/components/documents/download-button";
import { MarkdownPreview } from "@/components/documents/markdown-preview";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea } from "@/components/ui/field";
import { KeyValue, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { ProposeButton } from "@/components/ai/propose-button";
import { Table, Td, Th } from "@/components/ui/table";
import { FadeIn } from "@/components/ui/motion";

export const dynamic = "force-dynamic";

export default async function DocumentDetailPage({ params }: { params: Promise<{ orgId: string; documentId: string }> }) {
  const { orgId, documentId } = await params;
  const base = `/app/${orgId}/documents`;
  const ctx = await guardOrg(orgId, `${base}/${documentId}`, "documents.view");
  const doc = await getVisibleDocument(ctx, documentId);
  if (!doc) notFound();
  const [versions, requests, docx, signedDoc, uploader] = await Promise.all([
    listVersions(orgId, doc),
    listRequestsForDocument(orgId, doc.id),
    db.select().from(schema.documents).where(and(eq(schema.documents.orgId, orgId), eq(schema.documents.sourceType, "docx_of"), eq(schema.documents.sourceId, doc.id))).orderBy(desc(schema.documents.createdAt)).limit(1),
    db.select().from(schema.documents).where(and(eq(schema.documents.orgId, orgId), eq(schema.documents.sourceType, "signed_of"), eq(schema.documents.sourceId, doc.id))).orderBy(desc(schema.documents.createdAt)).limit(1),
    doc.uploadedBy ? db.select({ firstName: schema.users.firstName, lastName: schema.users.lastName }).from(schema.users).where(eq(schema.users.id, doc.uploadedBy)).limit(1) : Promise.resolve([]),
  ]);
  const gen = (doc.generationData ?? {}) as { text?: string; missing?: { key: string; label: string }[]; answers?: Record<string, string>; signedFrom?: string };
  const canGenerate = ctx.permissions.has("documents.generate");
  const isAdminDoc = doc.visibility === "administratif" || doc.visibility === "confidentiel";
  const canManageThis = canGenerate && (!isAdminDoc || ctx.permissions.has("dossier.admin_docs.manage")) && doc.sourceType !== "org_rib";
  const pendingRequest = requests.find((r) => r.status === "envoyee" || r.status === "signee_partiellement");
  const latest = versions[0]?.id === doc.id;
  const esignConfigured = integrations.esign();

  return (
    <FadeIn>
      <PageHeader
        breadcrumb={[{ label: "Documents", href: base }, { label: doc.title }]}
        title={doc.title}
        description={
          <>
            {CATEGORY_LABELS[doc.category]} · version {doc.version} · {VISIBILITY_LABELS[doc.visibility]}
            {doc.enrollmentId ? (
              <>
                {" "}
                · <Link href={`/app/${orgId}/inscriptions/${doc.enrollmentId}`} className="underline">dossier d&apos;inscription</Link>
              </>
            ) : null}
            {doc.sessionId ? (
              <>
                {" "}
                · <Link href={`/app/${orgId}/sessions/${doc.sessionId}`} className="underline">session</Link>
              </>
            ) : null}
          </>
        }
        actions={
          <>
            <DownloadButton action={downloadDocumentAction} fields={{ orgId, documentId: doc.id }} label="Télécharger" variant="primary" size="md" />
            {docx[0] ? <DownloadButton action={downloadDocumentAction} fields={{ orgId, documentId: docx[0].id }} label="Version Word" size="md" /> : null}
            {canManageThis ? <ProposeButton orgId={orgId} agent="pieces" entityType="document" entityId={doc.id} back={`${base}/${documentId}`} size="md" /> : null}
          </>
        }
      />

      {!latest ? (
        <Notice tone="warn" className="mb-4">
          Une version plus récente existe :{" "}
          <Link href={`${base}/${versions[0].id}`} className="underline">
            version {versions[0].version}
          </Link>
          . Cette version est conservée telle quelle.
        </Notice>
      ) : null}
      {doc.status === "archive" ? <Notice tone="info" className="mb-4">Document archivé : conservé dans l&apos;historique, non diffusé.</Notice> : null}
      {signedDoc[0] ? (
        <Notice tone="ok" className="mb-4">
          Version signée disponible :{" "}
          <Link href={`${base}/${signedDoc[0].id}`} className="underline">
            {signedDoc[0].title}
          </Link>
        </Notice>
      ) : null}
      {gen.signedFrom ? (
        <Notice tone="info" className="mb-4">
          Ce document est la version signée de{" "}
          <Link href={`${base}/${gen.signedFrom}`} className="underline">
            l&apos;original
          </Link>
          ; la dernière page contient la preuve de signature.
        </Notice>
      ) : null}

      <div className="grid gap-5 lg:grid-cols-[1fr_380px]">
        <div className="space-y-5">
          <Panel>
            <PanelHeader title="Cycle de vie" description="Brouillon, généré, transmis, signé, validé. Un document généré n'est jamais signé par la génération." />
            <div className="flex flex-wrap items-center gap-2 px-5 py-4">
              {(["genere", "transmis", "signe", "valide"] as const).map((s, i) => {
                const order = ["brouillon", "genere", "transmis", "signe", "valide"];
                const reached = order.indexOf(doc.status) >= order.indexOf(s) && doc.status !== "archive" && doc.status !== "invalide";
                return (
                  <span key={s} className="flex items-center gap-2">
                    {i > 0 ? <span className="text-ink-3">/</span> : null}
                    <Badge tone={reached ? (s === "signe" || s === "valide" ? "ok" : "info") : "neutral"}>{{ genere: "Généré", transmis: "Transmis", signe: "Signé", valide: "Validé" }[s]}</Badge>
                  </span>
                );
              })}
              <span className="ml-auto">
                <StatusBadge status={doc.status} />
              </span>
            </div>
            <div className="border-t border-line px-5 py-4">
              <KeyValue
                items={[
                  { k: "Fichier", v: <span className="num">{doc.fileName} · {fmtBytes(doc.sizeBytes)}</span> },
                  { k: "Empreinte", v: <span className="num text-[12px]">{doc.sha256 ?? "-"}</span> },
                  { k: "Créé", v: `${fmtDateTime(doc.createdAt)}${uploader[0] ? ` par ${uploader[0].firstName} ${uploader[0].lastName}` : ""}` },
                  { k: "Transmis", v: doc.transmittedAt ? fmtDateTime(doc.transmittedAt) : "-" },
                  { k: "Signé", v: doc.signedAt ? fmtDateTime(doc.signedAt) : "-" },
                  { k: "Validé", v: doc.validatedAt ? fmtDateTime(doc.validatedAt) : "-" },
                  { k: "Modèle", v: doc.templateCode ? <span className="num">{doc.templateCode}</span> : "Dépôt manuel" },
                ]}
              />
            </div>
          </Panel>

          {gen.text ? (
            <Panel>
              <PanelHeader title="Contenu généré" description={gen.missing?.length ? `${gen.missing.length} donnée(s) manquante(s) à la génération : ${gen.missing.map((m) => m.label).join(", ")}.` : "Toutes les données étaient renseignées à la génération."} />
              <div className="max-h-[70dvh] overflow-y-auto p-6">
                <MarkdownPreview text={gen.text} />
              </div>
            </Panel>
          ) : null}

          <Panel>
            <PanelHeader title="Versions" description="Chaque régénération ou nouveau dépôt crée une version ; une version signée ou validée n'est jamais remplacée." />
            <Table>
              <thead>
                <tr>
                  <Th num>Version</Th>
                  <Th>Statut</Th>
                  <Th>Date</Th>
                  <Th>Fichier</Th>
                </tr>
              </thead>
              <tbody>
                {versions.map((v) => (
                  <tr key={v.id} className={v.id === doc.id ? "bg-bg-sunken" : undefined}>
                    <Td num>
                      {v.id === doc.id ? (
                        <span>v{v.version}</span>
                      ) : (
                        <Link href={`${base}/${v.id}`} className="underline">
                          v{v.version}
                        </Link>
                      )}
                    </Td>
                    <Td>
                      <StatusBadge status={v.status} />
                    </Td>
                    <Td className="whitespace-nowrap">{fmtDateTime(v.createdAt)}</Td>
                    <Td className="num text-[12px]">{v.fileName}</Td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </Panel>

          <Panel>
            <PanelHeader
              title="Signatures"
              description={esignConfigured ? "Prestataire externe configuré (ESIGN_PROVIDER)." : "Signature électronique interne : lien personnel, consentement, code par e-mail, horodatage serveur, page de preuve."}
              actions={
                canManageThis && doc.mimeType === "application/pdf" && !pendingRequest && ["genere", "transmis", "brouillon"].includes(doc.status) ? (
                  <FormDialog action={createSignatureRequestAction} trigger="Demander une signature" triggerSize="sm" title="Demande de signature" description="Chaque signataire reçoit un lien personnel valable 30 jours. À la dernière signature, un PDF signé est créé avec sa page de preuve." submitLabel="Envoyer la demande" wide>
                    <input type="hidden" name="orgId" value={orgId} />
                    <input type="hidden" name="documentId" value={doc.id} />
                    {[0, 1, 2].map((i) => (
                      <div key={i} className="grid gap-3 sm:grid-cols-[1fr_1fr_160px]">
                        <Field label={`Signataire ${i + 1}${i === 0 ? "" : " (facultatif)"}`} htmlFor={`s${i}n`} required={i === 0}>
                          <Input id={`s${i}n`} name={`signer${i}Name`} required={i === 0} placeholder="Nom et prénom" />
                        </Field>
                        <Field label="E-mail" htmlFor={`s${i}e`} required={i === 0}>
                          <Input id={`s${i}e`} name={`signer${i}Email`} type="email" required={i === 0} />
                        </Field>
                        <Field label="Rôle" htmlFor={`s${i}r`}>
                          <Select id={`s${i}r`} name={`signer${i}Role`} defaultValue={i === 0 ? "entreprise" : i === 1 ? "apprenant" : "organisme"}>
                            {SIGNER_ROLES.map((r) => (
                              <option key={r} value={r}>
                                {SIGNER_ROLE_LABELS[r]}
                              </option>
                            ))}
                          </Select>
                        </Field>
                      </div>
                    ))}
                    <Field label="Message (facultatif)" htmlFor="sig-msg">
                      <Textarea id="sig-msg" name="message" rows={2} />
                    </Field>
                  </FormDialog>
                ) : null
              }
            />
            {requests.length ? (
              <ul className="divide-y divide-line">
                {requests.map((r) => {
                  const signers = signersOf(r) as Signer[];
                  const proof = r.proof as { signedDocumentId?: string } | null;
                  return (
                    <li key={r.id} className="px-5 py-4">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div>
                          <StatusBadge status={r.status} /> <span className="ml-2 text-[12.5px] text-ink-3">{fmtDateTime(r.createdAt)} · {r.provider}</span>
                        </div>
                        <div className="flex gap-2">
                          {r.signedDocumentId ? (
                            <Button asChild variant="secondary" size="sm">
                              <Link href={`${base}/${r.signedDocumentId}`}>PDF signé</Link>
                            </Button>
                          ) : null}
                          {canManageThis && (r.status === "envoyee" || r.status === "signee_partiellement") && r.provider === "interne" ? (
                            <>
                              <ActionButton action={resendSignatureAction} fields={{ orgId, requestId: r.id }} label="Relancer" />
                              <ActionButton action={cancelSignatureRequestAction} fields={{ orgId, requestId: r.id }} label="Annuler" variant="danger" confirm={{ title: "Annuler la demande de signature", description: "Les liens envoyés ne fonctionneront plus.", input: { name: "reason", label: "Motif" }, confirmLabel: "Annuler la demande", danger: true }} />
                            </>
                          ) : null}
                        </div>
                      </div>
                      <ul className="mt-2 space-y-1 text-[12.5px]">
                        {signers.map((s) => (
                          <li key={s.id} className="flex flex-wrap gap-x-2">
                            <span className="font-medium text-ink">{s.name}</span>
                            <span className="text-ink-3">{SIGNER_ROLE_LABELS[s.role] ?? s.role} · {s.email}</span>
                            {s.signedAt ? <Badge tone="ok">Signé le {fmtDateTime(new Date(s.signedAt))}</Badge> : <Badge tone="warn">En attente</Badge>}
                          </li>
                        ))}
                      </ul>
                      {proof?.signedDocumentId ? <p className="mt-1 text-[12px] text-ink-3">Preuve JSON enregistrée (empreintes, horodatages, IP) ; page de preuve dans le PDF signé.</p> : null}
                    </li>
                  );
                })}
              </ul>
            ) : (
              <p className="px-5 py-4 text-[13px] text-ink-3">Aucune demande de signature pour ce document.</p>
            )}
          </Panel>
        </div>

        <div className="space-y-5">
          <Panel>
            <PanelHeader title="Transmettre" description="Envoie un lien de téléchargement temporaire (24 h) par e-mail et passe le document en « transmis »." />
            <div className="p-5">
              {canGenerate && doc.status !== "archive" && doc.status !== "invalide" && doc.sourceType !== "org_rib" ? (
                <ActionForm action={transmitDocumentAction} submitLabel="Transmettre" submitSize="sm" className="space-y-3">
                  <input type="hidden" name="orgId" value={orgId} />
                  <input type="hidden" name="documentId" value={doc.id} />
                  <Field label="Destinataire" required htmlFor="tr-to">
                    <Input id="tr-to" name="to" type="email" required />
                  </Field>
                  <Field label="Message" htmlFor="tr-msg">
                    <Textarea id="tr-msg" name="message" rows={3} />
                  </Field>
                </ActionForm>
              ) : (
                <p className="text-[13px] text-ink-3">{canGenerate ? "Ce document ne peut pas être transmis dans son état actuel." : "Habilitation « générer et transmettre des documents » nécessaire."}</p>
              )}
            </div>
          </Panel>

          <Panel>
            <PanelHeader title="Validation" description="Marque le document validé (qui et quand sont conservés). La validation n'est pas une signature." />
            <div className="p-5">
              {canManageThis && doc.status !== "valide" && doc.status !== "archive" && doc.status !== "invalide" ? (
                <ActionButton action={validateDocumentAction} fields={{ orgId, documentId: doc.id }} label="Marquer validé" variant="primary" confirm={{ title: "Marquer le document validé", description: "Le document sera marqué validé à votre nom, à l'heure du serveur." }} />
              ) : doc.status === "valide" ? (
                <p className="text-[13px] text-ok-ink">Validé le {fmtDateTime(doc.validatedAt)}.</p>
              ) : (
                <p className="text-[13px] text-ink-3">{canManageThis ? "Validation impossible dans cet état." : "Habilitation nécessaire."}</p>
              )}
            </div>
          </Panel>

          <Panel>
            <PanelHeader title="Nouvelle version" description={doc.status === "signe" || doc.status === "valide" ? "Ce document est verrouillé : une nouvelle version s'ajoute sans le remplacer." : "Le dépôt d'un fichier crée une version ; l'actuelle est archivée."} />
            <div className="space-y-3 p-5">
              {canManageThis ? (
                <>
                  <ActionForm action={replaceDocumentAction} submitLabel="Déposer une nouvelle version" submitSize="sm" className="space-y-3">
                    <input type="hidden" name="orgId" value={orgId} />
                    <input type="hidden" name="documentId" value={doc.id} />
                    <Field label="Fichier" required htmlFor="rep-file">
                      <Input id="rep-file" name="file" type="file" accept={ACCEPT_ATTR} required className="py-1.5" />
                    </Field>
                  </ActionForm>
                  {doc.templateCode && (doc.enrollmentId || doc.sessionId) ? (
                    <Button asChild variant="secondary" size="sm">
                      <Link href={`${base}/nouveau?${doc.enrollmentId ? `enrollmentId=${doc.enrollmentId}` : `sessionId=${doc.sessionId}`}&template=${encodeURIComponent(doc.templateCode)}${Object.entries(gen.answers ?? {})
                        .map(([k, v]) => `&a.${encodeURIComponent(k)}=${encodeURIComponent(v)}`)
                        .join("")}`}>
                        Régénérer depuis le modèle
                      </Link>
                    </Button>
                  ) : null}
                  {doc.status !== "signe" && doc.status !== "archive" ? (
                    <ActionButton action={archiveDocumentAction} fields={{ orgId, documentId: doc.id }} label="Archiver" variant="ghost" confirm={{ title: "Archiver le document", description: "Le document reste conservé dans l'historique mais n'est plus diffusé.", input: { name: "reason", label: "Motif" }, confirmLabel: "Archiver" }} />
                  ) : null}
                </>
              ) : (
                <p className="text-[13px] text-ink-3">Habilitation nécessaire.</p>
              )}
            </div>
          </Panel>
        </div>
      </div>
    </FadeIn>
  );
}
