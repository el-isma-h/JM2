import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/server/auth";
import { verifyEmailAction } from "@/server/actions/auth";
import { Notice } from "@/components/ui/surface";
import { Button } from "@/components/ui/button";
import { requireEmailVerification } from "@/lib/env";
import { ResendButton } from "./resend-button";
import { AutoRedirect } from "./auto-redirect";

export const metadata: Metadata = { title: "Vérification de l'adresse" };

export default async function VerifyPage({ searchParams }: { searchParams: Promise<{ token?: string }> }) {
  const { token } = await searchParams;
  if (token) {
    const res = await verifyEmailAction(token);
    if (res.ok) {
      const u = await getCurrentUser();
      redirect(u ? "/app" : "/connexion");
    }
    return (
      <div>
        <h1 className="text-[30px] text-ink">Lien invalide</h1>
        <Notice tone="danger" className="mt-6">
          {res.error}
        </Notice>
        <Button asChild variant="secondary" className="mt-4">
          <Link href="/connexion">Se connecter</Link>
        </Button>
      </div>
    );
  }
  const user = await getCurrentUser();
  if (!user) redirect("/connexion");
  if (user.emailVerified) redirect("/app");
  if (!requireEmailVerification()) {
    return (
      <div>
        <h1 className="text-[30px] text-ink">Vérification non requise</h1>
        <p className="mt-3 text-[14px] text-ink-2">
          Aucun service d&apos;envoi d&apos;e-mail n&apos;est configuré sur cette installation : votre adresse <span className="font-medium text-ink">{user.email}</span> n&apos;a pas besoin d&apos;être confirmée pour accéder à votre espace.
        </p>
        <Notice tone="info" className="mt-6">
          Redirection vers votre espace dans quelques secondes.
        </Notice>
        <Button asChild className="mt-4">
          <Link href="/app">Accéder à mon espace</Link>
        </Button>
        <AutoRedirect href="/app" delayMs={2500} />
      </div>
    );
  }
  return (
    <div>
      <h1 className="text-[30px] text-ink">Vérifiez votre adresse</h1>
      <p className="mt-3 text-[14px] text-ink-2">
        Un e-mail a été envoyé à <span className="font-medium text-ink">{user.email}</span>. Cliquez sur le lien qu&apos;il contient pour activer votre espace.
      </p>
      <div className="mt-6 flex flex-wrap items-center gap-3">
        <ResendButton />
        <form action="/deconnexion" method="post">
          <Button type="submit" variant="ghost">
            Se déconnecter
          </Button>
        </form>
      </div>
    </div>
  );
}
