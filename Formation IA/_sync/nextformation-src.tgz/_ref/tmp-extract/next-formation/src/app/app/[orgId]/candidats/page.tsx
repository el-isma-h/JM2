import Link from "next/link";
import { and, desc, eq, ilike, or, sql, type SQL } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { createPersonAction } from "@/server/actions/crm";
import { isOverdue } from "@/server/crm/queries";
import { todayParis } from "@/lib/time";
import { fmtDate } from "@/lib/dates";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/field";
import { EmptyState, PageHeader, Panel } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FormDialog } from "@/components/admin/form-dialog";
import { Pagination, readPage, readParam } from "@/components/admin/pagination";
import { PersonFields, personStatusLabels } from "@/components/crm/fields";
import { NextActionCell } from "@/components/crm/next-action";

export const dynamic = "force-dynamic";
const PAGE = 50;

export default async function CandidatesPage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const base = `/app/${orgId}`;
  const ctx = await guardOrg(orgId, `${base}/candidats`, "crm.view");
  const sp = await searchParams;
  const q = readParam(sp.q);
  const status = readParam(sp.status);
  const source = readParam(sp.source);
  const tag = readParam(sp.tag);
  const page = readPage(sp.page);
  const today = todayParis();

  const conds: SQL[] = [eq(schema.persons.orgId, ctx.org.id)];
  if (status && (schema.personStatusEnum.enumValues as readonly string[]).includes(status)) conds.push(eq(schema.persons.status, status as "candidat"));
  else if (!status) conds.push(or(eq(schema.persons.status, "candidat"), eq(schema.persons.status, "apprenant"))!);
  // Liens du pilotage : placements en cours / réalisés (décision dans la période from/to).
  const placement = readParam(sp.placement);
  const pFrom = readParam(sp.from);
  const pTo = readParam(sp.to);
  if (placement === "en_cours") conds.push(sql`exists (select 1 from ${schema.placements} pl where pl.person_id = ${schema.persons.id} and pl.status in ('propose','entretien','retenu'))`);
  if (placement === "place") conds.push(sql`exists (select 1 from ${schema.placements} pl where pl.person_id = ${schema.persons.id} and pl.status = 'place'${pFrom && /^\d{4}-\d{2}-\d{2}$/.test(pFrom) ? sql` and pl.decided_at >= ${pFrom}::date` : sql``}${pTo && /^\d{4}-\d{2}-\d{2}$/.test(pTo) ? sql` and pl.decided_at < (${pTo}::date + interval '1 day')` : sql``})`);
  if (source) conds.push(ilike(schema.persons.source, `%${source}%`));
  if (tag) conds.push(sql`${schema.persons.tags} @> ${JSON.stringify([tag])}::jsonb`);
  if (q) conds.push(or(ilike(schema.persons.lastName, `%${q}%`), ilike(schema.persons.firstName, `%${q}%`), ilike(schema.persons.email, `%${q}%`), ilike(schema.persons.city, `%${q}%`))!);
  const where = and(...conds);

  const nextAt = sql<string | null>`(select i.next_action_at::text from ${schema.interactions} i where i.person_id = "persons"."id" and i.next_action_at is not null order by i.at desc limit 1)`;
  const nextLabel = sql<string | null>`(select i.next_action from ${schema.interactions} i where i.person_id = "persons"."id" and i.next_action_at is not null order by i.at desc limit 1)`;
  const [rows, [{ total }], companies, sources] = await Promise.all([
    db
      .select({
        p: schema.persons,
        companyName: schema.companies.name,
        placements: sql<number>`(select count(*)::int from ${schema.placements} pl where pl.person_id = "persons"."id" and pl.status in ('propose','entretien','retenu'))`,
        enrollments: sql<number>`(select count(*)::int from ${schema.enrollments} e where e.person_id = "persons"."id")`,
        nextAt,
        nextLabel,
      })
      .from(schema.persons)
      .leftJoin(schema.companies, eq(schema.companies.id, schema.persons.companyId))
      .where(where)
      .orderBy(desc(schema.persons.updatedAt))
      .limit(PAGE)
      .offset((page - 1) * PAGE),
    db.select({ total: sql<number>`count(*)::int` }).from(schema.persons).where(where),
    db.select({ id: schema.companies.id, name: schema.companies.name }).from(schema.companies).where(eq(schema.companies.orgId, ctx.org.id)).orderBy(schema.companies.name).limit(500),
    db.select({ source: schema.persons.source }).from(schema.persons).where(and(eq(schema.persons.orgId, ctx.org.id), sql`${schema.persons.source} is not null`)).groupBy(schema.persons.source).limit(50),
  ]);
  const canManage = ctx.permissions.has("crm.manage");

  return (
    <>
      <PageHeader
        title="Candidats"
        description="Vivier de candidats et apprenants. Les CV et notes sensibles ne sont visibles qu'avec l'habilitation dédiée."
        actions={
          canManage ? (
            <FormDialog action={createPersonAction} trigger="Nouveau candidat" title="Nouveau candidat" description="Les doublons (nom + date de naissance, ou e-mail) sont signalés, jamais fusionnés automatiquement." submitLabel="Créer la fiche" wide>
              <PersonFields orgId={ctx.org.id} companies={companies} />
            </FormDialog>
          ) : null
        }
      />
      <Panel>
        <form method="get" className="flex flex-wrap items-end gap-3 border-b border-line px-5 py-3">
          <Field label="Recherche" htmlFor="q" className="w-full max-w-xs">
            <Input id="q" name="q" defaultValue={q} placeholder="Nom, e-mail ou ville" />
          </Field>
          <Field label="Statut" htmlFor="status" className="w-44">
            <Select id="status" name="status" defaultValue={status ?? ""}>
              <option value="">Candidats et apprenants</option>
              {Object.entries(personStatusLabels).map(([v, l]) => (
                <option key={v} value={v}>
                  {l}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Source" htmlFor="source" className="w-44">
            <Select id="source" name="source" defaultValue={source ?? ""}>
              <option value="">Toutes</option>
              {sources.map((s) => (
                <option key={s.source ?? ""} value={s.source ?? ""}>
                  {s.source}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Étiquette" htmlFor="tag" className="w-40">
            <Input id="tag" name="tag" defaultValue={tag} />
          </Field>
          <Button type="submit" variant="secondary">
            Filtrer
          </Button>
        </form>
        {rows.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Personne</Th>
                <Th>Statut</Th>
                <Th>Employeur</Th>
                <Th>Source</Th>
                <Th num>Placements</Th>
                <Th num>Inscriptions</Th>
                <Th>Prochaine action</Th>
              </tr>
            </thead>
            <tbody>
              {rows.map(({ p, companyName, placements, enrollments, nextAt, nextLabel }) => (
                <tr key={p.id}>
                  <Td>
                    <Link href={`${base}/candidats/${p.id}`} className="font-medium text-ink hover:underline">
                      {p.firstName} {p.lastName}
                    </Link>
                    <p className="text-[12px] text-ink-3">
                      {[p.email, p.city, p.birthDate ? `né(e) le ${fmtDate(p.birthDate)}` : null].filter(Boolean).join(" · ")}
                    </p>
                    {(p.tags as string[]).length ? (
                      <div className="mt-1 flex flex-wrap gap-1">
                        {(p.tags as string[]).map((t) => (
                          <Badge key={t}>{t}</Badge>
                        ))}
                      </div>
                    ) : null}
                  </Td>
                  <Td>
                    <StatusBadge status={p.status} />
                  </Td>
                  <Td>{companyName ?? <span className="text-ink-3">-</span>}</Td>
                  <Td>{p.source ?? "-"}</Td>
                  <Td num>{placements}</Td>
                  <Td num>{enrollments}</Td>
                  <Td>
                    <NextActionCell date={nextAt} label={nextLabel} overdue={isOverdue(nextAt, today)} />
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucun candidat" description={q || status || source || tag ? "Aucun résultat pour ces filtres." : "Créez une fiche ou importez votre vivier depuis « Imports et exports »."} />
        )}
        <Pagination basePath={`${base}/candidats`} params={{ q, status, source, tag }} page={page} pageSize={PAGE} total={total} />
      </Panel>
    </>
  );
}
