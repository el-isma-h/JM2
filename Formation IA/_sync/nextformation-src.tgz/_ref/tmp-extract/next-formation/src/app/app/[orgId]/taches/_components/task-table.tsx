import Link from "next/link";
import { StatusBadge, Badge } from "@/components/ui/badge";
import { EmptyState } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { fmtDate } from "@/lib/dates";
import { isOverdue, taskFamilyLabels, entityTypeLabels, type TaskFamily } from "@/server/tasks/rules";
import type { TaskRow } from "@/server/tasks/queries";
import { roleLabels, type OrgRole } from "@/server/authz";

export type StaffMap = Map<string, string>;

export function assigneeLabel(task: Pick<TaskRow, "assigneeUserId" | "assigneeRole">, staff: StaffMap): string {
  if (task.assigneeUserId) return staff.get(task.assigneeUserId) ?? "Membre inactif";
  if (task.assigneeRole) return `Rôle : ${roleLabels[task.assigneeRole as OrgRole] ?? task.assigneeRole}`;
  return "À affecter";
}

export function TaskTable({ tasks, orgId, staff, today, selectable, emptyTitle = "Aucune tâche", emptyDescription = "Rien à traiter avec ces filtres." }: { tasks: TaskRow[]; orgId: string; staff: StaffMap; today: string; selectable?: boolean; emptyTitle?: string; emptyDescription?: string }) {
  if (!tasks.length) return <EmptyState title={emptyTitle} description={emptyDescription} />;
  return (
    <Table>
      <thead>
        <tr>
          {selectable ? <Th className="w-8" /> : null}
          <Th>Objet</Th>
          <Th>Dossier</Th>
          <Th>Responsable</Th>
          <Th>Échéance</Th>
          <Th>Priorité</Th>
          <Th>Statut</Th>
        </tr>
      </thead>
      <tbody>
        {tasks.map((t) => {
          const late = isOverdue(t, today);
          return (
            <tr key={t.id}>
              {selectable ? (
                <Td>
                  <input type="checkbox" name="taskIds" value={t.id} form="bulk-form" aria-label={`Sélectionner : ${t.title}`} className="h-4 w-4 rounded-none accent-[var(--accent)]" />
                </Td>
              ) : null}
              <Td>
                <Link href={`/app/${orgId}/taches/${t.id}`} className="font-medium text-ink hover:underline">
                  {t.title}
                </Link>
                <p className="mt-0.5 text-[12px] text-ink-3">
                  {taskFamilyLabels[t.family as TaskFamily] ?? t.family}
                  {t.status === "bloquee" && t.blockedReason ? <span className="text-danger-ink"> : bloquée, {t.blockedReason}</span> : null}
                </p>
              </Td>
              <Td className="max-w-[260px]">
                {t.entityId && t.href ? (
                  <Link href={t.href} className="hover:underline">
                    <span className="etiquette mr-1">{entityTypeLabels[t.entityType ?? ""] ?? t.entityType}</span>
                    <span className="truncate">{t.entityLabel ?? ""}</span>
                  </Link>
                ) : (
                  <span className="text-ink-3">-</span>
                )}
              </Td>
              <Td className="text-ink-2">{assigneeLabel(t, staff)}</Td>
              <Td className="whitespace-nowrap">
                <span className={late ? "num text-danger-ink" : "num"}>{t.dueDate ? fmtDate(t.dueDate) : "-"}</span>
                {late ? (
                  <Badge tone="danger" className="ml-2">
                    Retard
                  </Badge>
                ) : null}
              </Td>
              <Td>
                <StatusBadge status={t.priority} />
              </Td>
              <Td>
                <StatusBadge status={t.status} />
              </Td>
            </tr>
          );
        })}
      </tbody>
    </Table>
  );
}
