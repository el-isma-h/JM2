"use client";

import { useActionState } from "react";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea } from "@/components/ui/field";
import { Notice } from "@/components/ui/surface";
import { contactAction } from "@/server/actions/contact";

/** Formulaire de contact : labels au-dessus des champs, erreur près de l'action, champs conservés en cas d'échec. */
export function ContactForm() {
  const [state, action, pending] = useActionState(contactAction, {});
  if (state.ok) {
    return (
      <Notice tone="ok" title="Message reçu">
        {state.message}
      </Notice>
    );
  }
  return (
    <form action={action} className="grid gap-5 sm:grid-cols-2" noValidate>
      <Field label="Nom" htmlFor="c-name" required>
        <Input id="c-name" name="name" autoComplete="name" required minLength={2} />
      </Field>
      <Field label="E-mail" htmlFor="c-email" required>
        <Input id="c-email" name="email" type="email" autoComplete="email" required />
      </Field>
      <Field label="Organisme" htmlFor="c-org" help="Facultatif">
        <Input id="c-org" name="organisation" autoComplete="organization" />
      </Field>
      <Field label="Sujet" htmlFor="c-subject" required>
        <Select id="c-subject" name="subject" defaultValue="demo" required>
          <option value="demo">Démonstration accompagnée</option>
          <option value="tarifs">Tarifs</option>
          <option value="reprise">Reprise de données</option>
          <option value="securite">Sécurité et conformité</option>
          <option value="autre">Autre</option>
        </Select>
      </Field>
      <div className="sm:col-span-2">
        <Field label="Message" htmlFor="c-message" required help="Dix caractères minimum. Aucune pièce jointe : n'envoyez pas de données d'apprenants.">
          <Textarea id="c-message" name="message" required minLength={10} rows={6} />
        </Field>
      </div>
      <div className="absolute -left-[9999px] top-auto h-px w-px overflow-hidden" aria-hidden="true">
        <label htmlFor="c-website">Site web</label>
        <input id="c-website" name="website" type="text" tabIndex={-1} autoComplete="off" />
      </div>
      <div className="flex flex-wrap items-center gap-4 sm:col-span-2">
        <Button type="submit" size="lg" loading={pending}>
          Envoyer le message
        </Button>
        {state.error ? (
          <Notice tone="danger" className="flex-1">
            {state.error}
          </Notice>
        ) : null}
      </div>
    </form>
  );
}
