import { SiteFooter, SiteHeader } from "@/components/marketing/site";

/** Pages publiques du site vitrine (hors accueil) : en-tête et pied de page communs. */
export default function MarketingLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-[100dvh] flex-col bg-bg text-ink">
      <SiteHeader />
      <main className="flex-1">{children}</main>
      <SiteFooter />
    </div>
  );
}
