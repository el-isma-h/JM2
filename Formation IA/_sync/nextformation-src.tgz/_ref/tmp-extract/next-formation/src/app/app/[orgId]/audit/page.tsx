import { desc, eq, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardSecurityAdmin } from "@/server/security/access";
import { orgAuditWhere, readOrgAuditFilters } from "@/server/security/audit-query";
import { fmtDateTime } from "@/lib/dates";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/field";
import { EmptyState, PageHeader, Panel } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FadeIn } from "@/components/ui/motion";
import { Pagination, readPage } from "@/components/admin/pagination";

export const dynamic = "force-dynamic";
const PAGE = 50;

function summarize(v: unknown): string {
  if (v === null || v === undefined) return "";
  const s = JSON.stringify(v);
  return s.length > 140 ? `${s.slice(0, 139)}…` : s;
}

/** Journal d'audit de l'organisme (propriétaire, S01). Jamais modifié depuis l'interface. */
export default async function OrgAuditPage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const ctx = await guardSecurityAdmin(orgId, `/app/${orgId}/audit`);
  const sp = await searchParams;
  const f = readOrgAuditFilters(sp);
  const page = readPage(sp.page);
  const where = orgAuditWhere(orgId, f);
  const [rows, [{ total }]] = await Promise.all([
    db.select({ a: schema.auditLogs, email: schema.users.email }).from(schema.auditLogs).leftJoin(schema.users, eq(schema.users.id, schema.auditLogs.userId)).where(where).orderBy(desc(schema.auditLogs.createdAt)).limit(PAGE).offset((page - 1) * PAGE),
    db.select({ total: sql<number>`count(*)::int` }).from(schema.auditLogs).leftJoin(schema.users, eq(schema.users.id, schema.auditLogs.userId)).where(where),
  ]);
  const qs = new URLSearchParams(Object.entries(f).filter(([, v]) => v) as [string, string][]).toString();
  const canExport = ctx.permissions.has("exports.run");

  return (
    <FadeIn>
      <PageHeader
        title="Journal d'audit"
        description="Toutes les actions sensibles de l'organisme, lues ou écrites, avec leur auteur. Les journaux ne contiennent ni mots de passe ni clés."
        actions={
          canExport ? (
            <Button asChild variant="secondary">
              <a href={`/app/${orgId}/audit/export${qs ? `?${qs}` : ""}`}>Exporter en CSV</a>
            </Button>
          ) : (
            <Button variant="secondary" disabled title="Export réservé à la permission « Exporter des données »">
              Exporter en CSV
            </Button>
          )
        }
      />
      <Panel>
        <form method="get" className="flex flex-wrap items-end gap-3 border-b border-line px-5 py-3">
          <Field label="Action" htmlFor="au-action" className="w-48" help="Préfixe : task., security., finance.">
            <Input id="au-action" name="action" defaultValue={f.action} />
          </Field>
          <Field label="Utilisateur" htmlFor="au-user" className="w-56">
            <Input id="au-user" name="user" defaultValue={f.user} placeholder="E-mail ou identifiant" />
          </Field>
          <Field label="Type d'entité" htmlFor="au-et" className="w-40">
            <Input id="au-et" name="entityType" defaultValue={f.entityType} placeholder="enrollment, task…" />
          </Field>
          <Field label="Identifiant d'entité" htmlFor="au-eid" className="w-72">
            <Input id="au-eid" name="entityId" defaultValue={f.entityId} className="num" />
          </Field>
          <Field label="Du" htmlFor="au-from" className="w-40">
            <Input id="au-from" name="from" type="date" defaultValue={f.from} className="num" />
          </Field>
          <Field label="Au" htmlFor="au-to" className="w-40">
            <Input id="au-to" name="to" type="date" defaultValue={f.to} className="num" />
          </Field>
          <Button type="submit" variant="secondary" className="mb-5">
            Filtrer
          </Button>
        </form>
        {rows.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Date</Th>
                <Th>Action</Th>
                <Th>Utilisateur</Th>
                <Th>Entité</Th>
                <Th>Avant</Th>
                <Th>Après</Th>
              </tr>
            </thead>
            <tbody>
              {rows.map(({ a, email }) => (
                <tr key={a.id}>
                  <Td className="num whitespace-nowrap text-[12.5px]">{fmtDateTime(a.createdAt)}</Td>
                  <Td className="num text-[12.5px]">{a.action}</Td>
                  <Td className="text-[12.5px] text-ink-2">{email ?? (a.userId ? "Compte supprimé" : "Système")}</Td>
                  <Td className="text-[12.5px] text-ink-2">
                    {a.entityType ?? "-"}
                    {a.entityId ? <span className="num block text-[11px] text-ink-3">{a.entityId}</span> : null}
                  </Td>
                  <Td className="num max-w-[220px] truncate text-[11.5px] text-ink-3" title={summarize(a.before)}>{summarize(a.before)}</Td>
                  <Td className="num max-w-[220px] truncate text-[11.5px] text-ink-3" title={summarize(a.after)}>{summarize(a.after)}</Td>
                </tr>
              ))}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucune entrée" description="Aucune action journalisée ne correspond à ces filtres." />
        )}
        <Pagination basePath={`/app/${orgId}/audit`} params={f} page={page} pageSize={PAGE} total={total} />
      </Panel>
    </FadeIn>
  );
}
