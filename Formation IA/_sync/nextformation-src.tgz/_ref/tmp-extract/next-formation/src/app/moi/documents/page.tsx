import { guardLearner } from "@/server/extranet/guard";
import { listVisibleDocuments } from "@/server/extranet/queries";
import { NoAttachment } from "@/components/extranet/shell";
import { DocumentTable } from "@/components/extranet/ui";
import { PageHeader, Panel, PanelHeader } from "@/components/ui/surface";

export const dynamic = "force-dynamic";

/** Documents destinés à l'apprenant (visibilité `apprenant` : convention, convocation, attestation, certificat…). */
export default async function LearnerDocuments() {
  const ctx = await guardLearner("/moi/documents");
  if (!ctx) return <NoAttachment kind="learner" />;
  const docs = await listVisibleDocuments(ctx.org.id, { enrollmentIds: ctx.enrollmentIds, personId: ctx.person.id }, ["apprenant", "public"]);
  const byEnrollment = ctx.enrollments.map((e) => ({ e, docs: docs.filter((d) => d.enrollmentId === e.enrollment.id) }));
  const others = docs.filter((d) => !d.enrollmentId);
  return (
    <>
      <PageHeader title="Mes documents" description="Documents que l'organisme a mis à votre disposition : convention, convocation, attestations, certificats. Le téléchargement passe par un lien temporaire personnel." />
      <div className="space-y-6">
        {byEnrollment.map(({ e, docs }) => (
          <Panel key={e.enrollment.id}>
            <PanelHeader title={e.program?.title ?? e.session.title} description={`Session ${e.session.code}`} />
            <DocumentTable docs={docs} downloadBase="/moi/documents" emptyTitle="Aucun document" emptyDescription="Aucun document n'a encore été transmis pour cette inscription." />
          </Panel>
        ))}
        {others.length ? (
          <Panel>
            <PanelHeader title="Autres documents" />
            <DocumentTable docs={others} downloadBase="/moi/documents" emptyTitle="Aucun document" emptyDescription="" />
          </Panel>
        ) : null}
        {!ctx.enrollments.length && !others.length ? (
          <Panel>
            <DocumentTable docs={[]} downloadBase="/moi/documents" emptyTitle="Aucun document" emptyDescription="Aucun document n'a été transmis pour le moment." />
          </Panel>
        ) : null}
      </div>
    </>
  );
}
