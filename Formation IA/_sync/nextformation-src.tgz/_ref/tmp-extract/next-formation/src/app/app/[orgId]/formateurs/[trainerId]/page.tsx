import Link from "next/link";
import { notFound } from "next/navigation";
import { and, desc, eq, gte } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { addUnavailabilityAction, deleteUnavailabilityAction, inviteTrainerAction, updateTrainerAction, uploadTrainerDocumentAction } from "@/server/actions/trainers";
import { ACCEPT_ATTR, ALLOWED_LABEL } from "@/server/documents/upload-rules";
import { todayParis } from "@/lib/time";
import { fmtDate } from "@/lib/dates";
import { formatCents } from "@/lib/money";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Checkbox, Field, Input, Select } from "@/components/ui/field";
import { EmptyState, KeyValue, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { ActionButton, ActionForm } from "@/components/admin/action-form";
import { FormDialog } from "@/components/admin/form-dialog";
import { TrainerFields, trainerKindLabels } from "@/components/catalog/trainer-fields";
import { DocumentList } from "@/components/crm/documents";
import { FadeIn } from "@/components/ui/motion";
import { listMissions, missionFormOptions } from "@/server/missions/queries";
import { MissionsTable, ProposeMissionDialog } from "@/components/missions/mission-ui";

export const dynamic = "force-dynamic";
const partLabels: Record<string, string> = { matin: "Matin", apres_midi: "Après-midi", journee: "Journée", soir: "Soir" };
const roleLabels: Record<string, string> = { principal: "Principal", intervenant: "Intervenant", jury: "Jury", tuteur_pedagogique: "Tuteur pédagogique" };

export default async function TrainerPage({ params }: { params: Promise<{ orgId: string; trainerId: string }> }) {
  const { orgId, trainerId } = await params;
  const base = `/app/${orgId}`;
  const ctx = await guardOrg(orgId, `${base}/formateurs/${trainerId}`, "sessions.view");
  if (!/^[0-9a-f-]{36}$/i.test(trainerId)) notFound();
  if (ctx.trainerOnly && ctx.trainerId !== trainerId) notFound();
  const [trainer] = await db.select().from(schema.trainers).where(and(eq(schema.trainers.id, trainerId), eq(schema.trainers.orgId, ctx.org.id))).limit(1);
  if (!trainer) notFound();
  const canManage = ctx.permissions.has("sessions.manage");
  const today = todayParis();

  const [assignments, unavailabilities, docs, pendingInvite] = await Promise.all([
    db
      .select({ st: schema.sessionTrainers, s: schema.trainingSessions, groupName: schema.groups.name })
      .from(schema.sessionTrainers)
      .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.sessionTrainers.sessionId))
      .leftJoin(schema.groups, eq(schema.groups.id, schema.sessionTrainers.groupId))
      .where(and(eq(schema.sessionTrainers.orgId, ctx.org.id), eq(schema.sessionTrainers.trainerId, trainer.id)))
      .orderBy(desc(schema.trainingSessions.startDate)),
    db.select().from(schema.trainerUnavailabilities).where(and(eq(schema.trainerUnavailabilities.orgId, ctx.org.id), eq(schema.trainerUnavailabilities.trainerId, trainer.id), gte(schema.trainerUnavailabilities.endDate, today))).orderBy(schema.trainerUnavailabilities.startDate),
    db.select().from(schema.documents).where(and(eq(schema.documents.orgId, ctx.org.id), eq(schema.documents.trainerId, trainer.id))).orderBy(desc(schema.documents.createdAt)),
    db.select({ id: schema.invitations.id, email: schema.invitations.email, expiresAt: schema.invitations.expiresAt }).from(schema.invitations).where(and(eq(schema.invitations.trainerId, trainer.id), eq(schema.invitations.status, "pending"))).orderBy(desc(schema.invitations.createdAt)).limit(1).then((r) => r[0] ?? null),
  ]);
  // Missions (proposition, réponse, contrat de prestation) : visibles avec le droit planning, gérées avec planning.manage.
  const canSeeMissions = ctx.permissions.has("planning.view");
  const canManageMissions = ctx.permissions.has("planning.manage") && !ctx.trainerOnly && ctx.trainerId !== trainer.id;
  const [missions, missionOptions] = canSeeMissions ? await Promise.all([listMissions(ctx.org.id, { trainerId: trainer.id, limit: 50 }), missionFormOptions(ctx.org.id, { excludeTrainerId: ctx.trainerId })]) : [[], null];
  const hasQualDocs = docs.some((d) => d.category === "cv" || d.category === "diplome");
  const next = !hasQualDocs ? "Déposer le CV ou un diplôme (preuve de qualification, indicateur 21)" : !trainer.userId ? "Inviter le formateur à l'espace formateur pour l'émargement et le planning" : assignments.some((a) => a.s.status === "ouverte" || a.s.status === "confirmee" || a.s.status === "en_cours") ? "Formateur affecté : suivre les séances dans le planning" : "Aucune affectation en cours : affectez-le depuis une session";

  return (
    <FadeIn>
      <PageHeader
        breadcrumb={[{ label: "Formation" }, { label: "Formateurs", href: `${base}/formateurs` }, { label: `${trainer.firstName} ${trainer.lastName}` }]}
        title={`${trainer.firstName} ${trainer.lastName}`}
        description={[trainerKindLabels[trainer.kind], trainer.companyName, trainer.email].filter(Boolean).join(" · ")}
        actions={
          <>
            {trainer.isActive ? <Badge tone="ok">Actif</Badge> : <Badge>Inactif</Badge>}
            {trainer.userId ? <Badge tone="accent">Espace formateur ouvert</Badge> : null}
            {canManage && !trainer.userId ? (
              <FormDialog action={inviteTrainerAction} trigger="Inviter à l'espace formateur" triggerVariant="accent" title="Inviter à l'espace formateur" description="Crée une invitation (rôle formateur, périmètre limité aux séances affectées), valable 7 jours." submitLabel="Envoyer l'invitation">
                <input type="hidden" name="orgId" value={ctx.org.id} />
                <input type="hidden" name="trainerId" value={trainer.id} />
                <Field label="Adresse e-mail" required htmlFor="inv-email">
                  <Input id="inv-email" name="email" type="email" required defaultValue={trainer.email ?? ""} />
                </Field>
                {pendingInvite ? <Checkbox name="resend" value="1" label={`Renvoyer (invitation en attente pour ${pendingInvite.email}, expire le ${fmtDate(pendingInvite.expiresAt)})`} /> : null}
              </FormDialog>
            ) : null}
            {canManage ? (
              <FormDialog action={updateTrainerAction} trigger="Modifier" triggerVariant="secondary" title="Modifier la fiche formateur" submitLabel="Enregistrer" wide>
                <TrainerFields orgId={ctx.org.id} trainer={trainer} prefix="et" />
              </FormDialog>
            ) : null}
          </>
        }
      />
      <Notice tone={!hasQualDocs ? "warn" : "info"} title="Prochaine action" className="mb-6">
        {next}
      </Notice>

      <div className="grid gap-6 lg:grid-cols-[minmax(0,2fr)_minmax(0,1fr)]">
        <div className="space-y-6">
          <Panel>
            <PanelHeader title="Fiche" />
            <div className="grid gap-6 p-5 md:grid-cols-2">
              <KeyValue
                items={[
                  { k: "Statut", v: trainerKindLabels[trainer.kind] },
                  { k: "Structure", v: trainer.companyName },
                  { k: "SIRET", v: trainer.siret ? <span className="num">{trainer.siret}</span> : null },
                  { k: "NDA", v: trainer.nda ? <span className="num">{trainer.nda}</span> : null },
                  { k: "Tarif horaire HT", v: trainer.hourlyRateCents != null ? <span className="num">{formatCents(trainer.hourlyRateCents)}</span> : null },
                ]}
              />
              <KeyValue
                items={[
                  { k: "E-mail", v: trainer.email },
                  { k: "Téléphone", v: trainer.phone ? <span className="num">{trainer.phone}</span> : null },
                  { k: "Domaines", v: Array.isArray(trainer.skills) && (trainer.skills as string[]).length ? <span className="flex flex-wrap gap-1">{(trainer.skills as string[]).map((s) => <Badge key={s}>{s}</Badge>)}</span> : null },
                  { k: "Compte", v: trainer.userId ? "Rattaché (espace formateur)" : pendingInvite ? `Invitation en attente (${pendingInvite.email})` : "Aucun compte" },
                ]}
              />
            </div>
            {trainer.qualifications || trainer.notes ? (
              <div className="space-y-3 border-t border-line px-5 py-4 text-[13.5px]">
                {trainer.qualifications ? (
                  <div>
                    <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">Qualifications</p>
                    <p className="mt-1 whitespace-pre-line text-ink">{trainer.qualifications}</p>
                  </div>
                ) : null}
                {trainer.notes ? (
                  <div>
                    <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">Notes</p>
                    <p className="mt-1 whitespace-pre-line text-ink-2">{trainer.notes}</p>
                  </div>
                ) : null}
              </div>
            ) : null}
          </Panel>

          <Panel>
            <PanelHeader title="Documents" description="CV, diplômes et habilitations : preuves de qualification des formateurs (Qualiopi, indicateur 21)." />
            <DocumentList orgId={ctx.org.id} docs={docs} emptyTitle="Aucun document" emptyDescription="Déposez le CV et les diplômes du formateur." />
            {canManage ? (
              <ActionForm action={uploadTrainerDocumentAction} submitLabel="Déposer" submitVariant="secondary" submitSize="sm" className="border-t border-line p-5">
                <input type="hidden" name="orgId" value={ctx.org.id} />
                <input type="hidden" name="trainerId" value={trainer.id} />
                <div className="mb-3 grid gap-4 md:grid-cols-[160px_1fr_1fr]">
                  <Field label="Catégorie" htmlFor="td-cat">
                    <Select id="td-cat" name="category" defaultValue="cv">
                      <option value="cv">CV</option>
                      <option value="diplome">Diplôme / titre</option>
                      <option value="justificatif">Habilitation / justificatif</option>
                    </Select>
                  </Field>
                  <Field label="Intitulé" htmlFor="td-title" help="Facultatif.">
                    <Input id="td-title" name="title" placeholder="Master MEEF, habilitation électrique B2V…" />
                  </Field>
                  <Field label="Fichier" required htmlFor="td-file" help={`Formats : ${ALLOWED_LABEL}.`}>
                    <Input id="td-file" name="file" type="file" accept={ACCEPT_ATTR} required className="py-1.5" />
                  </Field>
                </div>
              </ActionForm>
            ) : null}
          </Panel>

          <Panel>
            <PanelHeader title="Sessions affectées" description="Lecture : les affectations se font depuis la session ou le planning." />
            {assignments.length ? (
              <Table>
                <thead>
                  <tr>
                    <Th>Session</Th>
                    <Th>Rôle</Th>
                    <Th>Dates</Th>
                    <Th>Statut</Th>
                  </tr>
                </thead>
                <tbody>
                  {assignments.map(({ st, s, groupName }) => (
                    <tr key={st.id}>
                      <Td>
                        <Link href={`${base}/sessions/${s.id}`} className="font-medium text-ink hover:underline">
                          {s.title}
                        </Link>
                        <span className="num block text-[12px] text-ink-3">
                          {s.code}
                          {groupName ? ` · groupe ${groupName}` : ""}
                        </span>
                      </Td>
                      <Td>{roleLabels[st.role] ?? st.role}</Td>
                      <Td className="num whitespace-nowrap">
                        {fmtDate(s.startDate)} au {fmtDate(s.endDate)}
                      </Td>
                      <Td>
                        <StatusBadge status={s.status} />
                      </Td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            ) : (
              <EmptyState title="Aucune affectation" description="Ce formateur n'est affecté à aucune session." className="py-8" />
            )}
          </Panel>

          {canSeeMissions && missionOptions ? (
            <Panel>
              <PanelHeader
                title="Missions"
                description="Propositions de mission, réponses et contrats de prestation de ce formateur."
                actions={
                  canManageMissions && trainer.isActive ? (
                    <ProposeMissionDialog orgId={ctx.org.id} options={missionOptions} fixedTrainer={{ id: trainer.id, firstName: trainer.firstName, lastName: trainer.lastName, hourlyRateCents: trainer.hourlyRateCents }} triggerVariant="secondary" triggerSize="sm" />
                  ) : null
                }
              />
              <MissionsTable
                orgId={ctx.org.id}
                rows={missions}
                canManage={canManageMissions}
                canGenerate={canManageMissions && ctx.permissions.has("documents.generate")}
                canDownload={ctx.permissions.has("documents.view")}
                ownTrainerId={ctx.trainerId}
                trainers={missionOptions.trainers}
                showTrainer={false}
                emptyTitle="Aucune mission"
                emptyDescription="Aucune mission n'a encore été proposée à ce formateur."
              />
              {missions.length ? (
                <div className="border-t border-line px-5 py-3 text-[13px]">
                  <Link href={`${base}/formateurs/missions?formateur=${trainer.id}`} className="font-medium text-ink underline-offset-4 hover:underline">
                    Toutes les missions de ce formateur
                  </Link>
                </div>
              ) : null}
            </Panel>
          ) : null}
        </div>

        <Panel className="self-start">
          <PanelHeader
            title="Indisponibilités"
            description="À venir. Prises en compte par le planning."
            actions={
              canManage ? (
                <FormDialog action={addUnavailabilityAction} trigger="Ajouter" triggerVariant="secondary" triggerSize="sm" title="Nouvelle indisponibilité" submitLabel="Enregistrer">
                  <input type="hidden" name="orgId" value={ctx.org.id} />
                  <input type="hidden" name="trainerId" value={trainer.id} />
                  <div className="grid gap-4 sm:grid-cols-2">
                    <Field label="Du" required htmlFor="un-start">
                      <Input id="un-start" name="startDate" type="date" required defaultValue={today} />
                    </Field>
                    <Field label="Au" htmlFor="un-end" help="Vide = même jour.">
                      <Input id="un-end" name="endDate" type="date" />
                    </Field>
                  </div>
                  <Field label="Période" htmlFor="un-part">
                    <Select id="un-part" name="part" defaultValue="">
                      <option value="">Toute la journée</option>
                      {Object.entries(partLabels).map(([v, l]) => (
                        <option key={v} value={v}>
                          {l}
                        </option>
                      ))}
                    </Select>
                  </Field>
                  <Field label="Motif" htmlFor="un-reason">
                    <Input id="un-reason" name="reason" placeholder="Congés, autre mission…" />
                  </Field>
                </FormDialog>
              ) : null
            }
          />
          {unavailabilities.length ? (
            <ul className="divide-y divide-line">
              {unavailabilities.map((u) => (
                <li key={u.id} className="flex items-center justify-between gap-3 px-5 py-3 text-[13.5px]">
                  <div>
                    <span className="num">
                      {fmtDate(u.startDate)}
                      {u.endDate !== u.startDate ? ` au ${fmtDate(u.endDate)}` : ""}
                    </span>
                    <span className="block text-[12px] text-ink-3">
                      {u.part ? partLabels[u.part] : "Journée entière"}
                      {u.reason ? ` · ${u.reason}` : ""}
                    </span>
                  </div>
                  {canManage ? <ActionButton action={deleteUnavailabilityAction} fields={{ orgId: ctx.org.id, unavailabilityId: u.id }} label="Retirer" variant="ghost" /> : null}
                </li>
              ))}
            </ul>
          ) : (
            <EmptyState title="Aucune indisponibilité à venir" className="py-8" />
          )}
        </Panel>
      </div>
    </FadeIn>
  );
}
