import type { Metadata } from "next";
import Link from "next/link";
import { publisher } from "@/lib/legal";
import { Fill, LegalDoc } from "../legal-doc";

export const metadata: Metadata = { title: "Politique de confidentialité", description: "Données traitées par Next Formation, finalités, durées de conservation, sous-traitants et exercice de vos droits RGPD.", alternates: { canonical: "/confidentialite" } };
export const dynamic = "force-dynamic";

export default function ConfidentialitePage() {
  const p = publisher();
  const contact = p.dpoEmail ? <a href={`mailto:${p.dpoEmail}`}>{p.dpoEmail}</a> : <Fill value="" label="adresse dédiée" />;
  return (
    <LegalDoc title="Confidentialité" updated="23 octobre 2026">
      <p>
        Cette politique explique quelles données Next Formation traite, pourquoi, combien de temps et avec qui. Elle distingue deux situations, car les responsabilités ne
        sont pas les mêmes.
      </p>

      <h2>1. Les données de vos apprenants et contacts : vous êtes responsable, nous sommes sous-traitant</h2>
      <p>
        Lorsque vous gérez votre organisme de formation ou votre CFA dans Next Formation, votre organisme est <strong>responsable de traitement</strong> des données de
        ses apprenants, candidats, contacts d&apos;entreprise, tuteurs et formateurs. <Fill value={p.name} label="raison sociale" /> agit en <strong>sous-traitant</strong> (article 28 du RGPD) : nous traitons ces données uniquement
        pour fournir le service, sur vos instructions, et ne les utilisons jamais à d&apos;autres fins, notamment pas pour entraîner des modèles d&apos;IA.
      </p>
      <p>
        Les durées de conservation sont paramétrées par catégorie de données (dossiers d&apos;inscription, feuilles d&apos;émargement, documents contractuels, preuves
        qualité) selon les textes applicables ; les valeurs retenues sont validées par le responsable de traitement. Les apprenants et contacts exercent leurs droits
        auprès de l&apos;organisme, que nous assistons (export, anonymisation ou suppression autorisée).
      </p>

      <h2>2. Les données de votre compte : nous sommes responsable</h2>
      <ul>
        <li>
          <strong>Données</strong> : nom, prénom, adresse e-mail professionnelle, organisme, mot de passe (haché, jamais lisible), paramètres de double
          authentification, journal de connexion (date, adresse IP, navigateur) et d&apos;actions.
        </li>
        <li>
          <strong>Finalités</strong> : créer et sécuriser votre accès, fournir le service, vous envoyer les e-mails nécessaires (vérification, réinitialisation,
          rappels d&apos;échéances), prévenir la fraude.
        </li>
        <li>
          <strong>Bases légales</strong> : exécution du contrat ; intérêt légitime pour la sécurité et le journal d&apos;audit ; obligations légales pour la facturation.
        </li>
        <li>
          <strong>Durées</strong> : pendant la vie du compte, puis 3 ans pour la relation commerciale ; journal d&apos;audit 1 an ; sessions supprimées à expiration ;
          pièces comptables 10 ans.
        </li>
      </ul>

      <h2>3. Sécurité</h2>
      <p>
        Coordonnées bancaires et secrets d&apos;authentification sont chiffrés au repos. Les accès sensibles demandent une vérification récente. Chaque organisme est
        strictement isolé des autres ; les pièces administratives, CV et notes pédagogiques ne sont visibles qu&apos;avec la permission dédiée. Les fichiers sont stockés
        de façon privée et ne sont servis que par des liens temporaires. Toute écriture ou lecture sensible est journalisée.
      </p>

      <h2>4. Sous-traitants</h2>
      <ul>
        <li>
          Hébergement de l&apos;application et de la base de données : <Fill value={p.host} label="hébergeur" />.
        </li>
        <li>E-mails transactionnels : Resend (si activé).</li>
        <li>Assistant et aide à la rédaction : fournisseur d&apos;IA configuré par l&apos;organisme (Anthropic, OpenAI ou xAI), uniquement si la fonction est activée, avec un contexte réduit au strict nécessaire et une validation humaine avant tout effet.</li>
        <li>Signature électronique et e-learning (Moodle, SCORM) : prestataires connectés uniquement si l&apos;option est activée par l&apos;organisme.</li>
      </ul>
      <p>Les transferts hors de l&apos;Union européenne sont encadrés par les clauses contractuelles types de la Commission européenne.</p>

      <h2>5. Cookies</h2>
      <p>
        Next Formation dépose un seul cookie, strictement nécessaire : <code>nextformation_session</code>, qui maintient votre connexion. Il n&apos;y a ni cookie publicitaire ni outil
        de mesure d&apos;audience tiers ; aucun consentement n&apos;est donc requis.
      </p>

      <h2>6. Vos droits</h2>
      <p>
        Vous pouvez accéder à vos données, les rectifier, les effacer, en limiter le traitement, vous y opposer et en demander la portabilité en écrivant à {contact}.
        Vous pouvez aussi saisir la CNIL (cnil.fr). Les conditions d&apos;utilisation du service sont décrites dans les <Link href="/cgu">conditions générales</Link>.
      </p>
    </LegalDoc>
  );
}
