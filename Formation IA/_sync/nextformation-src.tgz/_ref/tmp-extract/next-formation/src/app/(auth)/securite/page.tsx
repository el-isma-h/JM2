import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/server/auth";
import { ElevateForm, TotpSetup } from "./forms";

export const metadata: Metadata = { title: "Sécurité" };

/**
 * /securite?next=/app/... : vérification renforcée avant un accès sensible.
 * /securite?setup=1 : activation de l'authentification renforcée (TOTP).
 */
export default async function SecurityPage({ searchParams }: { searchParams: Promise<{ next?: string; setup?: string }> }) {
  const sp = await searchParams;
  const user = await getCurrentUser();
  if (!user) redirect(`/connexion?next=${encodeURIComponent(`/securite?next=${sp.next ?? "/app"}`)}`);
  if (sp.setup === "1" || !user.totpEnabled) {
    return (
      <div>
        <h1 className="text-[30px] text-ink">Authentification renforcée</h1>
        <p className="mt-3 text-[14px] text-ink-2">
          Les accès sensibles (RIB central, exports, administration de la sécurité) demandent un second facteur. Scannez le code avec une application d&apos;authentification (Google Authenticator, Authy, 1Password…).
        </p>
        <TotpSetup next={sp.next} />
      </div>
    );
  }
  return (
    <div>
      <h1 className="text-[30px] text-ink">Vérification renforcée</h1>
      <p className="mt-3 text-[14px] text-ink-2">Cet accès est sensible. Saisissez le code de votre application d&apos;authentification.</p>
      <ElevateForm next={sp.next ?? "/app"} totp />
    </div>
  );
}
