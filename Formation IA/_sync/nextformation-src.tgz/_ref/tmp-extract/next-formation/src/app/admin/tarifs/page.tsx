import { asc } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardAdmin } from "@/server/guard";
import { checkPrice, pricingUnitLabels } from "@/server/pricing/compute";
import { savePricingPlanAction } from "@/server/actions/admin-pricing";
import { deletePricingPlanAction, reseedPricingAction, togglePricingActiveAction } from "@/server/actions/admin";
import { formatCents } from "@/lib/money";
import { fmtDate } from "@/lib/dates";
import { Badge } from "@/components/ui/badge";
import { EmptyState, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { ActionButton } from "@/components/admin/action-form";
import { PricingDialog, type PlanFormValue } from "@/components/admin/pricing-dialog";

export const dynamic = "force-dynamic";

export default async function PricingAdminPage() {
  await guardAdmin("/admin/tarifs");
  const rows = await db.select().from(schema.pricingPlans).orderBy(asc(schema.pricingPlans.isOption), asc(schema.pricingPlans.sortOrder), asc(schema.pricingPlans.name));
  const toForm = (p: (typeof rows)[number]): PlanFormValue => ({
    id: p.id,
    code: p.code,
    name: p.name,
    description: p.description ?? "",
    isOption: p.isOption,
    unit: p.unit,
    priceCents: p.priceCents,
    priceMonthlyCents: p.priceMonthlyCents,
    referencePriceCents: p.referencePriceCents,
    referenceMonthlyCents: p.referenceMonthlyCents,
    referenceLabel: p.referenceLabel ?? "",
    referenceUrl: p.referenceUrl ?? "",
    referenceCheckedAt: p.referenceCheckedAt ?? "",
    discountRate: p.discountRate,
    calculationNote: p.calculationNote ?? "",
    features: Array.isArray(p.features) ? (p.features as string[]) : [],
    isActive: p.isActive,
    sortOrder: p.sortOrder,
  });
  const alerts = rows.map((p) => ({ p, c: checkPrice({ priceCents: p.priceCents, referencePriceCents: p.referencePriceCents, discountRate: p.discountRate, unit: p.unit }) })).filter((x) => x.c.level === "danger");

  return (
    <>
      <PageHeader
        title="Tarifs"
        description="Grille publique Next Formation : chaque ligne porte son prix de référence, sa source et sa date de relevé. Règle contrôlée : jamais au-dessus de 90 % de la référence ; aucun prix inventé."
        actions={
          <>
            <ActionButton action={reseedPricingAction} fields={{ overwrite: "0" }} label="Compléter depuis la grille sourcée" />
            <ActionButton action={reseedPricingAction} fields={{ overwrite: "1" }} label="Réaligner sur la référence" variant="danger" confirm={{ title: "Réaligner toute la grille", description: "Les prix de chaque ligne connue seront recalculés à partir de la grille de référence sourcée. Les lignes ajoutées manuellement sont conservées.", phrase: "REALIGNER", confirmLabel: "Réaligner", danger: true }} />
            <PricingDialog action={savePricingPlanAction} trigger="Nouvelle ligne" triggerVariant="primary" />
          </>
        }
      />
      {alerts.length ? (
        <Notice tone="danger" className="mb-6" title={`${alerts.length} ligne(s) au-dessus du plafond de 90 %`}>
          {alerts.map((a) => `${a.p.name} : ${a.c.message}`).join(" ")}
        </Notice>
      ) : null}
      <Panel>
        <PanelHeader title="Grille" description={`${rows.filter((r) => !r.isOption).length} offre(s), ${rows.filter((r) => r.isOption).length} option(s).`} />
        {rows.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Ligne</Th>
                <Th>Unité</Th>
                <Th num>Référence</Th>
                <Th num>Next Formation</Th>
                <Th num>Sans engagement</Th>
                <Th>Source</Th>
                <Th>Contrôle</Th>
                <Th>État</Th>
                <Th />
              </tr>
            </thead>
            <tbody>
              {rows.map((p) => {
                const c = checkPrice({ priceCents: p.priceCents, referencePriceCents: p.referencePriceCents, discountRate: p.discountRate, unit: p.unit });
                return (
                  <tr key={p.id}>
                    <Td>
                      <span className="font-medium">{p.name}</span>
                      {p.isOption ? (
                        <Badge tone="neutral" className="ml-2">
                          Option
                        </Badge>
                      ) : null}
                      <p className="num text-[11.5px] text-ink-3">{p.code}</p>
                    </Td>
                    <Td className="text-[12.5px] text-ink-2">{pricingUnitLabels[p.unit] ?? p.unit}</Td>
                    <Td num>{p.referencePriceCents === null ? "-" : formatCents(p.referencePriceCents)}</Td>
                    <Td num className="font-medium">{p.unit === "sur_devis" ? "Sur devis" : p.unit === "inclus" ? "Inclus" : formatCents(p.priceCents)}</Td>
                    <Td num>{p.priceMonthlyCents === null ? "-" : formatCents(p.priceMonthlyCents)}</Td>
                    <Td className="max-w-[220px] text-[12px] text-ink-2">
                      {p.referenceLabel ?? "-"}
                      {p.referenceCheckedAt ? <span className="block text-ink-3">relevé le {fmtDate(p.referenceCheckedAt)}</span> : null}
                      {p.referenceUrl ? (
                        <a href={p.referenceUrl} target="_blank" rel="noreferrer" className="block truncate text-ink-3 underline">
                          {p.referenceUrl}
                        </a>
                      ) : null}
                    </Td>
                    <Td>
                      <Badge tone={c.level === "danger" ? "danger" : c.level === "info" ? "info" : "ok"}>{c.level === "danger" ? "Au-dessus du plafond" : c.level === "info" ? "À vérifier" : "Conforme"}</Badge>
                      <p className="mt-1 max-w-[200px] text-[11.5px] text-ink-3">{c.message}</p>
                    </Td>
                    <Td>{p.isActive ? <Badge tone="ok">Publiée</Badge> : <Badge tone="neutral">Masquée</Badge>}</Td>
                    <Td>
                      <div className="flex flex-wrap justify-end gap-1">
                        <PricingDialog action={savePricingPlanAction} trigger="Modifier" triggerVariant="ghost" plan={toForm(p)} />
                        <ActionButton action={togglePricingActiveAction} fields={{ id: p.id }} label={p.isActive ? "Masquer" : "Publier"} variant="ghost" />
                        <ActionButton action={deletePricingPlanAction} fields={{ id: p.id }} label="Supprimer" variant="ghost" confirm={{ title: "Supprimer la ligne", description: `${p.name} (${p.code}) sera retirée de la grille.`, phrase: p.code, confirmLabel: "Supprimer", danger: true }} />
                      </div>
                    </Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Grille vide" description="Chargez la grille sourcée (référence publique × 0,90) ou créez une ligne." />
        )}
      </Panel>
    </>
  );
}
