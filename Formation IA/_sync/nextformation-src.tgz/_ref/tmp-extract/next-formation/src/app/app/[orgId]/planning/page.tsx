import Link from "next/link";
import { and, asc, eq, gte, inArray, lte } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { trainerSessionIds } from "@/server/authz";
import { listPeriods } from "@/server/planning/service";
import { addClosureAction, addUnavailabilityAction, cancelSlotAction, createSlotSeriesAction, updateSlotAction } from "@/server/actions/planning";
import { todayParis } from "@/lib/time";
import { fmtDate } from "@/lib/dates";
import { Button } from "@/components/ui/button";
import { Checkbox, Field, Input, Select, Textarea } from "@/components/ui/field";
import { EmptyState, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { StatusBadge } from "@/components/ui/badge";
import { FormDialog } from "@/components/admin/form-dialog";
import { ActionButton } from "@/components/admin/action-form";
import { readParam } from "@/components/admin/pagination";
import { MonthCalendar, WeekCalendar, weekStart, monthRange, type CalendarItem } from "@/components/planning/calendar";

export const dynamic = "force-dynamic";

const WEEKDAYS: [number, string][] = [
  [1, "Lundi"],
  [2, "Mardi"],
  [3, "Mercredi"],
  [4, "Jeudi"],
  [5, "Vendredi"],
  [6, "Samedi"],
];

function shift(iso: string, days: number) {
  const d = new Date(`${iso}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}
function shiftMonth(iso: string, n: number) {
  const [y, m] = iso.split("-").map(Number);
  const d = new Date(Date.UTC(y, m - 1 + n, 1));
  return d.toISOString().slice(0, 10);
}

export default async function PlanningPage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const base = `/app/${orgId}`;
  const ctx = await guardOrg(orgId, `${base}/planning`, "planning.view");
  const sp = await searchParams;
  const vue = readParam(sp.vue) === "mois" ? "mois" : "semaine";
  const today = todayParis();
  const dateRaw = readParam(sp.date);
  const date = dateRaw && /^\d{4}-\d{2}-\d{2}$/.test(dateRaw) ? dateRaw : today;
  const filters = { sessionId: readParam(sp.session), trainerId: readParam(sp.formateur), roomId: readParam(sp.salle), siteId: readParam(sp.site) };
  const range = vue === "mois" ? { from: weekStart(monthRange(date).first), to: shift(weekStart(monthRange(date).last), 6) } : { from: weekStart(date), to: shift(weekStart(date), 6) };
  const canManage = ctx.permissions.has("planning.manage");
  const scope = await trainerSessionIds(ctx);

  const [rows, sessions, trainers, sites, rooms, groups, modules, closures] = await Promise.all([
    listPeriods(ctx, range, filters),
    db
      .select({ id: schema.trainingSessions.id, code: schema.trainingSessions.code, title: schema.trainingSessions.title, programVersionId: schema.trainingSessions.programVersionId, startDate: schema.trainingSessions.startDate, endDate: schema.trainingSessions.endDate, status: schema.trainingSessions.status })
      .from(schema.trainingSessions)
      .where(and(eq(schema.trainingSessions.orgId, orgId), scope ? (scope.length ? inArray(schema.trainingSessions.id, scope) : eq(schema.trainingSessions.id, "00000000-0000-0000-0000-000000000000")) : inArray(schema.trainingSessions.status, ["brouillon", "ouverte", "confirmee", "en_cours"])))
      .orderBy(asc(schema.trainingSessions.startDate)),
    db.select({ id: schema.trainers.id, firstName: schema.trainers.firstName, lastName: schema.trainers.lastName }).from(schema.trainers).where(and(eq(schema.trainers.orgId, orgId), eq(schema.trainers.isActive, true))).orderBy(asc(schema.trainers.lastName)),
    db.select({ id: schema.sites.id, name: schema.sites.name }).from(schema.sites).where(eq(schema.sites.orgId, orgId)).orderBy(asc(schema.sites.name)),
    db.select({ id: schema.rooms.id, name: schema.rooms.name, siteId: schema.rooms.siteId }).from(schema.rooms).where(eq(schema.rooms.orgId, orgId)).orderBy(asc(schema.rooms.name)),
    db.select({ id: schema.groups.id, name: schema.groups.name, sessionId: schema.groups.sessionId }).from(schema.groups).where(eq(schema.groups.orgId, orgId)).orderBy(asc(schema.groups.name)),
    db.select({ id: schema.modules.id, title: schema.modules.title, programVersionId: schema.modules.programVersionId, position: schema.modules.position }).from(schema.modules).where(eq(schema.modules.orgId, orgId)).orderBy(asc(schema.modules.position)),
    db.select().from(schema.closures).where(and(eq(schema.closures.orgId, orgId), lte(schema.closures.startDate, range.to), gte(schema.closures.endDate, range.from))),
  ]);

  const items: CalendarItem[] = rows.map((r) => ({
    periodId: r.period.id,
    slotId: r.slot.id,
    date: r.slot.date,
    startTime: r.period.startTime,
    endTime: r.period.endTime,
    part: r.period.part,
    status: r.period.status,
    slotStatus: r.slot.status,
    sessionCode: r.session.code,
    sessionTitle: r.session.title,
    moduleTitle: r.moduleTitle,
    trainerName: r.trainerFirst ? `${r.trainerFirst} ${r.trainerLast}` : null,
    roomName: r.roomName,
    groupName: r.groupName,
  }));
  const slotsInRange = [...new Map(rows.map((r) => [r.slot.id, r])).values()];
  const sessionById = new Map(sessions.map((s) => [s.id, s]));
  const sessionLabel = (id: string) => {
    const s = sessionById.get(id);
    return s ? `${s.code} : ${s.title}` : id;
  };
  const qs = (patch: Record<string, string | undefined>) => {
    const q = new URLSearchParams();
    const all = { vue, date, session: filters.sessionId, formateur: filters.trainerId, salle: filters.roomId, site: filters.siteId, ...patch };
    for (const [k, v] of Object.entries(all)) if (v) q.set(k, v);
    return `${base}/planning?${q.toString()}`;
  };
  const prev = vue === "mois" ? shiftMonth(date, -1) : shift(date, -7);
  const next = vue === "mois" ? shiftMonth(date, 1) : shift(date, 7);
  const title = vue === "mois" ? fmtDate(monthRange(date).first, "MMMM yyyy") : `Semaine du ${fmtDate(weekStart(date), "d MMMM yyyy")}`;

  const seriesForm = (
    <>
      <input type="hidden" name="orgId" value={orgId} />
      <Field label="Session" required htmlFor="s-session" help="Les dates suivent les jours de centre du rythme de la session ; les horaires matin / après-midi de la session, sinon ceux de l'organisme.">
        <Select id="s-session" name="sessionId" required defaultValue={filters.sessionId ?? ""}>
          <option value="">Choisir une session</option>
          {sessions.map((s) => (
            <option key={s.id} value={s.id}>
              {s.code} : {s.title} ({fmtDate(s.startDate)} au {fmtDate(s.endDate)})
            </option>
          ))}
        </Select>
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Du" required htmlFor="s-from">
          <Input id="s-from" name="from" type="date" required defaultValue={date} />
        </Field>
        <Field label="Au" required htmlFor="s-to">
          <Input id="s-to" name="to" type="date" required defaultValue={shift(date, 6)} />
        </Field>
      </div>
      <Field label="Périodes de chaque séance" required help="Chaque période est indépendante : horaires, présences, signature et clôture propres.">
        <div className="flex gap-5">
          <Checkbox name="parts" value="matin" defaultChecked label="Matin" />
          <Checkbox name="parts" value="apres_midi" defaultChecked label="Après-midi" />
        </div>
      </Field>
      <Field label="Jours de centre (facultatif)" help="Vide : jours du rythme de la session (lundi à vendredi si non défini).">
        <div className="flex flex-wrap gap-4">
          {WEEKDAYS.map(([n, l]) => (
            <Checkbox key={n} name="weekdays" value={String(n)} label={l} />
          ))}
        </div>
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Matin : début" htmlFor="s-ms" help="Vide : horaires de la session / de l'organisme.">
          <Input id="s-ms" name="morningStart" type="time" />
        </Field>
        <Field label="Matin : fin" htmlFor="s-me">
          <Input id="s-me" name="morningEnd" type="time" />
        </Field>
        <Field label="Après-midi : début" htmlFor="s-as">
          <Input id="s-as" name="afternoonStart" type="time" />
        </Field>
        <Field label="Après-midi : fin" htmlFor="s-ae">
          <Input id="s-ae" name="afternoonEnd" type="time" />
        </Field>
      </div>
      <Field label="Module" htmlFor="s-module" help="Doit appartenir au programme de la session (vérifié côté serveur).">
        <Select id="s-module" name="moduleId" defaultValue="">
          <option value="">Aucun</option>
          {sessions.map((s) => {
            const list = modules.filter((m) => m.programVersionId === s.programVersionId);
            return list.length ? (
              <optgroup key={s.id} label={s.code}>
                {list.map((m) => (
                  <option key={`${s.id}-${m.id}`} value={m.id}>
                    {m.title}
                  </option>
                ))}
              </optgroup>
            ) : null;
          })}
        </Select>
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Formateur" htmlFor="s-trainer">
          <Select id="s-trainer" name="trainerId" defaultValue={filters.trainerId ?? ""}>
            <option value="">Non affecté</option>
            {trainers.map((t) => (
              <option key={t.id} value={t.id}>
                {t.lastName} {t.firstName}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Groupe" htmlFor="s-group">
          <Select id="s-group" name="groupId" defaultValue="">
            <option value="">Toute la session</option>
            {groups.map((g) => (
              <option key={g.id} value={g.id}>
                {sessionById.get(g.sessionId)?.code ?? ""} · {g.name}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Site" htmlFor="s-site">
          <Select id="s-site" name="siteId" defaultValue={filters.siteId ?? ""}>
            <option value="">Site de la session</option>
            {sites.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Salle" htmlFor="s-room">
          <Select id="s-room" name="roomId" defaultValue={filters.roomId ?? ""}>
            <option value="">Salle de la session</option>
            {rooms.map((r) => (
              <option key={r.id} value={r.id}>
                {r.name}
              </option>
            ))}
          </Select>
        </Field>
      </div>
      <Field label="Intitulé (facultatif)" htmlFor="s-title">
        <Input id="s-title" name="title" maxLength={160} />
      </Field>
      <Checkbox name="force" value="1" label="Créer malgré les conflits signalés (ils restent journalisés)" />
    </>
  );

  return (
    <>
      <PageHeader
        title="Planning"
        description="Séances et périodes de l'organisme. Les conflits de formateur, de salle et de groupe sont détectés avant validation ; les heures prévues, programmées, effectuées, justifiées et validées restent distinctes."
        actions={
          canManage ? (
            <>
              <FormDialog action={createSlotSeriesAction} trigger="Nouvelle série de séances" title="Séances en série" description="Génère une séance par jour de centre entre deux dates, avec une ou deux périodes indépendantes." submitLabel="Créer les séances" wide>
                {seriesForm}
              </FormDialog>
              <FormDialog action={addUnavailabilityAction} trigger="Indisponibilité" triggerVariant="secondary" title="Indisponibilité d'un formateur" submitLabel="Enregistrer">
                <input type="hidden" name="orgId" value={orgId} />
                <Field label="Formateur" required htmlFor="u-trainer">
                  <Select id="u-trainer" name="trainerId" required defaultValue="">
                    <option value="">Choisir</option>
                    {trainers.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.lastName} {t.firstName}
                      </option>
                    ))}
                  </Select>
                </Field>
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Du" required htmlFor="u-from">
                    <Input id="u-from" name="startDate" type="date" required defaultValue={date} />
                  </Field>
                  <Field label="Au" required htmlFor="u-to">
                    <Input id="u-to" name="endDate" type="date" required defaultValue={date} />
                  </Field>
                </div>
                <Field label="Partie" htmlFor="u-part">
                  <Select id="u-part" name="part" defaultValue="journee">
                    <option value="journee">Journée</option>
                    <option value="matin">Matin</option>
                    <option value="apres_midi">Après-midi</option>
                  </Select>
                </Field>
                <Field label="Motif" htmlFor="u-reason">
                  <Input id="u-reason" name="reason" maxLength={200} />
                </Field>
              </FormDialog>
              <FormDialog action={addClosureAction} trigger="Fermeture" triggerVariant="secondary" title="Fermeture (férié, congés)" submitLabel="Enregistrer">
                <input type="hidden" name="orgId" value={orgId} />
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Du" required htmlFor="c-from">
                    <Input id="c-from" name="startDate" type="date" required defaultValue={date} />
                  </Field>
                  <Field label="Au" required htmlFor="c-to">
                    <Input id="c-to" name="endDate" type="date" required defaultValue={date} />
                  </Field>
                </div>
                <Field label="Motif" required htmlFor="c-reason">
                  <Input id="c-reason" name="reason" required maxLength={200} />
                </Field>
                <Field label="Site" htmlFor="c-site" help="Vide : tout l'organisme.">
                  <Select id="c-site" name="siteId" defaultValue="">
                    <option value="">Tous les sites</option>
                    {sites.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name}
                      </option>
                    ))}
                  </Select>
                </Field>
              </FormDialog>
            </>
          ) : null
        }
      />

      <Panel className="mb-6">
        <form method="get" className="flex flex-wrap items-end gap-3 border-b border-line px-5 py-3">
          <input type="hidden" name="vue" value={vue} />
          <Field label="Date" htmlFor="f-date" className="w-40">
            <Input id="f-date" name="date" type="date" defaultValue={date} />
          </Field>
          <Field label="Session" htmlFor="f-session" className="w-56">
            <Select id="f-session" name="session" defaultValue={filters.sessionId ?? ""}>
              <option value="">Toutes</option>
              {sessions.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.code}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Formateur" htmlFor="f-trainer" className="w-48">
            <Select id="f-trainer" name="formateur" defaultValue={filters.trainerId ?? ""}>
              <option value="">Tous</option>
              {trainers.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.lastName} {t.firstName}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Salle" htmlFor="f-room" className="w-40">
            <Select id="f-room" name="salle" defaultValue={filters.roomId ?? ""}>
              <option value="">Toutes</option>
              {rooms.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.name}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Site" htmlFor="f-site" className="w-40">
            <Select id="f-site" name="site" defaultValue={filters.siteId ?? ""}>
              <option value="">Tous</option>
              {sites.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </Select>
          </Field>
          <Button type="submit" variant="secondary">
            Filtrer
          </Button>
        </form>
        <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-3">
          <div className="flex items-center gap-2">
            <Button asChild variant="secondary" size="sm">
              <Link href={qs({ date: prev })}>Précédent</Link>
            </Button>
            <Button asChild variant="secondary" size="sm">
              <Link href={qs({ date: today })}>Aujourd&apos;hui</Link>
            </Button>
            <Button asChild variant="secondary" size="sm">
              <Link href={qs({ date: next })}>Suivant</Link>
            </Button>
            <h2 className="ml-3 text-[15px] text-ink">{title}</h2>
          </div>
          <div className="flex items-center gap-2">
            <Button asChild variant={vue === "semaine" ? "primary" : "secondary"} size="sm">
              <Link href={qs({ vue: "semaine" })}>Semaine</Link>
            </Button>
            <Button asChild variant={vue === "mois" ? "primary" : "secondary"} size="sm">
              <Link href={qs({ vue: "mois" })}>Mois</Link>
            </Button>
            {filters.trainerId ? (
              <Button asChild variant="ghost" size="sm">
                <a href={`${base}/planning/ical/${filters.trainerId}`}>Agenda iCal du formateur</a>
              </Button>
            ) : null}
          </div>
        </div>
        {closures.length ? (
          <Notice tone="warn" className="mx-5 mb-3">
            Fermetures sur la période : {closures.map((c) => `${fmtDate(c.startDate)}${c.endDate !== c.startDate ? ` au ${fmtDate(c.endDate)}` : ""} (${c.reason})`).join(" ; ")}.
          </Notice>
        ) : null}
        <div className="px-5 pb-5">
          {items.length || vue === "mois" ? (
            vue === "mois" ? (
              <MonthCalendar month={date} items={items} base={base} today={today} />
            ) : (
              <WeekCalendar start={weekStart(date)} items={items} base={base} today={today} />
            )
          ) : (
            <EmptyState title="Aucune séance cette semaine" description={scope && !scope.length ? "Vous n'êtes affecté à aucune session : aucune séance n'est visible." : canManage ? "Créez une série de séances à partir d'une session pour remplir le planning." : "Aucune séance planifiée sur cet intervalle."} />
          )}
        </div>
      </Panel>

      {slotsInRange.length ? (
        <Panel>
          <PanelHeader title="Séances de l'intervalle" description="Modification et annulation possibles tant qu'aucune période de la séance n'est clôturée." />
          <Table>
            <thead>
              <tr>
                <Th>Date</Th>
                <Th>Session</Th>
                <Th>Module</Th>
                <Th>Formateur</Th>
                <Th>Salle</Th>
                <Th>Périodes</Th>
                <Th>État</Th>
                {canManage ? <Th>Actions</Th> : null}
              </tr>
            </thead>
            <tbody>
              {slotsInRange.map((r) => {
                const periods = rows.filter((x) => x.slot.id === r.slot.id);
                const locked = periods.some((p) => p.period.status === "cloturee");
                const sess = sessionById.get(r.slot.sessionId);
                return (
                  <tr key={r.slot.id}>
                    <Td className="whitespace-nowrap">{fmtDate(r.slot.date, "EEE d MMM")}</Td>
                    <Td>
                      <span className="font-medium">{r.session.code}</span>
                      <p className="text-[12px] text-ink-3">{r.session.title}</p>
                    </Td>
                    <Td>{r.moduleTitle ?? r.slot.title ?? "-"}</Td>
                    <Td>{r.trainerFirst ? `${r.trainerFirst} ${r.trainerLast}` : "-"}</Td>
                    <Td>{r.roomName ?? "-"}</Td>
                    <Td>
                      <div className="flex flex-wrap gap-1">
                        {periods.map((p) => (
                          <Link key={p.period.id} href={`${base}/emargement/${p.period.id}`} className="num border border-line px-1.5 py-0.5 text-[11px] hover:border-ink">
                            {p.period.startTime}-{p.period.endTime}
                          </Link>
                        ))}
                      </div>
                    </Td>
                    <Td>
                      <StatusBadge status={locked ? "cloturee" : r.slot.status} />
                    </Td>
                    {canManage ? (
                      <Td>
                        {locked || r.slot.status === "annulee" ? (
                          <span className="text-[12px] text-ink-3">{locked ? "Verrouillée" : "Annulée"}</span>
                        ) : (
                          <div className="flex flex-wrap gap-2">
                            <FormDialog action={updateSlotAction} trigger="Modifier" triggerVariant="secondary" triggerSize="sm" title={`Séance du ${fmtDate(r.slot.date)}`} description={sessionLabel(r.slot.sessionId)} submitLabel="Enregistrer">
                              <input type="hidden" name="orgId" value={orgId} />
                              <input type="hidden" name="slotId" value={r.slot.id} />
                              <Field label="Module" htmlFor={`m-${r.slot.id}`}>
                                <Select id={`m-${r.slot.id}`} name="moduleId" defaultValue={r.slot.moduleId ?? ""}>
                                  <option value="">Aucun</option>
                                  {modules
                                    .filter((m) => m.programVersionId === sess?.programVersionId)
                                    .map((m) => (
                                      <option key={m.id} value={m.id}>
                                        {m.title}
                                      </option>
                                    ))}
                                </Select>
                              </Field>
                              <Field label="Formateur" htmlFor={`t-${r.slot.id}`}>
                                <Select id={`t-${r.slot.id}`} name="trainerId" defaultValue={r.slot.trainerId ?? ""}>
                                  <option value="">Non affecté</option>
                                  {trainers.map((t) => (
                                    <option key={t.id} value={t.id}>
                                      {t.lastName} {t.firstName}
                                    </option>
                                  ))}
                                </Select>
                              </Field>
                              <Field label="Groupe" htmlFor={`g-${r.slot.id}`}>
                                <Select id={`g-${r.slot.id}`} name="groupId" defaultValue={r.slot.groupId ?? ""}>
                                  <option value="">Toute la session</option>
                                  {groups
                                    .filter((g) => g.sessionId === r.slot.sessionId)
                                    .map((g) => (
                                      <option key={g.id} value={g.id}>
                                        {g.name}
                                      </option>
                                    ))}
                                </Select>
                              </Field>
                              <div className="grid grid-cols-2 gap-3">
                                <Field label="Site" htmlFor={`si-${r.slot.id}`}>
                                  <Select id={`si-${r.slot.id}`} name="siteId" defaultValue={r.slot.siteId ?? ""}>
                                    <option value="">Aucun</option>
                                    {sites.map((s) => (
                                      <option key={s.id} value={s.id}>
                                        {s.name}
                                      </option>
                                    ))}
                                  </Select>
                                </Field>
                                <Field label="Salle" htmlFor={`r-${r.slot.id}`}>
                                  <Select id={`r-${r.slot.id}`} name="roomId" defaultValue={r.slot.roomId ?? ""}>
                                    <option value="">Aucune</option>
                                    {rooms.map((x) => (
                                      <option key={x.id} value={x.id}>
                                        {x.name}
                                      </option>
                                    ))}
                                  </Select>
                                </Field>
                              </div>
                              <Field label="Statut" htmlFor={`st-${r.slot.id}`}>
                                <Select id={`st-${r.slot.id}`} name="status" defaultValue={r.slot.status}>
                                  <option value="prevue">Prévue</option>
                                  <option value="confirmee">Confirmée</option>
                                  <option value="reportee">Reportée</option>
                                </Select>
                              </Field>
                              <Field label="Intitulé" htmlFor={`ti-${r.slot.id}`}>
                                <Input id={`ti-${r.slot.id}`} name="title" defaultValue={r.slot.title ?? ""} maxLength={160} />
                              </Field>
                              <Field label="Notes" htmlFor={`n-${r.slot.id}`}>
                                <Textarea id={`n-${r.slot.id}`} name="notes" defaultValue={r.slot.notes ?? ""} />
                              </Field>
                              <Checkbox name="force" value="1" label="Enregistrer malgré les conflits" />
                            </FormDialog>
                            <ActionButton action={cancelSlotAction} fields={{ orgId, slotId: r.slot.id }} label="Annuler" variant="danger" confirm={{ title: "Annuler cette séance ?", description: "La séance et ses périodes passent au statut « annulée » et restent dans l'historique.", input: { name: "reason", label: "Motif", placeholder: "Formateur absent, report demandé…" }, confirmLabel: "Confirmer l'annulation", danger: true }} />
                          </div>
                        )}
                      </Td>
                    ) : null}
                  </tr>
                );
              })}
            </tbody>
          </Table>
        </Panel>
      ) : null}
    </>
  );
}
