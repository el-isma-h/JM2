import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { getObject } from "@/server/storage";
import { imageKind } from "@/server/documents/pdf";

/**
 * Plan d'accès d'un site : document public de l'organisme (F10), servi sans session (convocations, catalogue public).
 * Seule la clé enregistrée sur le site est lue ; aucun autre fichier du stockage n'est accessible par cette route.
 */
export async function GET(_req: Request, { params }: { params: Promise<{ orgId: string; siteId: string }> }) {
  const { orgId, siteId } = await params;
  if (!/^[0-9a-f-]{36}$/i.test(orgId) || !/^[0-9a-f-]{36}$/i.test(siteId)) return new NextResponse("Introuvable.", { status: 404 });
  const [site] = await db.select({ key: schema.sites.accessPlanKey, name: schema.sites.name }).from(schema.sites).where(and(eq(schema.sites.id, siteId), eq(schema.sites.orgId, orgId))).limit(1);
  if (!site?.key) return new NextResponse("Aucun plan d'accès.", { status: 404 });
  const data = await getObject(site.key);
  const kind = imageKind(data);
  const type = kind === "png" ? "image/png" : kind === "jpeg" ? "image/jpeg" : "application/pdf";
  return new NextResponse(new Uint8Array(data), { headers: { "Content-Type": type, "Content-Disposition": `inline; filename*=UTF-8''${encodeURIComponent(`plan-acces-${site.name}`)}`, "Cache-Control": "public, max-age=300" } });
}
