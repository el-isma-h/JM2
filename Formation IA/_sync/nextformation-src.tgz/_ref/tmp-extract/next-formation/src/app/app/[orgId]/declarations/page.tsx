import Link from "next/link";
import { and, desc, eq, inArray, ne, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { trainerSessionIds } from "@/server/authz";
import { readParam } from "@/components/admin/pagination";
import { carifDeclarations, edofDeclarations, EDOF_STATUSES, kairosDeclarations, KAIROS_STATUSES, type DeclRow, type EnrollmentDecl } from "@/server/declarations/service";
import { updateEdofAction, updateKairosAction } from "@/server/actions/declarations";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/field";
import { EmptyState, Notice, PageHeader, Panel } from "@/components/ui/surface";
import { ActionForm, CopyButton } from "@/components/admin/action-form";
import { FadeIn } from "@/components/ui/motion";
import { TabNav } from "@/components/sessions/tabs";
import { todayParis } from "@/lib/time";

export const dynamic = "force-dynamic";

const TABS = ["carif", "kairos", "edof"] as const;
type Tab = (typeof TABS)[number];

function FieldsGrid({ row }: { row: DeclRow }) {
  const groups = [...new Set(row.fields.map((f) => f.group))];
  return (
    <div className="grid gap-6 lg:grid-cols-2">
      {groups.map((g) => (
        <div key={g}>
          <p className="etiquette mb-2 text-ink-3">{g}</p>
          <dl className="divide-y divide-line border-y border-line">
            {row.fields
              .filter((f) => f.group === g)
              .map((f) => (
                <div key={f.key} className="grid grid-cols-[minmax(0,1fr)_minmax(0,1.3fr)_auto] items-center gap-3 py-2">
                  <dt className="text-[12.5px] text-ink-2">
                    {f.label}
                    {f.help ? <span className="block text-[11.5px] text-ink-3">{f.help}</span> : null}
                  </dt>
                  <dd className="min-w-0 break-words text-[13px] text-ink">{f.value ? <span className="num">{f.value}</span> : <Badge tone="warn">À compléter</Badge>}</dd>
                  <div className="justify-self-end">{f.value ? <CopyButton value={f.value} /> : null}</div>
                </div>
              ))}
          </dl>
        </div>
      ))}
    </div>
  );
}

function RowSummary({ row, status }: { row: DeclRow; status?: string }) {
  const missing = row.fields.filter((f) => !f.value).length;
  return (
    <summary className="flex cursor-pointer flex-wrap items-center gap-x-4 gap-y-1 px-5 py-3.5">
      <span className="font-medium text-ink">{row.title}</span>
      <span className="num text-[12px] text-ink-3">{row.subtitle}</span>
      <span className="ml-auto flex flex-wrap items-center gap-2">
        {status ? <Badge tone="info">{status}</Badge> : null}
        {missing ? <Badge tone="warn">{missing} à compléter</Badge> : <Badge tone="ok">Complet</Badge>}
      </span>
    </summary>
  );
}

function KairosForm({ orgId, row }: { orgId: string; row: EnrollmentDecl }) {
  return (
    <ActionForm action={updateKairosAction} submitLabel="Enregistrer le suivi" submitVariant="secondary" submitSize="sm" className="grid gap-3 sm:grid-cols-[1.4fr_1fr_auto] sm:items-end" footerClassName="">
      <input type="hidden" name="orgId" value={orgId} />
      <input type="hidden" name="enrollmentId" value={row.enrollmentId} />
      <Field label="Statut du devis Kairos" htmlFor={`ks-${row.id}`} help="Consultez régulièrement le tableau de bord Kairos.">
        <Select id={`ks-${row.id}`} name="kairosStatus" defaultValue={row.status ?? ""}>
          <option value="">Non renseigné</option>
          {KAIROS_STATUSES.map((s) => (
            <option key={s.value} value={s.value}>
              {s.label}
            </option>
          ))}
        </Select>
      </Field>
      <Field label="Référence du devis" htmlFor={`kr-${row.id}`}>
        <Input id={`kr-${row.id}`} name="kairosDevisRef" defaultValue={row.ref ?? ""} maxLength={60} className="num" />
      </Field>
    </ActionForm>
  );
}

function EdofForm({ orgId, row, today }: { orgId: string; row: EnrollmentDecl; today: string }) {
  return (
    <ActionForm action={updateEdofAction} submitLabel="Enregistrer le suivi" submitVariant="secondary" submitSize="sm" className="grid gap-3 sm:grid-cols-[1.4fr_1fr_1fr_auto] sm:items-end" footerClassName="">
      <input type="hidden" name="orgId" value={orgId} />
      <input type="hidden" name="enrollmentId" value={row.enrollmentId} />
      <Field label="Statut EDOF" htmlFor={`es-${row.id}`}>
        <Select id={`es-${row.id}`} name="edofStatus" defaultValue={row.status ?? ""}>
          <option value="">Non renseigné</option>
          {EDOF_STATUSES.map((s) => (
            <option key={s.value} value={s.value}>
              {s.label}
            </option>
          ))}
        </Select>
      </Field>
      <Field label="Entrée déclarée le" htmlFor={`ee-${row.id}`} help={row.firstLoginAt ? undefined : "Aucune connexion e-learning enregistrée."}>
        <Input id={`ee-${row.id}`} name="edofEntryAt" type="date" max={today} defaultValue={row.entryAt ?? ""} className="num" />
      </Field>
      <Field label="Sortie déclarée le" htmlFor={`ex-${row.id}`}>
        <Input id={`ex-${row.id}`} name="edofExitAt" type="date" max={today} defaultValue={row.exitAt ?? ""} className="num" />
      </Field>
    </ActionForm>
  );
}

export default async function DeclarationsPage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const sp = await searchParams;
  const ctx = await guardOrg(orgId, `/app/${orgId}/declarations`, "enrollments.view", "sessions.view");
  const canManage = ctx.permissions.has("enrollments.manage");
  const canExport = ctx.permissions.has("exports.run");
  const rawTab = readParam(sp.onglet);
  const tab: Tab = (TABS as readonly string[]).includes(rawTab ?? "") ? (rawTab as Tab) : "carif";
  const rawSession = readParam(sp.session);
  const sessionId = rawSession && /^[0-9a-f-]{36}$/i.test(rawSession) ? rawSession : null;
  const scope = await trainerSessionIds(ctx);
  const sessions = await db
    .select({ id: schema.trainingSessions.id, code: schema.trainingSessions.code, title: schema.trainingSessions.title })
    .from(schema.trainingSessions)
    .where(and(eq(schema.trainingSessions.orgId, orgId), ne(schema.trainingSessions.status, "annulee"), scope ? (scope.length ? inArray(schema.trainingSessions.id, scope) : sql`false`) : undefined))
    .orderBy(desc(schema.trainingSessions.startDate))
    .limit(300);
  const today = todayParis();

  const carif = tab === "carif" ? await carifDeclarations(ctx, { sessionId }) : [];
  const kairos = tab === "kairos" ? await kairosDeclarations(ctx, { sessionId }) : [];
  const edof = tab === "edof" ? await edofDeclarations(ctx, { sessionId }) : [];
  const rows: DeclRow[] = tab === "carif" ? carif : tab === "kairos" ? kairos : edof;
  const base = `/app/${orgId}/declarations`;
  const qs = (extra: Record<string, string | null>) => {
    const p = new URLSearchParams();
    for (const [k, v] of Object.entries({ onglet: tab === "carif" ? null : tab, session: sessionId, ...extra })) if (v) p.set(k, v);
    const s = p.toString();
    return s ? `?${s}` : "";
  };

  return (
    <FadeIn>
      <PageHeader
        title="Déclarations"
        description="Formulaires préremplis pour les plateformes externes : Carif-Oref (par session), Kairos AIF et EDOF (par inscription). Copiez chaque champ ou exportez en CSV ; les champs manquants sont signalés « À compléter » et se corrigent dans la fiche d'origine."
        actions={
          canExport ? (
            <Button asChild variant="secondary">
              <a href={`${base}/export${qs({ onglet: tab })}`}>Exporter en CSV</a>
            </Button>
          ) : null
        }
      />
      <TabNav
        basePath={base}
        current={tab}
        tabs={[
          { key: "carif", label: "Carif-Oref" },
          { key: "kairos", label: "Kairos AIF" },
          { key: "edof", label: "EDOF (CPF)" },
        ]}
      />
      {!canExport ? <Notice tone="info" className="mb-4">Export CSV réservé à la permission « Exporter des données » (vérification renforcée). La copie champ par champ reste disponible.</Notice> : null}

      <form method="get" className="mb-5 flex flex-wrap items-end gap-3">
        {tab !== "carif" ? <input type="hidden" name="onglet" value={tab} /> : null}
        <Field label="Session" htmlFor="decl-session">
          <Select id="decl-session" name="session" defaultValue={sessionId ?? ""} className="min-w-[280px]">
            <option value="">Toutes les sessions</option>
            {sessions.map((s) => (
              <option key={s.id} value={s.id}>
                {s.code} · {s.title}
              </option>
            ))}
          </Select>
        </Field>
        <Button type="submit" variant="secondary" size="sm">
          Filtrer
        </Button>
        {sessionId ? (
          <Button asChild variant="ghost" size="sm">
            <Link href={`${base}${tab === "carif" ? "" : `?onglet=${tab}`}`}>Retirer le filtre</Link>
          </Button>
        ) : null}
      </form>

      {tab === "carif" ? <p className="mb-4 text-[12.5px] text-ink-2">Onglet 7 « Sessions » de la saisie Carif-Oref. Le numéro de session Carif, l&apos;effectif total, le recrutement et les publics se renseignent dans la fiche session (section repliable « Déclaration Carif-Oref »).</p> : null}
      {tab === "kairos" ? <p className="mb-4 text-[12.5px] text-ink-2">Devis AIF à saisir sur Kairos (Gérer DE, Saisir un devis AIF) : identifiant France Travail et zone géographique du demandeur, numéro de session Carif. Inscriptions retenues : parcours AIF, financement France Travail ou dossier Kairos déjà suivi.</p> : null}
      {tab === "edof" ? <p className="mb-4 text-[12.5px] text-ink-2">Dossiers CPF : entrée en formation (avec trace de connexion), puis sortie après la certification. Inscriptions retenues : parcours CPF, contrat CPF, financement CPF ou dossier EDOF déjà suivi.</p> : null}

      {rows.length ? (
        <div className="space-y-3">
          {tab === "carif"
            ? carif.map((r) => (
                <Panel key={r.id}>
                  <details>
                    <RowSummary row={r} />
                    <div className="space-y-4 border-t border-line p-5">
                      <FieldsGrid row={r} />
                      <Button asChild variant="ghost" size="sm">
                        <Link href={r.href}>Ouvrir la session</Link>
                      </Button>
                    </div>
                  </details>
                </Panel>
              ))
            : (tab === "kairos" ? kairos : edof).map((r) => (
                <Panel key={r.id}>
                  <details>
                    <RowSummary row={r} status={r.statusLabel} />
                    <div className="space-y-5 border-t border-line p-5">
                      <FieldsGrid row={r} />
                      {canManage ? (
                        <div className="border-t border-line pt-4">{tab === "kairos" ? <KairosForm orgId={orgId} row={r} /> : <EdofForm orgId={orgId} row={r} today={today} />}</div>
                      ) : (
                        <p className="text-[12.5px] text-ink-3">Mise à jour du statut réservée à la gestion des inscriptions.</p>
                      )}
                      <Button asChild variant="ghost" size="sm">
                        <Link href={r.href}>Ouvrir le dossier</Link>
                      </Button>
                    </div>
                  </details>
                </Panel>
              ))}
          {rows.length >= 300 ? <Notice tone="info">Affichage limité à 300 lignes : filtrez par session.</Notice> : null}
        </div>
      ) : (
        <Panel>
          <EmptyState
            title={tab === "carif" ? "Aucune session" : tab === "kairos" ? "Aucun dossier AIF" : "Aucun dossier CPF"}
            description={tab === "carif" ? "Créez une session pour préparer sa déclaration Carif-Oref." : tab === "kairos" ? "Une inscription apparaît ici dès qu'elle suit le parcours AIF ou porte un financement France Travail." : "Une inscription apparaît ici dès qu'elle suit le parcours CPF ou porte un financement CPF."}
            action={
              <Button asChild variant="secondary" size="sm">
                <Link href={tab === "carif" ? `/app/${orgId}/sessions` : `/app/${orgId}/inscriptions`}>{tab === "carif" ? "Voir les sessions" : "Voir les inscriptions"}</Link>
              </Button>
            }
          />
        </Panel>
      )}
    </FadeIn>
  );
}
