import { guardLearner } from "@/server/extranet/guard";
import { listEvaluations } from "@/server/extranet/queries";
import { NoAttachment } from "@/components/extranet/shell";
import { StatusBadge } from "@/components/ui/badge";
import { EmptyState, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { fmtDate } from "@/lib/dates";

export const dynamic = "force-dynamic";

const kindLabels: Record<string, string> = { positionnement: "Positionnement", formative: "Formative", sommative: "Sommative", finale: "Finale", auto_evaluation: "Auto-évaluation", competences: "Compétences" };

/** Mes évaluations : résultats et compétences, sans les commentaires internes de l'évaluateur. */
export default async function LearnerEvaluations() {
  const ctx = await guardLearner("/moi/evaluations");
  if (!ctx) return <NoAttachment kind="learner" />;
  const rows = await listEvaluations(ctx.org.id, ctx.enrollmentIds);
  return (
    <>
      <PageHeader title="Mes évaluations" description="Résultats des évaluations réalisées pendant votre parcours. Les notes internes de l'équipe pédagogique ne sont pas affichées." />
      <div className="space-y-6">
        {ctx.enrollments.map((e) => {
          const mine = rows.filter((r) => r.enrollmentId === e.enrollment.id);
          return (
            <Panel key={e.enrollment.id}>
              <PanelHeader title={e.program?.title ?? e.session.title} description={`Session ${e.session.code}`} />
              {mine.length ? (
                <Table>
                  <thead>
                    <tr>
                      <Th>Date</Th>
                      <Th>Évaluation</Th>
                      <Th>Type</Th>
                      <Th num>Score</Th>
                      <Th>Résultat</Th>
                      <Th>Compétences</Th>
                    </tr>
                  </thead>
                  <tbody>
                    {mine.map((r) => {
                      const skills = (Array.isArray(r.skills) ? r.skills : []) as { code?: string; label?: string; level?: string }[];
                      return (
                        <tr key={r.id}>
                          <Td className="num whitespace-nowrap">{fmtDate(r.date)}</Td>
                          <Td>
                            <span className="font-medium text-ink">{r.title}</span>
                            {r.moduleTitle ? <span className="block text-[12.5px] text-ink-3">{r.moduleTitle}</span> : null}
                          </Td>
                          <Td>{kindLabels[r.kind] ?? r.kind}</Td>
                          <Td num>{r.score != null && r.maxScore ? `${r.score} / ${r.maxScore}` : "-"}</Td>
                          <Td>
                            <StatusBadge status={r.result} />
                          </Td>
                          <Td>
                            {skills.length ? (
                              <ul className="space-y-0.5 text-[12.5px]">
                                {skills.map((s, i) => (
                                  <li key={i}>
                                    {s.label ?? s.code}
                                    {s.level ? <span className="text-ink-3"> : {s.level}</span> : null}
                                  </li>
                                ))}
                              </ul>
                            ) : (
                              "-"
                            )}
                          </Td>
                        </tr>
                      );
                    })}
                  </tbody>
                </Table>
              ) : (
                <EmptyState title="Aucune évaluation" description="Les résultats apparaîtront ici après chaque évaluation enregistrée." />
              )}
            </Panel>
          );
        })}
      </div>
    </>
  );
}
