import Link from "next/link";
import { guardTrainer } from "@/server/extranet/guard";
import { NoAttachment } from "@/components/extranet/shell";
import { StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { EmptyState, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { fmtDate } from "@/lib/dates";

export const dynamic = "force-dynamic";

/** Évaluations : accès par session à l'écran d'évaluations et livrets de l'application (périmètre formateur). */
export default async function TrainerEvaluations() {
  const ctx = await guardTrainer("/formateur/evaluations");
  if (!ctx) return <NoAttachment kind="trainer" />;
  return (
    <>
      <PageHeader title="Évaluations" description="Saisie des évaluations et des entrées de livret par session, dans l'application. Une évaluation ne peut pas porter une date future." />
      <Notice tone="info" className="mb-6">
        L&apos;écran d&apos;évaluations s&apos;ouvre dans l&apos;application, limité à vos sessions.
      </Notice>
      <Panel>
        <PanelHeader title="Mes sessions" />
        {ctx.sessions.length ? (
          <ul className="divide-y divide-line">
            {ctx.sessions.map((s) => (
              <li key={s.id} className="flex flex-wrap items-center justify-between gap-3 px-5 py-3">
                <div>
                  <p className="font-medium text-ink">{s.title}</p>
                  <p className="num text-[12px] text-ink-3">
                    {s.code} · {fmtDate(s.startDate)} au {fmtDate(s.endDate)}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <StatusBadge status={s.status} />
                  <Button asChild variant="secondary" size="sm">
                    <Link href={`/app/${ctx.org.id}/evaluations?session=${s.id}`}>Évaluations de la session</Link>
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        ) : (
          <EmptyState title="Aucune session affectée" />
        )}
      </Panel>
    </>
  );
}
