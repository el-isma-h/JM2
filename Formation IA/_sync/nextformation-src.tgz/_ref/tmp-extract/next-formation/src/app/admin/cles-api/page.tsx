import { guardAdmin } from "@/server/guard";
import { listPlatformSecrets, loadPlatformSecretsIntoEnv, PLATFORM_SECRETS, type PlatformSecretDef, type PlatformSecretListItem } from "@/server/platform/secrets";
import { deletePlatformSecretAction, setPlatformSecretAction, testPlatformSecretAction } from "@/server/actions/admin-secrets";
import { integrations } from "@/lib/env";
import { aiStatus } from "@/server/ai/provider";
import { fmtDateTime } from "@/lib/dates";
import { Badge } from "@/components/ui/badge";
import { Field, Input, Select } from "@/components/ui/field";
import { Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { ActionButton, ActionForm } from "@/components/admin/action-form";

export const dynamic = "force-dynamic";

function SourceBadge({ item }: { item: PlatformSecretListItem }) {
  if (item.source === "base") return <Badge tone="ok">Administration</Badge>;
  if (item.source === "environnement") return <Badge tone="info">Environnement du serveur</Badge>;
  return <Badge tone="neutral">Non définie</Badge>;
}

function ValueInput({ def }: { def: PlatformSecretDef }) {
  const id = `secret-${def.key}`;
  if (def.kind === "boolean") {
    return (
      <Field label={`Nouvelle valeur : ${def.key}`} htmlFor={id} help={def.help}>
        <Select id={id} name="value" defaultValue="" required>
          <option value="" disabled>
            Choisir
          </option>
          <option value="false">false : envoi coupé</option>
          <option value="true">true : envoi activé</option>
        </Select>
      </Field>
    );
  }
  return (
    <Field label={`Nouvelle valeur : ${def.key}`} htmlFor={id} help={def.help}>
      <Input id={id} name="value" type={def.kind === "secret" ? "password" : "text"} defaultValue="" autoComplete="off" spellCheck={false} required className="num" />
    </Field>
  );
}

function SecretRows({ defs, items }: { defs: PlatformSecretDef[]; items: PlatformSecretListItem[] }) {
  return (
    <Table>
      <thead>
        <tr>
          <Th>Clé</Th>
          <Th>Valeur enregistrée</Th>
          <Th>Source active</Th>
          <Th>Modifier</Th>
          <Th />
        </tr>
      </thead>
      <tbody>
        {defs.map((def) => {
          const item = items.find((i) => i.key === def.key)!;
          const testable = Boolean(def.provider) || def.key === "RESEND_API_KEY";
          return (
            <tr key={def.key} className="align-top">
              <Td>
                <span className="font-medium">{def.label}</span>
                <p className="num text-[11.5px] text-ink-3">{def.key}</p>
              </Td>
              <Td className="text-[12.5px]">
                {item.last4 ? (
                  <>
                    <span className="num">•••• {item.last4}</span>
                    {item.updatedAt ? <p className="text-ink-3">{fmtDateTime(item.updatedAt)}</p> : null}
                  </>
                ) : (
                  <span className="text-ink-3">Aucune</span>
                )}
              </Td>
              <Td className="text-[12.5px]">
                <SourceBadge item={item} />
                {item.shadowed ? <p className="mt-1 max-w-[220px] text-warn-ink">Valeur enregistrée ignorée : la variable du serveur garde la priorité.</p> : null}
              </Td>
              <Td className="min-w-[280px]">
                <ActionForm action={setPlatformSecretAction} submitLabel="Enregistrer" submitSize="sm" className="space-y-2" footerClassName="pt-1">
                  <input type="hidden" name="key" value={def.key} />
                  <ValueInput def={def} />
                </ActionForm>
              </Td>
              <Td>
                <div className="flex flex-wrap justify-end gap-1">
                  {testable ? <ActionButton action={testPlatformSecretAction} fields={{ key: def.key }} label="Tester" variant="ghost" /> : null}
                  {item.last4 ? (
                    <ActionButton
                      action={deletePlatformSecretAction}
                      fields={{ key: def.key }}
                      label="Supprimer"
                      variant="ghost"
                      confirm={{ title: `Supprimer ${def.key} ?`, description: "La valeur enregistrée est effacée de la base. Si elle était active, le service correspondant s'arrête immédiatement (sauf variable définie dans l'environnement du serveur).", confirmLabel: "Supprimer", danger: true }}
                    />
                  ) : null}
                </div>
              </Td>
            </tr>
          );
        })}
      </tbody>
    </Table>
  );
}

export default async function PlatformSecretsPage() {
  await guardAdmin("/admin/cles-api");
  // Resynchronise cette instance avec la base (modification faite depuis une autre instance).
  await loadPlatformSecretsIntoEnv();
  const items = await listPlatformSecrets();
  const ai = aiStatus();
  const mailOn = integrations.mail();
  return (
    <>
      <PageHeader
        title="Clés API"
        description="Clés des services externes saisies ici, chiffrées au repos (AES-256-GCM) et jamais réaffichées : seuls les 4 derniers caractères restent visibles. Une valeur enregistrée s'applique immédiatement, sans redémarrage."
      />
      <Notice tone="info" className="mb-6" title="Priorité">
        Une variable déjà définie dans l&apos;environnement du serveur (.env, docker-compose) garde la priorité sur la valeur saisie ici : l&apos;hébergeur conserve la main. Retirez-la de l&apos;environnement puis redémarrez pour utiliser la valeur de l&apos;administration. Avec plusieurs instances, les autres appliquent la modification au redémarrage ou à l&apos;ouverture de cette page.
      </Notice>
      <Panel className="mb-6">
        <PanelHeader title="Assistant et agents IA" description={ai.configured ? `Actif : ${ai.label}, modèle ${ai.model}. Une seule clé suffit.` : "Inactif : une seule clé suffit (Anthropic, OpenAI ou xAI Grok)."} actions={ai.configured ? <Badge tone="ok">Actif</Badge> : <Badge tone="warn">Non configuré</Badge>} />
        <SecretRows defs={PLATFORM_SECRETS.filter((d) => d.group === "ia")} items={items} />
      </Panel>
      <Panel>
        <PanelHeader
          title="E-mail (Resend)"
          description={mailOn ? "Envoi activé : les e-mails partent via Resend." : "Envoi coupé : les e-mails restent dans la boîte d'envoi et les liens s'affichent à l'écran. Pour l'activer : RESEND_API_KEY, MAIL_FROM, puis MAIL_ENABLED=true."}
          actions={mailOn ? <Badge tone="ok">Envoi activé</Badge> : <Badge tone="warn">Envoi coupé</Badge>}
        />
        <SecretRows defs={PLATFORM_SECRETS.filter((d) => d.group === "mail")} items={items} />
      </Panel>
    </>
  );
}
