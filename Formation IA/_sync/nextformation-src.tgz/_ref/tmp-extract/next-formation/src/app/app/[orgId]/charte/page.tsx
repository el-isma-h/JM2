/* eslint-disable @next/next/no-img-element -- images privées servies par des routes protégées, non optimisables */
import Link from "next/link";
import { guardOrg } from "@/server/guard";
import { orgAddress } from "@/server/documents/brand";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { KeyValue, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { FadeIn } from "@/components/ui/motion";

export const dynamic = "force-dynamic";

/** F10 : charte institutionnelle en lecture pour tous les membres autorisés (org.view) ; modification réservée au propriétaire actif. */
export default async function ChartePage({ params }: { params: Promise<{ orgId: string }> }) {
  const { orgId } = await params;
  const base = `/app/${orgId}/charte`;
  const ctx = await guardOrg(orgId, base, "org.view");
  const o = ctx.org;
  return (
    <FadeIn>
      <PageHeader
        title="Charte institutionnelle"
        description="Identité reprise sur tous les documents générés : raison sociale, SIRET, NDA, signataire, coordonnées, logo, couleurs, en-tête et pied de page."
        actions={
          <>
            <Button asChild variant="secondary">
              <Link href={`${base}/sites`}>Sites et salles</Link>
            </Button>
            <Button asChild variant="secondary">
              <a href={`${base}/apercu`} target="_blank" rel="noreferrer">
                Aperçu d&apos;un document témoin
              </a>
            </Button>
            {ctx.isOwner ? (
              <Button asChild>
                <Link href={`${base}/modifier`}>Modifier la charte</Link>
              </Button>
            ) : null}
          </>
        }
      />
      {!ctx.isOwner ? (
        <Notice tone="info" className="mb-5" title="Lecture seule">
          Seul le propriétaire actif de l&apos;organisme peut modifier la charte (raison sociale, SIRET, NDA, signataire, coordonnées, logo, couleurs, en-tête et pied de page), quels que soient vos rôles. Les sites et plans d&apos;accès restent modifiables par les responsables de sessions.
        </Notice>
      ) : null}
      <div className="grid gap-5 lg:grid-cols-2">
        <Panel>
          <PanelHeader title="Identité" />
          <div className="p-5">
            <KeyValue
              items={[
                { k: "Raison sociale", v: o.legalName },
                { k: "Nom commercial", v: o.tradeName ?? "-" },
                { k: "Forme", v: o.legalForm ?? "-" },
                { k: "SIREN", v: <span className="num">{o.siren ?? "-"}</span> },
                { k: "SIRET", v: <span className="num">{o.siret ?? "-"}</span> },
                { k: "NDA", v: <span className="num">{o.nda ?? "-"}</span> },
                { k: "Région NDA", v: o.ndaRegion ?? "-" },
                { k: "UAI", v: <span className="num">{o.uaiCode ?? "-"}</span> },
                { k: "Qualiopi", v: o.qualiopiNumber ? `${o.qualiopiNumber} (${o.qualiopiCertifier ?? "certificateur non renseigné"})` : "-" },
              ]}
            />
          </div>
        </Panel>
        <Panel>
          <PanelHeader title="Coordonnées et signataire" />
          <div className="p-5">
            <KeyValue
              items={[
                { k: "Adresse", v: orgAddress(o) ?? "-" },
                { k: "E-mail", v: o.email ?? "-" },
                { k: "Téléphone", v: <span className="num">{o.phone ?? "-"}</span> },
                { k: "Site web", v: o.website ?? "-" },
                { k: "Signataire", v: o.signatoryName ? `${o.signatoryName}${o.signatoryTitle ? `, ${o.signatoryTitle}` : ""}` : "-" },
                { k: "Signature", v: o.signatureKey ? <img src={`${base}/signature`} alt="Signature du signataire" className="max-h-16 border border-line bg-white p-1" /> : <span className="text-ink-3">Aucune image</span> },
              ]}
            />
          </div>
        </Panel>
        <Panel>
          <PanelHeader title="Logo et couleurs" />
          <div className="flex flex-wrap items-start gap-6 p-5">
            <div>
              <p className="mb-2 font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">Logo</p>
              {o.logoKey ? <img src={`${base}/logo`} alt={`Logo ${o.legalName}`} className="max-h-24 max-w-[220px] border border-line bg-white p-2" /> : <span className="text-[13px] text-ink-3">Aucun logo (le nom est utilisé en en-tête).</span>}
            </div>
            <div className="space-y-2">
              <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">Couleurs des documents</p>
              <p className="flex items-center gap-2 text-[13px]">
                <span className="inline-block h-5 w-5 border border-line" style={{ background: o.primaryColor }} aria-hidden /> Principale (filets, titres) <span className="num">{o.primaryColor}</span>
              </p>
              <p className="flex items-center gap-2 text-[13px]">
                <span className="inline-block h-5 w-5 border border-line" style={{ background: o.secondaryColor }} aria-hidden /> Secondaire <span className="num">{o.secondaryColor}</span>
              </p>
            </div>
          </div>
        </Panel>
        <Panel>
          <PanelHeader title="En-tête et pied de page des documents" />
          <div className="p-5">
            <KeyValue
              items={[
                { k: "En-tête", v: o.documentHeader ?? <span className="text-ink-3">Par défaut : SIRET et NDA</span> },
                { k: "Pied de page", v: o.documentFooter ?? <span className="text-ink-3">Par défaut : raison sociale, adresse, SIRET, NDA</span> },
                { k: "Pagination", v: <Badge>page x / y automatique</Badge> },
              ]}
            />
          </div>
        </Panel>
      </div>
    </FadeIn>
  );
}
