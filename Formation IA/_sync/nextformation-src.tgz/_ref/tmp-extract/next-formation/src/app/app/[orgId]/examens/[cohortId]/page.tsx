import Link from "next/link";
import { notFound } from "next/navigation";
import { eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { listCandidates, listMembers, loadCohort, loadCohortFormData } from "@/server/exams/service";
import { assignMemberAction, convokeAction, recordResultAction, removeMemberAction, updateCohortAction } from "@/server/actions/exams";
import { issueDownloadLink } from "@/server/documents/store";
import { todayParis } from "@/lib/time";
import { fmtDate, fmtDateTime } from "@/lib/dates";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Field, Input, Select, Textarea } from "@/components/ui/field";
import { EmptyState, KeyValue, Notice, PageHeader, Panel, PanelHeader, Stat } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FormDialog } from "@/components/admin/form-dialog";
import { ActionButton } from "@/components/admin/action-form";
import { CohortFields } from "@/components/pedagogy/cohort-form";

export const dynamic = "force-dynamic";

const RESULTS: [string, string][] = [
  ["admis", "Admis"],
  ["ajourne", "Ajourné"],
  ["partiel", "Résultat partiel"],
  ["rattrapage", "Rattrapage"],
  ["absent", "Absent"],
];

/** Écran d'une cohorte : charge et modifie uniquement la cohorte sélectionnée (cohortId vérifié dans l'organisme). */
export default async function CohortPage({ params }: { params: Promise<{ orgId: string; cohortId: string }> }) {
  const { orgId, cohortId } = await params;
  const base = `/app/${orgId}`;
  const ctx = await guardOrg(orgId, `${base}/examens/${cohortId}`, "exams.view");
  const cohort = await loadCohort(orgId, cohortId);
  if (!cohort) notFound();
  const canManage = ctx.permissions.has("exams.manage");
  const today = todayParis();
  const [members, candidates, form, program, site, manager] = await Promise.all([
    listMembers(orgId, cohort.id),
    canManage ? listCandidates(orgId, cohort) : Promise.resolve([]),
    canManage ? loadCohortFormData(orgId) : Promise.resolve(null),
    db.select({ title: schema.programs.title, code: schema.programs.code }).from(schema.programs).where(eq(schema.programs.id, cohort.programId)).limit(1).then((r) => r[0]),
    cohort.siteId ? db.select({ name: schema.sites.name }).from(schema.sites).where(eq(schema.sites.id, cohort.siteId)).limit(1).then((r) => r[0]) : Promise.resolve(null),
    cohort.managerUserId ? db.select({ firstName: schema.users.firstName, lastName: schema.users.lastName }).from(schema.users).where(eq(schema.users.id, cohort.managerUserId)).limit(1).then((r) => r[0]) : Promise.resolve(null),
  ]);
  const convocationLinks = new Map<string, string>();
  for (const m of members) if (m.member.convocationDocumentId) convocationLinks.set(m.member.id, await issueDownloadLink(m.member.convocationDocumentId, ctx.user.id));
  const options = (cohort.allowsPartial ?? {}) as { partial?: boolean; retake?: boolean };
  const blocks = (form?.blocks ?? []).filter((b) => b.programId === cohort.programId && (cohort.blocks as string[]).includes(b.code));
  const results = members.filter((m) => m.member.result).length;
  const examPassed = cohort.date <= today;
  const open = cohort.status !== "terminee" && cohort.status !== "annulee";

  return (
    <>
      <PageHeader
        breadcrumb={[{ label: "Examens", href: `${base}/examens` }, { label: cohort.code }]}
        title={cohort.label}
        description={`${cohort.code} · ${program?.title ?? ""} · ${fmtDate(cohort.date, "EEEE d MMMM yyyy")}${cohort.endDate && cohort.endDate !== cohort.date ? ` au ${fmtDate(cohort.endDate, "d MMMM yyyy")}` : ""}.`}
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <StatusBadge status={cohort.status} />
            {canManage && form ? (
              <FormDialog action={updateCohortAction} trigger="Modifier la cohorte" triggerVariant="secondary" triggerSize="sm" title={`Cohorte ${cohort.code}`} description="Seule cette cohorte est modifiée." submitLabel="Enregistrer" wide>
                <input type="hidden" name="orgId" value={orgId} />
                <input type="hidden" name="cohortId" value={cohort.id} />
                <CohortFields data={{ ...form, cohort: { ...cohort, blocks: cohort.blocks as string[], allowsPartial: options, scope: cohort.scope }, defaultDate: today }} idPrefix={`c-${cohort.id.slice(0, 6)}`} />
              </FormDialog>
            ) : null}
            {canManage && open && members.length ? <ActionButton action={convokeAction} fields={{ orgId, cohortId: cohort.id }} label="Convoquer tous les membres" variant="primary" size="sm" confirm={{ title: "Générer les convocations ?", description: `${members.filter((m) => m.member.status !== "desiste").length} convocation(s) PDF rattachée(s) aux inscriptions ; e-mail envoyé quand une adresse existe (jamais en démonstration).`, confirmLabel: "Convoquer" }} /> : null}
          </div>
        }
      />

      <div className="mb-6 grid gap-4 lg:grid-cols-[2fr_1fr]">
        <Panel className="p-5">
          <KeyValue
            items={[
              { k: "Formation", v: program ? `${program.code} : ${program.title}` : "-" },
              { k: "Périmètre", v: cohort.scope === "complet" ? "Examen complet" : blocks.length ? blocks.map((b) => `${b.code} (${b.label})`).join(", ") : (cohort.blocks as string[]).join(", ") || "Blocs non précisés" },
              { k: "Lieu", v: site?.name ?? "Non précisé" },
              { k: "Responsable", v: manager ? `${manager.firstName} ${manager.lastName}` : "Non désigné" },
              { k: "Options", v: `${options.partial === false ? "Pas de résultat partiel" : "Résultats partiels admis"} · ${options.retake === false ? "pas de rattrapage" : "rattrapage admis"}` },
              { k: "Notes", v: cohort.notes ?? "-" },
            ]}
          />
        </Panel>
        <Panel className="grid grid-cols-3 gap-4 p-5">
          <Stat label="Membres" value={<span className="num">{members.length}</span>} hint={`Capacité ${cohort.capacity}`} />
          <Stat label="Convoqués" value={<span className="num">{members.filter((m) => m.member.convokedAt).length}</span>} />
          <Stat label="Résultats" value={<span className="num">{results}</span>} />
        </Panel>
      </div>

      {!examPassed ? (
        <Notice tone="info" className="mb-6">
          L&apos;examen n&apos;a pas encore eu lieu : les résultats ne peuvent pas être saisis avant le {fmtDate(cohort.date)}.
        </Notice>
      ) : null}

      <Panel className="mb-6">
        <PanelHeader
          title="Membres de la cohorte"
          description="Affectation contrôlée côté serveur : même organisme, même formation, inscription inscrite / en cours / terminée, capacité, pas de doublon (y compris envois simultanés)."
          actions={
            canManage && open ? (
              <FormDialog action={assignMemberAction} trigger="Affecter une inscription" triggerSize="sm" title={`Affecter à ${cohort.code}`} description={`${candidates.length} inscription(s) éligible(s) : formation ${program?.title ?? ""}, non encore membres.`} submitLabel="Affecter">
                <input type="hidden" name="orgId" value={orgId} />
                <input type="hidden" name="cohortId" value={cohort.id} />
                <Field label="Inscription" required htmlFor="as-enr" help="Une inscription terminée reste éligible.">
                  <Select id="as-enr" name="enrollmentId" required defaultValue="">
                    <option value="">Choisir</option>
                    {candidates.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.lastName.toUpperCase()} {c.firstName} · {c.reference} · {c.sessionCode} ({c.status})
                      </option>
                    ))}
                  </Select>
                </Field>
              </FormDialog>
            ) : null
          }
        />
        {members.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Candidat</Th>
                <Th>Inscription</Th>
                <Th>Statut</Th>
                <Th>Convocation</Th>
                <Th>Résultat</Th>
                <Th>Blocs</Th>
                <Th>Actions</Th>
              </tr>
            </thead>
            <tbody>
              {members.map(({ member, enrollment, person }) => {
                const link = convocationLinks.get(member.id);
                const blockResults = (member.blockResults ?? []) as { code: string; result: string }[];
                return (
                  <tr key={member.id}>
                    <Td>
                      <span className="font-medium">
                        {person.lastName.toUpperCase()} {person.firstName}
                      </span>
                      {member.accommodations ? <p className="text-[12px] text-ink-3">Aménagements : {member.accommodations}</p> : null}
                    </Td>
                    <Td>
                      <Link href={`${base}/inscriptions/${enrollment.id}`} className="num hover:underline">
                        {enrollment.reference}
                      </Link>
                      <div className="mt-1 flex gap-1">
                        <StatusBadge status={enrollment.status} />
                        <StatusBadge status={enrollment.examState} />
                      </div>
                    </Td>
                    <Td>
                      <StatusBadge status={member.status} />
                    </Td>
                    <Td className="text-[12.5px]">
                      {member.convokedAt ? (
                        <>
                          {fmtDateTime(member.convokedAt)}
                          {link ? (
                            <>
                              {" · "}
                              <a href={link} className="text-accent underline-offset-2 hover:underline">
                                PDF
                              </a>
                            </>
                          ) : null}
                        </>
                      ) : (
                        <span className="text-ink-3">Non convoqué</span>
                      )}
                    </Td>
                    <Td>
                      {member.result ? (
                        <>
                          <StatusBadge status={member.result} />
                          {member.score != null ? <span className="num ml-1 text-[12px] text-ink-3">{member.score}</span> : null}
                          {member.observations ? <p className="mt-1 max-w-xs text-[12px] text-ink-3">{member.observations}</p> : null}
                        </>
                      ) : (
                        <span className="text-[12px] text-ink-3">-</span>
                      )}
                    </Td>
                    <Td className="text-[12px]">{blockResults.length ? blockResults.map((b) => `${b.code} : ${b.result}`).join(", ") : "-"}</Td>
                    <Td>
                      {canManage && open ? (
                        <div className="flex flex-wrap gap-2">
                          {member.status !== "desiste" ? <ActionButton action={convokeAction} fields={{ orgId, cohortId: cohort.id, memberId: member.id }} label={member.convokedAt ? "Reconvoquer" : "Convoquer"} variant="secondary" /> : null}
                          {examPassed && member.status !== "desiste" ? (
                            <FormDialog action={recordResultAction} trigger={member.result ? "Modifier le résultat" : "Résultat"} triggerVariant="primary" triggerSize="sm" title={`Résultat : ${person.firstName} ${person.lastName}`} description={`Cohorte ${cohort.code} · membre rechargé par (cohorte, identifiant) côté serveur.`} submitLabel="Enregistrer le résultat">
                              <input type="hidden" name="orgId" value={orgId} />
                              <input type="hidden" name="cohortId" value={cohort.id} />
                              <input type="hidden" name="memberId" value={member.id} />
                              <div className="grid grid-cols-2 gap-3">
                                <Field label="Résultat" required htmlFor={`r-${member.id}`}>
                                  <Select id={`r-${member.id}`} name="result" defaultValue={member.result ?? "admis"}>
                                    {RESULTS.filter(([v]) => (v === "partiel" ? options.partial !== false : v === "rattrapage" ? options.retake !== false : true)).map(([v, l]) => (
                                      <option key={v} value={v}>
                                        {l}
                                      </option>
                                    ))}
                                  </Select>
                                </Field>
                                <Field label="Note / points" htmlFor={`s-${member.id}`}>
                                  <Input id={`s-${member.id}`} name="score" type="number" min={0} defaultValue={member.score ?? ""} className="num" />
                                </Field>
                              </div>
                              {cohort.scope === "blocs" && blocks.length ? (
                                <Field label="Résultat par bloc">
                                  <div className="space-y-2">
                                    {blocks.map((b) => (
                                      <div key={b.code} className="grid grid-cols-[1fr_140px] items-center gap-2 text-[13px]">
                                        <span>
                                          <span className="num">{b.code}</span> · {b.label}
                                        </span>
                                        <Select name={`block:${b.code}`} defaultValue={blockResults.find((x) => x.code === b.code)?.result ?? ""} aria-label={`Résultat ${b.code}`}>
                                          <option value="">Non évalué</option>
                                          <option value="admis">Admis</option>
                                          <option value="ajourne">Ajourné</option>
                                          <option value="absent">Absent</option>
                                        </Select>
                                      </div>
                                    ))}
                                  </div>
                                </Field>
                              ) : null}
                              <Field label="Observations" htmlFor={`o-${member.id}`}>
                                <Textarea id={`o-${member.id}`} name="observations" defaultValue={member.observations ?? ""} className="min-h-16" />
                              </Field>
                              <Field label="Aménagements d'épreuve" htmlFor={`a-${member.id}`} help="Données limitées au strict nécessaire (T04).">
                                <Input id={`a-${member.id}`} name="accommodations" defaultValue={member.accommodations ?? ""} maxLength={1000} />
                              </Field>
                            </FormDialog>
                          ) : null}
                          {!member.result ? <ActionButton action={removeMemberAction} fields={{ orgId, cohortId: cohort.id, memberId: member.id }} label="Retirer" variant="ghost" confirm={{ title: "Retirer ce membre ?", description: member.convokedAt ? "Déjà convoqué : il sera marqué désisté, la convocation est conservée." : "L'inscription repasse « à inscrire »." }} /> : null}
                        </div>
                      ) : (
                        <span className="text-[12px] text-ink-3">-</span>
                      )}
                    </Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucun membre" description={canManage ? "Affectez les inscriptions éligibles à cette cohorte." : "Aucune inscription affectée."} />
        )}
      </Panel>

      {canManage && candidates.length && open ? (
        <Panel>
          <PanelHeader title="Inscriptions éligibles non affectées" description="Même formation, statut inscrit, en cours ou terminé." />
          <Table>
            <thead>
              <tr>
                <Th>Candidat</Th>
                <Th>Inscription</Th>
                <Th>Session</Th>
                <Th>Statut</Th>
                <Th>Examen</Th>
                <Th />
              </tr>
            </thead>
            <tbody>
              {candidates.slice(0, 50).map((c) => (
                <tr key={c.id}>
                  <Td>
                    {c.lastName.toUpperCase()} {c.firstName}
                  </Td>
                  <Td className="num">{c.reference}</Td>
                  <Td>{c.sessionCode}</Td>
                  <Td>
                    <StatusBadge status={c.status} />
                  </Td>
                  <Td>
                    <StatusBadge status={c.examState} />
                  </Td>
                  <Td>
                    <ActionButton action={assignMemberAction} fields={{ orgId, cohortId: cohort.id, enrollmentId: c.id }} label="Affecter" variant="secondary" />
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
          {candidates.length > 50 ? <p className="px-5 py-3 text-[12px] text-ink-3">{candidates.length - 50} autre(s) : utilisez « Affecter une inscription ».</p> : null}
        </Panel>
      ) : null}
      {!canManage ? (
        <p className="mt-4 text-[12px] text-ink-3">
          <Badge>Lecture seule</Badge> Votre habilitation ne permet pas de modifier cette cohorte.
        </p>
      ) : null}
    </>
  );
}
