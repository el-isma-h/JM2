import { getTrainerContext } from "@/server/extranet/context";
import { extranetDownload } from "@/server/extranet/download";
import { findVisibleDocument } from "@/server/extranet/queries";

/** Mes documents (fiche formateur) et documents pédagogiques des sessions affectées. */
export async function GET(_req: Request, { params }: { params: Promise<{ documentId: string }> }) {
  const { documentId } = await params;
  const ctx = await getTrainerContext().catch(() => null);
  const mine = ctx ? await findVisibleDocument(ctx.org.id, documentId, { trainerId: ctx.trainer.id }, ["interne", "pedagogie", "public", "administratif"]) : null;
  if (mine) return extranetDownload(getTrainerContext, (c) => ({ scope: { trainerId: c.trainer.id }, visibilities: ["interne", "pedagogie", "public", "administratif"] }), documentId, "/formateur/documents");
  return extranetDownload(getTrainerContext, (c) => ({ scope: { sessionIds: c.sessionIds }, visibilities: ["pedagogie", "public"] }), documentId, "/formateur/documents");
}
