import Link from "next/link";
import { notFound } from "next/navigation";
import { and, desc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { addInteractionAction, createContactAction, createNeedAction, setCompanyStatusAction, updateCompanyAction } from "@/server/actions/crm";
import { isOverdue, listStaffUsers, nextActionFor, userNames } from "@/server/crm/queries";
import { todayParis } from "@/lib/time";
import { fmtDate } from "@/lib/dates";
import { formatCents } from "@/lib/money";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { EmptyState, KeyValue, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FormDialog } from "@/components/admin/form-dialog";
import { CompanyFields, ContactFields, InteractionFields, NeedFields, companyStatusLabels, interactionKindLabels } from "@/components/crm/fields";
import { NextActionBanner, NextActionCell } from "@/components/crm/next-action";
import { StageSelect } from "@/components/crm/stage-select";
import { DocumentList } from "@/components/crm/documents";
import { FadeIn } from "@/components/ui/motion";

export const dynamic = "force-dynamic";

export default async function CompanyPage({ params }: { params: Promise<{ orgId: string; companyId: string }> }) {
  const { orgId, companyId } = await params;
  const base = `/app/${orgId}`;
  const ctx = await guardOrg(orgId, `${base}/entreprises/${companyId}`, "crm.view");
  if (!/^[0-9a-f-]{36}$/i.test(companyId)) notFound();
  const [company] = await db.select().from(schema.companies).where(and(eq(schema.companies.id, companyId), eq(schema.companies.orgId, ctx.org.id))).limit(1);
  if (!company) notFound();
  const canManage = ctx.permissions.has("crm.manage");
  const today = todayParis();

  const [contacts, needs, interactions, quotes, enrollments, docs, staff, programs, persons, action] = await Promise.all([
    db.select().from(schema.contacts).where(and(eq(schema.contacts.orgId, ctx.org.id), eq(schema.contacts.companyId, company.id))).orderBy(schema.contacts.lastName),
    db.select().from(schema.needs).where(and(eq(schema.needs.orgId, ctx.org.id), eq(schema.needs.companyId, company.id))).orderBy(desc(schema.needs.updatedAt)),
    db.select().from(schema.interactions).where(and(eq(schema.interactions.orgId, ctx.org.id), eq(schema.interactions.companyId, company.id))).orderBy(desc(schema.interactions.at)).limit(50),
    db.select().from(schema.quotes).where(and(eq(schema.quotes.orgId, ctx.org.id), eq(schema.quotes.companyId, company.id))).orderBy(desc(schema.quotes.createdAt)),
    db
      .select({ e: schema.enrollments, p: schema.persons, s: schema.trainingSessions })
      .from(schema.enrollments)
      .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
      .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.enrollments.sessionId))
      .where(and(eq(schema.enrollments.orgId, ctx.org.id), eq(schema.enrollments.companyId, company.id)))
      .orderBy(desc(schema.enrollments.createdAt)),
    db.select().from(schema.documents).where(and(eq(schema.documents.orgId, ctx.org.id), eq(schema.documents.companyId, company.id))).orderBy(desc(schema.documents.createdAt)),
    listStaffUsers(ctx.org.id),
    db.select({ id: schema.programs.id, name: schema.programs.title }).from(schema.programs).where(and(eq(schema.programs.orgId, ctx.org.id), eq(schema.programs.status, "actif"))).orderBy(schema.programs.title),
    db.select({ id: schema.persons.id, firstName: schema.persons.firstName, lastName: schema.persons.lastName }).from(schema.persons).where(and(eq(schema.persons.orgId, ctx.org.id), eq(schema.persons.companyId, company.id))).orderBy(schema.persons.lastName).limit(200),
    nextActionFor(ctx.org.id, { companyId: company.id }),
  ]);
  const names = await userNames([company.assignedUserId, ...interactions.map((i) => i.userId)]);
  const contactOptions = contacts.map((c) => ({ id: c.id, name: `${c.firstName} ${c.lastName}` }));
  const personOptions = persons.map((p) => ({ id: p.id, name: `${p.firstName} ${p.lastName}` }));
  const contactName = (id: string | null) => (id ? contactOptions.find((c) => c.id === id)?.name ?? null : null);

  return (
    <FadeIn>
      <PageHeader
        breadcrumb={[{ label: "Commercial" }, { label: "Entreprises", href: `${base}/entreprises` }, { label: company.name }]}
        title={company.name}
        description={[company.sector, company.city, company.siret ? `SIRET ${company.siret}` : company.siren ? `SIREN ${company.siren}` : null].filter(Boolean).join(" · ") || "Identité à compléter."}
        actions={
          <>
            <StatusBadge status={company.status} />
            {canManage ? (
              <>
                <StageSelect action={setCompanyStatusAction} fields={{ orgId: ctx.org.id, companyId: company.id }} name="status" value={company.status} label="Changer le statut" options={Object.entries(companyStatusLabels).map(([value, label]) => ({ value, label }))} />
                <FormDialog action={updateCompanyAction} trigger="Modifier" triggerVariant="secondary" title="Modifier l'entreprise" submitLabel="Enregistrer" wide>
                  <CompanyFields orgId={ctx.org.id} company={company} staff={staff} prefix="e" />
                </FormDialog>
              </>
            ) : null}
          </>
        }
      />
      <NextActionBanner action={action} base={base} />

      <div className="grid gap-6 lg:grid-cols-[minmax(0,2fr)_minmax(0,1fr)]">
        <div className="space-y-6">
          <Panel>
            <PanelHeader title="Identité" />
            <div className="grid gap-6 p-5 md:grid-cols-2">
              <KeyValue
                items={[
                  { k: "SIRET", v: company.siret ? <span className="num">{company.siret}</span> : null },
                  { k: "SIREN", v: company.siren ? <span className="num">{company.siren}</span> : null },
                  { k: "APE", v: company.apeCode },
                  { k: "IDCC", v: company.idcc },
                  { k: "OPCO", v: company.opco },
                  { k: "Effectif", v: company.headcount != null ? <span className="num">{company.headcount}</span> : null },
                ]}
              />
              <KeyValue
                items={[
                  { k: "Adresse", v: [company.addressLine1, company.addressLine2, [company.postalCode, company.city].filter(Boolean).join(" ")].filter(Boolean).join(", ") || null },
                  { k: "E-mail", v: company.email },
                  { k: "Téléphone", v: company.phone },
                  { k: "Site", v: company.website },
                  { k: "Référent", v: company.assignedUserId ? names.get(company.assignedUserId) : "Non attribué" },
                  { k: "Source", v: company.source },
                ]}
              />
            </div>
            {(company.tags as string[]).length || company.notes ? (
              <div className="border-t border-line px-5 py-4 text-[13.5px]">
                <div className="flex flex-wrap gap-1.5">
                  {(company.tags as string[]).map((t) => (
                    <Badge key={t}>{t}</Badge>
                  ))}
                </div>
                {company.notes ? <p className="mt-3 whitespace-pre-line text-ink-2">{company.notes}</p> : null}
              </div>
            ) : null}
          </Panel>

          <Panel>
            <PanelHeader
              title="Contacts"
              description="Tuteurs, signataires et contacts de facturation sont réutilisés dans les inscriptions et conventions."
              actions={
                canManage ? (
                  <FormDialog action={createContactAction} trigger="Ajouter un contact" triggerVariant="secondary" triggerSize="sm" title="Nouveau contact" submitLabel="Ajouter" wide>
                    <ContactFields orgId={ctx.org.id} companies={[{ id: company.id, name: company.name }]} companyId={company.id} />
                  </FormDialog>
                ) : null
              }
            />
            {contacts.length ? (
              <Table>
                <thead>
                  <tr>
                    <Th>Contact</Th>
                    <Th>Fonction</Th>
                    <Th>Coordonnées</Th>
                    <Th>Rôles</Th>
                  </tr>
                </thead>
                <tbody>
                  {contacts.map((c) => (
                    <tr key={c.id}>
                      <Td>
                        <Link href={`${base}/contacts?q=${encodeURIComponent(c.lastName)}`} className="font-medium text-ink hover:underline">
                          {c.civility ? `${c.civility === "M" ? "M." : c.civility === "Mme" ? "Mme" : ""} ` : ""}
                          {c.firstName} {c.lastName}
                        </Link>
                      </Td>
                      <Td>{c.jobTitle ?? "-"}</Td>
                      <Td>
                        {c.email ? <span className="block">{c.email}</span> : null}
                        {c.phone || c.mobile ? <span className="num block text-[12.5px] text-ink-2">{[c.phone, c.mobile].filter(Boolean).join(" · ")}</span> : null}
                      </Td>
                      <Td>
                        <div className="flex flex-wrap gap-1">
                          {c.isTutor ? <Badge tone="info">Tuteur</Badge> : null}
                          {c.isSignatory ? <Badge tone="accent">Signataire</Badge> : null}
                          {c.isBilling ? <Badge>Facturation</Badge> : null}
                        </div>
                      </Td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            ) : (
              <EmptyState title="Aucun contact" description="Ajoutez le dirigeant, le responsable RH ou le tuteur pour préparer les conventions." className="py-8" />
            )}
          </Panel>

          <Panel>
            <PanelHeader
              title="Besoins"
              description="Besoins de formation ou de recrutement suivis dans le pipeline."
              actions={
                canManage ? (
                  <FormDialog action={createNeedAction} trigger="Nouveau besoin" triggerVariant="secondary" triggerSize="sm" title="Nouveau besoin" submitLabel="Créer le besoin" wide>
                    <NeedFields orgId={ctx.org.id} companies={[{ id: company.id, name: company.name }]} contacts={contactOptions} persons={personOptions} programs={programs} staff={staff} companyId={company.id} />
                  </FormDialog>
                ) : null
              }
            />
            {needs.length ? (
              <Table>
                <thead>
                  <tr>
                    <Th>Besoin</Th>
                    <Th>Étape</Th>
                    <Th num>Effectif</Th>
                    <Th num>Montant</Th>
                    <Th>Prochaine action</Th>
                  </tr>
                </thead>
                <tbody>
                  {needs.map((n) => (
                    <tr key={n.id}>
                      <Td>
                        <Link href={`${base}/besoins/${n.id}`} className="font-medium text-ink hover:underline">
                          {n.title}
                        </Link>
                        {n.contactId ? <p className="text-[12px] text-ink-3">{contactName(n.contactId)}</p> : null}
                      </Td>
                      <Td>
                        <StatusBadge status={n.stage} />
                      </Td>
                      <Td num>{n.headcount}</Td>
                      <Td num>{formatCents(n.amountCents)}</Td>
                      <Td>
                        <NextActionCell date={n.stage === "gagne" || n.stage === "perdu" ? null : n.nextActionAt} label={n.nextAction} overdue={isOverdue(n.nextActionAt, today)} />
                      </Td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            ) : (
              <EmptyState title="Aucun besoin" description="Un besoin ouvre le pipeline commercial : qualification, proposition, devis, placement." className="py-8" />
            )}
          </Panel>

          <Panel>
            <PanelHeader title="Inscriptions des salariés" description="Lecture : les inscriptions se gèrent depuis le dossier central." />
            {enrollments.length ? (
              <Table>
                <thead>
                  <tr>
                    <Th>Salarié</Th>
                    <Th>Session</Th>
                    <Th>Référence</Th>
                    <Th>Inscription</Th>
                    <Th>Financement</Th>
                  </tr>
                </thead>
                <tbody>
                  {enrollments.map(({ e, p, s }) => (
                    <tr key={e.id}>
                      <Td>
                        <Link href={`${base}/candidats/${p.id}`} className="font-medium text-ink hover:underline">
                          {p.firstName} {p.lastName}
                        </Link>
                      </Td>
                      <Td>
                        <Link href={`${base}/sessions/${s.id}`} className="hover:underline">
                          {s.title}
                        </Link>
                        <span className="num block text-[12px] text-ink-3">
                          {fmtDate(s.startDate)} au {fmtDate(s.endDate)}
                        </span>
                      </Td>
                      <Td>
                        <Link href={`${base}/inscriptions/${e.id}`} className="num hover:underline">
                          {e.reference}
                        </Link>
                      </Td>
                      <Td>
                        <StatusBadge status={e.status} />
                      </Td>
                      <Td>
                        <StatusBadge status={e.fundingState} />
                      </Td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            ) : (
              <EmptyState title="Aucune inscription" description="Les inscriptions rattachées à cette entreprise apparaîtront ici." className="py-8" />
            )}
          </Panel>

          <Panel>
            <PanelHeader title="Devis" actions={canManage ? <Button asChild variant="secondary" size="sm"><Link href={`${base}/devis/nouveau?companyId=${company.id}`}>Nouveau devis</Link></Button> : null} />
            {quotes.length ? (
              <Table>
                <thead>
                  <tr>
                    <Th>Numéro</Th>
                    <Th>Objet</Th>
                    <Th>Statut</Th>
                    <Th num>Total TTC</Th>
                    <Th>Validité</Th>
                  </tr>
                </thead>
                <tbody>
                  {quotes.map((q) => (
                    <tr key={q.id}>
                      <Td>
                        <Link href={`${base}/devis/${q.id}`} className="num font-medium text-ink hover:underline">
                          {q.number}
                        </Link>
                      </Td>
                      <Td>{q.title}</Td>
                      <Td>
                        <StatusBadge status={q.status} />
                      </Td>
                      <Td num>{formatCents(q.totalTtcCents)}</Td>
                      <Td className={q.status === "envoye" && isOverdue(q.validUntil, today) ? "text-danger-ink" : ""}>{q.validUntil ? fmtDate(q.validUntil) : "-"}</Td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            ) : (
              <EmptyState title="Aucun devis" className="py-8" />
            )}
          </Panel>

          <Panel>
            <PanelHeader title="Documents liés" />
            <DocumentList orgId={ctx.org.id} docs={docs} emptyDescription="Devis générés et pièces rattachées à l'entreprise." />
          </Panel>
        </div>

        <div className="space-y-6">
          <Panel>
            <PanelHeader
              title="Journal des échanges"
              actions={
                canManage ? (
                  <FormDialog action={addInteractionAction} trigger="Ajouter" triggerVariant="secondary" triggerSize="sm" title="Nouvel échange" description="Indiquez la prochaine action pour qu'elle apparaisse en tête de fiche et dans les listes." submitLabel="Enregistrer">
                    <InteractionFields orgId={ctx.org.id} companyId={company.id} contacts={contactOptions} today={today} />
                  </FormDialog>
                ) : null
              }
            />
            {interactions.length ? (
              <ol className="divide-y divide-line">
                {interactions.map((i) => (
                  <li key={i.id} className="px-5 py-3.5 text-[13.5px]">
                    <div className="flex flex-wrap items-center gap-2">
                      <Badge>{interactionKindLabels[i.kind] ?? i.kind}</Badge>
                      <span className="num text-[12px] text-ink-3">{fmtDate(i.at)}</span>
                      {i.userId ? <span className="text-[12px] text-ink-3">{names.get(i.userId)}</span> : null}
                    </div>
                    <p className="mt-1.5 font-medium text-ink">{i.subject}</p>
                    {i.contactId ? <p className="text-[12px] text-ink-3">avec {contactName(i.contactId)}</p> : null}
                    {i.body ? <p className="mt-1 whitespace-pre-line text-ink-2">{i.body}</p> : null}
                    {i.nextActionAt ? (
                      <p className={`mt-1.5 text-[12.5px] ${isOverdue(i.nextActionAt, today) ? "text-danger-ink font-medium" : "text-ink-2"}`}>
                        Prochaine action : {i.nextAction} le <span className="num">{fmtDate(i.nextActionAt)}</span>
                        {isOverdue(i.nextActionAt, today) ? " (dépassée)" : ""}
                      </p>
                    ) : null}
                  </li>
                ))}
              </ol>
            ) : (
              <EmptyState title="Aucun échange" description="Appels, e-mails, rendez-vous : chaque échange conserve sa prochaine relance." className="py-8" />
            )}
          </Panel>
        </div>
      </div>
    </FadeIn>
  );
}
