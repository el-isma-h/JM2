import { NextResponse } from "next/server";
import { requireOrg } from "@/server/authz";
import { loadOrgLogo } from "@/server/documents/brand";
import { imageKind } from "@/server/documents/pdf";

/** Logo de l'organisme (stockage privé) : lecture réservée aux membres avec org.view. */
export async function GET(_req: Request, { params }: { params: Promise<{ orgId: string }> }) {
  const { orgId } = await params;
  let ctx;
  try {
    ctx = await requireOrg(orgId, "org.view");
  } catch {
    return new NextResponse("Accès refusé.", { status: 403 });
  }
  const logo = await loadOrgLogo(ctx.org);
  if (!logo) return new NextResponse("Aucun logo.", { status: 404 });
  const kind = imageKind(logo);
  // Logo SVG (ex. espace de démonstration) : servi tel quel ; les PDF n'utilisent que PNG/JPEG.
  const isSvg = !kind && /^\s*(<\?xml|<svg)/i.test(logo.subarray(0, 200).toString("utf8"));
  if (!kind && !isSvg) return new NextResponse("Aucun logo.", { status: 404 });
  const contentType = kind === "png" ? "image/png" : kind === "jpeg" ? "image/jpeg" : "image/svg+xml";
  return new NextResponse(new Uint8Array(logo), { headers: { "Content-Type": contentType, "Cache-Control": "private, no-store", "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'" } });
}
