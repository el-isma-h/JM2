import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowRight, Check, ShieldCheck } from "@phosphor-icons/react/dist/ssr";
import { PageHero, btnContour, btnEncre, btnOsContour, btnPastel } from "@/components/marketing/site";
import { Ecran } from "@/components/marketing/ecran";
import { FEATURES, SOLUTIONS } from "@/lib/marketing-data";
import { SITE, breadcrumbJsonLd, faqJsonLd, jsonLdScript, pageMeta } from "@/lib/seo";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const f = FEATURES.find((x) => x.slug === slug);
  if (!f) return {};
  return pageMeta(`/fonctionnalites/${f.slug}`, `${f.title} : logiciel organisme de formation`, `${f.promise} ${f.description}`.slice(0, 300));
}

export default async function FeaturePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const f = FEATURES.find((x) => x.slug === slug);
  if (!f) notFound();
  const others = FEATURES.filter((x) => x.slug !== f.slug);
  const solutions = SOLUTIONS.filter((s) => s.features.includes(f.slug));
  const jsonLd = [
    breadcrumbJsonLd([
      { name: "Accueil", path: "/" },
      { name: "Fonctionnalités", path: "/fonctionnalites" },
      { name: f.short, path: `/fonctionnalites/${f.slug}` },
    ]),
    faqJsonLd(f.faq),
    { "@context": "https://schema.org", "@type": "WebPage", name: f.title, description: f.description, isPartOf: { "@type": "WebSite", name: SITE.name } },
  ];
  return (
    <article>
      <script type="application/ld+json" dangerouslySetInnerHTML={jsonLdScript(jsonLd)} />
      <PageHero crumbs={[{ label: "Accueil", href: "/" }, { label: "Fonctionnalités", href: "/fonctionnalites" }, { label: f.short }]} eyebrow={f.short} title={f.title} description={f.promise} filigrane={String(FEATURES.indexOf(f) + 1).padStart(2, "0")}>
        <Link href="/inscription" className={btnPastel}>
          Essai gratuit 15 jours <ArrowRight size={14} />
        </Link>
        <Link href="/demo" className={btnContour}>
          Explorer la démonstration
        </Link>
      </PageHero>

      <section className="conteneur grid gap-12 py-16 lg:grid-cols-[1.1fr_0.9fr] lg:items-start lg:py-24">
        <div>
          <p className="max-w-[62ch] text-[16px] leading-relaxed text-ink-2">{f.description}</p>
          <h2 className="mt-12 text-[26px] sm:text-[32px]">Ce que vous gagnez</h2>
          <ul className="mt-6 flex flex-col divide-y divide-line border-t border-line-strong">
            {f.benefits.map((b) => (
              <li key={b} className="flex gap-3 py-4 text-[14.5px] leading-relaxed text-ink-2">
                <Check size={16} className="mt-0.5 shrink-0 text-accent" aria-hidden="true" />
                {b}
              </li>
            ))}
          </ul>
        </div>
        <div className="lg:sticky lg:top-20">
          <Ecran kind={f.ecran} />
          <p className="mt-3 font-mono text-[9.5px] uppercase tracking-[0.18em] text-ink-3">Aperçu illustratif, données fictives</p>
        </div>
      </section>

      <section className="border-t border-line bg-bg-sunken">
        <div className="conteneur py-16 lg:py-24">
          <h2 className="text-[26px] sm:text-[32px]">Comment ça marche</h2>
          <ol className="mt-10 grid gap-px border border-line-strong bg-line-strong sm:grid-cols-2 lg:grid-cols-4">
            {f.steps.map((s, i) => (
              <li key={s.t} className="bg-bg p-6">
                <span className="num font-mono text-[11px] tracking-[0.2em] text-accent">{String(i + 1).padStart(2, "0")}</span>
                <h3 className="mt-5 text-[18px]">{s.t}</h3>
                <p className="mt-3 text-[13.5px] leading-relaxed text-ink-2">{s.d}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className="sombre bg-[#0a0b0d] text-[#f3f0e8]">
        <div className="conteneur grid gap-10 py-16 lg:grid-cols-[0.8fr_1.2fr] lg:py-24">
          <div>
            <p className="etiquette">Règles garanties</p>
            <h2 className="mt-5 text-[26px] sm:text-[32px]">Ce que le serveur refuse, quoi qu&apos;il arrive.</h2>
            <p className="mt-5 max-w-md text-[14px] leading-relaxed text-[#f3f0e8]/60">Ces règles viennent du cahier des charges métier. Elles sont vérifiées côté serveur et en base, pas seulement dans l&apos;interface.</p>
          </div>
          <ul className="flex flex-col divide-y divide-[#f3f0e8]/15 border-t border-[#f3f0e8]/25">
            {f.rules.map((r) => (
              <li key={r} className="flex gap-4 py-5 text-[15px] leading-relaxed text-[#f3f0e8]/85">
                <ShieldCheck size={18} className="mt-0.5 shrink-0 text-[#c9b8f0]" aria-hidden="true" />
                {r}
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="conteneur grid gap-12 py-16 lg:grid-cols-[0.8fr_1.2fr] lg:py-24">
        <div>
          <h2 className="text-[26px] sm:text-[32px]">Questions fréquentes</h2>
          {solutions.length ? (
            <div className="mt-8">
              <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">Utile pour</p>
              <ul className="mt-3 flex flex-wrap gap-2">
                {solutions.map((s) => (
                  <li key={s.slug}>
                    <Link href={`/solutions/${s.slug}`} className="inline-flex min-h-[36px] items-center border border-line-strong px-3 font-mono text-[10px] uppercase tracking-[0.16em] text-ink-2 transition-colors hover:border-ink hover:text-ink">
                      {s.short}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ) : null}
        </div>
        <dl className="border-t border-line-strong">
          {f.faq.map((q) => (
            <div key={q.q} className="border-b border-line py-5">
              <dt className="font-display text-[17px] font-medium">{q.q}</dt>
              <dd className="mt-2 max-w-2xl text-[14px] leading-relaxed text-ink-2">{q.a}</dd>
            </div>
          ))}
        </dl>
      </section>

      <section className="border-t border-line bg-bg-sunken">
        <div className="conteneur flex flex-wrap items-center justify-between gap-6 py-14">
          <div>
            <h2 className="text-[26px] sm:text-[32px]">Essayez sur vos propres dossiers.</h2>
            <p className="mt-2 text-[14px] text-ink-2">Quinze jours gratuits, sans carte bancaire, import guidé de vos données.</p>
          </div>
          <div className="flex flex-wrap gap-3">
            <Link href="/inscription" className={btnEncre}>
              Commencer l&apos;essai <ArrowRight size={14} />
            </Link>
            <Link href="/tarifs" className={btnOsContour}>
              Voir les tarifs
            </Link>
          </div>
        </div>
      </section>

      <section className="conteneur py-14">
        <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">Autres fonctionnalités</p>
        <ul className="mt-5 flex flex-wrap gap-2">
          {others.map((o) => (
            <li key={o.slug}>
              <Link href={`/fonctionnalites/${o.slug}`} className="inline-flex min-h-[38px] items-center border border-line-strong px-4 font-mono text-[10.5px] uppercase tracking-[0.18em] text-ink-2 transition-colors hover:border-ink hover:text-ink">
                {o.short}
              </Link>
            </li>
          ))}
        </ul>
      </section>
    </article>
  );
}
