import { NextResponse, type NextRequest } from "next/server";
import { requireOrg } from "@/server/authz";
import { AuthError } from "@/server/auth";
import { audit } from "@/server/audit";
import { todayParis } from "@/lib/time";
import { carifDeclarations, declarationsCsv, edofDeclarations, kairosDeclarations } from "@/server/declarations/service";

export const dynamic = "force-dynamic";

/** Export CSV des déclarations (Carif-Oref, Kairos AIF, EDOF) : permissions de lecture + export renforcé `exports.run`. */
export async function GET(req: NextRequest, { params }: { params: Promise<{ orgId: string }> }) {
  const { orgId } = await params;
  const back = `/app/${orgId}/declarations`;
  let ctx;
  try {
    ctx = await requireOrg(orgId, "enrollments.view", "sessions.view", "exports.run");
  } catch (e) {
    if (e instanceof AuthError && e.code === "elevation_required") return NextResponse.redirect(new URL(`/securite?next=${encodeURIComponent(back)}`, req.url));
    if (e instanceof AuthError && e.code === "unauthenticated") return NextResponse.redirect(new URL(`/connexion?next=${encodeURIComponent(back)}`, req.url));
    return new NextResponse("Accès refusé", { status: 403 });
  }
  const tab = req.nextUrl.searchParams.get("onglet") ?? "carif";
  if (!["carif", "kairos", "edof"].includes(tab)) return NextResponse.json({ error: "Onglet inconnu." }, { status: 400 });
  const rawSession = req.nextUrl.searchParams.get("session");
  const sessionId = rawSession && /^[0-9a-f-]{36}$/i.test(rawSession) ? rawSession : null;
  const rows = tab === "carif" ? await carifDeclarations(ctx, { sessionId }) : tab === "kairos" ? await kairosDeclarations(ctx, { sessionId }) : await edofDeclarations(ctx, { sessionId });
  if (!rows.length) return new NextResponse("Aucune ligne à exporter pour ce filtre.", { status: 404, headers: { "content-type": "text/plain; charset=utf-8" } });
  await audit({ action: "export.run", userId: ctx.user.id, orgId, entityType: "export", after: { kind: `declarations_${tab}`, rows: rows.length, sessionId } });
  return new NextResponse(declarationsCsv(rows), {
    headers: { "content-type": "text/csv; charset=utf-8", "content-disposition": `attachment; filename="declarations-${tab}-${todayParis()}.csv"`, "cache-control": "no-store" },
  });
}
