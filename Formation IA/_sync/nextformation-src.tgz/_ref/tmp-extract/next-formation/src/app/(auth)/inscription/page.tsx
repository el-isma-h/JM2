import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/server/auth";
import { SignupForm } from "./signup-form";

export const metadata: Metadata = {
  title: "Créer mon compte",
  description: "Créez votre espace Next Formation en quelques minutes : logiciel de gestion pour organismes de formation et CFA, essai gratuit 15 jours, sans engagement.",
  alternates: { canonical: "/inscription" },
};

export default async function SignupPage() {
  if (await getCurrentUser()) redirect("/app");
  return (
    <div>
      <h1 className="text-[30px] text-ink">Créer mon compte</h1>
      <p className="mt-3 text-[14px] text-ink-2">
        Vous créez votre accès et votre espace entreprise ou cabinet. Déjà inscrit ?{" "}
        <Link href="/connexion" className="font-medium text-accent hover:underline">
          Se connecter
        </Link>
      </p>
      <SignupForm />
      <p className="mt-6 text-[13px] text-ink-3">
        Vous préférez voir avant de créer un compte ?{" "}
        <Link href="/demo" className="font-medium text-accent hover:underline">
          Explorer la démonstration
        </Link>
      </p>
    </div>
  );
}
