import Link from "next/link";
import { notFound } from "next/navigation";
import { and, asc, desc, eq, inArray, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { assertEnrollmentInScope, trainerSessionIds } from "@/server/authz";
import { AuthError } from "@/server/auth";
import { hoursForEnrollment } from "@/server/planning/service";
import { sessionProgressionGrid } from "@/server/pedagogy/service";
import { EVALUATION_KIND_LABELS, PROGRESSION_LABELS, RECORD_KIND_LABELS } from "@/server/pedagogy/labels";
import { addRecordEntryAction, createEvaluationAction, generateLivretAction, setProgressionAction } from "@/server/actions/pedagogy";
import { issueDownloadLink } from "@/server/documents/store";
import { fmtMinutes, todayParis } from "@/lib/time";
import { fmtDate } from "@/lib/dates";
import { Button } from "@/components/ui/button";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Checkbox, Field, Input, Select, Textarea } from "@/components/ui/field";
import { EmptyState, Notice, PageHeader, Panel, PanelHeader, Stat } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FormDialog } from "@/components/admin/form-dialog";
import { ActionForm } from "@/components/admin/action-form";
import { readParam } from "@/components/admin/pagination";

export const dynamic = "force-dynamic";

export default async function EvaluationsPage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const base = `/app/${orgId}`;
  const ctx = await guardOrg(orgId, `${base}/evaluations`, "dossier.pedagogy.view");
  const sp = await searchParams;
  const sessionId = readParam(sp.session);
  const enrollmentId = readParam(sp.enrollment);
  const canManage = ctx.permissions.has("dossier.pedagogy.manage");
  const scope = await trainerSessionIds(ctx);
  const today = todayParis();

  /* ---------- Vue inscription ---------- */
  if (enrollmentId) {
    if (!/^[0-9a-f-]{36}$/.test(enrollmentId)) notFound();
    try {
      await assertEnrollmentInScope(ctx, enrollmentId);
    } catch (e) {
      if (e instanceof AuthError) notFound();
      throw e;
    }
    const [row] = await db
      .select({ enrollment: schema.enrollments, person: schema.persons, session: schema.trainingSessions })
      .from(schema.enrollments)
      .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
      .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.enrollments.sessionId))
      .where(and(eq(schema.enrollments.id, enrollmentId), eq(schema.enrollments.orgId, orgId)))
      .limit(1);
    if (!row) notFound();
    const versionId = row.enrollment.programVersionId ?? row.session.programVersionId;
    const [modules, evaluations, entries, hours, livrets] = await Promise.all([
      db.select().from(schema.modules).where(and(eq(schema.modules.orgId, orgId), eq(schema.modules.programVersionId, versionId))).orderBy(asc(schema.modules.position)),
      db
        .select({ ev: schema.evaluations, moduleTitle: schema.modules.title })
        .from(schema.evaluations)
        .leftJoin(schema.modules, eq(schema.modules.id, schema.evaluations.moduleId))
        .where(and(eq(schema.evaluations.orgId, orgId), eq(schema.evaluations.enrollmentId, enrollmentId)))
        .orderBy(desc(schema.evaluations.date)),
      db.select().from(schema.recordEntries).where(and(eq(schema.recordEntries.orgId, orgId), eq(schema.recordEntries.enrollmentId, enrollmentId))).orderBy(desc(schema.recordEntries.date)),
      hoursForEnrollment(orgId, enrollmentId),
      db.select().from(schema.documents).where(and(eq(schema.documents.orgId, orgId), eq(schema.documents.enrollmentId, enrollmentId), eq(schema.documents.category, "livret"))).orderBy(desc(schema.documents.createdAt)).limit(3),
    ]);
    const livretLinks = await Promise.all(livrets.map(async (d) => ({ d, href: await issueDownloadLink(d.id, ctx.user.id) })));
    const p = row.person;
    return (
      <>
        <PageHeader
          breadcrumb={[{ label: "Évaluations et livrets", href: `${base}/evaluations` }, { label: row.session.code, href: `${base}/evaluations?session=${row.session.id}` }, { label: `${p.firstName} ${p.lastName}` }]}
          title={`${p.firstName} ${p.lastName}`}
          description={`Inscription ${row.enrollment.reference} · ${row.session.code} : ${row.session.title}. Les évaluations en cours de formation sont distinguées du résultat final ; la progression est déclarée explicitement.`}
          actions={
            <div className="flex flex-wrap gap-2">
              <Button asChild variant="secondary" size="sm">
                <Link href={`${base}/inscriptions/${row.enrollment.id}`}>Dossier</Link>
              </Button>
              {ctx.permissions.has("documents.generate") ? (
                <ActionForm action={generateLivretAction} submitLabel="Générer le livret PDF" submitVariant="primary" submitSize="sm">
                  <input type="hidden" name="orgId" value={orgId} />
                  <input type="hidden" name="enrollmentId" value={row.enrollment.id} />
                </ActionForm>
              ) : null}
            </div>
          }
        />
        <div className="mb-6 grid gap-4 lg:grid-cols-[1fr_2fr]">
          <Panel className="p-5">
            <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">Progression pédagogique</p>
            <div className="mt-2 flex items-center gap-2">
              <StatusBadge status={row.enrollment.progression} />
              <span className="text-[12px] text-ink-3">statut distinct du financement et de l&apos;examen</span>
            </div>
            {canManage && !ctx.trainerOnly ? (
              <ActionForm action={setProgressionAction} submitLabel="Déclarer" submitVariant="secondary" submitSize="sm" className="mt-4" footerClassName="mt-3">
                <input type="hidden" name="orgId" value={orgId} />
                <input type="hidden" name="enrollmentId" value={row.enrollment.id} />
                <Field label="Nouvelle progression" htmlFor="prog" help="Jamais déduite automatiquement des évaluations.">
                  <Select id="prog" name="progression" defaultValue={row.enrollment.progression}>
                    {Object.entries(PROGRESSION_LABELS).map(([v, l]) => (
                      <option key={v} value={v}>
                        {l}
                      </option>
                    ))}
                  </Select>
                </Field>
                <Field label="Motif (facultatif)" htmlFor="prog-reason" className="mt-3">
                  <Input id="prog-reason" name="reason" maxLength={500} />
                </Field>
              </ActionForm>
            ) : (
              <p className="mt-3 text-[12px] text-ink-3">Déclarée par le responsable pédagogique.</p>
            )}
            {livretLinks.length ? (
              <div className="mt-5 border-t border-line pt-4">
                <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">Livrets générés</p>
                <ul className="mt-2 space-y-1 text-[13px]">
                  {livretLinks.map(({ d, href }) => (
                    <li key={d.id}>
                      <a href={href} className="text-accent underline-offset-2 hover:underline">
                        Version {d.version} · {fmtDate(d.createdAt)}
                      </a>{" "}
                      <StatusBadge status={d.status} />
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}
          </Panel>
          <Panel className="grid grid-cols-2 gap-4 p-5 sm:grid-cols-5">
            <Stat label="Prévues" value={<span className="num">{fmtMinutes(hours.planned)}</span>} />
            <Stat label="Programmées" value={<span className="num">{fmtMinutes(hours.scheduled)}</span>} />
            <Stat label="Effectuées" value={<span className="num">{fmtMinutes(hours.done)}</span>} />
            <Stat label="Justifiées" value={<span className="num">{fmtMinutes(hours.justified)}</span>} />
            <Stat label="Validées" value={<span className="num">{fmtMinutes(hours.validated)}</span>} hint={hours.legacy ? `Solde historique à part : ${fmtMinutes(hours.legacy)}` : "Périodes clôturées"} />
          </Panel>
        </div>

        <Panel className="mb-6">
          <PanelHeader
            title="Évaluations"
            description="Positionnement, formatives, sommatives, finale, compétences. Date future refusée."
            actions={
              canManage ? (
                <FormDialog action={createEvaluationAction} trigger="Nouvelle évaluation" triggerSize="sm" title="Évaluation" submitLabel="Enregistrer" wide>
                  <input type="hidden" name="orgId" value={orgId} />
                  <input type="hidden" name="enrollmentId" value={row.enrollment.id} />
                  <div className="grid grid-cols-2 gap-3">
                    <Field label="Type" required htmlFor="ev-kind">
                      <Select id="ev-kind" name="kind" defaultValue="formative">
                        {Object.entries(EVALUATION_KIND_LABELS).map(([v, l]) => (
                          <option key={v} value={v}>
                            {l}
                          </option>
                        ))}
                      </Select>
                    </Field>
                    <Field label="Date" required htmlFor="ev-date" help="Au plus tard aujourd'hui.">
                      <Input id="ev-date" name="date" type="date" required defaultValue={today} max={today} />
                    </Field>
                  </div>
                  <Field label="Intitulé" required htmlFor="ev-title">
                    <Input id="ev-title" name="title" required maxLength={160} />
                  </Field>
                  <Field label="Module" htmlFor="ev-module">
                    <Select id="ev-module" name="moduleId" defaultValue="">
                      <option value="">Général (hors module)</option>
                      {modules.map((m) => (
                        <option key={m.id} value={m.id}>
                          {m.blockCode ? `${m.blockCode} · ` : ""}
                          {m.title}
                        </option>
                      ))}
                    </Select>
                  </Field>
                  <div className="grid grid-cols-3 gap-3">
                    <Field label="Résultat" required htmlFor="ev-result">
                      <Select id="ev-result" name="result" defaultValue="non_evalue">
                        <option value="non_evalue">Non évalué</option>
                        <option value="en_cours">En cours</option>
                        <option value="partiel">Partiel</option>
                        <option value="acquis">Acquis</option>
                        <option value="non_acquis">Non acquis</option>
                      </Select>
                    </Field>
                    <Field label="Note" htmlFor="ev-score">
                      <Input id="ev-score" name="score" type="number" min={0} className="num" />
                    </Field>
                    <Field label="Barème" htmlFor="ev-max">
                      <Input id="ev-max" name="maxScore" type="number" min={1} defaultValue={20} className="num" />
                    </Field>
                  </div>
                  <Field label="Compétences (une par ligne : libellé | niveau)" htmlFor="ev-skills">
                    <Textarea id="ev-skills" name="skills" placeholder={"Analyser un besoin | acquis\nRédiger un cahier des charges | en cours"} />
                  </Field>
                  <Field label="Commentaire" htmlFor="ev-comment">
                    <Textarea id="ev-comment" name="comment" />
                  </Field>
                </FormDialog>
              ) : null
            }
          />
          {evaluations.length ? (
            <Table>
              <thead>
                <tr>
                  <Th>Date</Th>
                  <Th>Type</Th>
                  <Th>Intitulé</Th>
                  <Th>Module</Th>
                  <Th num>Note</Th>
                  <Th>Résultat</Th>
                </tr>
              </thead>
              <tbody>
                {evaluations.map(({ ev, moduleTitle }) => (
                  <tr key={ev.id}>
                    <Td className="whitespace-nowrap">{fmtDate(ev.date)}</Td>
                    <Td>
                      <Badge tone={ev.kind === "finale" ? "accent" : "neutral"}>{EVALUATION_KIND_LABELS[ev.kind]?.split(" (")[0] ?? ev.kind}</Badge>
                    </Td>
                    <Td>
                      {ev.title}
                      {ev.comment ? <p className="text-[12px] text-ink-3">{ev.comment}</p> : null}
                      {(ev.skills as { label: string; level: string }[]).length ? <p className="text-[12px] text-ink-3">{(ev.skills as { label: string; level: string }[]).map((s) => `${s.label}${s.level ? ` : ${s.level}` : ""}`).join(" · ")}</p> : null}
                    </Td>
                    <Td>{moduleTitle ?? "Général"}</Td>
                    <Td num>{ev.score != null ? `${ev.score}${ev.maxScore ? ` / ${ev.maxScore}` : ""}` : "-"}</Td>
                    <Td>
                      <StatusBadge status={ev.result} />
                    </Td>
                  </tr>
                ))}
              </tbody>
            </Table>
          ) : (
            <EmptyState title="Aucune évaluation" description="Commencez par un positionnement à l'entrée en formation." />
          )}
        </Panel>

        <Panel>
          <PanelHeader
            title="Livret de suivi"
            description="Entrées datées ; cochez la visibilité pour l'apprenant et l'entreprise (extranets)."
            actions={
              canManage ? (
                <FormDialog action={addRecordEntryAction} trigger="Nouvelle entrée" triggerSize="sm" triggerVariant="secondary" title="Entrée de livret" submitLabel="Ajouter">
                  <input type="hidden" name="orgId" value={orgId} />
                  <input type="hidden" name="enrollmentId" value={row.enrollment.id} />
                  <div className="grid grid-cols-2 gap-3">
                    <Field label="Type" required htmlFor="re-kind">
                      <Select id="re-kind" name="kind" defaultValue="observation">
                        {Object.entries(RECORD_KIND_LABELS).map(([v, l]) => (
                          <option key={v} value={v}>
                            {l}
                          </option>
                        ))}
                      </Select>
                    </Field>
                    <Field label="Date" required htmlFor="re-date">
                      <Input id="re-date" name="date" type="date" required defaultValue={today} max={today} />
                    </Field>
                  </div>
                  <Field label="Intitulé" required htmlFor="re-title">
                    <Input id="re-title" name="title" required maxLength={160} />
                  </Field>
                  <Field label="Contenu" htmlFor="re-body">
                    <Textarea id="re-body" name="body" />
                  </Field>
                  <div className="flex flex-wrap gap-5">
                    <Checkbox name="visibleToLearner" value="1" defaultChecked label="Visible par l'apprenant" />
                    <Checkbox name="visibleToCompany" value="1" label="Visible par l'entreprise / le tuteur" />
                  </div>
                </FormDialog>
              ) : null
            }
          />
          {entries.length ? (
            <ul className="divide-y divide-line">
              {entries.map((en) => (
                <li key={en.id} className="flex flex-wrap items-start justify-between gap-3 px-5 py-3">
                  <div className="min-w-0">
                    <p className="text-[13.5px] text-ink">
                      <span className="num text-ink-3">{fmtDate(en.date)}</span> · <Badge>{RECORD_KIND_LABELS[en.kind] ?? en.kind}</Badge> <span className="ml-1 font-medium">{en.title}</span>
                    </p>
                    {en.body ? <p className="mt-1 whitespace-pre-line text-[13px] text-ink-2">{en.body}</p> : null}
                  </div>
                  <div className="flex gap-1">
                    {en.visibleToLearner ? <Badge tone="info">Apprenant</Badge> : null}
                    {en.visibleToCompany ? <Badge tone="info">Entreprise</Badge> : null}
                    {!en.visibleToLearner && !en.visibleToCompany ? <Badge>Interne</Badge> : null}
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <EmptyState title="Livret vide" description="Les entrées datées (objectifs, activités, bilans) alimentent le livret PDF." />
          )}
        </Panel>
      </>
    );
  }

  /* ---------- Vue session (grille) ---------- */
  if (sessionId) {
    if (!/^[0-9a-f-]{36}$/.test(sessionId)) notFound();
    if (scope && !scope.includes(sessionId)) notFound();
    const grid = await sessionProgressionGrid(orgId, sessionId);
    if (!grid) notFound();
    return (
      <>
        <PageHeader breadcrumb={[{ label: "Évaluations et livrets", href: `${base}/evaluations` }, { label: grid.session.code }]} title={grid.session.title} description={`${grid.session.code} · ${grid.enrollments.length} inscrit(s) · ${grid.modules.length} module(s). Dernier résultat par module ; cliquez sur un apprenant pour le détail et le livret.`} />
        <Panel>
          {grid.enrollments.length ? (
            <Table>
              <thead>
                <tr>
                  <Th>Apprenant</Th>
                  <Th>Progression</Th>
                  {grid.modules.map((m) => (
                    <Th key={m.id}>
                      <span title={m.title}>{m.code ?? m.blockCode ?? m.title.slice(0, 14)}</span>
                    </Th>
                  ))}
                  <Th>Général</Th>
                </tr>
              </thead>
              <tbody>
                {grid.enrollments.map(({ enrollment, person }) => (
                  <tr key={enrollment.id}>
                    <Td>
                      <Link href={`${base}/evaluations?enrollment=${enrollment.id}`} className="font-medium hover:underline">
                        {person.lastName.toUpperCase()} {person.firstName}
                      </Link>
                      <p className="num text-[12px] text-ink-3">{enrollment.reference}</p>
                    </Td>
                    <Td>
                      <StatusBadge status={enrollment.progression} />
                    </Td>
                    {[...grid.modules.map((m) => m.id), "general"].map((mid) => {
                      const c = grid.cell.get(`${enrollment.id}:${mid}`);
                      return <Td key={mid}>{c ? <StatusBadge status={c.result} /> : <span className="text-ink-3">-</span>}</Td>;
                    })}
                  </tr>
                ))}
              </tbody>
            </Table>
          ) : (
            <EmptyState title="Aucun inscrit" description="Les inscriptions actives de la session apparaissent ici." />
          )}
        </Panel>
      </>
    );
  }

  /* ---------- Liste des sessions ---------- */
  const sessions = await db
    .select({ s: schema.trainingSessions, enrolled: sql<number>`(select count(*)::int from ${schema.enrollments} e where e.session_id = "sessions_formation"."id" and e.status in ('inscrit','en_cours','termine'))`, evals: sql<number>`(select count(*)::int from ${schema.evaluations} ev join ${schema.enrollments} e on e.id = ev.enrollment_id where e.session_id = "sessions_formation"."id")` })
    .from(schema.trainingSessions)
    .where(and(eq(schema.trainingSessions.orgId, orgId), scope ? (scope.length ? inArray(schema.trainingSessions.id, scope) : eq(schema.trainingSessions.id, "00000000-0000-0000-0000-000000000000")) : inArray(schema.trainingSessions.status, ["ouverte", "confirmee", "en_cours", "terminee"])))
    .orderBy(desc(schema.trainingSessions.startDate));
  return (
    <>
      <PageHeader title="Évaluations et livrets" description="Par session : grille apprenants × modules. Par inscription : évaluations, livret daté, progression déclarée et génération du livret PDF." />
      {ctx.trainerOnly ? (
        <Notice tone="info" className="mb-6">
          Seules vos sessions affectées sont visibles.
        </Notice>
      ) : null}
      <Panel>
        {sessions.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Session</Th>
                <Th>Dates</Th>
                <Th>État</Th>
                <Th num>Inscrits</Th>
                <Th num>Évaluations</Th>
                <Th />
              </tr>
            </thead>
            <tbody>
              {sessions.map(({ s, enrolled, evals }) => (
                <tr key={s.id}>
                  <Td>
                    <Link href={`${base}/evaluations?session=${s.id}`} className="font-medium hover:underline">
                      {s.code}
                    </Link>
                    <p className="text-[12px] text-ink-3">{s.title}</p>
                  </Td>
                  <Td className="whitespace-nowrap">
                    {fmtDate(s.startDate)} au {fmtDate(s.endDate)}
                  </Td>
                  <Td>
                    <StatusBadge status={s.status} />
                  </Td>
                  <Td num>{enrolled}</Td>
                  <Td num>{evals}</Td>
                  <Td>
                    <Button asChild variant="secondary" size="sm">
                      <Link href={`${base}/evaluations?session=${s.id}`}>Grille</Link>
                    </Button>
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucune session" description={scope && !scope.length ? "Vous n'êtes affecté à aucune session." : "Les sessions ouvertes, en cours ou terminées apparaissent ici."} />
        )}
      </Panel>
    </>
  );
}
