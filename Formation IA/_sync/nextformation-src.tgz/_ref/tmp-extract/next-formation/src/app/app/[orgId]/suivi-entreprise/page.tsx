import Link from "next/link";
import { notFound } from "next/navigation";
import { and, asc, desc, eq, inArray, or, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { assertEnrollmentInScope, trainerSessionIds } from "@/server/authz";
import { AuthError } from "@/server/auth";
import { createOverdueFollowupTasks } from "@/server/pedagogy/service";
import { FOLLOWUP_KIND_LABELS } from "@/server/pedagogy/labels";
import { createFollowupAction } from "@/server/actions/pedagogy";
import { todayParis } from "@/lib/time";
import { fmtDate } from "@/lib/dates";
import { Button } from "@/components/ui/button";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Field, Input, Select, Textarea } from "@/components/ui/field";
import { EmptyState, KeyValue, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FormDialog } from "@/components/admin/form-dialog";
import { readParam } from "@/components/admin/pagination";

export const dynamic = "force-dynamic";

export default async function SuiviEntreprisePage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const base = `/app/${orgId}`;
  const ctx = await guardOrg(orgId, `${base}/suivi-entreprise`, "dossier.pedagogy.view");
  const sp = await searchParams;
  const enrollmentId = readParam(sp.enrollment);
  const canManage = ctx.permissions.has("dossier.pedagogy.manage");
  const scope = await trainerSessionIds(ctx);
  const today = todayParis();
  // Rappels : une tâche par échéance dépassée (idempotent).
  await createOverdueFollowupTasks(orgId, ctx.org.isDemo);

  const followupForm = (eid: string, tutor: { id: string; firstName: string; lastName: string } | null) => (
    <FormDialog action={createFollowupAction} trigger="Nouveau suivi" triggerSize="sm" title="Suivi en entreprise" description="Visite, appel, bilan avec le tuteur : résumé, actions et prochaine échéance (un rappel est créé si elle est dépassée)." submitLabel="Enregistrer">
      <input type="hidden" name="orgId" value={orgId} />
      <input type="hidden" name="enrollmentId" value={eid} />
      <div className="grid grid-cols-2 gap-3">
        <Field label="Type" required htmlFor={`fk-${eid}`}>
          <Select id={`fk-${eid}`} name="kind" defaultValue="appel">
            {Object.entries(FOLLOWUP_KIND_LABELS).map(([v, l]) => (
              <option key={v} value={v}>
                {l}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Date" required htmlFor={`fd-${eid}`} help="Suivi réalisé (pas de date future).">
          <Input id={`fd-${eid}`} name="date" type="date" required defaultValue={today} max={today} />
        </Field>
      </div>
      {tutor ? <p className="text-[12.5px] text-ink-2">Tuteur du dossier : {tutor.firstName} {tutor.lastName}</p> : null}
      <Field label="Résumé" required htmlFor={`fs-${eid}`}>
        <Textarea id={`fs-${eid}`} name="summary" required />
      </Field>
      <Field label="Actions convenues" htmlFor={`fa-${eid}`}>
        <Textarea id={`fa-${eid}`} name="actions" className="min-h-16" />
      </Field>
      <Field label="Prochaine échéance" htmlFor={`fn-${eid}`} help="Un rappel est adressé au responsable pédagogique si elle est dépassée sans nouveau suivi.">
        <Input id={`fn-${eid}`} name="nextDate" type="date" />
      </Field>
    </FormDialog>
  );

  if (enrollmentId) {
    if (!/^[0-9a-f-]{36}$/.test(enrollmentId)) notFound();
    try {
      await assertEnrollmentInScope(ctx, enrollmentId);
    } catch (e) {
      if (e instanceof AuthError) notFound();
      throw e;
    }
    const [row] = await db
      .select({ enrollment: schema.enrollments, person: schema.persons, session: schema.trainingSessions, company: schema.companies, tutor: schema.contacts })
      .from(schema.enrollments)
      .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
      .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.enrollments.sessionId))
      .leftJoin(schema.companies, eq(schema.companies.id, schema.enrollments.companyId))
      .leftJoin(schema.contacts, eq(schema.contacts.id, schema.enrollments.tutorContactId))
      .where(and(eq(schema.enrollments.id, enrollmentId), eq(schema.enrollments.orgId, orgId)))
      .limit(1);
    if (!row) notFound();
    const followups = await db
      .select({ f: schema.companyFollowups, tutor: { firstName: schema.contacts.firstName, lastName: schema.contacts.lastName } })
      .from(schema.companyFollowups)
      .leftJoin(schema.contacts, eq(schema.contacts.id, schema.companyFollowups.tutorContactId))
      .where(and(eq(schema.companyFollowups.orgId, orgId), eq(schema.companyFollowups.enrollmentId, enrollmentId)))
      .orderBy(desc(schema.companyFollowups.date));
    const last = followups[0]?.f;
    const overdue = last?.nextDate && last.nextDate < today;
    return (
      <>
        <PageHeader
          breadcrumb={[{ label: "Suivi en entreprise", href: `${base}/suivi-entreprise` }, { label: `${row.person.firstName} ${row.person.lastName}` }]}
          title={`${row.person.firstName} ${row.person.lastName}`}
          description={`${row.enrollment.reference} · ${row.session.code} : ${row.session.title}`}
          actions={
            <div className="flex gap-2">
              <Button asChild variant="secondary" size="sm">
                <Link href={`${base}/inscriptions/${row.enrollment.id}`}>Dossier</Link>
              </Button>
              {canManage ? followupForm(row.enrollment.id, row.tutor ? { id: row.tutor.id, firstName: row.tutor.firstName, lastName: row.tutor.lastName } : null) : null}
            </div>
          }
        />
        {overdue ? (
          <Notice tone="warn" className="mb-6" title="Échéance dépassée">
            Le suivi prévu le {fmtDate(last!.nextDate)} n&apos;a pas été enregistré. Une tâche de rappel est adressée au responsable pédagogique.
          </Notice>
        ) : null}
        <Panel className="mb-6 p-5">
          <KeyValue
            items={[
              { k: "Entreprise", v: row.company ? <Link href={`${base}/entreprises/${row.company.id}`} className="hover:underline">{row.company.name}</Link> : "Non renseignée" },
              { k: "Tuteur", v: row.tutor ? `${row.tutor.firstName} ${row.tutor.lastName}${row.tutor.email ? ` · ${row.tutor.email}` : ""}` : "Non renseigné" },
              { k: "Contrat", v: <StatusBadge status={row.enrollment.contractKind} /> },
              { k: "Prochaine échéance", v: last?.nextDate ? fmtDate(last.nextDate) : "Aucune" },
            ]}
          />
        </Panel>
        <Panel>
          <PanelHeader title="Historique des suivis" description="Les incidents restent internes ; les autres suivis sont visibles par le tuteur sur l'extranet entreprise." />
          {followups.length ? (
            <ul className="divide-y divide-line">
              {followups.map(({ f, tutor }) => (
                <li key={f.id} className="px-5 py-4">
                  <p className="text-[13.5px]">
                    <span className="num text-ink-3">{fmtDate(f.date)}</span> · <Badge tone={f.kind === "incident" ? "danger" : "neutral"}>{FOLLOWUP_KIND_LABELS[f.kind] ?? f.kind}</Badge>
                    {tutor ? <span className="ml-2 text-ink-3">avec {tutor.firstName} {tutor.lastName}</span> : null}
                  </p>
                  <p className="mt-1.5 whitespace-pre-line text-[13.5px] text-ink">{f.summary}</p>
                  {f.actions ? <p className="mt-1 whitespace-pre-line text-[13px] text-ink-2">Actions : {f.actions}</p> : null}
                  {f.nextDate ? (
                    <p className="num mt-1 text-[12px] text-ink-3">
                      Prochaine échéance : {fmtDate(f.nextDate)}
                      {f.id === last?.id && overdue ? <Badge tone="warn" className="ml-2">Dépassée</Badge> : null}
                    </p>
                  ) : null}
                </li>
              ))}
            </ul>
          ) : (
            <EmptyState title="Aucun suivi" description="Enregistrez la première visite ou le premier appel avec le tuteur." action={canManage ? followupForm(row.enrollment.id, row.tutor ? { id: row.tutor.id, firstName: row.tutor.firstName, lastName: row.tutor.lastName } : null) : undefined} />
          )}
        </Panel>
      </>
    );
  }

  const lastSub = db
    .select({ enrollmentId: schema.companyFollowups.enrollmentId, maxDate: sql<string>`max(${schema.companyFollowups.date})`.as("max_date"), count: sql<number>`count(*)::int`.as("cnt") })
    .from(schema.companyFollowups)
    .where(eq(schema.companyFollowups.orgId, orgId))
    .groupBy(schema.companyFollowups.enrollmentId)
    .as("last");
  const rows = await db
    .select({ enrollment: schema.enrollments, person: { firstName: schema.persons.firstName, lastName: schema.persons.lastName }, session: { id: schema.trainingSessions.id, code: schema.trainingSessions.code }, company: { name: schema.companies.name }, lastDate: lastSub.maxDate, count: lastSub.count, nextDate: schema.companyFollowups.nextDate })
    .from(schema.enrollments)
    .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
    .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.enrollments.sessionId))
    .leftJoin(schema.companies, eq(schema.companies.id, schema.enrollments.companyId))
    .leftJoin(lastSub, eq(lastSub.enrollmentId, schema.enrollments.id))
    .leftJoin(schema.companyFollowups, and(eq(schema.companyFollowups.enrollmentId, schema.enrollments.id), eq(schema.companyFollowups.date, lastSub.maxDate)))
    .where(
      and(
        eq(schema.enrollments.orgId, orgId),
        inArray(schema.enrollments.status, ["inscrit", "en_cours"]),
        or(eq(schema.trainingSessions.isApprenticeship, true), inArray(schema.enrollments.contractKind, ["contrat_apprentissage", "contrat_professionnalisation", "stage"])),
        scope ? (scope.length ? inArray(schema.enrollments.sessionId, scope) : eq(schema.enrollments.id, "00000000-0000-0000-0000-000000000000")) : sql`true`,
      ),
    )
    .orderBy(asc(schema.persons.lastName));
  const seen = new Set<string>();
  const list = rows.filter((r) => (seen.has(r.enrollment.id) ? false : (seen.add(r.enrollment.id), true)));
  const overdueCount = list.filter((r) => r.nextDate && r.nextDate < today).length;

  return (
    <>
      <PageHeader title="Suivi en entreprise" description="Alternants et stagiaires : visites, appels, bilans avec le tuteur, prochaine échéance. Les échéances dépassées créent une tâche pour le responsable pédagogique." />
      {overdueCount ? (
        <Notice tone="warn" className="mb-6">
          {overdueCount} suivi(s) en retard.
        </Notice>
      ) : null}
      <Panel>
        {list.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Apprenant</Th>
                <Th>Entreprise</Th>
                <Th>Session</Th>
                <Th>Contrat</Th>
                <Th num>Suivis</Th>
                <Th>Dernier suivi</Th>
                <Th>Prochaine échéance</Th>
                <Th />
              </tr>
            </thead>
            <tbody>
              {list.map((r) => {
                const late = r.nextDate && r.nextDate < today;
                return (
                  <tr key={r.enrollment.id}>
                    <Td>
                      <Link href={`${base}/suivi-entreprise?enrollment=${r.enrollment.id}`} className="font-medium hover:underline">
                        {r.person.lastName.toUpperCase()} {r.person.firstName}
                      </Link>
                      <p className="num text-[12px] text-ink-3">{r.enrollment.reference}</p>
                    </Td>
                    <Td>{r.company?.name ?? "-"}</Td>
                    <Td>{r.session.code}</Td>
                    <Td>
                      <StatusBadge status={r.enrollment.contractKind} />
                    </Td>
                    <Td num>{r.count ?? 0}</Td>
                    <Td>{r.lastDate ? fmtDate(r.lastDate) : "Jamais"}</Td>
                    <Td>
                      {r.nextDate ? fmtDate(r.nextDate) : "-"} {late ? <Badge tone="warn">Dépassée</Badge> : null}
                    </Td>
                    <Td>
                      <Button asChild variant="secondary" size="sm">
                        <Link href={`${base}/suivi-entreprise?enrollment=${r.enrollment.id}`}>Suivre</Link>
                      </Button>
                    </Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucune inscription en alternance" description="Les inscriptions actives en apprentissage, professionnalisation ou stage apparaissent ici." />
        )}
      </Panel>
    </>
  );
}
