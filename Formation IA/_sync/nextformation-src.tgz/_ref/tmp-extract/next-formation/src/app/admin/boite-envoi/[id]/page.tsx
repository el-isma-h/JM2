import { notFound } from "next/navigation";
import { eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardAdmin } from "@/server/guard";
import { audit } from "@/server/audit";
import { resendMailAction } from "@/server/actions/admin";
import { appUrl, integrations } from "@/lib/env";
import { fmtDateTime } from "@/lib/dates";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { KeyValue, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td } from "@/components/ui/table";
import { ActionButton, LinkToCopy } from "@/components/admin/action-form";

export const dynamic = "force-dynamic";

const linkKinds: [RegExp, string][] = [
  [/\/verification\?token=/, "Vérification de l'adresse e-mail"],
  [/\/reinitialiser\?token=/, "Réinitialisation du mot de passe"],
  [/\/invitation\//, "Invitation"],
  [/\/telechargement\//, "Téléchargement temporaire"],
];

export default async function MailDetail({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!/^[0-9a-f-]{36}$/.test(id)) notFound();
  const admin = await guardAdmin(`/admin/boite-envoi/${id}`);
  const [m] = await db.select().from(schema.mailOutbox).where(eq(schema.mailOutbox.id, id)).limit(1);
  if (!m) notFound();
  // Lecture sensible : le contenu peut porter un lien à usage unique.
  await audit({ action: "admin.mail.view", userId: admin.id, entityType: "mail", entityId: id });

  const base = appUrl();
  const hrefs = [...new Set([...m.html.matchAll(/href="([^"]+)"/g)].map((x) => x[1].replace(/&amp;/g, "&")))];
  const links = hrefs.map((h) => ({ url: h, kind: linkKinds.find(([re]) => re.test(h))?.[1] ?? (h.startsWith(base) ? "Lien de l'application" : "Lien externe") }));
  const canResend = integrations.mail() && !m.isDemo;

  return (
    <>
      <PageHeader
        breadcrumb={[{ label: "Boîte d'envoi", href: "/admin/boite-envoi" }, { label: m.subject }]}
        title={m.subject}
        description={`À ${m.to}`}
        actions={
          canResend ? (
            <ActionButton action={resendMailAction} fields={{ id }} label="Renvoyer" variant="primary" size="md" confirm={{ title: "Renvoyer cet e-mail", description: `Un nouvel envoi identique partira vers ${m.to}. Les liens à usage unique déjà utilisés ou expirés ne fonctionneront plus.`, confirmLabel: "Renvoyer" }} />
          ) : null
        }
      />
      {!integrations.mail() ? (
        <Notice tone="warn" className="mb-6" title="Mode sans e-mail">
          Le service e-mail n&apos;est pas configuré : cet e-mail n&apos;est pas parti. Copiez le lien ci-dessous et transmettez-le à la personne par un canal sûr.
        </Notice>
      ) : null}
      {m.isDemo ? (
        <Notice tone="warn" className="mb-6">
          Démonstration : aucun envoi réel.
        </Notice>
      ) : null}
      <div className="grid gap-6 lg:grid-cols-[minmax(0,2fr)_minmax(0,3fr)]">
        <div className="space-y-6">
          <Panel>
            <PanelHeader title="Envoi" />
            <KeyValue
              className="px-5 py-4"
              items={[
                { k: "Statut", v: <span className="flex gap-1"><StatusBadge status={m.status} />{m.isDemo ? <Badge tone="warn">Démo</Badge> : null}</span> },
                { k: "Créé", v: fmtDateTime(m.createdAt) },
                { k: "Envoyé", v: m.sentAt ? fmtDateTime(m.sentAt) : "Non" },
                { k: "Identifiant fournisseur", v: m.providerId ? <span className="num text-[12px]">{m.providerId}</span> : "-" },
                { k: "Erreur", v: m.error && m.error !== "demo" ? <span className="text-danger-ink">{m.error}</span> : "-" },
              ]}
            />
          </Panel>
          <Panel>
            <PanelHeader title="Liens contenus" description="Liens présents dans l'e-mail, à copier si l'envoi n'est pas configuré." />
            {links.length ? (
              <Table>
                <tbody>
                  {links.map((l) => (
                    <tr key={l.url}>
                      <Td>
                        <p className="text-[13px] font-medium">{l.kind}</p>
                        <LinkToCopy value={l.url} />
                      </Td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            ) : (
              <p className="px-5 py-4 text-[13.5px] text-ink-2">Aucun lien dans cet e-mail.</p>
            )}
          </Panel>
          {m.text ? (
            <Panel>
              <PanelHeader title="Version texte" />
              <pre className="whitespace-pre-wrap px-5 py-4 text-[13px] text-ink-2">{m.text}</pre>
            </Panel>
          ) : null}
        </div>
        <Panel className="overflow-hidden">
          <PanelHeader title="Aperçu" description="Rendu isolé : aucun script ni ressource externe n'est exécuté." />
          <iframe title="Aperçu de l'e-mail" sandbox="" srcDoc={m.html} className="h-[640px] w-full border-0 bg-bg" />
        </Panel>
      </div>
    </>
  );
}
