import Link from "next/link";
import { addDays, addMonths, endOfMonth, format, parseISO, startOfMonth, startOfWeek } from "date-fns";
import { fr } from "date-fns/locale";
import { guardOrg } from "@/server/guard";
import { agendaFor, type AgendaItem } from "@/server/tasks/agenda";
import { todayParis, toParis } from "@/lib/time";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { FadeIn } from "@/components/ui/motion";
import { ActionButton } from "@/components/admin/action-form";
import { deleteAgendaEventAction } from "@/server/actions/agenda";
import { CreateEventDialog } from "./create-event";

export const dynamic = "force-dynamic";

const iso = (d: Date) => format(d, "yyyy-MM-dd");
const kindTone: Record<AgendaItem["kind"], "accent" | "info" | "warn" | "ok" | "neutral"> = { seance: "accent", tache: "warn", examen: "info", rdv: "ok", autre: "neutral" };
const kindLabel: Record<AgendaItem["kind"], string> = { seance: "Séance", tache: "Tâche", examen: "Examen", rdv: "Rendez-vous", autre: "Autre" };

export default async function AgendaPage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const ctx = await guardOrg(orgId, `/app/${orgId}/agenda`);
  const sp = await searchParams;
  const view = sp.view === "mois" ? "mois" : "semaine";
  const today = todayParis();
  const anchorRaw = typeof sp.d === "string" && /^\d{4}-\d{2}-\d{2}$/.test(sp.d) ? sp.d : today;
  const anchor = parseISO(anchorRaw);
  const from = view === "semaine" ? startOfWeek(anchor, { weekStartsOn: 1 }) : startOfMonth(anchor);
  const to = view === "semaine" ? addDays(from, 6) : endOfMonth(anchor);
  const items = await agendaFor(ctx, iso(from), iso(to));
  const prev = view === "semaine" ? addDays(anchor, -7) : addMonths(anchor, -1);
  const next = view === "semaine" ? addDays(anchor, 7) : addMonths(anchor, 1);
  const link = (d: Date, v = view) => `/app/${orgId}/agenda?view=${v}&d=${iso(d)}`;

  const days: Date[] = [];
  for (let d = from; d <= to; d = addDays(d, 1)) days.push(d);
  const byDay = new Map<string, AgendaItem[]>();
  for (const it of items) {
    const k = iso(toParis(it.start));
    byDay.set(k, [...(byDay.get(k) ?? []), it]);
  }
  const fmtTime = (d: Date) => format(toParis(d), "HH:mm");

  return (
    <FadeIn>
      <PageHeader
        title="Agenda"
        description={`Vos rendez-vous, vos séances comme formateur, les échéances de vos tâches et les examens dont vous êtes responsable. ${view === "semaine" ? `Semaine du ${format(from, "d MMMM yyyy", { locale: fr })}` : format(from, "MMMM yyyy", { locale: fr })}.`}
        actions={
          <>
            <Button asChild variant="ghost" size="sm">
              <a href={`/app/${orgId}/agenda/ical?from=${iso(from)}&to=${iso(addDays(to, 60))}`}>Exporter (iCal)</a>
            </Button>
            <CreateEventDialog orgId={orgId} defaultDate={anchorRaw} />
          </>
        }
      />
      <Panel>
        <PanelHeader
          title={view === "semaine" ? `Semaine ${format(from, "I", { locale: fr })}` : format(from, "MMMM yyyy", { locale: fr })}
          actions={
            <>
              <Button asChild variant="ghost" size="sm">
                <Link href={link(prev)}>Précédent</Link>
              </Button>
              <Button asChild variant="ghost" size="sm">
                <Link href={link(parseISO(today))}>Aujourd&apos;hui</Link>
              </Button>
              <Button asChild variant="ghost" size="sm">
                <Link href={link(next)}>Suivant</Link>
              </Button>
              <Button asChild variant={view === "semaine" ? "primary" : "secondary"} size="sm">
                <Link href={link(anchor, "semaine")}>Semaine</Link>
              </Button>
              <Button asChild variant={view === "mois" ? "primary" : "secondary"} size="sm">
                <Link href={link(anchor, "mois")}>Mois</Link>
              </Button>
            </>
          }
        />
        <div className={view === "semaine" ? "grid gap-px bg-line md:grid-cols-7" : "grid gap-px bg-line sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-7"}>
          {days.map((d) => {
            const k = iso(d);
            const list = byDay.get(k) ?? [];
            const isToday = k === today;
            return (
              <div key={k} className={`min-h-[120px] bg-bg-elev p-3 ${view === "mois" && (d.getDay() === 0 || d.getDay() === 6) ? "bg-bg-sunken" : ""}`}>
                <p className={`mb-2 font-mono text-[10px] uppercase tracking-[0.16em] ${isToday ? "text-accent" : "text-ink-3"}`}>
                  {format(d, view === "semaine" ? "EEEE d" : "EEE d", { locale: fr })}
                  {isToday ? " (aujourd'hui)" : ""}
                </p>
                <ul className="space-y-1.5">
                  {list.map((it) => (
                    <li key={it.id} className="border-s-2 border-line-strong pl-2 text-[12.5px]">
                      <div className="flex items-center gap-1.5">
                        <Badge tone={kindTone[it.kind]}>{kindLabel[it.kind]}</Badge>
                        {!it.allDay ? (
                          <span className="num text-ink-3">
                            {fmtTime(it.start)} {it.end ? `: ${fmtTime(it.end)}` : ""}
                          </span>
                        ) : null}
                      </div>
                      {it.href ? (
                        <Link href={it.href} className="mt-0.5 block text-ink hover:underline">
                          {it.title}
                        </Link>
                      ) : (
                        <p className="mt-0.5 text-ink">{it.title}</p>
                      )}
                      {it.detail ? <p className="text-[11.5px] text-ink-3">{it.detail}</p> : null}
                      {it.location ? <p className="text-[11.5px] text-ink-3">{it.location}</p> : null}
                      {it.own ? <ActionButton action={deleteAgendaEventAction} fields={{ orgId, eventId: it.id.slice(3) }} label="Supprimer" variant="ghost" confirm={{ title: "Supprimer l'événement", description: it.title, confirmLabel: "Supprimer", danger: true }} className="mt-1" /> : null}
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>
        {!items.length ? <p className="border-t border-line px-5 py-4 text-[13.5px] text-ink-2">Aucun élément sur cette période. Les séances apparaissent si votre compte est rattaché à une fiche formateur ; les échéances viennent de « Mes tâches ».</p> : null}
      </Panel>
    </FadeIn>
  );
}
