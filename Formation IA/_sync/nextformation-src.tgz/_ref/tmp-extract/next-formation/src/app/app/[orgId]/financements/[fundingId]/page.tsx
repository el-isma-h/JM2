import Link from "next/link";
import { notFound } from "next/navigation";
import { and, asc, desc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { changeFundingStatusAction, deleteFundingAction, downloadFinanceDocumentAction, updateFundingAction, uploadFundingAgreementAction } from "@/server/actions/finance";
import { allowedFundingTransitions, funderKindLabels, overdueScheduleLines, type FundingStatus } from "@/server/finance/compute";
import { financeSummary, readSchedule } from "@/server/finance/service";
import { formatCents } from "@/lib/money";
import { fmtDate, fmtDateTime } from "@/lib/dates";
import { todayParis } from "@/lib/time";
import { Badge, StatusBadge, statusMeta } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea } from "@/components/ui/field";
import { KeyValue, Notice, PageHeader, Panel, PanelHeader, Stat } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { ActionButton, ActionForm } from "@/components/admin/action-form";
import { FormDialog } from "@/components/admin/form-dialog";
import { FundingForm } from "@/components/finance/funding-form";

export const dynamic = "force-dynamic";

export default async function FundingPage({ params }: { params: Promise<{ orgId: string; fundingId: string }> }) {
  const { orgId, fundingId } = await params;
  const ctx = await guardOrg(orgId, `/app/${orgId}/financements/${fundingId}`, "finance.view");
  const canManage = ctx.permissions.has("finance.manage");
  if (!/^[0-9a-f-]{36}$/.test(fundingId)) notFound();
  const [row] = await db
    .select({ f: schema.fundings, e: schema.enrollments, person: { firstName: schema.persons.firstName, lastName: schema.persons.lastName }, session: { code: schema.trainingSessions.code, title: schema.trainingSessions.title }, funderName: schema.funders.name, companyName: schema.companies.name })
    .from(schema.fundings)
    .innerJoin(schema.enrollments, eq(schema.enrollments.id, schema.fundings.enrollmentId))
    .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
    .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.enrollments.sessionId))
    .leftJoin(schema.funders, eq(schema.funders.id, schema.fundings.funderId))
    .leftJoin(schema.companies, eq(schema.companies.id, schema.enrollments.companyId))
    .where(and(eq(schema.fundings.id, fundingId), eq(schema.fundings.orgId, orgId)))
    .limit(1);
  if (!row) notFound();
  const { f, e } = row;
  const [funders, invoices, history, summary, doc] = await Promise.all([
    db.select({ id: schema.funders.id, name: schema.funders.name, kind: schema.funders.kind }).from(schema.funders).where(eq(schema.funders.orgId, orgId)).orderBy(asc(schema.funders.name)),
    db.select().from(schema.invoices).where(and(eq(schema.invoices.orgId, orgId), eq(schema.invoices.fundingId, f.id))).orderBy(desc(schema.invoices.createdAt)),
    db.select().from(schema.auditLogs).where(and(eq(schema.auditLogs.orgId, orgId), eq(schema.auditLogs.entityType, "funding"), eq(schema.auditLogs.entityId, f.id))).orderBy(desc(schema.auditLogs.createdAt)).limit(30),
    financeSummary(orgId, e.id),
    f.documentId ? db.select({ id: schema.documents.id, title: schema.documents.title, fileName: schema.documents.fileName, createdAt: schema.documents.createdAt, version: schema.documents.version }).from(schema.documents).where(and(eq(schema.documents.id, f.documentId), eq(schema.documents.orgId, orgId))).limit(1).then((r) => r[0] ?? null) : Promise.resolve(null),
  ]);
  const schedule = readSchedule(f.schedule);
  const today = todayParis();
  const late = overdueScheduleLines(schedule, today);
  const transitions = allowedFundingTransitions(f.status as FundingStatus);
  const invoiceById = new Map(invoices.map((i) => [i.id, i]));
  const locked = f.status === "solde";
  const billable = ["accorde", "facture"].includes(f.status);

  return (
    <>
      <PageHeader
        breadcrumb={[{ label: "Finance" }, { label: "Financements", href: `/app/${orgId}/financements?enrollment=${e.id}` }, { label: f.label }]}
        title={f.label}
        description={
          <>
            Inscription <Link href={`/app/${orgId}/inscriptions/${e.id}`} className="num underline">{e.reference}</Link> · {row.person.firstName} {row.person.lastName} · {row.session.code} {row.session.title}
          </>
        }
        actions={
          <>
            <StatusBadge status={f.status} />
            {canManage && transitions.length ? (
              <FormDialog action={changeFundingStatusAction} trigger="Changer le statut" triggerVariant="secondary" title="Changer le statut du financement" description="Le passage à « accordé » exige la référence de prise en charge, sa source et sa date de validité. Chaque changement est journalisé." submitLabel="Appliquer">
                <input type="hidden" name="orgId" value={orgId} />
                <input type="hidden" name="fundingId" value={f.id} />
                <Field label="Nouveau statut" htmlFor="st-status">
                  <Select id="st-status" name="status" defaultValue={transitions[0]}>
                    {transitions.map((t) => (
                      <option key={t} value={t}>
                        {statusMeta[t]?.label ?? t}
                      </option>
                    ))}
                  </Select>
                </Field>
                <Field label="Référence de prise en charge" htmlFor="st-ref" help="Obligatoire pour « accordé ». Laissez vide pour conserver la valeur actuelle.">
                  <Input id="st-ref" name="agreementRef" className="num" defaultValue={f.agreementRef ?? ""} />
                </Field>
                <Field label="Source de l'accord" htmlFor="st-src">
                  <Input id="st-src" name="agreementSource" defaultValue={f.agreementSource ?? ""} />
                </Field>
                <div className="grid grid-cols-3 gap-3">
                  <Field label="Date de l'accord" htmlFor="st-ad">
                    <Input id="st-ad" name="agreementDate" type="date" defaultValue={f.agreementDate ?? ""} />
                  </Field>
                  <Field label="Valide du" htmlFor="st-vf">
                    <Input id="st-vf" name="validFrom" type="date" defaultValue={f.validFrom ?? ""} />
                  </Field>
                  <Field label="Valide jusqu'au" htmlFor="st-vu">
                    <Input id="st-vu" name="validUntil" type="date" defaultValue={f.validUntil ?? ""} />
                  </Field>
                </div>
                <Field label="Motif (obligatoire pour refus ou annulation)" htmlFor="st-reason">
                  <Textarea id="st-reason" name="reason" className="min-h-16" />
                </Field>
              </FormDialog>
            ) : null}
            {canManage && billable ? (
              <Button asChild>
                <Link href={`/app/${orgId}/factures/nouvelle?funding=${f.id}`}>Facturer ce financement</Link>
              </Button>
            ) : null}
          </>
        }
      />

      {!["accorde", "facture", "solde"].includes(f.status) && canManage ? <Notice tone="info" className="mb-6">La facturation n&apos;est possible qu&apos;une fois le financement « accordé » avec sa référence de prise en charge.</Notice> : null}
      {late.length ? (
        <Notice tone="warn" className="mb-6">
          {late.length} échéance(s) dépassée(s) sans facture : {late.map((l) => `${l.label} (${fmtDate(l.dueDate)}, ${formatCents(l.amountCents)})`).join(" ; ")}. Une tâche « finance » a été créée pour chacune.
        </Notice>
      ) : null}

      <Panel className="mb-6 grid grid-cols-2 gap-6 p-5 md:grid-cols-5">
        <Stat label="Ce financement" value={formatCents(f.amountCents)} hint={funderKindLabels[f.kind] + (row.funderName ? ` · ${row.funderName}` : "")} />
        <Stat label="Inscription : prévu" value={formatCents(summary.plannedCents)} />
        <Stat label="Accordé" value={formatCents(summary.grantedCents)} />
        <Stat label="Facturé" value={formatCents(summary.billedCents)} />
        <Stat label="Encaissé" value={formatCents(summary.paidCents)} hint={`solde ${formatCents(summary.balanceCents)}`} />
      </Panel>

      <div className="grid gap-6 xl:grid-cols-[1.4fr_1fr]">
        <div className="space-y-6">
          <Panel>
            <PanelHeader title="Fiche et échéancier" description={locked ? "Financement soldé : lecture seule." : "Montant, barème, accord et échéances. Les lignes facturées sont figées."} />
            <div className="p-5">
              {canManage ? (
                <FundingForm orgId={orgId} action={updateFundingAction} funders={funders} submitLabel="Enregistrer" withSchedule locked={locked} initial={{ fundingId: f.id, kind: f.kind, funderId: f.funderId, label: f.label, amountCents: f.amountCents, rateNote: f.rateNote, notes: f.notes, agreementRef: f.agreementRef, agreementSource: f.agreementSource, agreementDate: f.agreementDate, validFrom: f.validFrom, validUntil: f.validUntil, schedule }} />
              ) : (
                <KeyValue items={[{ k: "Type", v: funderKindLabels[f.kind] }, { k: "Financeur", v: row.funderName }, { k: "Montant", v: <span className="num">{formatCents(f.amountCents)}</span> }, { k: "Barème", v: f.rateNote }, { k: "Référence", v: f.agreementRef }, { k: "Source", v: f.agreementSource }, { k: "Validité", v: f.validUntil ? `${f.validFrom ? `du ${fmtDate(f.validFrom)} ` : ""}jusqu'au ${fmtDate(f.validUntil)}` : null }, { k: "Notes", v: f.notes }]} />
              )}
            </div>
            {schedule.length ? (
              <Table>
                <thead>
                  <tr>
                    <Th>Échéance</Th>
                    <Th>Date</Th>
                    <Th num>Montant</Th>
                    <Th>Facture</Th>
                    <Th></Th>
                  </tr>
                </thead>
                <tbody>
                  {schedule.map((l, i) => {
                    const inv = l.invoiceId ? invoiceById.get(l.invoiceId) : null;
                    const overdue = !l.invoiceId && l.dueDate < today;
                    return (
                      <tr key={i}>
                        <Td>{l.label}</Td>
                        <Td>
                          {fmtDate(l.dueDate)} {overdue ? <Badge tone="danger" className="ml-2">Dépassée</Badge> : null}
                        </Td>
                        <Td num>{formatCents(l.amountCents)}</Td>
                        <Td>
                          {inv ? (
                            <Link href={`/app/${orgId}/factures/${inv.id}`} className="num hover:underline">
                              {inv.number ?? "Brouillon"} <StatusBadge status={inv.status} className="ml-1" />
                            </Link>
                          ) : (
                            <span className="text-ink-3">À facturer</span>
                          )}
                        </Td>
                        <Td>
                          {!inv && canManage && billable ? (
                            <Button asChild size="sm" variant="secondary">
                              <Link href={`/app/${orgId}/factures/nouvelle?funding=${f.id}&schedule=${i}`}>Facturer (acompte)</Link>
                            </Button>
                          ) : null}
                        </Td>
                      </tr>
                    );
                  })}
                </tbody>
              </Table>
            ) : null}
          </Panel>

          <Panel>
            <PanelHeader title="Factures rattachées" />
            {invoices.length ? (
              <Table>
                <thead>
                  <tr>
                    <Th>Numéro</Th>
                    <Th>Type</Th>
                    <Th>Date</Th>
                    <Th>Statut</Th>
                    <Th num>TTC</Th>
                    <Th num>Réglé</Th>
                  </tr>
                </thead>
                <tbody>
                  {invoices.map((i) => (
                    <tr key={i.id}>
                      <Td>
                        <Link href={`/app/${orgId}/factures/${i.id}`} className="num text-ink hover:underline">
                          {i.number ?? "Brouillon"}
                        </Link>
                      </Td>
                      <Td>{i.kind}</Td>
                      <Td>{fmtDate(i.issueDate)}</Td>
                      <Td>
                        <StatusBadge status={i.status} />
                      </Td>
                      <Td num>{formatCents(i.totalTtcCents)}</Td>
                      <Td num>{formatCents(i.paidCents)}</Td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            ) : (
              <p className="px-5 py-6 text-[13px] text-ink-3">Aucune facture rattachée.</p>
            )}
          </Panel>
        </div>

        <div className="space-y-6">
          <Panel>
            <PanelHeader title="Document d'accord" description="Accord de prise en charge du financeur (pièce justificative, 10 ans)." />
            <div className="space-y-4 p-5">
              {doc ? (
                <div className="text-[13px]">
                  <p className="font-medium text-ink">{doc.title}</p>
                  <p className="text-ink-3">
                    {doc.fileName} · version {doc.version} · déposé le {fmtDateTime(doc.createdAt)}
                  </p>
                  <ActionButton action={downloadFinanceDocumentAction} fields={{ orgId, documentId: doc.id }} label="Télécharger" className="mt-2" />
                </div>
              ) : (
                <p className="text-[13px] text-ink-3">Aucun document déposé.{f.status === "accorde" ? " Une tâche « Pièce : accord de prise en charge » est ouverte pour l'administratif." : ""}</p>
              )}
              {canManage && !locked ? (
                <ActionForm action={uploadFundingAgreementAction} submitLabel={doc ? "Déposer une nouvelle version" : "Déposer l'accord"} submitVariant="secondary" submitSize="sm">
                  <input type="hidden" name="orgId" value={orgId} />
                  <input type="hidden" name="fundingId" value={f.id} />
                  <Field label="Fichier (PDF, image)" htmlFor="agr-file" className="mb-3">
                    <Input id="agr-file" name="file" type="file" accept=".pdf,.png,.jpg,.jpeg" required className="py-1.5" />
                  </Field>
                </ActionForm>
              ) : null}
            </div>
          </Panel>

          <Panel>
            <PanelHeader title="Dossier" />
            <div className="p-5">
              <KeyValue items={[{ k: "Inscription", v: <Link href={`/app/${orgId}/inscriptions/${e.id}`} className="num underline">{e.reference}</Link> }, { k: "Apprenant", v: `${row.person.firstName} ${row.person.lastName}` }, { k: "Entreprise", v: row.companyName }, { k: "Session", v: `${row.session.code} · ${row.session.title}` }, { k: "État financement", v: <StatusBadge status={summary.fundingState} /> }, { k: "Prochaine échéance", v: summary.nextDue ? `${fmtDate(summary.nextDue.dueDate)} · ${formatCents(summary.nextDue.amountCents)}` : "aucune" }]} />
            </div>
          </Panel>

          <Panel>
            <PanelHeader title="Historique" description="Journal d'audit : chaque modification conserve avant / après." />
            {history.length ? (
              <ul className="divide-y divide-line text-[12.5px]">
                {history.map((h) => (
                  <li key={h.id} className="px-5 py-2.5">
                    <span className="num text-ink-3">{fmtDateTime(h.createdAt)}</span> · <span className="font-mono text-[11px]">{h.action}</span>
                    {h.after && typeof h.after === "object" && "status" in (h.after as object) ? <span className="ml-2">→ {String((h.after as { status?: string }).status)}</span> : null}
                  </li>
                ))}
              </ul>
            ) : (
              <p className="px-5 py-6 text-[13px] text-ink-3">Aucun événement.</p>
            )}
          </Panel>

          {canManage && ["prevu", "demande", "annule", "refuse"].includes(f.status) && !invoices.length ? (
            <ActionButton action={deleteFundingAction} fields={{ orgId, fundingId: f.id }} label="Supprimer ce financement" variant="danger" confirm={{ title: "Supprimer le financement ?", description: "Possible uniquement sans facture rattachée. L'état de l'inscription est recalculé.", danger: true, confirmLabel: "Supprimer" }} />
          ) : null}
        </div>
      </div>
    </>
  );
}
