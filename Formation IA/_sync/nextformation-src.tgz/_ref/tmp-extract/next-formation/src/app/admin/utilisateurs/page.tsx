import Link from "next/link";
import { and, desc, eq, ilike, isNotNull, isNull, not, or, sql, type SQL } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardAdmin } from "@/server/guard";
import { fmtDateTime } from "@/lib/dates";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox, Field, Input, Select } from "@/components/ui/field";
import { EmptyState, PageHeader, Panel } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { Pagination, readPage, readParam } from "@/components/admin/pagination";

export const dynamic = "force-dynamic";
const PAGE = 50;

export default async function UsersPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  await guardAdmin("/admin/utilisateurs");
  const sp = await searchParams;
  const q = readParam(sp.q);
  const filter = readParam(sp.filter);
  const demo = readParam(sp.demo) === "1";
  const page = readPage(sp.page);

  const conds: SQL[] = [];
  if (!demo) conds.push(not(ilike(schema.users.email, "%@demo.nextformation.invalid")));
  if (q) conds.push(or(ilike(schema.users.email, `%${q}%`), ilike(schema.users.firstName, `%${q}%`), ilike(schema.users.lastName, `%${q}%`), ilike(sql`${schema.users.firstName} || ' ' || ${schema.users.lastName}`, `%${q}%`))!);
  if (filter === "admins") conds.push(eq(schema.users.platformRole, "platform_admin"));
  if (filter === "disabled") conds.push(isNotNull(schema.users.disabledAt));
  if (filter === "unverified") conds.push(isNull(schema.users.emailVerifiedAt));
  if (filter === "no_totp") conds.push(isNull(schema.users.totpEnabledAt));
  const where = conds.length ? and(...conds) : undefined;

  const [rows, [{ total }]] = await Promise.all([
    db
      .select({
        u: schema.users,
        tenantName: schema.tenants.name,
        orgs: sql<number>`(select count(*)::int from ${schema.memberships} m where m.user_id = "users"."id")`,
      })
      .from(schema.users)
      .leftJoin(schema.tenants, eq(schema.tenants.id, schema.users.tenantId))
      .where(where)
      .orderBy(desc(schema.users.createdAt))
      .limit(PAGE)
      .offset((page - 1) * PAGE),
    db.select({ total: sql<number>`count(*)::int` }).from(schema.users).where(where),
  ]);

  return (
    <>
      <PageHeader title="Utilisateurs" description="Tous les comptes de la plateforme. Les comptes de démonstration (adresse en @demo.nextformation.invalid) sont masqués par défaut." />
      <Panel>
        <form method="get" className="flex flex-wrap items-end gap-3 border-b border-line px-5 py-3">
          <Field label="Recherche" htmlFor="q" className="w-full max-w-xs">
            <Input id="q" name="q" defaultValue={q} placeholder="Nom ou adresse e-mail" />
          </Field>
          <Field label="Filtre" htmlFor="filter" className="w-56">
            <Select id="filter" name="filter" defaultValue={filter ?? ""}>
              <option value="">Tous les comptes</option>
              <option value="admins">Administrateurs plateforme</option>
              <option value="disabled">Comptes désactivés</option>
              <option value="unverified">Adresse non vérifiée</option>
              <option value="no_totp">Sans double authentification</option>
            </Select>
          </Field>
          <Checkbox name="demo" value="1" defaultChecked={demo} label="Inclure les démonstrations" className="mb-2" />
          <Button type="submit" variant="secondary">
            Filtrer
          </Button>
        </form>
        {rows.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Personne</Th>
                <Th>Organisation</Th>
                <Th num>Organismes</Th>
                <Th>Sécurité</Th>
                <Th>Dernière connexion</Th>
                <Th>État</Th>
              </tr>
            </thead>
            <tbody>
              {rows.map(({ u, tenantName, orgs }) => (
                <tr key={u.id}>
                  <Td>
                    <Link href={`/admin/utilisateurs/${u.id}`} className="font-medium hover:underline">
                      {u.firstName} {u.lastName}
                    </Link>
                    <p className="text-[12px] text-ink-3">{u.email}</p>
                  </Td>
                  <Td className="text-ink-2">{tenantName ?? "-"}</Td>
                  <Td num>{orgs}</Td>
                  <Td>
                    <div className="flex flex-wrap gap-1">
                      {u.totpEnabledAt ? <Badge tone="ok">Double authentification</Badge> : <Badge tone="neutral">Mot de passe seul</Badge>}
                      {!u.emailVerifiedAt ? <Badge tone="warn">Non vérifié</Badge> : null}
                    </div>
                  </Td>
                  <Td className="whitespace-nowrap text-ink-2">{u.lastLoginAt ? fmtDateTime(u.lastLoginAt) : "Jamais"}</Td>
                  <Td>
                    <div className="flex flex-wrap gap-1">
                      {u.platformRole === "platform_admin" ? <Badge tone="info">Admin plateforme</Badge> : null}
                      {u.disabledAt ? <Badge tone="danger">Désactivé</Badge> : <Badge tone="ok">Actif</Badge>}
                    </div>
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucun compte" description="Aucun compte ne correspond à ces critères." />
        )}
        <Pagination basePath="/admin/utilisateurs" params={{ q, filter, demo: demo ? "1" : undefined }} page={page} pageSize={PAGE} total={total} />
      </Panel>
    </>
  );
}
