import Link from "next/link";
import { and, desc, eq, ilike, or, sql, type SQL } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardAdmin } from "@/server/guard";
import { createTenantAction } from "@/server/actions/admin";
import { fmtDate } from "@/lib/dates";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox, Field, Input, Select } from "@/components/ui/field";
import { EmptyState, PageHeader, Panel } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FormDialog } from "@/components/admin/form-dialog";
import { Pagination, readPage, readParam } from "@/components/admin/pagination";

export const dynamic = "force-dynamic";

const kindLabel: Record<string, string> = { organisme: "Organisme", groupe: "Groupe" };
const PAGE = 50;

export default async function OrganisationsPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  await guardAdmin("/admin/organisations");
  const sp = await searchParams;
  const q = readParam(sp.q);
  const kind = readParam(sp.kind);
  const demo = readParam(sp.demo) === "1";
  const page = readPage(sp.page);

  const conds: SQL[] = [];
  if (!demo) conds.push(eq(schema.tenants.isDemo, false));
  if (kind && ["organisme", "groupe"].includes(kind)) conds.push(eq(schema.tenants.kind, kind as "organisme"));
  if (q) conds.push(or(ilike(schema.tenants.name, `%${q}%`), ilike(schema.tenants.slug, `%${q}%`), sql`exists (select 1 from ${schema.organismes} c where c.tenant_id = "tenants"."id" and (c.legal_name ilike ${`%${q}%`} or c.siren = ${q.replace(/\s/g, "")}))`)!);
  const where = conds.length ? and(...conds) : undefined;

  const [rows, [{ total }]] = await Promise.all([
    db
      .select({
        t: schema.tenants,
        orgs: sql<number>`(select count(*)::int from ${schema.organismes} c where c.tenant_id = "tenants"."id")`,
        users: sql<number>`(select count(*)::int from ${schema.users} u where u.tenant_id = "tenants"."id")`,
        enrollments: sql<number>`(select count(*)::int from ${schema.enrollments} e join ${schema.organismes} c on c.id = e.org_id where c.tenant_id = "tenants"."id" and e.status in ('inscrit','en_cours'))`,
      })
      .from(schema.tenants)
      .where(where)
      .orderBy(desc(schema.tenants.createdAt))
      .limit(PAGE)
      .offset((page - 1) * PAGE),
    db.select({ total: sql<number>`count(*)::int` }).from(schema.tenants).where(where),
  ]);

  return (
    <>
      <PageHeader
        title="Organisations"
        description="Chaque organisation (tenant) est un organisme seul ou un groupe gérant plusieurs organismes isolés. Les espaces de démonstration sont masqués par défaut."
        actions={
          <FormDialog action={createTenantAction} trigger="Nouvelle organisation" title="Nouvelle organisation" description="Crée le tenant et son premier organisme (OF ou CFA). Le propriétaire reçoit une invitation." submitLabel="Créer l'organisation">
            <Field label="Nom de l'organisation" required htmlFor="t-name">
              <Input id="t-name" name="name" required />
            </Field>
            <Field label="Type" htmlFor="t-kind" help="Un groupe peut gérer plusieurs organismes isolés (ex. un OF et un CFA).">
              <Select id="t-kind" name="kind" defaultValue="organisme">
                <option value="organisme">Organisme seul</option>
                <option value="groupe">Groupe de plusieurs organismes</option>
              </Select>
            </Field>
            <Field label="Raison sociale de l'organisme" required htmlFor="t-legal">
              <Input id="t-legal" name="legalName" required />
            </Field>
            <Field label="Activité" htmlFor="t-orgkind">
              <Select id="t-orgkind" name="orgKind" defaultValue="of">
                <option value="of">Organisme de formation</option>
                <option value="cfa">CFA</option>
                <option value="of_cfa">OF et CFA</option>
              </Select>
            </Field>
            <Field label="E-mail du propriétaire" htmlFor="t-owner" help="Facultatif. Une invitation valable 7 jours lui est adressée (lien affiché si l'e-mail n'est pas configuré).">
              <Input id="t-owner" name="ownerEmail" type="email" />
            </Field>
          </FormDialog>
        }
      />

      <Panel>
        <form method="get" className="flex flex-wrap items-end gap-3 border-b border-line px-5 py-3">
          <Field label="Recherche" htmlFor="q" className="w-full max-w-xs">
            <Input id="q" name="q" defaultValue={q} placeholder="Nom, organisme ou SIREN" />
          </Field>
          <Field label="Type" htmlFor="kind" className="w-44">
            <Select id="kind" name="kind" defaultValue={kind ?? ""}>
              <option value="">Tous</option>
              <option value="organisme">Organisme</option>
              <option value="groupe">Groupe</option>
            </Select>
          </Field>
          <Checkbox name="demo" value="1" defaultChecked={demo} label="Inclure les démonstrations" className="mb-2" />
          <Button type="submit" variant="secondary">
            Filtrer
          </Button>
        </form>
        {rows.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Organisation</Th>
                <Th>Type</Th>
                <Th num>Organismes</Th>
                <Th num>Comptes</Th>
                <Th num>Inscriptions actives</Th>
                <Th>Création</Th>
                <Th>État</Th>
              </tr>
            </thead>
            <tbody>
              {rows.map(({ t, orgs, users, enrollments }) => {
                const archived = Boolean((t.settings as { archive?: unknown })?.archive);
                return (
                  <tr key={t.id}>
                    <Td>
                      <Link href={`/admin/organisations/${t.id}`} className="font-medium text-ink hover:underline">
                        {t.name}
                      </Link>
                      <p className="num text-[12px] text-ink-3">{t.slug}</p>
                    </Td>
                    <Td>{kindLabel[t.kind]}</Td>
                    <Td num>{orgs}</Td>
                    <Td num>{users}</Td>
                    <Td num>{enrollments}</Td>
                    <Td className="whitespace-nowrap">{fmtDate(t.createdAt)}</Td>
                    <Td>
                      <div className="flex gap-1">
                        {t.isDemo ? <Badge tone="warn">Démo</Badge> : null}
                        {archived ? <Badge tone="neutral">Archivée</Badge> : !t.isDemo ? <Badge tone="ok">Active</Badge> : null}
                      </div>
                    </Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucune organisation" description={q ? "Aucun résultat pour cette recherche." : "Les organisations apparaissent à l'inscription ou quand vous en créez une."} />
        )}
        <Pagination basePath="/admin/organisations" params={{ q, kind, demo: demo ? "1" : undefined }} page={page} pageSize={PAGE} total={total} />
      </Panel>
    </>
  );
}
