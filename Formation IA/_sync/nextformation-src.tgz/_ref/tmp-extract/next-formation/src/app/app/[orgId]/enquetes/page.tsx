import Link from "next/link";
import { guardOrg } from "@/server/guard";
import { createSurveyAction, runSurveyDispatchAction } from "@/server/actions/surveys";
import { listSurveys, orgSessions } from "@/server/quality/queries";
import { responseRate, satisfactionRate } from "@/server/quality/indicators";
import { readAutomation } from "@/server/quality/jobs-rules";
import { SURVEY_TEMPLATES } from "@/server/quality/survey-templates";
import { surveyKindLabels } from "@/server/quality/labels";
import { fmtDateTime } from "@/lib/dates";
import { Badge, statusMeta } from "@/components/ui/badge";
import { SurveyStatusBadge } from "@/components/quality/survey-badge";
import { Checkbox, Field, Input, Select } from "@/components/ui/field";
import { EmptyState, PageHeader, Panel, PanelHeader, Stat } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { ActionButton } from "@/components/admin/action-form";
import { FormDialog } from "@/components/admin/form-dialog";
import { FadeIn } from "@/components/ui/motion";

export const dynamic = "force-dynamic";

export default async function EnquetesPage({ params }: { params: Promise<{ orgId: string }> }) {
  const { orgId } = await params;
  const path = `/app/${orgId}/enquetes`;
  const ctx = await guardOrg(orgId, path, "quality.view");
  const canManage = ctx.permissions.has("quality.manage");
  const [surveys, sessions, satisfaction, retour] = await Promise.all([listSurveys(ctx.org.id), orgSessions(ctx.org.id), satisfactionRate(ctx.org.id), responseRate(ctx.org.id)]);

  return (
    <FadeIn>
      <PageHeader
        title="Enquêtes"
        description="Positionnement, satisfaction à chaud et à froid, employeur, formateur, financeur, besoins : modèles par type avec définition explicite des indicateurs (numérateur, dénominateur, exclusions). Chaque réponse reçue devient une preuve (indicateur 30)."
        actions={
          canManage ? (
            <>
              <ActionButton action={runSurveyDispatchAction} fields={{ orgId: ctx.org.id }} label="Exécuter l'envoi automatique" variant="secondary" size="md" />
              <FormDialog action={createSurveyAction} trigger="Nouvelle enquête" title="Nouvelle enquête" description="Les questions et les définitions d'indicateurs du modèle sont copiées ; vous pouvez les adapter avant activation." submitLabel="Créer en brouillon">
                <input type="hidden" name="orgId" value={ctx.org.id} />
                <Field label="Type" required htmlFor="s-kind">
                  <Select id="s-kind" name="kind" defaultValue="satisfaction_chaud">
                    {SURVEY_TEMPLATES.map((t) => (
                      <option key={t.kind} value={t.kind}>
                        {surveyKindLabels[t.kind]} : {t.questions.length} questions
                      </option>
                    ))}
                  </Select>
                </Field>
                <Field label="Titre" htmlFor="s-title" help="Par défaut : le titre du modèle (et la session).">
                  <Input id="s-title" name="title" maxLength={200} />
                </Field>
                <Field label="Session" htmlFor="s-session" help="Sans session : enquête modèle de l'organisme ; avec l'envoi automatique, une enquête est créée et envoyée pour chaque session terminée.">
                  <Select id="s-session" name="sessionId" defaultValue="">
                    <option value="">Aucune (modèle d&apos;organisme)</option>
                    {sessions.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.code} : {s.title} ({statusMeta[s.status]?.label ?? s.status})
                      </option>
                    ))}
                  </Select>
                </Field>
                <div className="grid gap-4 sm:grid-cols-2">
                  <Checkbox name="automation" defaultChecked label="Envoi automatique à la fin de session" className="mt-6" />
                  <Field label="Délai après la fin (jours)" htmlFor="s-delay" help="0 = à chaud ; 90 = à froid.">
                    <Input id="s-delay" name="delayDays" type="number" min={0} max={365} defaultValue={0} />
                  </Field>
                </div>
              </FormDialog>
            </>
          ) : null
        }
      />

      <Panel className="mb-6">
        <PanelHeader title="Indicateurs de l'organisme" description="Toutes enquêtes confondues. Chaque indicateur affiche sa définition, son dénominateur et sa date de calcul (F15)." />
        <div className="grid gap-6 px-5 py-5 md:grid-cols-2">
          {[satisfaction, retour].map((ind, i) => (
            <div key={i}>
              <Stat label={i === 0 ? "Taux de satisfaction" : "Taux de retour"} value={<span className="num">{ind.value === null ? "n.c." : `${ind.value} %`}</span>} hint={<span className="num">{ind.numerator} / {ind.denominator}</span>} />
              <p className="mt-2 text-[12px] text-ink-2">{ind.definition}</p>
              <p className="text-[12px] text-ink-3">Exclusions : {ind.exclusions}</p>
              <p className="num text-[11px] text-ink-3">Calculé le {fmtDateTime(ind.computedAt)}</p>
            </div>
          ))}
        </div>
      </Panel>

      <Panel>
        <PanelHeader title="Enquêtes" description="Brouillon : modifiable. Active : envoi possible, réponses acceptées. Clôturée : lecture seule." />
        {surveys.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Enquête</Th>
                <Th>Type</Th>
                <Th>Session</Th>
                <Th>Automatisation</Th>
                <Th num>Envoyés</Th>
                <Th num>Reçus</Th>
                <Th>Statut</Th>
              </tr>
            </thead>
            <tbody>
              {surveys.map(({ s, sessionTitle, sent, submitted }) => {
                const auto = readAutomation(s.automation);
                return (
                  <tr key={s.id}>
                    <Td>
                      <Link href={`${path}/${s.id}`} className="font-medium text-ink hover:underline">
                        {s.title}
                      </Link>
                      <p className="num text-[11px] text-ink-3">créée le {fmtDateTime(s.createdAt)}</p>
                    </Td>
                    <Td>{surveyKindLabels[s.kind] ?? s.kind}</Td>
                    <Td>{sessionTitle ?? <Badge tone="neutral">Modèle d&apos;organisme</Badge>}</Td>
                    <Td className="text-[12.5px]">
                      {auto.trigger === "session_end" ? `Fin de session + ${auto.delayDays} j` : auto.fromSurveyId ? "Créée automatiquement" : "Manuelle"}
                      {auto.lastRunAt ? <p className="num text-[11px] text-ink-3">dernier passage {fmtDateTime(auto.lastRunAt)}</p> : null}
                    </Td>
                    <Td num>{sent}</Td>
                    <Td num>{submitted}</Td>
                    <Td>
                      <SurveyStatusBadge status={s.status} />
                    </Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucune enquête" description="Créez une enquête depuis un modèle : satisfaction à chaud (envoi automatique en fin de session), à froid (après N jours), positionnement, employeur…" />
        )}
      </Panel>
    </FadeIn>
  );
}
