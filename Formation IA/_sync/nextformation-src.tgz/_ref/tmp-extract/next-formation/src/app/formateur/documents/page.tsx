import { guardTrainer } from "@/server/extranet/guard";
import { listVisibleDocuments } from "@/server/extranet/queries";
import { NoAttachment } from "@/components/extranet/shell";
import { DocumentTable } from "@/components/extranet/ui";
import { PageHeader, Panel, PanelHeader } from "@/components/ui/surface";

export const dynamic = "force-dynamic";

/** Mes documents : contrat de prestation (rattaché à ma fiche formateur) et programmes des sessions affectées. */
export default async function TrainerDocuments() {
  const ctx = await guardTrainer("/formateur/documents");
  if (!ctx) return <NoAttachment kind="trainer" />;
  const mine = await listVisibleDocuments(ctx.org.id, { trainerId: ctx.trainer.id }, ["interne", "pedagogie", "public", "administratif"]);
  const sessionDocs = (await listVisibleDocuments(ctx.org.id, { sessionIds: ctx.sessionIds }, ["pedagogie", "public"])).filter((d) => ["programme", "reglement_interieur", "annexe_parcours", "plan_acces", "procedure"].includes(d.category));
  return (
    <>
      <PageHeader title="Mes documents" description="Contrat de prestation et documents pédagogiques des sessions affectées (programme, règlement intérieur, plan d'accès)." />
      <div className="space-y-6">
        <Panel>
          <PanelHeader title="Documents me concernant" description="Contrat de prestation, attestations, pièces déposées pour ma fiche formateur." />
          <DocumentTable docs={mine} downloadBase="/formateur/documents" emptyTitle="Aucun document" emptyDescription="Votre contrat de prestation apparaîtra ici lorsque l'organisme l'aura transmis." />
        </Panel>
        <Panel>
          <PanelHeader title="Programmes des sessions" />
          <DocumentTable docs={sessionDocs} downloadBase="/formateur/documents" emptyTitle="Aucun programme publié" emptyDescription="Les programmes et règlements des sessions apparaîtront ici lorsqu'ils seront générés." />
        </Panel>
      </div>
    </>
  );
}
