import Link from "next/link";
import { notFound } from "next/navigation";
import { and, asc, desc, eq, inArray, sql, type SQL } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { contractKindLabels, parseAppliesTo, providedByLabels } from "@/server/enrollments/rules";
import { fmtDate } from "@/lib/dates";
import { todayParis } from "@/lib/time";
import { readPage, readParam, Pagination } from "@/components/admin/pagination";
import { ActionButton } from "@/components/admin/action-form";
import { FormDialog } from "@/components/admin/form-dialog";
import { TabNav } from "@/components/sessions/tabs";
import { PieceReview } from "@/components/enrollments/piece-actions";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox, Field, Input, Select, Textarea } from "@/components/ui/field";
import { EmptyState, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FadeIn } from "@/components/ui/motion";
import { savePieceAction, togglePieceAction } from "@/server/actions/pieces";

export const dynamic = "force-dynamic";
const PAGE = 60;
const FUNDING_KINDS = schema.funderKindEnum.enumValues;
const funderKindLabels: Record<string, string> = { opco: "OPCO", entreprise: "Entreprise", france_travail: "France Travail", region: "Région", cpf: "CPF", particulier: "Particulier", etat: "État", agefiph: "Agefiph", transition_pro: "Transitions Pro", autre: "Autre" };
const categoryLabels: Partial<Record<string, string>> = { piece_identite: "Pièce d'identité", cv: "CV", diplome: "Diplôme", convention: "Convention", contrat: "Contrat", cerfa: "CERFA", justificatif: "Justificatif", reglement_interieur: "Règlement intérieur", rib: "RIB", kbis: "Kbis", attestation: "Attestation", autre: "Autre" };

export default async function PiecesPage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const path = `/app/${orgId}/pieces`;
  const ctx = await guardOrg(orgId, path, "dossier.admin_docs.view");
  if (ctx.trainerOnly) notFound();
  const sp = await searchParams;
  const tab = readParam(sp.onglet) === "parametrage" ? "parametrage" : "manquantes";
  const canManage = ctx.permissions.has("dossier.admin_docs.manage");

  const pieces = await db.select().from(schema.requiredPieces).where(eq(schema.requiredPieces.orgId, orgId)).orderBy(asc(schema.requiredPieces.position), asc(schema.requiredPieces.label));

  return (
    <FadeIn>
      <PageHeader
        title="Pièces attendues"
        description="Pièces exigées par activité, contrat et financement (F09) : paramétrage de l'organisme et suivi transversal des pièces manquantes avec relance."
        actions={
          canManage ? <PieceDialog orgId={orgId} /> : null
        }
      />
      <TabNav basePath={path} tabs={[{ key: "manquantes", label: "Pièces manquantes" }, { key: "parametrage", label: "Paramétrage", count: pieces.filter((p) => p.isActive).length }]} current={tab} />
      {tab === "parametrage" ? (
        <Panel>
          <PanelHeader title="Pièces paramétrées" description="Une pièce s'applique selon le type de contrat, le type de financement et l'activité. « * » = toujours. Les dossiers existants ne sont pas modifiés rétroactivement." />
          {pieces.length ? (
            <Table>
              <thead>
                <tr>
                  <Th num>Ordre</Th>
                  <Th>Pièce</Th>
                  <Th>Catégorie</Th>
                  <Th>Fournie par</Th>
                  <Th>Déclencheurs</Th>
                  <Th num>Échéance</Th>
                  <Th>État</Th>
                  {canManage ? <Th></Th> : null}
                </tr>
              </thead>
              <tbody>
                {pieces.map((p) => {
                  const a = parseAppliesTo(p.appliesTo);
                  return (
                    <tr key={p.id} className={p.isActive ? undefined : "opacity-60"}>
                      <Td num>{p.position}</Td>
                      <Td>
                        <span className="font-medium">{p.label}</span> {p.isRequired ? <Badge tone="warn">Obligatoire</Badge> : <Badge>Facultative</Badge>}
                        <p className="num text-[12px] text-ink-3">{p.code}</p>
                        {p.description ? <p className="text-[12.5px] text-ink-2">{p.description}</p> : null}
                      </Td>
                      <Td>{categoryLabels[p.category] ?? p.category}</Td>
                      <Td>{providedByLabels[p.providedBy] ?? p.providedBy}</Td>
                      <Td className="text-[12.5px]">
                        <p>Contrats : {a.contractKinds.includes("*") ? "tous" : a.contractKinds.map((k) => contractKindLabels[k as keyof typeof contractKindLabels] ?? k).join(", ")}</p>
                        <p>Financements : {a.fundingKinds.includes("*") ? "tous" : a.fundingKinds.map((k) => funderKindLabels[k] ?? k).join(", ")}</p>
                        <p>Activité : {a.activity.includes("*") ? "OF et CFA" : a.activity.map((x) => x.toUpperCase()).join(", ")}</p>
                      </Td>
                      <Td num>{p.dueDaysBeforeStart === null ? "-" : `J-${p.dueDaysBeforeStart}`}</Td>
                      <Td>
                        <Badge tone={p.isActive ? "ok" : "neutral"}>{p.isActive ? "Active" : "Désactivée"}</Badge>
                      </Td>
                      {canManage ? (
                        <Td>
                          <div className="flex justify-end gap-2">
                            <PieceDialog orgId={orgId} piece={p} />
                            <ActionButton action={togglePieceAction} fields={{ orgId, pieceId: p.id }} label={p.isActive ? "Désactiver" : "Réactiver"} variant="ghost" />
                          </div>
                        </Td>
                      ) : null}
                    </tr>
                  );
                })}
              </tbody>
            </Table>
          ) : (
            <EmptyState title="Aucune pièce paramétrée" description="Ajoutez les pièces attendues pour vos contrats et financements." />
          )}
        </Panel>
      ) : (
        <MissingTab orgId={orgId} sp={sp} canManage={canManage} />
      )}
    </FadeIn>
  );
}

function PieceDialog({ orgId, piece }: { orgId: string; piece?: typeof schema.requiredPieces.$inferSelect }) {
  const a = piece ? parseAppliesTo(piece.appliesTo) : { contractKinds: ["*"], fundingKinds: ["*"], activity: ["*"] };
  const id = piece?.id ?? "new";
  return (
    <FormDialog action={savePieceAction} trigger={piece ? "Modifier" : "Nouvelle pièce"} triggerVariant={piece ? "ghost" : "primary"} triggerSize={piece ? "sm" : "md"} title={piece ? `Modifier « ${piece.label} »` : "Nouvelle pièce attendue"} submitLabel="Enregistrer" wide>
      <input type="hidden" name="orgId" value={orgId} />
      {piece ? <input type="hidden" name="pieceId" value={piece.id} /> : null}
      <div className="grid gap-4 md:grid-cols-2">
        <Field label="Libellé" required htmlFor={`p-label-${id}`}>
          <Input id={`p-label-${id}`} name="label" required defaultValue={piece?.label ?? ""} />
        </Field>
        <Field label="Code" required htmlFor={`p-code-${id}`} help="Identifiant stable (minuscules, _) : utilisé par les tâches de relais.">
          <Input id={`p-code-${id}`} name="code" required defaultValue={piece?.code ?? ""} className="num" pattern="[a-z0-9_]+" />
        </Field>
        <Field label="Catégorie documentaire" htmlFor={`p-cat-${id}`}>
          <Select id={`p-cat-${id}`} name="category" defaultValue={piece?.category ?? "justificatif"}>
            {schema.documentCategoryEnum.enumValues.map((c) => (
              <option key={c} value={c}>
                {categoryLabels[c] ?? c}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Fournie par" htmlFor={`p-by-${id}`}>
          <Select id={`p-by-${id}`} name="providedBy" defaultValue={piece?.providedBy ?? "apprenant"}>
            <option value="apprenant">Apprenant</option>
            <option value="entreprise">Entreprise</option>
            <option value="organisme">Organisme</option>
            <option value="financeur">Financeur</option>
          </Select>
        </Field>
        <Field label="Échéance (jours avant le début)" htmlFor={`p-due-${id}`} help="Vide = sans échéance. 0 = le jour du début.">
          <Input id={`p-due-${id}`} name="dueDaysBeforeStart" type="number" min={0} max={365} defaultValue={piece?.dueDaysBeforeStart ?? ""} className="num" />
        </Field>
        <Field label="Ordre d'affichage" htmlFor={`p-pos-${id}`}>
          <Input id={`p-pos-${id}`} name="position" type="number" min={0} defaultValue={piece?.position ?? 0} className="num" />
        </Field>
        <Field label="Description (affichée dans les relances)" htmlFor={`p-desc-${id}`} className="md:col-span-2">
          <Textarea id={`p-desc-${id}`} name="description" defaultValue={piece?.description ?? ""} className="min-h-16" />
        </Field>
      </div>
      <div className="grid gap-4 md:grid-cols-3">
        <div>
          <p className="mb-2 font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">Types de contrat</p>
          <div className="space-y-1.5">
            <Checkbox name="contractKinds" value="*" defaultChecked={a.contractKinds.includes("*")} label="Tous" />
            {schema.contractKindEnum.enumValues.map((k) => (
              <Checkbox key={k} name="contractKinds" value={k} defaultChecked={a.contractKinds.includes(k)} label={contractKindLabels[k]} />
            ))}
          </div>
        </div>
        <div>
          <p className="mb-2 font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">Types de financement</p>
          <div className="space-y-1.5">
            <Checkbox name="fundingKinds" value="*" defaultChecked={a.fundingKinds.includes("*")} label="Tous" />
            {FUNDING_KINDS.map((k) => (
              <Checkbox key={k} name="fundingKinds" value={k} defaultChecked={a.fundingKinds.includes(k)} label={funderKindLabels[k] ?? k} />
            ))}
          </div>
        </div>
        <div className="space-y-4">
          <div>
            <p className="mb-2 font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">Activité</p>
            <div className="space-y-1.5">
              <Checkbox name="activity" value="*" defaultChecked={a.activity.includes("*")} label="OF et CFA" />
              <Checkbox name="activity" value="of" defaultChecked={a.activity.includes("of")} label="Formation continue (OF)" />
              <Checkbox name="activity" value="cfa" defaultChecked={a.activity.includes("cfa")} label="Apprentissage (CFA)" />
            </div>
          </div>
          <Checkbox name="isRequired" defaultChecked={piece?.isRequired ?? true} label="Obligatoire (crée une tâche de relais)" />
        </div>
      </div>
    </FormDialog>
  );
}

async function MissingTab({ orgId, sp, canManage }: { orgId: string; sp: Record<string, string | string[] | undefined>; canManage: boolean }) {
  const sessionId = readParam(sp.session);
  const providedBy = readParam(sp.fournisseur);
  const status = readParam(sp.statut);
  const page = readPage(sp.page);
  const conds: SQL[] = [eq(schema.pieceSubmissions.orgId, orgId), eq(schema.enrollments.orgId, orgId), inArray(schema.enrollments.status, ["preinscrit", "inscrit", "en_cours"])];
  conds.push(status === "deposee" ? eq(schema.pieceSubmissions.status, "deposee") : status === "refusee" ? eq(schema.pieceSubmissions.status, "refusee") : status === "attendue" ? inArray(schema.pieceSubmissions.status, ["attendue", "refusee"]) : inArray(schema.pieceSubmissions.status, ["attendue", "refusee", "deposee"]));
  // Lien du pilotage « pièces en retard » : date limite dépassée, pièce non déposée.
  if (readParam(sp.retard) === "1") conds.push(sql`${schema.pieceSubmissions.dueDate} < ${todayParis()} and ${schema.pieceSubmissions.status} <> 'deposee'`);
  if (sessionId && /^[0-9a-f-]{36}$/i.test(sessionId)) conds.push(eq(schema.enrollments.sessionId, sessionId));
  if (providedBy && ["apprenant", "entreprise", "organisme", "financeur"].includes(providedBy)) conds.push(eq(schema.requiredPieces.providedBy, providedBy));
  const where = and(...conds);
  const from = () =>
    db
      .select({ s: schema.pieceSubmissions, p: schema.requiredPieces, e: schema.enrollments, person: schema.persons, sessionCode: schema.trainingSessions.code, sessionTitle: schema.trainingSessions.title, sessionId: schema.trainingSessions.id })
      .from(schema.pieceSubmissions)
      .innerJoin(schema.requiredPieces, eq(schema.requiredPieces.id, schema.pieceSubmissions.requiredPieceId))
      .innerJoin(schema.enrollments, eq(schema.enrollments.id, schema.pieceSubmissions.enrollmentId))
      .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
      .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.enrollments.sessionId))
      .where(where);
  const [rows, [{ total }], sessions, bySession] = await Promise.all([
    from().orderBy(asc(schema.trainingSessions.startDate), asc(schema.persons.lastName), asc(schema.requiredPieces.position)).limit(PAGE).offset((page - 1) * PAGE),
    db
      .select({ total: sql<number>`count(*)::int` })
      .from(schema.pieceSubmissions)
      .innerJoin(schema.requiredPieces, eq(schema.requiredPieces.id, schema.pieceSubmissions.requiredPieceId))
      .innerJoin(schema.enrollments, eq(schema.enrollments.id, schema.pieceSubmissions.enrollmentId))
      .where(where),
    db.select({ id: schema.trainingSessions.id, code: schema.trainingSessions.code, title: schema.trainingSessions.title }).from(schema.trainingSessions).where(and(eq(schema.trainingSessions.orgId, orgId), inArray(schema.trainingSessions.status, ["brouillon", "ouverte", "confirmee", "en_cours"]))).orderBy(desc(schema.trainingSessions.startDate)).limit(300),
    db
      .select({ sessionId: schema.enrollments.sessionId, code: schema.trainingSessions.code, title: schema.trainingSessions.title, missing: sql<number>`count(*)::int`, enrollments: sql<number>`count(distinct ${schema.enrollments.id})::int` })
      .from(schema.pieceSubmissions)
      .innerJoin(schema.requiredPieces, eq(schema.requiredPieces.id, schema.pieceSubmissions.requiredPieceId))
      .innerJoin(schema.enrollments, eq(schema.enrollments.id, schema.pieceSubmissions.enrollmentId))
      .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.enrollments.sessionId))
      .where(and(eq(schema.pieceSubmissions.orgId, orgId), eq(schema.enrollments.orgId, orgId), inArray(schema.pieceSubmissions.status, ["attendue", "refusee"]), eq(schema.requiredPieces.isRequired, true), inArray(schema.enrollments.status, ["preinscrit", "inscrit", "en_cours"])))
      .groupBy(schema.enrollments.sessionId, schema.trainingSessions.code, schema.trainingSessions.title, schema.trainingSessions.startDate)
      .orderBy(asc(schema.trainingSessions.startDate)),
  ]);
  const base = `/app/${orgId}/pieces`;
  const today = todayParis();
  return (
    <div className="space-y-6">
      {bySession.length ? (
        <Panel>
          <PanelHeader title="Par session" description="Pièces obligatoires attendues ou refusées sur les inscriptions actives." />
          <ul className="grid gap-px bg-line sm:grid-cols-2 lg:grid-cols-3">
            {bySession.map((b) => (
              <li key={b.sessionId} className="bg-bg-elev px-5 py-4">
                <Link href={`${base}?session=${b.sessionId}`} className="font-medium hover:underline">
                  {b.title}
                </Link>
                <p className="num text-[12px] text-ink-3">{b.code}</p>
                <p className="mt-2 text-[13px]">
                  <span className="num font-medium text-warn-ink">{b.missing}</span> pièce(s) sur <span className="num">{b.enrollments}</span> dossier(s)
                </p>
              </li>
            ))}
          </ul>
        </Panel>
      ) : null}
      <Panel>
        <PanelHeader title="Par inscription" description="Relance par e-mail à la personne ou à l'entreprise selon qui fournit la pièce." />
        <form method="get" className="flex flex-wrap items-end gap-3 border-b border-line px-5 py-3">
          <Field label="Session" htmlFor="session" className="w-64">
            <Select id="session" name="session" defaultValue={sessionId ?? ""}>
              <option value="">Toutes</option>
              {sessions.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.code} · {s.title}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Fournie par" htmlFor="fournisseur" className="w-40">
            <Select id="fournisseur" name="fournisseur" defaultValue={providedBy ?? ""}>
              <option value="">Tous</option>
              <option value="apprenant">Apprenant</option>
              <option value="entreprise">Entreprise</option>
              <option value="organisme">Organisme</option>
              <option value="financeur">Financeur</option>
            </Select>
          </Field>
          <Field label="État" htmlFor="statut" className="w-44">
            <Select id="statut" name="statut" defaultValue={status ?? ""}>
              <option value="">Attendues, refusées, à contrôler</option>
              <option value="refusee">Refusées</option>
              <option value="deposee">À contrôler (déposées)</option>
            </Select>
          </Field>
          <Button type="submit" variant="secondary">
            Filtrer
          </Button>
        </form>
        {rows.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Inscription</Th>
                <Th>Session</Th>
                <Th>Pièce</Th>
                <Th>Fournie par</Th>
                <Th>Échéance</Th>
                <Th>État</Th>
                {canManage ? <Th></Th> : null}
              </tr>
            </thead>
            <tbody>
              {rows.map(({ s, p, e, person, sessionCode, sessionTitle, sessionId: sid }) => {
                const late = s.dueDate && s.status !== "deposee" && s.dueDate < today;
                return (
                  <tr key={s.id}>
                    <Td>
                      <Link href={`/app/${orgId}/inscriptions/${e.id}?onglet=pieces`} className="font-medium hover:underline">
                        {person.lastName.toUpperCase()} {person.firstName}
                      </Link>
                      <p className="num text-[12px] text-ink-3">{e.reference}</p>
                    </Td>
                    <Td>
                      <Link href={`/app/${orgId}/sessions/${sid}`} className="hover:underline">
                        {sessionTitle}
                      </Link>
                      <p className="num text-[12px] text-ink-3">{sessionCode}</p>
                    </Td>
                    <Td>
                      {p.label} {p.isRequired ? <Badge tone="warn">Obligatoire</Badge> : null}
                      {s.refusalReason ? <p className="text-[12px] text-danger-ink">Refus : {s.refusalReason}</p> : null}
                    </Td>
                    <Td>{providedByLabels[p.providedBy] ?? p.providedBy}</Td>
                    <Td className={`num whitespace-nowrap ${late ? "text-danger-ink" : ""}`}>{s.dueDate ? `${fmtDate(s.dueDate)}${late ? " (dépassée)" : ""}` : "-"}</Td>
                    <Td>
                      <StatusBadge status={s.status} />
                    </Td>
                    {canManage ? (
                      <Td>
                        <PieceReview orgId={orgId} submissionId={s.id} status={s.status} label={p.label} canRemind={p.providedBy !== "financeur"} />
                      </Td>
                    ) : null}
                  </tr>
                );
              })}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucune pièce en attente" description="Toutes les pièces des inscriptions actives sont acceptées ou non applicables." />
        )}
        <Pagination basePath={base} params={{ session: sessionId, fournisseur: providedBy, statut: status }} page={page} pageSize={PAGE} total={total} />
      </Panel>
    </div>
  );
}
