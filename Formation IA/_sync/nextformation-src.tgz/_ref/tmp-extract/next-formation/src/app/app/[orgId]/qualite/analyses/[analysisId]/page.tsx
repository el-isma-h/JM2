import Link from "next/link";
import { notFound } from "next/navigation";
import { eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { runAnalysisAction } from "@/server/actions/quality";
import { analysisById, analysisEvidences, analysisIsStale } from "@/server/quality/analysis";
import type { Control, Summary } from "@/server/quality/engine";
import { memberNames } from "@/server/quality/queries";
import { scopeLabels } from "@/server/quality/labels";
import { fmtDate, fmtDateTime } from "@/lib/dates";
import { todayParis } from "@/lib/time";
import { Button } from "@/components/ui/button";
import { KeyValue, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { ActionButton } from "@/components/admin/action-form";
import { FadeIn } from "@/components/ui/motion";
import { AnalysisSummary, ControlsTable, StaleNotice } from "@/components/quality/analysis-view";

export const dynamic = "force-dynamic";

export default async function AnalysisPage({ params }: { params: Promise<{ orgId: string; analysisId: string }> }) {
  const { orgId, analysisId } = await params;
  const path = `/app/${orgId}/qualite/analyses/${analysisId}`;
  const ctx = await guardOrg(orgId, path, "quality.view");
  if (!/^[0-9a-f-]{36}$/i.test(analysisId)) notFound();
  const analysis = await analysisById(ctx.org.id, analysisId);
  if (!analysis) notFound();
  const canManage = ctx.permissions.has("quality.manage");
  const [evidences, stale, names, [ref]] = await Promise.all([
    analysisEvidences(ctx.org.id, analysis),
    analysisIsStale(ctx.org.id, analysis),
    memberNames(ctx.org.id),
    db.select({ title: schema.referentials.title, version: schema.referentials.version, status: schema.referentials.status }).from(schema.referentials).where(eq(schema.referentials.id, analysis.referentialId)).limit(1),
  ]);
  const scopeHref =
    analysis.scope === "session" && analysis.scopeId ? `/app/${orgId}/sessions/${analysis.scopeId}` : analysis.scope === "inscription" && analysis.scopeId ? `/app/${orgId}/inscriptions/${analysis.scopeId}` : analysis.scope === "programme" && analysis.scopeId ? `/app/${orgId}/catalogue/${analysis.scopeId}` : null;

  return (
    <FadeIn>
      <PageHeader
        breadcrumb={[{ label: "Qualité", href: `/app/${orgId}/qualite` }, { label: "Analyse" }]}
        title={`Analyse du ${fmtDateTime(analysis.createdAt)}`}
        description="Photographie immuable : version du moteur, date de référence, contrôles, preuves retenues et résultat. Elle ne se modifie jamais ; une nouvelle analyse crée une nouvelle photographie."
        actions={
          canManage && !analysis.supersededById ? (
            <ActionButton action={runAnalysisAction} fields={{ orgId: ctx.org.id, scope: analysis.scope, scopeId: analysis.scopeId ?? "", referenceDate: todayParis() }} label="Relancer une analyse (même périmètre)" variant="primary" size="md" />
          ) : null
        }
      />
      {analysis.supersededById ? (
        <Notice tone="info" className="mb-6">
          Cette photographie a été remplacée par une analyse plus récente du même périmètre.{" "}
          <Link href={`/app/${orgId}/qualite/analyses/${analysis.supersededById}`} className="underline underline-offset-4">
            Ouvrir l&apos;analyse la plus récente
          </Link>
          . Son contenu ci-dessous est conservé tel quel.
        </Notice>
      ) : stale ? (
        <div className="mb-6">
          <StaleNotice orgId={ctx.org.id} />
        </div>
      ) : null}

      <Panel className="mb-6">
        <PanelHeader title="Synthèse" description="Identique à celle affichée dans le dossier : même photographie, mêmes chiffres." />
        <AnalysisSummary summary={analysis.summary as Summary} referenceDate={analysis.referenceDate} engineVersion={analysis.engineVersion} analysedAt={analysis.createdAt} />
        <div className="border-t border-line px-5 py-4">
          <KeyValue
            items={[
              { k: "Périmètre", v: scopeHref ? <Link href={scopeHref} className="underline underline-offset-4">{scopeLabels[analysis.scope]} : ouvrir le dossier</Link> : scopeLabels[analysis.scope] },
              { k: "Référentiel", v: ref ? `${ref.title}, version « ${ref.version} »${ref.status === "retire" ? " (retiré depuis)" : ""}` : "-" },
              { k: "Lancée par", v: analysis.createdBy ? (names.get(analysis.createdBy) ?? "Membre") : "Système" },
              { k: "Date de référence", v: <span className="num">{fmtDate(analysis.referenceDate)}</span> },
            ]}
          />
        </div>
      </Panel>

      <Panel>
        <PanelHeader title="Contrôles" description="Statuts : prouvé (preuve valide reliée, antérieure à la date de référence), absent, non applicable (activité ou périmètre), à examiner (appréciation humaine ou preuve invalidée depuis)." />
        <ControlsTable controls={analysis.controls as Control[]} evidences={evidences} orgId={ctx.org.id} />
      </Panel>
      <div className="mt-6">
        <Button asChild variant="secondary">
          <Link href={`/app/${orgId}/qualite`}>Retour au tableau de bord qualité</Link>
        </Button>
      </div>
    </FadeIn>
  );
}
