import Link from "next/link";
import { guardOrg } from "@/server/guard";
import { dashboardMetrics, monthlySeries, objectivesFor } from "@/server/pilotage/metrics";
import { definedIndicators } from "@/server/pilotage/indicators";
import { monthShort, monthsOf, PERIOD_PRESETS, resolvePeriod } from "@/server/pilotage/period";
import { todayParis } from "@/lib/time";
import { fmtDateTime } from "@/lib/dates";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/field";
import { Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FadeIn } from "@/components/ui/motion";
import { MetricGroupPanel } from "@/components/dashboard/metric-card";
import { ObjectivesStrip } from "@/components/dashboard/objectives";
import { MonthBars, MonthLine } from "@/components/dashboard/charts";

export const dynamic = "force-dynamic";

export default async function PilotagePage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const ctx = await guardOrg(orgId, `/app/${orgId}/pilotage`, "dashboards.view");
  const sp = await searchParams;
  const today = todayParis();
  const period = resolvePeriod(sp, today);
  const months = monthsOf(period);
  const [{ groups, updatedAt }, indicators, series, objectives] = await Promise.all([dashboardMetrics(ctx, period, today), definedIndicators(orgId, period), monthlySeries(ctx, months), objectivesFor(orgId, period)]);
  const updated = fmtDateTime(updatedAt);
  const chartData = series.map((s) => ({ ...s, label: monthShort(s.month) }));
  const qs = `periode=${period.key}&from=${period.from}&to=${period.to}`;
  const canEditObjectives = ctx.isOwner || ctx.roles.includes("direction");
  const p = ctx.permissions;

  return (
    <FadeIn>
      <PageHeader
        title="Pilotage"
        description={`Indicateurs détaillés sur la période « ${period.label} » (du ${period.from.split("-").reverse().join("/")} au ${period.to.split("-").reverse().join("/")}). Mise à jour : ${updated}. Les objectifs sont affichés comme cibles, jamais comme résultats.`}
        actions={
          <>
            {canEditObjectives ? (
              <Button asChild variant="secondary">
                <Link href={`/app/${orgId}/pilotage/objectifs`}>Objectifs</Link>
              </Button>
            ) : null}
            {p.has("exports.run") ? (
              <Button asChild variant="secondary">
                <a href={`/app/${orgId}/pilotage/export?${qs}`}>Exporter en CSV</a>
              </Button>
            ) : (
              <Button variant="secondary" disabled title="Export réservé à la permission « Exporter des données »">
                Exporter en CSV
              </Button>
            )}
          </>
        }
      />

      <Panel className="mb-6">
        <form method="get" className="flex flex-wrap items-end gap-3 px-5 py-3">
          <Field label="Période" htmlFor="pp-periode" className="w-56">
            <Select id="pp-periode" name="periode" defaultValue={period.key}>
              {PERIOD_PRESETS.map((o) => (
                <option key={o.key} value={o.key}>
                  {o.label}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Du" htmlFor="pp-from" help="Avec « Personnalisée »." className="w-44">
            <Input id="pp-from" name="from" type="date" defaultValue={period.from} className="num" />
          </Field>
          <Field label="Au" htmlFor="pp-to" className="w-44">
            <Input id="pp-to" name="to" type="date" defaultValue={period.to} className="num" />
          </Field>
          <Button type="submit" variant="secondary" className="mb-5">
            Appliquer
          </Button>
        </form>
      </Panel>

      <Panel className="mb-6">
        <PanelHeader title="Indicateurs à définition explicite" description="Satisfaction, retour d'enquêtes, abandon et réussite : définition, numérateur, dénominateur et exclusions affichés. Un pourcentage sans dénominateur n'est pas un résultat." />
        <Table>
          <thead>
            <tr>
              <Th>Indicateur</Th>
              <Th num>Valeur</Th>
              <Th num>Numérateur</Th>
              <Th num>Dénominateur</Th>
              <Th>Définition</Th>
            </tr>
          </thead>
          <tbody>
            {indicators.map((i) => (
              <tr key={i.key}>
                <Td>
                  <Link href={i.href} className="font-medium hover:underline">
                    {i.label}
                  </Link>
                </Td>
                <Td num className="font-medium">{i.value === null ? <span className="text-ink-3">Non calculable (dénominateur nul)</span> : `${i.value.toLocaleString("fr-FR")} %`}</Td>
                <Td num>
                  {i.numerator}
                  <p className="text-[11.5px] font-normal text-ink-3">{i.numeratorLabel}</p>
                </Td>
                <Td num>
                  {i.denominator}
                  <p className="text-[11.5px] font-normal text-ink-3">{i.denominatorLabel}</p>
                </Td>
                <Td className="max-w-[360px] text-[12.5px] text-ink-2">
                  {i.definition}
                  <p className="mt-1 text-ink-3">Exclusions : {i.exclusions}.</p>
                </Td>
              </tr>
            ))}
          </tbody>
        </Table>
        <ObjectivesStrip objectives={objectives} orgId={orgId} canEdit={canEditObjectives} />
      </Panel>

      <div className="mb-6 grid gap-6 lg:grid-cols-2">
        {p.has("enrollments.view") ? (
          <Panel>
            <PanelHeader title="Entrées en formation par mois" description="Inscriptions dont la date de début tombe dans le mois." />
            <div className="px-3 py-3">
              <MonthBars data={chartData} dataKey="entrees" name="Entrées" />
            </div>
          </Panel>
        ) : null}
        {p.has("planning.view") || p.has("attendance.record") ? (
          <Panel>
            <PanelHeader title="Heures réalisées par mois" description="Minutes comptées des présences courantes, converties en heures arrondies (hors heures validées, non additionnées)." />
            <div className="px-3 py-3">
              <MonthLine data={chartData} dataKey="heures" name="Heures réalisées" unit="h" />
            </div>
          </Panel>
        ) : null}
        {p.has("finance.view") ? (
          <Panel>
            <PanelHeader title="Encaissements par mois" description="Règlements datés dans le mois, en euros." />
            <div className="px-3 py-3">
              <MonthBars data={chartData} dataKey="encaissements" name="Encaissements" unit="€" />
            </div>
          </Panel>
        ) : null}
        {p.has("planning.view") || p.has("attendance.record") ? (
          <Panel>
            <PanelHeader title="Absences par mois" description="Présences au statut absent (non justifié)." />
            <div className="px-3 py-3">
              <MonthLine data={chartData} dataKey="absences" name="Absences" />
            </div>
          </Panel>
        ) : null}
      </div>
      {!months.length ? <Notice tone="info" className="mb-6">Période vide : aucune série mensuelle.</Notice> : null}

      <div className="space-y-6">
        {groups.map((g) => (
          <MetricGroupPanel key={g.key} g={g} updatedAt={updated} />
        ))}
      </div>
    </FadeIn>
  );
}
