import { guardLearner } from "@/server/extranet/guard";
import { listElearning } from "@/server/extranet/queries";
import { startElearningAction } from "@/server/actions/self";
import { NoAttachment } from "@/components/extranet/shell";
import { ActionButton } from "@/components/admin/action-form";
import { StatusBadge } from "@/components/ui/badge";
import { EmptyState, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { fmtDateTime } from "@/lib/dates";
import { fmtMinutes } from "@/lib/time";

export const dynamic = "force-dynamic";

const kindLabels: Record<string, string> = { scorm: "SCORM", xapi: "xAPI", moodle: "Moodle", lien: "Lien externe", contenu: "Contenu", video: "Vidéo", quiz: "Quiz" };

/** Modules e-learning des versions de programme de mes inscriptions, lancement et progression. */
export default async function LearnerElearning() {
  const ctx = await guardLearner("/moi/elearning");
  if (!ctx) return <NoAttachment kind="learner" />;
  const rows = await listElearning(
    ctx.org.id,
    ctx.enrollments.map((e) => ({ id: e.enrollment.id, programVersionId: e.enrollment.programVersionId, sessionVersionId: e.session.programVersionId })),
  );
  return (
    <>
      <PageHeader title="E-learning" description="Modules à distance de votre programme. Le temps passé est enregistré ; il ne compte comme heures réalisées qu'après validation par l'organisme." />
      <div className="space-y-6">
        {ctx.enrollments.map((e) => {
          const mine = rows.filter((r) => r.enrollmentId === e.enrollment.id);
          return (
            <Panel key={e.enrollment.id}>
              <PanelHeader title={e.program?.title ?? e.session.title} description={`Session ${e.session.code}`} />
              {mine.length ? (
                <Table>
                  <thead>
                    <tr>
                      <Th>Module</Th>
                      <Th>Type</Th>
                      <Th num>Durée</Th>
                      <Th>Progression</Th>
                      <Th>Dernier accès</Th>
                      <Th className="text-right">Action</Th>
                    </tr>
                  </thead>
                  <tbody>
                    {mine.map((r) => (
                      <tr key={r.module.id}>
                        <Td>
                          <span className="font-medium text-ink">{r.module.title}</span>
                          {r.module.description ? <span className="block text-[12.5px] text-ink-3">{r.module.description}</span> : null}
                        </Td>
                        <Td>{kindLabels[r.module.kind] ?? r.module.kind}</Td>
                        <Td num>{r.module.durationMinutes ? fmtMinutes(r.module.durationMinutes) : "-"}</Td>
                        <Td>
                          <StatusBadge status={r.progress?.status ?? "non_commence"} />
                          {r.progress?.score != null && r.progress.maxScore ? (
                            <span className="num ml-2 text-[12px] text-ink-3">
                              {r.progress.score}/{r.progress.maxScore}
                            </span>
                          ) : null}
                        </Td>
                        <Td className="num">{r.progress?.lastAccessAt ? fmtDateTime(r.progress.lastAccessAt) : "-"}</Td>
                        <Td className="text-right">
                          <ActionButton action={startElearningAction} fields={{ moduleId: r.module.id, enrollmentId: e.enrollment.id }} label={r.progress?.status === "termine" ? "Revoir" : r.progress ? "Reprendre" : "Commencer"} variant={r.progress ? "secondary" : "primary"} />
                        </Td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
              ) : (
                <EmptyState title="Aucun module à distance" description="Ce programme ne comporte pas de module e-learning, ou ils ne sont pas encore publiés." />
              )}
            </Panel>
          );
        })}
      </div>
    </>
  );
}
