"use client";

import * as React from "react";
import { FormDialog } from "@/components/admin/form-dialog";
import { Field, Input, Select, Textarea } from "@/components/ui/field";
import { createTaskAction, searchEntitiesAction } from "@/server/actions/tasks";
import { TASK_FAMILIES, TASK_PRIORITIES, taskFamilyLabels, taskPriorityLabels } from "@/server/tasks/rules";
import { AssigneeSelect, type StaffOption } from "./task-actions";

const ENTITY_TYPES = [
  { value: "", label: "Aucun dossier" },
  { value: "enrollment", label: "Inscription" },
  { value: "session", label: "Session" },
  { value: "company", label: "Entreprise" },
  { value: "person", label: "Personne (candidat ou apprenant)" },
  { value: "invoice", label: "Facture" },
];

/** Création d'une tâche manuelle avec sélecteur de dossier par recherche. */
export function CreateTaskDialog({ orgId, staff, defaultEntity }: { orgId: string; staff: StaffOption[]; defaultEntity?: { type: string; id: string; label: string } }) {
  const [entityType, setEntityType] = React.useState(defaultEntity?.type ?? "");
  const [q, setQ] = React.useState("");
  const [results, setResults] = React.useState<{ id: string; label: string }[]>([]);
  const [chosen, setChosen] = React.useState<{ id: string; label: string } | null>(defaultEntity ? { id: defaultEntity.id, label: defaultEntity.label } : null);
  const [searching, setSearching] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  React.useEffect(() => {
    if (!entityType || q.trim().length < 2) return;
    let cancelled = false;
    const h = setTimeout(async () => {
      setSearching(true);
      const fd = new FormData();
      fd.set("orgId", orgId);
      fd.set("entityType", entityType);
      fd.set("q", q);
      const r = await searchEntitiesAction({}, fd);
      if (cancelled) return;
      setSearching(false);
      if (r.error) {
        setError(r.error);
        setResults([]);
      } else {
        setError(null);
        try {
          setResults(JSON.parse(r.data?.results ?? "[]"));
        } catch {
          setResults([]);
        }
      }
    }, 250);
    return () => {
      cancelled = true;
      clearTimeout(h);
    };
  }, [q, entityType, orgId]);

  return (
    <FormDialog action={createTaskAction} trigger="Nouvelle tâche" title="Nouvelle tâche" description="Objet, dossier lié, responsable, échéance, priorité : la tâche est visible dans « Mes tâches » de son responsable." submitLabel="Créer la tâche" wide>
      <input type="hidden" name="orgId" value={orgId} />
      <Field label="Objet" htmlFor="ct-title" required>
        <Input id="ct-title" name="title" required maxLength={200} />
      </Field>
      <div className="grid gap-4 sm:grid-cols-3">
        <Field label="Famille" htmlFor="ct-family">
          <Select id="ct-family" name="family" defaultValue="administratif">
            {TASK_FAMILIES.map((f) => (
              <option key={f} value={f}>
                {taskFamilyLabels[f]}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Priorité" htmlFor="ct-priority">
          <Select id="ct-priority" name="priority" defaultValue="normale">
            {TASK_PRIORITIES.map((p) => (
              <option key={p} value={p}>
                {taskPriorityLabels[p]}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Échéance" htmlFor="ct-due">
          <Input id="ct-due" name="dueDate" type="date" className="num" />
        </Field>
      </div>
      <Field label="Responsable" htmlFor="ct-target" help="Un rôle sans responsable nommé : la tâche apparaît chez tous les membres de ce rôle jusqu'à prise en charge.">
        <AssigneeSelect id="ct-target" name="target" staff={staff} allowNone allowMe defaultValue="me" />
      </Field>
      <div className="grid gap-4 sm:grid-cols-[200px_1fr]">
        <Field label="Dossier lié" htmlFor="ct-etype">
          <Select
            id="ct-etype"
            name="entityType"
            value={entityType}
            onChange={(e) => {
              setEntityType(e.target.value);
              setChosen(null);
              setQ("");
            }}
          >
            {ENTITY_TYPES.map((t) => (
              <option key={t.value} value={t.value}>
                {t.label}
              </option>
            ))}
          </Select>
        </Field>
        {entityType ? (
          <Field label="Rechercher" htmlFor="ct-q" help={chosen ? `Sélectionné : ${chosen.label}` : searching ? "Recherche…" : error ?? "Deux caractères minimum."}>
            <Input id="ct-q" value={q} onChange={(e) => {
                setQ(e.target.value);
                if (e.target.value.trim().length < 2) setResults([]);
              }} placeholder="Référence, nom, code…" autoComplete="off" />
            {results.length ? (
              <ul className="mt-1 max-h-40 overflow-y-auto border border-line-strong bg-bg-elev text-[13px]" role="listbox">
                {results.map((r) => (
                  <li key={r.id}>
                    <button
                      type="button"
                      role="option"
                      aria-selected={chosen?.id === r.id}
                      className="block w-full px-3 py-1.5 text-left hover:bg-bg-sunken"
                      onClick={() => {
                        setChosen(r);
                        setResults([]);
                        setQ(r.label);
                      }}
                    >
                      {r.label}
                    </button>
                  </li>
                ))}
              </ul>
            ) : null}
          </Field>
        ) : null}
      </div>
      <input type="hidden" name="entityId" value={chosen?.id ?? ""} />
      <Field label="Description" htmlFor="ct-desc">
        <Textarea id="ct-desc" name="description" className="min-h-20" />
      </Field>
      <Field label="Prérequis explicites" htmlFor="ct-prereq" help="Un par ligne : donnée à obtenir, pièce à valider, décision humaine requise. La tâche ne pourra être terminée qu'une fois ces prérequis cochés, sauf dérogation motivée.">
        <Textarea id="ct-prereq" name="prerequisites" className="min-h-16" placeholder={"Convention signée reçue\nAccord de prise en charge validé"} />
      </Field>
    </FormDialog>
  );
}
