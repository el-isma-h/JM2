import { eq, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { deleteCertificationAction, saveCertificationAction } from "@/server/actions/catalog";
import { todayParis } from "@/lib/time";
import { fmtDate } from "@/lib/dates";
import { Badge } from "@/components/ui/badge";
import { EmptyState, PageHeader, Panel } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { ActionButton } from "@/components/admin/action-form";
import { FormDialog } from "@/components/admin/form-dialog";
import { CertificationFields } from "@/components/catalog/fields";

export const dynamic = "force-dynamic";

export default async function CertificationsPage({ params }: { params: Promise<{ orgId: string }> }) {
  const { orgId } = await params;
  const base = `/app/${orgId}`;
  const ctx = await guardOrg(orgId, `${base}/catalogue/certifications`, "catalog.view");
  const canManage = ctx.permissions.has("catalog.manage");
  const today = todayParis();
  const rows = await db
    .select({ c: schema.certifications, programs: sql<number>`(select count(*)::int from ${schema.programs} p where p.certification_id = "certifications"."id")` })
    .from(schema.certifications)
    .where(eq(schema.certifications.orgId, ctx.org.id))
    .orderBy(schema.certifications.title);
  const soon = (d: string | null) => {
    if (!d) return null;
    if (d < today) return <Badge tone="danger">Échue</Badge>;
    const limit = new Date(`${today}T12:00:00Z`);
    limit.setUTCMonth(limit.getUTCMonth() + 6);
    return d < limit.toISOString().slice(0, 10) ? <Badge tone="warn">Moins de 6 mois</Badge> : <Badge tone="ok">Valide</Badge>;
  };

  return (
    <>
      <PageHeader
        breadcrumb={[{ label: "Formation" }, { label: "Catalogue", href: `${base}/catalogue` }, { label: "Certifications" }]}
        title="Certifications et habilitations"
        description="Certifications RNCP / RS visées par vos formations, blocs de compétences et habilitations de l'organisme (validité suivie)."
        actions={
          canManage ? (
            <FormDialog action={saveCertificationAction} trigger="Nouvelle certification" title="Nouvelle certification" submitLabel="Enregistrer" wide>
              <CertificationFields orgId={ctx.org.id} />
            </FormDialog>
          ) : null
        }
      />
      <Panel>
        {rows.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Certification</Th>
                <Th>Codes</Th>
                <Th>Certificateur</Th>
                <Th>Enregistrement</Th>
                <Th>Habilitation</Th>
                <Th num>Blocs</Th>
                <Th num>Formations</Th>
                {canManage ? <Th /> : null}
              </tr>
            </thead>
            <tbody>
              {rows.map(({ c, programs }) => (
                <tr key={c.id}>
                  <Td>
                    <span className="font-medium text-ink">{c.title}</span>
                    {c.level ? <span className="block text-[12px] text-ink-3">Niveau {c.level}</span> : null}
                  </Td>
                  <Td className="num">{[c.rncpCode ? `RNCP ${c.rncpCode}` : null, c.rsCode ? `RS ${c.rsCode}` : null].filter(Boolean).join(" · ") || "-"}</Td>
                  <Td>{c.certifier ?? "-"}</Td>
                  <Td>
                    {c.validUntil ? (
                      <span className="flex items-center gap-2">
                        <span className="num">{fmtDate(c.validUntil)}</span>
                        {soon(c.validUntil)}
                      </span>
                    ) : (
                      "-"
                    )}
                  </Td>
                  <Td>
                    {c.habilitationRef ? (
                      <span className="flex flex-wrap items-center gap-2">
                        <span>{c.habilitationRef}</span>
                        {c.habilitationValidUntil ? (
                          <>
                            <span className="num">{fmtDate(c.habilitationValidUntil)}</span>
                            {soon(c.habilitationValidUntil)}
                          </>
                        ) : null}
                      </span>
                    ) : (
                      <span className="text-ink-3">Non renseignée</span>
                    )}
                  </Td>
                  <Td num>{Array.isArray(c.blocks) ? c.blocks.length : 0}</Td>
                  <Td num>{programs}</Td>
                  {canManage ? (
                    <Td>
                      <div className="flex items-center gap-1">
                        <FormDialog action={saveCertificationAction} trigger="Modifier" triggerVariant="ghost" triggerSize="sm" title={c.title} submitLabel="Enregistrer" wide>
                          <CertificationFields orgId={ctx.org.id} cert={c} prefix={`cf-${c.id.slice(0, 8)}`} />
                        </FormDialog>
                        <ActionButton action={deleteCertificationAction} fields={{ orgId: ctx.org.id, certificationId: c.id }} label="Supprimer" variant="ghost" confirm={{ title: `Supprimer « ${c.title} »`, description: "Impossible si des formations la visent encore.", confirmLabel: "Supprimer", danger: true }} />
                      </div>
                    </Td>
                  ) : null}
                </tr>
              ))}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucune certification" description="Ajoutez les certifications RNCP / RS préparées et les habilitations de l'organisme." />
        )}
      </Panel>
    </>
  );
}
