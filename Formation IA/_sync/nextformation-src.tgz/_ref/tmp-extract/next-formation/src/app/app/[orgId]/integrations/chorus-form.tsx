"use client";

import { ActionButton, ActionForm } from "@/components/admin/action-form";
import { Field, Input, Select } from "@/components/ui/field";
import { saveChorusAction, testChorusAction } from "@/server/actions/chorus";

export function ChorusForm({ orgId, env, supplierSiret, orgSiret, has, isDemo }: { orgId: string; env: "qualification" | "production"; supplierSiret: string; orgSiret: string | null; has: { clientId: boolean; clientSecret: boolean; techLogin: boolean; techPassword: boolean }; isDemo: boolean }) {
  const keep = "Enregistré (chiffré). Laissez vide pour conserver.";
  return (
    <div className="space-y-3">
      <ActionForm action={saveChorusAction} submitLabel="Enregistrer" submitVariant="secondary" submitSize="sm" className="space-y-3" footerClassName="pt-1">
        <input type="hidden" name="orgId" value={orgId} />
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Environnement" htmlFor="cp-env" required help="Commencez en qualification : chaque environnement a ses propres identifiants PISTE et son compte technique.">
            <Select id="cp-env" name="env" defaultValue={env}>
              <option value="qualification">Qualification (bac à sable)</option>
              <option value="production">Production</option>
            </Select>
          </Field>
          <Field label="SIRET fournisseur (facultatif)" htmlFor="cp-siret" help={orgSiret ? `Vide : SIRET de l'organisme (${orgSiret}).` : "Vide : SIRET de l'organisme (non renseigné dans Paramètres)."}>
            <Input id="cp-siret" name="supplierSiret" defaultValue={supplierSiret} className="num" inputMode="numeric" maxLength={20} />
          </Field>
          <Field label="client_id PISTE" htmlFor="cp-cid" help={has.clientId ? keep : "Application PISTE abonnée à l'API Chorus Pro."}>
            <Input id="cp-cid" name="clientId" autoComplete="off" className="num" placeholder={has.clientId ? "••••••••" : ""} />
          </Field>
          <Field label="client_secret PISTE" htmlFor="cp-csec" help={has.clientSecret ? keep : "Stocké chiffré, jamais réaffiché."}>
            <Input id="cp-csec" name="clientSecret" type="password" autoComplete="off" placeholder={has.clientSecret ? "••••••••" : ""} />
          </Field>
          <Field label="Login du compte technique" htmlFor="cp-login" help={has.techLogin ? keep : "Compte technique Chorus Pro rattaché à la structure, droits API activés."}>
            <Input id="cp-login" name="techLogin" autoComplete="off" placeholder={has.techLogin ? "••••••••" : ""} />
          </Field>
          <Field label="Mot de passe du compte technique" htmlFor="cp-pwd" help={has.techPassword ? keep : "Stocké chiffré, jamais réaffiché."}>
            <Input id="cp-pwd" name="techPassword" type="password" autoComplete="off" placeholder={has.techPassword ? "••••••••" : ""} />
          </Field>
        </div>
      </ActionForm>
      {!isDemo && has.clientId && has.clientSecret && has.techLogin && has.techPassword ? <ActionButton action={testChorusAction} fields={{ orgId }} label="Tester la connexion" variant="primary" size="sm" /> : null}
    </div>
  );
}
