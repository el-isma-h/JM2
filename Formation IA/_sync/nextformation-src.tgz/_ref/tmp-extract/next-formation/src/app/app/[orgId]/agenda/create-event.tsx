"use client";

import { FormDialog } from "@/components/admin/form-dialog";
import { Field, Input, Select, Textarea } from "@/components/ui/field";
import { createAgendaEventAction } from "@/server/actions/agenda";

export function CreateEventDialog({ orgId, defaultDate }: { orgId: string; defaultDate: string }) {
  return (
    <FormDialog action={createAgendaEventAction} trigger="Nouvel événement" title="Nouvel événement" description="Événement personnel (rendez-vous, réunion, visio). Heures en Europe/Paris." submitLabel="Ajouter">
      <input type="hidden" name="orgId" value={orgId} />
      <Field label="Titre" htmlFor="ae-title" required>
        <Input id="ae-title" name="title" required />
      </Field>
      <div className="grid gap-4 sm:grid-cols-3">
        <Field label="Date" htmlFor="ae-date" required>
          <Input id="ae-date" name="date" type="date" defaultValue={defaultDate} required className="num" />
        </Field>
        <Field label="Début" htmlFor="ae-start" required>
          <Input id="ae-start" name="start" type="time" defaultValue="09:00" required className="num" />
        </Field>
        <Field label="Fin" htmlFor="ae-end" required>
          <Input id="ae-end" name="end" type="time" defaultValue="10:00" required className="num" />
        </Field>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Type" htmlFor="ae-kind">
          <Select id="ae-kind" name="kind" defaultValue="rdv">
            <option value="rdv">Rendez-vous</option>
            <option value="reunion">Réunion</option>
            <option value="visio">Visio</option>
            <option value="autre">Autre</option>
          </Select>
        </Field>
        <Field label="Lieu" htmlFor="ae-loc">
          <Input id="ae-loc" name="location" />
        </Field>
      </div>
      <Field label="Notes" htmlFor="ae-notes">
        <Textarea id="ae-notes" name="notes" className="min-h-16" />
      </Field>
    </FormDialog>
  );
}
