import Link from "next/link";
import { and, desc, eq, inArray, sql, type SQL } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { runOverdueAction, updateAccountingSettingsAction } from "@/server/actions/finance";
import { accountingSettingsFrom, invoiceKindLabels } from "@/server/finance/compute";
import { formatCents } from "@/lib/money";
import { fmtDate } from "@/lib/dates";
import { todayParis } from "@/lib/time";
import { Badge, StatusBadge, statusMeta } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox, Field, Input, Select } from "@/components/ui/field";
import { EmptyState, Notice, PageHeader, Panel, PanelHeader, Stat } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { ActionButton, ActionForm } from "@/components/admin/action-form";
import { Pagination, readPage, readParam } from "@/components/admin/pagination";
import { RibLink } from "@/components/finance/rib-link";

export const dynamic = "force-dynamic";
const PAGE = 50;
const STATUSES = schema.invoiceStatusEnum.enumValues;

export default async function InvoicesPage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const ctx = await guardOrg(orgId, `/app/${orgId}/factures`, "finance.view");
  const canManage = ctx.permissions.has("finance.manage");
  const canExport = ctx.permissions.has("exports.run");
  const sp = await searchParams;
  const status = readParam(sp.status);
  const kind = readParam(sp.kind);
  const client = readParam(sp.client);
  const from = readParam(sp.from);
  const to = readParam(sp.to);
  const late = readParam(sp.late) === "1";
  const page = readPage(sp.page);
  const today = todayParis();

  const conds: SQL[] = [eq(schema.invoices.orgId, orgId)];
  if (status && (STATUSES as readonly string[]).includes(status)) conds.push(eq(schema.invoices.status, status as (typeof STATUSES)[number]));
  if (kind && (schema.invoiceKindEnum.enumValues as readonly string[]).includes(kind)) conds.push(eq(schema.invoices.kind, kind as "facture"));
  if (client) conds.push(sql`(${schema.invoices.billTo}->>'name') ilike ${`%${client}%`}`);
  if (from && /^\d{4}-\d{2}-\d{2}$/.test(from)) conds.push(sql`${schema.invoices.issueDate} >= ${from}`);
  if (to && /^\d{4}-\d{2}-\d{2}$/.test(to)) conds.push(sql`${schema.invoices.issueDate} <= ${to}`);
  if (late) conds.push(and(inArray(schema.invoices.status, ["emise", "envoyee", "partiellement_payee", "en_retard"]), sql`${schema.invoices.dueDate} < ${today}`)!);
  const where = and(...conds);

  const [rows, [{ total }], totals, [{ unexported }]] = await Promise.all([
    db.select().from(schema.invoices).where(where).orderBy(desc(schema.invoices.issueDate), desc(schema.invoices.createdAt)).limit(PAGE).offset((page - 1) * PAGE),
    db.select({ total: sql<number>`count(*)::int` }).from(schema.invoices).where(where),
    db
      .select({
        billed: sql<number>`coalesce(sum(case when ${schema.invoices.status} not in ('brouillon','annulee') and ${schema.invoices.kind} in ('facture','acompte') then ${schema.invoices.totalTtcCents} else 0 end), 0)::int`,
        credits: sql<number>`coalesce(sum(case when ${schema.invoices.status} not in ('brouillon','annulee') and ${schema.invoices.kind} = 'avoir' then ${schema.invoices.totalTtcCents} else 0 end), 0)::int`,
        paid: sql<number>`coalesce(sum(case when ${schema.invoices.status} not in ('brouillon','annulee') and ${schema.invoices.kind} in ('facture','acompte') then ${schema.invoices.paidCents} else 0 end), 0)::int`,
        overdue: sql<number>`coalesce(sum(case when ${schema.invoices.status} in ('emise','envoyee','partiellement_payee','en_retard') and ${schema.invoices.dueDate} < ${today} then ${schema.invoices.totalTtcCents} - ${schema.invoices.paidCents} else 0 end), 0)::int`,
        drafts: sql<number>`count(*) filter (where ${schema.invoices.status} = 'brouillon')::int`,
      })
      .from(schema.invoices)
      .where(where)
      .then((r) => r[0]),
    db.select({ unexported: sql<number>`count(*)::int` }).from(schema.invoices).where(and(eq(schema.invoices.orgId, orgId), inArray(schema.invoices.status, ["emise", "envoyee", "partiellement_payee", "payee", "en_retard"]), sql`${schema.invoices.exportedAt} is null`)),
  ]);
  const acc = accountingSettingsFrom(ctx.org.settings);
  const filterParams = { status, kind, client, from, to, late: late ? "1" : undefined };
  const year = today.slice(0, 4);

  return (
    <>
      <PageHeader
        title="Factures et règlements"
        description="Factures, acomptes et avoirs numérotés en continu à l'émission ; règlements, relances et rapprochement bancaire. Une facture émise ne se modifie plus : elle s'annule par un avoir."
        actions={
          <>
            <RibLink orgId={orgId} manage={canManage || ctx.isOwner} />
            {canManage ? (
              <Button asChild variant="secondary">
                <Link href={`/app/${orgId}/factures/rapprochement`}>Rapprochement bancaire</Link>
              </Button>
            ) : null}
            {canManage ? <ActionButton action={runOverdueAction} fields={{ orgId }} label="Recalculer les retards" size="md" /> : null}
            {canManage ? (
              <Button asChild>
                <Link href={`/app/${orgId}/factures/nouvelle`}>Nouvelle facture</Link>
              </Button>
            ) : null}
          </>
        }
      />

      <Panel className="mb-6 grid grid-cols-2 gap-6 p-5 md:grid-cols-5">
        <Stat label="Facturé TTC" value={formatCents(totals.billed)} hint="Factures et acomptes émis (filtre)" />
        <Stat label="Avoirs" value={formatCents(totals.credits)} />
        <Stat label="Encaissé" value={formatCents(totals.paid)} />
        <Stat label="En retard" value={formatCents(totals.overdue)} hint={`Échues au ${fmtDate(today)}, non soldées`} />
        <Stat label="Brouillons" value={totals.drafts} hint="Sans numéro, sans valeur comptable" />
      </Panel>

      <Panel>
        <form method="get" className="flex flex-wrap items-end gap-3 border-b border-line px-5 py-3">
          <Field label="Client / destinataire" htmlFor="client" className="w-56">
            <Input id="client" name="client" defaultValue={client} placeholder="Nom du destinataire" />
          </Field>
          <Field label="Statut" htmlFor="status" className="w-44">
            <Select id="status" name="status" defaultValue={status ?? ""}>
              <option value="">Tous</option>
              {STATUSES.map((s) => (
                <option key={s} value={s}>
                  {statusMeta[s]?.label ?? s}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Type" htmlFor="kind" className="w-40">
            <Select id="kind" name="kind" defaultValue={kind ?? ""}>
              <option value="">Tous</option>
              {schema.invoiceKindEnum.enumValues.map((k) => (
                <option key={k} value={k}>
                  {invoiceKindLabels[k]}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Émise du" htmlFor="from" className="w-40">
            <Input id="from" name="from" type="date" defaultValue={from ?? ""} />
          </Field>
          <Field label="au" htmlFor="to" className="w-40">
            <Input id="to" name="to" type="date" defaultValue={to ?? ""} />
          </Field>
          <Checkbox name="late" value="1" defaultChecked={late} label="En retard seulement" className="mb-2" />
          <Button type="submit" variant="secondary">
            Filtrer
          </Button>
        </form>
        {rows.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Numéro</Th>
                <Th>Type</Th>
                <Th>Destinataire</Th>
                <Th>Émission</Th>
                <Th>Échéance</Th>
                <Th>Statut</Th>
                <Th num>TTC</Th>
                <Th num>Réglé</Th>
                <Th num>Reste dû</Th>
              </tr>
            </thead>
            <tbody>
              {rows.map((i) => {
                const bt = i.billTo as { name?: string };
                const isLate = ["emise", "envoyee", "partiellement_payee", "en_retard"].includes(i.status) && i.dueDate && i.dueDate < today;
                const remaining = i.kind === "avoir" ? 0 : i.totalTtcCents - i.paidCents;
                return (
                  <tr key={i.id}>
                    <Td>
                      <Link href={`/app/${orgId}/factures/${i.id}`} className="num font-medium text-ink hover:underline">
                        {i.number ?? "Brouillon"}
                      </Link>
                      {i.exportBatch ? <p className="num text-[11px] text-ink-3">export {i.exportBatch}</p> : null}
                    </Td>
                    <Td>{invoiceKindLabels[i.kind]}</Td>
                    <Td>{bt.name ?? "-"}</Td>
                    <Td className="whitespace-nowrap">{fmtDate(i.issueDate)}</Td>
                    <Td className="whitespace-nowrap">
                      {i.dueDate ? fmtDate(i.dueDate) : "-"} {isLate && i.status !== "en_retard" ? <Badge tone="danger" className="ml-1">Échue</Badge> : null}
                    </Td>
                    <Td>
                      <StatusBadge status={i.status} />
                    </Td>
                    <Td num>{formatCents(i.totalTtcCents)}</Td>
                    <Td num>{i.kind === "avoir" ? "-" : formatCents(i.paidCents)}</Td>
                    <Td num>{i.status === "brouillon" || i.status === "annulee" ? "-" : formatCents(remaining)}</Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucune facture" description={Object.values(filterParams).some(Boolean) ? "Aucun résultat pour ces filtres." : "Créez une facture depuis un financement accordé, une inscription ou directement ici."} action={canManage ? <Button asChild><Link href={`/app/${orgId}/factures/nouvelle`}>Nouvelle facture</Link></Button> : undefined} />
        )}
        <Pagination basePath={`/app/${orgId}/factures`} params={filterParams} page={page} pageSize={PAGE} total={total} />
      </Panel>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <Panel>
          <PanelHeader title="Export comptable : journal des ventes" description={`CSV (date ; pièce ; compte ; libellé ; débit ; crédit). ${unexported} facture(s) émise(s) jamais exportée(s).`} />
          <div className="space-y-4 p-5">
            {canExport ? (
              <form method="get" action={`/app/${orgId}/factures/export`} className="flex flex-wrap items-end gap-3">
                <Field label="Du" htmlFor="ex-from" className="w-40">
                  <Input id="ex-from" name="from" type="date" defaultValue={`${year}-01-01`} required />
                </Field>
                <Field label="Au" htmlFor="ex-to" className="w-40">
                  <Input id="ex-to" name="to" type="date" defaultValue={today} required />
                </Field>
                <Checkbox name="onlyNew" value="1" defaultChecked label="Non exportées seulement" className="mb-2" />
                <Checkbox name="mark" value="1" defaultChecked label="Marquer comme exportées (lot)" className="mb-2" />
                <Button type="submit" variant="secondary">
                  Télécharger le CSV
                </Button>
              </form>
            ) : (
              <Notice tone="info">L&apos;export massif exige la permission « exports.run » et une session renforcée (code d&apos;authentification). Votre rôle permet la consultation.</Notice>
            )}
            <p className="text-[12.5px] text-ink-3">
              Comptes : ventes {acc.salesAccount} · clients {acc.customerAccount} · TVA collectée {acc.vatAccount} · journal {acc.journal}.
            </p>
          </div>
        </Panel>
        <Panel>
          <PanelHeader title="Paramétrage des comptes" description="Plan comptable utilisé par l'export (706 / 411 / 445)." />
          <div className="p-5">
            {canManage ? (
              <ActionForm action={updateAccountingSettingsAction} submitLabel="Enregistrer" submitVariant="secondary" submitSize="sm" footerClassName="mt-4">
                <input type="hidden" name="orgId" value={orgId} />
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Compte de ventes (706)" htmlFor="ac-sales">
                    <Input id="ac-sales" name="salesAccount" className="num" defaultValue={acc.salesAccount} />
                  </Field>
                  <Field label="Compte clients (411)" htmlFor="ac-cust">
                    <Input id="ac-cust" name="customerAccount" className="num" defaultValue={acc.customerAccount} />
                  </Field>
                  <Field label="TVA collectée (445)" htmlFor="ac-vat">
                    <Input id="ac-vat" name="vatAccount" className="num" defaultValue={acc.vatAccount} />
                  </Field>
                  <Field label="Code journal" htmlFor="ac-journal">
                    <Input id="ac-journal" name="journal" className="num" defaultValue={acc.journal} />
                  </Field>
                </div>
              </ActionForm>
            ) : (
              <p className="text-[13px] text-ink-3">Modification réservée à finance.manage.</p>
            )}
          </div>
        </Panel>
      </div>
    </>
  );
}
