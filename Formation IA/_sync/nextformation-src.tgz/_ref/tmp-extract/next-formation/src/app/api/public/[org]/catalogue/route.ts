import { appUrl } from "@/lib/env";
import { catalogueFamilies, filterByFamily, loadPublicCatalogueByRef, publicCatalogueJson } from "@/server/catalog/public";
import { cachedResponse, limitPublic, preflight, PUBLIC_CORS } from "@/server/catalog/public-http";

export const dynamic = "force-dynamic";

/**
 * GET /api/public/{slug du tenant | id de l'organisme}/catalogue[?famille=…]
 * Catalogue public en JSON (lecture seule, sans session) : formations publiées et actives avec leur version
 * active et les sessions publiées à venir. Utilisé par le widget /embed/catalogue et le plugin WordPress.
 */
export async function GET(req: Request, { params }: { params: Promise<{ org: string }> }) {
  const limited = await limitPublic();
  if (limited) return limited;
  const { org } = await params;
  const data = await loadPublicCatalogueByRef(org);
  if (!data) return Response.json({ error: "Catalogue introuvable." }, { status: 404, headers: PUBLIC_CORS });
  const famille = new URL(req.url).searchParams.get("famille");
  const json = publicCatalogueJson(filterByFamily(data, famille));
  const payload = { ...json, organismeId: data.org.id, organismeSlug: data.tenant.slug, catalogueUrl: `${appUrl()}/catalogue-public/${data.tenant.slug}`, familles: catalogueFamilies(data), famille: famille || null };
  const { generéLe: _ignored, ...stable } = payload;
  void _ignored;
  return cachedResponse(req, JSON.stringify(payload), "application/json; charset=utf-8", JSON.stringify(stable));
}

export const HEAD = GET;

export function OPTIONS() {
  return preflight();
}
