import Link from "next/link";
import { notFound } from "next/navigation";
import { and, desc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { assertSessionInScope } from "@/server/authz";
import { AuthError } from "@/server/auth";
import { currentAttendances, expectedEnrollments, loadPeriod } from "@/server/planning/service";
import { canCloseOrSign, canRecordAttendance, periodMinutes } from "@/server/planning/hours";
import { issueDownloadLink } from "@/server/documents/store";
import { ACCEPT_ATTR } from "@/server/documents/upload-rules";
import { clearAttendanceAction, closePeriodAction, decideCorrectionAction, openPeriodAction, recordAttendanceAction, requestCorrectionAction, sendSignLinksAction, signLearnerTabletAction, trainerSignAction } from "@/server/actions/attendance";
import { fmtMinutes, serverNow, timeParis, todayParis } from "@/lib/time";
import { fmtDate, fmtDateTime } from "@/lib/dates";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/ui/badge";
import { Field, Input, Select, Textarea, Checkbox } from "@/components/ui/field";
import { KeyValue, Notice, PageHeader, Panel, PanelHeader, Stat } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FormDialog } from "@/components/admin/form-dialog";
import { ActionButton, ActionForm } from "@/components/admin/action-form";
import { SignaturePad } from "@/components/pedagogy/signature-pad";
import { QrPanel } from "@/components/pedagogy/qr-panel";

export const dynamic = "force-dynamic";

const partLabel: Record<string, string> = { matin: "Matin", apres_midi: "Après-midi", journee: "Journée", soir: "Soir" };
const STATUSES: [string, string][] = [
  ["present", "Présent"],
  ["retard", "Retard (heure d'arrivée)"],
  ["depart_anticipe", "Départ anticipé (heure de départ)"],
  ["retard_et_depart", "Retard et départ anticipé"],
  ["absent", "Absent"],
  ["absent_justifie", "Absent justifié (motif, justificatif)"],
  ["excuse", "Excusé"],
];

export default async function PeriodSheetPage({ params }: { params: Promise<{ orgId: string; periodId: string }> }) {
  const { orgId, periodId } = await params;
  const base = `/app/${orgId}`;
  const ctx = await guardOrg(orgId, `${base}/emargement/${periodId}`, "attendance.record");
  if (!/^[0-9a-f-]{36}$/.test(periodId)) notFound();
  const row = await loadPeriod(orgId, periodId);
  if (!row) notFound();
  try {
    await assertSessionInScope(ctx, row.session.id);
  } catch (e) {
    if (e instanceof AuthError) notFound();
    throw e;
  }
  const { period, slot, session } = row;
  const now = serverNow();
  const t = { date: slot.date, startTime: period.startTime, endTime: period.endTime, status: period.status };
  const recordRule = canRecordAttendance(t, now);
  const closeRule = canCloseOrSign(t, now);
  const canClose = ctx.permissions.has("attendance.close");
  const canCorrect = ctx.permissions.has("attendance.correct");

  const [expected, attendances, corrections, moduleRow, trainer, room, sheetDoc] = await Promise.all([
    expectedEnrollments(orgId, session.id, slot.groupId),
    currentAttendances(orgId, periodId),
    db.select().from(schema.attendanceCorrections).where(and(eq(schema.attendanceCorrections.orgId, orgId), eq(schema.attendanceCorrections.periodId, periodId))).orderBy(desc(schema.attendanceCorrections.createdAt)),
    slot.moduleId ? db.select({ title: schema.modules.title }).from(schema.modules).where(eq(schema.modules.id, slot.moduleId)).limit(1).then((r) => r[0]) : Promise.resolve(null),
    (period.trainerId ?? slot.trainerId) ? db.select({ firstName: schema.trainers.firstName, lastName: schema.trainers.lastName }).from(schema.trainers).where(eq(schema.trainers.id, (period.trainerId ?? slot.trainerId)!)).limit(1).then((r) => r[0]) : Promise.resolve(null),
    (period.roomId ?? slot.roomId) ? db.select({ name: schema.rooms.name }).from(schema.rooms).where(eq(schema.rooms.id, (period.roomId ?? slot.roomId)!)).limit(1).then((r) => r[0]) : Promise.resolve(null),
    db.select().from(schema.documents).where(and(eq(schema.documents.orgId, orgId), eq(schema.documents.sourceType, "period"), eq(schema.documents.sourceId, periodId), eq(schema.documents.category, "feuille_emargement"))).orderBy(desc(schema.documents.createdAt)).limit(1).then((r) => r[0] ?? null),
  ]);
  const byEnrollment = new Map(attendances.map((a) => [a.enrollmentId, a]));
  const personById = new Map(expected.map((e) => [e.enrollment.id, e.person]));
  const sheetLink = sheetDoc ? await issueDownloadLink(sheetDoc.id, ctx.user.id) : null;
  const counted = expected.reduce((n, e) => n + (byEnrollment.get(e.enrollment.id)?.minutesCounted ?? 0), 0);
  const presentCount = expected.filter((e) => (byEnrollment.get(e.enrollment.id)?.minutesCounted ?? 0) > 0).length;
  const pendingCorrections = corrections.filter((c) => c.status === "demandee");

  return (
    <>
      <PageHeader
        breadcrumb={[{ label: "Émargement", href: `${base}/emargement` }, { label: `${session.code} · ${fmtDate(slot.date)}` }]}
        title={`${partLabel[period.part]} du ${fmtDate(slot.date, "EEEE d MMMM yyyy")}`}
        description={`${session.code} : ${session.title}. Période ${period.startTime}-${period.endTime} (heure de Paris). Heure serveur : ${todayParis(now) === slot.date ? timeParis(now) : fmtDateTime(now)}.`}
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <StatusBadge status={period.status} />
            {sheetLink ? (
              <Button asChild variant="secondary" size="sm">
                <a href={sheetLink}>Feuille PDF</a>
              </Button>
            ) : null}
            <Button asChild variant="ghost" size="sm">
              <Link href={`${base}/sessions/${session.id}`}>Session</Link>
            </Button>
          </div>
        }
      />

      <div className="mb-6 grid gap-4 md:grid-cols-[2fr_1fr]">
        <Panel className="p-5">
          <KeyValue
            items={[
              { k: "Session", v: `${session.code} : ${session.title}` },
              { k: "Module", v: moduleRow?.title ?? slot.title ?? "-" },
              { k: "Formateur", v: trainer ? `${trainer.firstName} ${trainer.lastName}` : "Non affecté" },
              { k: "Salle", v: room?.name ?? "-" },
              { k: "Ouverture", v: period.openedAt ? fmtDateTime(period.openedAt) : "Non ouverte" },
              { k: "Signature de fin", v: period.trainerSignedAt ? fmtDateTime(period.trainerSignedAt) : "Non signée" },
              { k: "Clôture", v: period.closedAt ? fmtDateTime(period.closedAt) : "Non clôturée" },
            ]}
          />
        </Panel>
        <Panel className="grid grid-cols-2 gap-4 p-5">
          <Stat label="Inscrits attendus" value={<span className="num">{expected.length}</span>} />
          <Stat label="Présents" value={<span className="num">{presentCount}</span>} />
          <Stat label="Durée de la période" value={<span className="num">{fmtMinutes(periodMinutes(period))}</span>} hint={period.breakMinutes ? `Pause de ${period.breakMinutes} min déduite.` : undefined} />
          <Stat label="Minutes comptées" value={<span className="num">{fmtMinutes(counted)}</span>} hint="Somme des présences de cette seule période." />
        </Panel>
      </div>

      {period.status === "prevue" ? (
        <Panel className="mb-6 p-5">
          <Notice tone="info" title="Préparation">
            La feuille peut être ouverte dès maintenant. {recordRule.ok ? "La période a commencé : les présences pourront être saisies dès l'ouverture." : recordRule.reason}
          </Notice>
          <div className="mt-4">
            <ActionButton action={openPeriodAction} fields={{ orgId, periodId }} label="Ouvrir la feuille d'émargement" variant="primary" size="md" />
          </div>
        </Panel>
      ) : null}
      {period.status === "annulee" || slot.status === "annulee" ? (
        <Notice tone="warn" className="mb-6">
          Cette période est annulée : aucune présence ne peut être saisie.
        </Notice>
      ) : null}
      {period.status === "ouverte" && !recordRule.ok ? (
        <Notice tone="warn" className="mb-6" title="Feuille ouverte, saisie non encore possible">
          {recordRule.reason}
        </Notice>
      ) : null}
      {period.status === "cloturee" ? (
        <Notice tone="ok" className="mb-6" title="Période clôturée et verrouillée">
          Les présences ne peuvent plus être modifiées ni supprimées directement. Une correction exceptionnelle passe par une demande motivée, une décision par un habilité « corriger », et crée une nouvelle ligne en conservant l&apos;original.
        </Notice>
      ) : null}

      {period.status === "ouverte" && recordRule.ok ? (
        <div className="mb-6 grid gap-4 lg:grid-cols-2">
          <Panel>
            <PanelHeader title="Signature par QR code" description="Code renouvelé toutes les 2 minutes ; l'apprenant saisit son e-mail et le code." />
            <div className="p-5">
              <QrPanel orgId={orgId} periodId={periodId} />
            </div>
          </Panel>
          <Panel>
            <PanelHeader title="Signature par lien e-mail" description="Chaque inscrit reçoit un lien personnel valable jusqu'à la clôture." />
            <div className="p-5">
              <ActionForm action={sendSignLinksAction} submitLabel="Envoyer les liens aux inscrits" submitVariant="secondary">
                <input type="hidden" name="orgId" value={orgId} />
                <input type="hidden" name="periodId" value={periodId} />
              </ActionForm>
              {ctx.org.isDemo ? <p className="mt-3 text-[12px] text-ink-3">Espace de démonstration : les e-mails sont journalisés, jamais envoyés.</p> : null}
            </div>
          </Panel>
        </div>
      ) : null}

      <Panel className="mb-6">
        <PanelHeader title="Présences" description="Une seule ligne courante par inscrit et par période : une actualisation ou un double envoi ne double jamais les heures." />
        {expected.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Apprenant</Th>
                <Th>Statut</Th>
                <Th>Arrivée / départ</Th>
                <Th num>Minutes</Th>
                <Th>Signature</Th>
                <Th>Actions</Th>
              </tr>
            </thead>
            <tbody>
              {expected.map(({ enrollment, person }) => {
                const a = byEnrollment.get(enrollment.id);
                const status = a?.status ?? "non_saisie";
                return (
                  <tr key={enrollment.id}>
                    <Td>
                      <Link href={`${base}/inscriptions/${enrollment.id}`} className="font-medium hover:underline">
                        {person.lastName.toUpperCase()} {person.firstName}
                      </Link>
                      <p className="num text-[12px] text-ink-3">{enrollment.reference}</p>
                    </Td>
                    <Td>
                      <StatusBadge status={status} />
                      {a?.justificationNote ? <p className="mt-1 text-[12px] text-ink-3">{a.justificationNote}</p> : null}
                    </Td>
                    <Td className="num">{[a?.arrivedAt ? `arr. ${a.arrivedAt}` : null, a?.leftAt ? `dép. ${a.leftAt}` : null].filter(Boolean).join(" / ") || "-"}</Td>
                    <Td num>{a?.minutesCounted ?? 0}</Td>
                    <Td className="text-[12px]">{a?.learnerSignedAt ? `${a.signatureMethod ?? "signé"} · ${fmtDate(a.learnerSignedAt, "HH:mm")}` : "Non signé"}</Td>
                    <Td>
                      {period.status === "ouverte" && recordRule.ok ? (
                        <div className="flex flex-wrap gap-2">
                          <FormDialog action={recordAttendanceAction} trigger="Saisir" triggerVariant="secondary" triggerSize="sm" title={`${person.firstName} ${person.lastName}`} description={`Période ${period.startTime}-${period.endTime}. Les minutes sont calculées côté serveur.`} submitLabel="Enregistrer">
                            <input type="hidden" name="orgId" value={orgId} />
                            <input type="hidden" name="periodId" value={periodId} />
                            <input type="hidden" name="enrollmentId" value={enrollment.id} />
                            <Field label="Statut" required htmlFor={`st-${enrollment.id}`}>
                              <Select id={`st-${enrollment.id}`} name="status" defaultValue={status === "non_saisie" ? "present" : status}>
                                {STATUSES.map(([v, l]) => (
                                  <option key={v} value={v}>
                                    {l}
                                  </option>
                                ))}
                              </Select>
                            </Field>
                            <div className="grid grid-cols-2 gap-3">
                              <Field label="Heure d'arrivée" htmlFor={`ar-${enrollment.id}`} help="Retard uniquement.">
                                <Input id={`ar-${enrollment.id}`} name="arrivedAt" type="time" defaultValue={a?.arrivedAt ?? ""} />
                              </Field>
                              <Field label="Heure de départ" htmlFor={`le-${enrollment.id}`} help="Départ anticipé uniquement.">
                                <Input id={`le-${enrollment.id}`} name="leftAt" type="time" defaultValue={a?.leftAt ?? ""} />
                              </Field>
                            </div>
                            <Field label="Motif (absence justifiée)" htmlFor={`jn-${enrollment.id}`}>
                              <Textarea id={`jn-${enrollment.id}`} name="justificationNote" defaultValue={a?.justificationNote ?? ""} className="min-h-16" />
                            </Field>
                            <Field label="Justificatif" htmlFor={`jf-${enrollment.id}`} help="PDF ou image, 20 Mo maximum ; rangé dans les pièces administratives.">
                              <Input id={`jf-${enrollment.id}`} name="justificatif" type="file" accept={ACCEPT_ATTR} className="py-1.5" />
                            </Field>
                          </FormDialog>
                          <FormDialog action={signLearnerTabletAction} trigger="Signature tablette" triggerVariant="secondary" triggerSize="sm" title={`Signature de ${person.firstName} ${person.lastName}`} description="L'apprenant signe sur l'écran ; l'image est conservée avec la présence." submitLabel="Valider la signature">
                            <input type="hidden" name="orgId" value={orgId} />
                            <input type="hidden" name="periodId" value={periodId} />
                            <input type="hidden" name="enrollmentId" value={enrollment.id} />
                            <SignaturePad />
                          </FormDialog>
                          {a && a.status !== "non_saisie" ? <ActionButton action={clearAttendanceAction} fields={{ orgId, periodId, enrollmentId: enrollment.id }} label="Effacer" variant="ghost" confirm={{ title: "Remettre à « non saisie » ?", description: "Possible uniquement tant que la période n'est pas clôturée." }} /> : null}
                        </div>
                      ) : period.status === "cloturee" && a ? (
                        <FormDialog action={requestCorrectionAction} trigger="Demander une correction" triggerVariant="secondary" triggerSize="sm" title={`Correction : ${person.firstName} ${person.lastName}`} description="Demande tracée, à décider par un habilité « corriger ». L'original est conservé." submitLabel="Envoyer la demande">
                          <input type="hidden" name="orgId" value={orgId} />
                          <input type="hidden" name="periodId" value={periodId} />
                          <input type="hidden" name="enrollmentId" value={enrollment.id} />
                          <Field label="Statut demandé" required htmlFor={`cs-${enrollment.id}`}>
                            <Select id={`cs-${enrollment.id}`} name="status" defaultValue={a.status === "non_saisie" ? "present" : a.status}>
                              {STATUSES.map(([v, l]) => (
                                <option key={v} value={v}>
                                  {l}
                                </option>
                              ))}
                            </Select>
                          </Field>
                          <div className="grid grid-cols-2 gap-3">
                            <Field label="Heure d'arrivée" htmlFor={`car-${enrollment.id}`}>
                              <Input id={`car-${enrollment.id}`} name="arrivedAt" type="time" defaultValue={a.arrivedAt ?? ""} />
                            </Field>
                            <Field label="Heure de départ" htmlFor={`cle-${enrollment.id}`}>
                              <Input id={`cle-${enrollment.id}`} name="leftAt" type="time" defaultValue={a.leftAt ?? ""} />
                            </Field>
                          </div>
                          <Field label="Motif de l'absence justifiée" htmlFor={`cjn-${enrollment.id}`}>
                            <Input id={`cjn-${enrollment.id}`} name="justificationNote" defaultValue={a.justificationNote ?? ""} />
                          </Field>
                          <Field label="Motif de la correction" required htmlFor={`cr-${enrollment.id}`} help="Conservé avec l'auteur et la décision.">
                            <Textarea id={`cr-${enrollment.id}`} name="reason" required className="min-h-20" />
                          </Field>
                        </FormDialog>
                      ) : (
                        <span className="text-[12px] text-ink-3">{period.status === "ouverte" ? "Après le début réel" : "-"}</span>
                      )}
                    </Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        ) : (
          <p className="px-5 py-8 text-[13.5px] text-ink-2">Aucune inscription active (inscrit, en cours, terminé) sur cette session{slot.groupId ? " et ce groupe" : ""}.</p>
        )}
      </Panel>

      {period.status === "ouverte" ? (
        <div className="mb-6 grid gap-4 lg:grid-cols-2">
          <Panel>
            <PanelHeader title="Signature de fin du formateur" description={closeRule.ok ? "La période est terminée : signez pour attester le déroulement." : closeRule.reason} />
            <div className="p-5">
              {closeRule.ok ? (
                <ActionForm action={trainerSignAction} submitLabel={period.trainerSignedAt ? "Signer à nouveau" : "Signer la fin de période"} submitVariant="secondary">
                  <input type="hidden" name="orgId" value={orgId} />
                  <input type="hidden" name="periodId" value={periodId} />
                  <div className="mb-4">
                    <SignaturePad label="Signature du formateur" />
                  </div>
                </ActionForm>
              ) : (
                <p className="text-[13px] text-ink-3">Disponible à partir de {period.endTime}.</p>
              )}
            </div>
          </Panel>
          <Panel>
            <PanelHeader title="Clôture" description="Verrouille la période, marque absents les non saisis, génère la feuille PDF et enregistre la preuve qualité (indicateur 11)." />
            <div className="p-5">
              {!canClose ? (
                <p className="text-[13px] text-ink-3">Votre habilitation ne permet pas de clôturer.</p>
              ) : closeRule.ok ? (
                <ActionForm action={closePeriodAction} submitLabel="Clôturer la période" confirm={{ title: "Clôturer et verrouiller cette période ?", description: "Les présences non saisies seront enregistrées absentes. Aucune modification directe ne sera plus possible.", confirmLabel: "Clôturer" }}>
                  <input type="hidden" name="orgId" value={orgId} />
                  <input type="hidden" name="periodId" value={periodId} />
                  {!period.trainerSignedAt ? <Checkbox name="withoutTrainerSignature" value="1" label="Clôturer sans signature de fin du formateur (mention conservée sur la feuille)" className="mb-4" /> : null}
                </ActionForm>
              ) : (
                <p className="text-[13px] text-ink-3">{closeRule.reason}</p>
              )}
            </div>
          </Panel>
        </div>
      ) : null}

      {corrections.length ? (
        <Panel>
          <PanelHeader title="Corrections exceptionnelles" description={`${pendingCorrections.length} demande(s) en attente de décision.`} />
          <Table>
            <thead>
              <tr>
                <Th>Demandée le</Th>
                <Th>Apprenant</Th>
                <Th>Avant</Th>
                <Th>Demandé</Th>
                <Th>Motif</Th>
                <Th>État</Th>
                <Th>Décision</Th>
              </tr>
            </thead>
            <tbody>
              {corrections.map((c) => {
                const p = c.enrollmentId ? personById.get(c.enrollmentId) : null;
                const before = (c.before ?? {}) as { status?: string; minutesCounted?: number };
                const req = (c.requested ?? {}) as { status?: string; arrivedAt?: string | null; leftAt?: string | null };
                return (
                  <tr key={c.id}>
                    <Td className="whitespace-nowrap">{fmtDateTime(c.createdAt)}</Td>
                    <Td>{p ? `${p.lastName.toUpperCase()} ${p.firstName}` : "-"}</Td>
                    <Td>
                      {before.status ? <StatusBadge status={before.status} /> : "-"} <span className="num text-[12px] text-ink-3">{before.minutesCounted ?? 0} min</span>
                    </Td>
                    <Td>
                      {req.status ? <StatusBadge status={req.status} /> : "-"}
                      <span className="num ml-1 text-[12px] text-ink-3">{[req.arrivedAt, req.leftAt].filter(Boolean).join(" / ")}</span>
                    </Td>
                    <Td className="max-w-xs text-[12.5px]">
                      {c.reason}
                      {c.decisionNote ? <p className="mt-1 text-ink-3">Décision : {c.decisionNote}</p> : null}
                    </Td>
                    <Td>
                      <StatusBadge status={c.status} />
                    </Td>
                    <Td>
                      {c.status === "demandee" && canCorrect ? (
                        <div className="flex gap-2">
                          <ActionButton action={decideCorrectionAction} fields={{ orgId, correctionId: c.id, decision: "approuvee" }} label="Approuver et appliquer" variant="primary" confirm={{ title: "Approuver cette correction ?", description: "Une nouvelle ligne de présence est créée ; l'original est conservé et marqué remplacé.", input: { name: "decisionNote", label: "Note de décision" } }} />
                          <ActionButton action={decideCorrectionAction} fields={{ orgId, correctionId: c.id, decision: "refusee" }} label="Refuser" variant="danger" confirm={{ title: "Refuser cette demande ?", input: { name: "decisionNote", label: "Motif du refus" }, danger: true }} />
                        </div>
                      ) : c.status === "demandee" ? (
                        <span className="text-[12px] text-ink-3">En attente d&apos;un habilité</span>
                      ) : (
                        <span className="text-[12px] text-ink-3">{c.decidedAt ? fmtDateTime(c.decidedAt) : "-"}</span>
                      )}
                    </Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        </Panel>
      ) : null}
    </>
  );
}
