import Link from "next/link";
import { guardTrainer } from "@/server/extranet/guard";
import { listSlotsForSessions } from "@/server/extranet/queries";
import { NoAttachment } from "@/components/extranet/shell";
import { SlotTable } from "@/components/extranet/ui";
import { StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { EmptyState, Notice, PageHeader, Panel, PanelHeader, Stat } from "@/components/ui/surface";
import { fmtDate } from "@/lib/dates";
import { todayParis } from "@/lib/time";
import { listMissions } from "@/server/missions/queries";
import { TrainerMissionList } from "@/components/missions/trainer-missions";

export const dynamic = "force-dynamic";

/** Mes séances : aujourd'hui, à venir, passées, avec l'état des périodes et l'accès à l'émargement. */
export default async function TrainerHome() {
  const ctx = await guardTrainer("/formateur");
  if (!ctx) return <NoAttachment kind="trainer" />;
  const today = todayParis();
  const all = (await listSlotsForSessions(ctx.org.id, ctx.sessionIds)).filter((s) => !s.slot.trainerId || s.slot.trainerId === ctx.trainer.id);
  const todays = all.filter((s) => s.slot.date === today);
  const upcoming = all.filter((s) => s.slot.date > today);
  const past = all.filter((s) => s.slot.date < today).reverse();
  const openPeriods = past.flatMap((s) => s.periods.filter((p) => p.status === "ouverte" || (p.status === "prevue" && s.slot.status !== "annulee")));
  const periodHref = (periodId: string) => `/app/${ctx.org.id}/emargement/${periodId}`;
  // Missions proposées en attente de réponse (section minimale ; détail dans /formateur/missions).
  const pendingMissions = (await listMissions(ctx.org.id, { trainerId: ctx.trainer.id, limit: 50 })).filter((r) => (r.m.status === "proposee" || r.m.status === "sans_reponse") && !r.m.replacedByMissionId);

  return (
    <>
      <PageHeader title={`Bonjour ${ctx.trainer.firstName}`} description={`Vos séances chez ${ctx.org.tradeName ?? ctx.org.legalName}. Les présences se saisissent après le début réel de la période ; la clôture après sa fin (heure de Paris).`} />
      {openPeriods.length ? (
        <Notice tone="warn" className="mb-6" title={`${openPeriods.length} période${openPeriods.length > 1 ? "s" : ""} passée${openPeriods.length > 1 ? "s" : ""} non clôturée${openPeriods.length > 1 ? "s" : ""}`}>
          Vérifiez les présences et clôturez ces périodes depuis l&apos;émargement.{" "}
          <Link href="/formateur/emargement" className="font-medium underline underline-offset-4">
            Ouvrir l&apos;émargement
          </Link>
        </Notice>
      ) : null}
      <Panel className="mb-6">
        <div className="grid grid-cols-2 gap-6 px-5 py-5 sm:grid-cols-4">
          <Stat label="Sessions affectées" value={<span className="num">{ctx.sessions.length}</span>} />
          <Stat label="Aujourd'hui" value={<span className="num">{todays.length}</span>} hint="séances" />
          <Stat label="À venir" value={<span className="num">{upcoming.length}</span>} hint="séances" />
          <Stat label="À clôturer" value={<span className="num">{openPeriods.length}</span>} hint="périodes" />
        </div>
      </Panel>
      <div className="space-y-6">
        {pendingMissions.length ? (
          <Panel>
            <PanelHeader
              title="Missions proposées"
              description="Acceptez ou refusez les missions que l'organisme vous propose."
              actions={
                <Button asChild variant="secondary" size="sm">
                  <Link href="/formateur/missions">Toutes mes missions</Link>
                </Button>
              }
            />
            <TrainerMissionList rows={pendingMissions} />
          </Panel>
        ) : null}
        <Panel>
          <PanelHeader title={`Aujourd'hui, ${fmtDate(today, "EEEE d MMMM")}`} />
          <SlotTable slots={todays} periodHref={periodHref} emptyTitle="Aucune séance aujourd'hui" emptyDescription="" />
        </Panel>
        <Panel>
          <PanelHeader title="À venir" />
          <SlotTable slots={upcoming.slice(0, 30)} emptyTitle="Aucune séance à venir" emptyDescription="Les séances affectées par l'organisme apparaîtront ici." />
        </Panel>
        <Panel>
          <PanelHeader title="Passées (30 dernières)" />
          <SlotTable slots={past.slice(0, 30)} periodHref={periodHref} emptyTitle="Aucune séance passée" emptyDescription="" />
        </Panel>
        <Panel>
          <PanelHeader title="Mes sessions" />
          {ctx.sessions.length ? (
            <ul className="divide-y divide-line">
              {ctx.sessions.map((s) => (
                <li key={s.id} className="flex flex-wrap items-center justify-between gap-3 px-5 py-3">
                  <div>
                    <p className="font-medium text-ink">{s.title}</p>
                    <p className="num text-[12px] text-ink-3">
                      {s.code} · {fmtDate(s.startDate)} au {fmtDate(s.endDate)}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <StatusBadge status={s.status} />
                    <Button asChild variant="secondary" size="sm">
                      <Link href={`/formateur/apprenants?session=${s.id}`}>Apprenants</Link>
                    </Button>
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <EmptyState title="Aucune session affectée" description="L'organisme vous affecte à une session ou à une séance ; votre espace se remplit alors automatiquement." />
          )}
        </Panel>
      </div>
    </>
  );
}
