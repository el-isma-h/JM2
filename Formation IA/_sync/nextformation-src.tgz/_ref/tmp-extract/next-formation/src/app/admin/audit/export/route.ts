import { NextResponse, type NextRequest } from "next/server";
import { desc, eq } from "drizzle-orm";
import Papa from "papaparse";
import { db, schema } from "@/db";
import { AuthError } from "@/server/auth";
import { requirePlatformAdmin } from "@/server/authz";
import { audit } from "@/server/audit";
import { auditWhere, readAuditFilters } from "@/server/admin/audit-query";

export const dynamic = "force-dynamic";

const MAX_ROWS = 50_000;

export async function GET(req: NextRequest) {
  let admin;
  try {
    admin = await requirePlatformAdmin();
  } catch (e) {
    const status = e instanceof AuthError && e.code === "unauthenticated" ? 401 : 403;
    return NextResponse.json({ error: "Accès réservé aux administrateurs plateforme." }, { status });
  }
  const f = readAuditFilters(Object.fromEntries(req.nextUrl.searchParams));
  const rows = await db
    .select({ a: schema.auditLogs, email: schema.users.email, company: schema.organismes.legalName })
    .from(schema.auditLogs)
    .leftJoin(schema.users, eq(schema.users.id, schema.auditLogs.userId))
    .leftJoin(schema.organismes, eq(schema.organismes.id, schema.auditLogs.orgId))
    .where(auditWhere(f))
    .orderBy(desc(schema.auditLogs.createdAt))
    .limit(MAX_ROWS);

  const csv = Papa.unparse(
    rows.map(({ a, email, company }) => ({
      date: a.createdAt.toISOString(),
      action: a.action,
      utilisateur_id: a.userId ?? "",
      utilisateur_email: email ?? "",
      tenant_id: a.tenantId ?? "",
      organisme_id: a.orgId ?? "",
      entreprise: company ?? "",
      objet_type: a.entityType ?? "",
      objet_id: a.entityId ?? "",
      avant: a.before === null ? "" : JSON.stringify(a.before),
      apres: a.after === null ? "" : JSON.stringify(a.after),
      ip: a.ip ?? "",
      navigateur: a.userAgent ?? "",
    })),
    { delimiter: ";", escapeFormulae: true },
  );
  await audit({ action: "admin.audit.export", userId: admin.id, entityType: "audit_logs", after: { filters: f, rows: rows.length } });
  const name = `journal-audit-${new Date().toISOString().slice(0, 10)}.csv`;
  // BOM UTF-8 : ouverture correcte des accents dans un tableur.
  return new NextResponse(`﻿${csv}`, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="${name}"`,
      "Cache-Control": "no-store",
    },
  });
}
