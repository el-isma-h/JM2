import type { Metadata } from "next";
import Link from "next/link";
import { publisher } from "@/lib/legal";
import { Fill, LegalDoc } from "../legal-doc";

export const metadata: Metadata = { title: "Conditions générales", description: "Conditions générales d'utilisation de Next Formation, logiciel de gestion d'organismes de formation et de CFA.", alternates: { canonical: "/cgu" } };
export const dynamic = "force-dynamic";

export default function CguPage() {
  const p = publisher();
  return (
    <LegalDoc title="Conditions générales" updated="23 octobre 2026">
      <p>
        Les présentes conditions régissent l&apos;utilisation de la plateforme Next Formation, éditée par <Fill value={p.name} label="raison sociale" /> (voir{" "}
        <Link href="/mentions-legales">mentions légales</Link>). Elles sont acceptées lors de la création du compte et s&apos;appliquent à chaque utilisateur.
      </p>

      <h2>1. Objet et public</h2>
      <p>
        Next Formation est un service en ligne de gestion d&apos;organismes de formation et de CFA (CRM, catalogue, sessions, inscriptions, émargement, documents,
        financements, facturation, qualité, extranets), destiné aux professionnels : organismes de formation, CFA, formateurs indépendants et groupes qui en gèrent
        plusieurs. Il n&apos;est pas destiné aux consommateurs. Les apprenants, tuteurs et formateurs externes y accèdent par les extranets ouverts par l&apos;organisme.
      </p>

      <h2>2. Compte et accès</h2>
      <ul>
        <li>Le compte est personnel. L&apos;utilisateur garde ses identifiants confidentiels et active la double authentification dès qu&apos;il accède à des données sensibles.</li>
        <li>
          Le propriétaire actif de l&apos;organisme désigne les personnes habilitées et leurs rôles ; il répond des actions effectuées par ses utilisateurs. Les rôles
          sont additifs ; leur cumul ne confère jamais le statut de propriétaire.
        </li>
        <li>L&apos;éditeur peut suspendre un accès en cas d&apos;usage frauduleux, de risque pour la sécurité ou de manquement grave aux présentes conditions.</li>
      </ul>

      <h2>3. Ce que fait le service, et ce qu&apos;il ne fait pas</h2>
      <ul>
        <li>
          Les heures prévues, programmées, effectuées, justifiées et validées sont calculées selon les règles affichées dans l&apos;application et restent distinctes.
          Une période d&apos;émargement clôturée ne peut plus être modifiée directement ; toute correction suit un circuit tracé qui conserve l&apos;original.
        </li>
        <li>
          Les documents générés depuis les modèles (conventions, convocations, attestations, factures) sont des aides à la production : le client vérifie leur
          contenu avant transmission et reste responsable de ses obligations envers les apprenants, les financeurs et l&apos;administration. Un document généré
          n&apos;est jamais réputé signé.
        </li>
        <li>
          Le suivi qualité organise les preuves et produit des analyses datées ; il ne constitue ni une attestation de conformité ni une certification. L&apos;audit
          reste conduit par l&apos;organisme certificateur du client.
        </li>
        <li>Aucune transmission à un financeur, à une plateforme publique ou à un tiers n&apos;a lieu sans action explicite du client dans l&apos;application.</li>
        <li>L&apos;assistant d&apos;intelligence artificielle formule des propositions ; aucune n&apos;a d&apos;effet sans validation d&apos;une personne habilitée.</li>
      </ul>

      <h2>4. Données</h2>
      <p>
        Le client reste propriétaire de ses données. Pour les données de ses apprenants, candidats, contacts, formateurs et tuteurs, il est responsable de traitement et
        l&apos;éditeur agit en sous-traitant au sens de l&apos;article 28 du RGPD, dans les conditions décrites dans la{" "}
        <Link href="/confidentialite">politique de confidentialité</Link>. Ces données ne sont jamais utilisées pour entraîner des modèles d&apos;intelligence
        artificielle. Le client peut exporter ses données à tout moment et en demander la suppression à la fin du
        contrat, sous réserve des durées de conservation légales.
      </p>

      <h2>5. Tarifs</h2>
      <p>
        Les tarifs en vigueur sont affichés sur la <Link href="/tarifs">page tarifs</Link>, hors taxes, avec le prix public de référence, sa source et sa date de relevé.
        L&apos;essai gratuit dure 15 jours et n&apos;exige aucun moyen de paiement. Toute évolution est notifiée au client au moins 30 jours avant son application ; il
        peut alors résilier sans frais.
      </p>

      <h2>6. Disponibilité et sécurité</h2>
      <p>
        L&apos;éditeur met en œuvre les moyens raisonnables pour assurer la disponibilité, la sauvegarde et la sécurité du service (chiffrement des données sensibles,
        journal d&apos;audit, isolation stricte par organisme, sauvegardes quotidiennes). Des interruptions peuvent survenir pour maintenance ; elles sont annoncées à l&apos;avance lorsque c&apos;est
        possible.
      </p>

      <h2>7. Responsabilité</h2>
      <p>
        L&apos;éditeur est tenu d&apos;une obligation de moyens. Sa responsabilité ne peut être engagée pour un dommage résultant d&apos;une information erronée fournie par le
        client, d&apos;un document transmis sans vérification, d&apos;une présence saisie de façon inexacte, ou d&apos;une situation signalée hors périmètre par l&apos;application.
      </p>

      <h2>8. Durée et résiliation</h2>
      <p>
        Le compte est ouvert avec engagement annuel ou sans engagement, selon l&apos;offre choisie. Le client peut fermer son compte à la fin de la période en cours ;
        ses données restent exportables pendant 30 jours, puis sont supprimées, à l&apos;exception de celles dont la loi impose la conservation.
      </p>

      <h2>9. Démonstration</h2>
      <p>
        L&apos;espace de démonstration (organisme fictif « Atelier Méridien Formation ») contient uniquement des données fictives, n&apos;effectue aucun envoi réel et est
        supprimé automatiquement au bout de 24 heures.
      </p>

      <h2>10. Droit applicable</h2>
      <p>
        Les présentes conditions sont soumises au droit français. À défaut d&apos;accord amiable, tout litige relève des tribunaux compétents du ressort du siège de
        l&apos;éditeur.
      </p>
    </LegalDoc>
  );
}
