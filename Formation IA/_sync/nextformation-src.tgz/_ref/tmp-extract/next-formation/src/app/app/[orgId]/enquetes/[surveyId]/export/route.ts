import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import Papa from "papaparse";
import { db, schema } from "@/db";
import { AuthError } from "@/server/auth";
import { requireOrg } from "@/server/authz";
import { audit } from "@/server/audit";
import { parseQuestions, type SurveyAnswers } from "@/server/quality/indicator-math";
import { surveyResponses } from "@/server/quality/queries";

export const dynamic = "force-dynamic";

/** Export CSV des réponses d'une enquête (lecture qualité ; chaque export est journalisé). */
export async function GET(_req: Request, { params }: { params: Promise<{ orgId: string; surveyId: string }> }) {
  const { orgId, surveyId } = await params;
  let ctx;
  try {
    ctx = await requireOrg(orgId, "quality.view");
  } catch (e) {
    const status = e instanceof AuthError && e.code === "unauthenticated" ? 401 : 403;
    return NextResponse.json({ error: "Accès refusé." }, { status });
  }
  if (!/^[0-9a-f-]{36}$/i.test(surveyId)) return NextResponse.json({ error: "Enquête introuvable." }, { status: 404 });
  const [survey] = await db.select().from(schema.surveys).where(and(eq(schema.surveys.id, surveyId), eq(schema.surveys.orgId, ctx.org.id))).limit(1);
  if (!survey) return NextResponse.json({ error: "Enquête introuvable." }, { status: 404 });
  const questions = parseQuestions(survey.questions);
  const rows = (await surveyResponses(ctx.org.id, survey.id)).filter((r) => r.r.submittedAt);
  const csv = Papa.unparse(
    rows.map(({ r, firstName, lastName, reference }) => {
      const answers = r.answers as SurveyAnswers;
      const base: Record<string, string | number> = {
        enquete: survey.title,
        inscription: reference ?? "",
        repondant: lastName ? `${lastName.toUpperCase()} ${firstName}` : "",
        envoye_le: r.sentAt?.toISOString() ?? "",
        repondu_le: r.submittedAt?.toISOString() ?? "",
        score_global: r.score ?? "",
      };
      for (const q of questions) base[`${q.key}_${q.label.slice(0, 40)}`] = answers[q.key] ?? "";
      return base;
    }),
  );
  await audit({ action: "survey.export", userId: ctx.user.id, orgId: ctx.org.id, entityType: "survey", entityId: survey.id, after: { rows: rows.length } });
  return new NextResponse(`﻿${csv}`, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename*=UTF-8''${encodeURIComponent(`enquete-${survey.id.slice(0, 8)}.csv`)}`,
      "Cache-Control": "private, no-store",
    },
  });
}
