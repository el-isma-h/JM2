import Link from "next/link";
import { and, asc, eq, ilike, or, sql, type SQL } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { createFunderAction } from "@/server/actions/finance";
import { FUNDER_KINDS, funderKindLabels } from "@/server/finance/compute";
import { formatCents } from "@/lib/money";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/field";
import { EmptyState, PageHeader, Panel } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FormDialog } from "@/components/admin/form-dialog";
import { Pagination, readPage, readParam } from "@/components/admin/pagination";
import { FunderFields } from "@/components/finance/funder-fields";
import { RibLink } from "@/components/finance/rib-link";

export const dynamic = "force-dynamic";
const PAGE = 50;

export default async function FundersPage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const ctx = await guardOrg(orgId, `/app/${orgId}/financeurs`, "finance.view");
  const canManage = ctx.permissions.has("finance.manage");
  const sp = await searchParams;
  const q = readParam(sp.q);
  const kind = readParam(sp.kind);
  const page = readPage(sp.page);

  const conds: SQL[] = [eq(schema.funders.orgId, orgId)];
  if (kind && (FUNDER_KINDS as readonly string[]).includes(kind)) conds.push(eq(schema.funders.kind, kind as (typeof FUNDER_KINDS)[number]));
  if (q) conds.push(or(ilike(schema.funders.name, `%${q}%`), ilike(schema.funders.city, `%${q}%`), ilike(schema.funders.contactName, `%${q}%`))!);
  const where = and(...conds);

  const [rows, [{ total }], companies] = await Promise.all([
    db
      .select({
        f: schema.funders,
        companyName: schema.companies.name,
        fundings: sql<number>`(select count(*)::int from ${schema.fundings} x where x.funder_id = ${schema.funders.id})`,
        granted: sql<number>`(select coalesce(sum(x.amount_cents), 0)::int from ${schema.fundings} x where x.funder_id = ${schema.funders.id} and x.status in ('accorde','facture','solde'))`,
      })
      .from(schema.funders)
      .leftJoin(schema.companies, eq(schema.companies.id, schema.funders.companyId))
      .where(where)
      .orderBy(asc(schema.funders.name))
      .limit(PAGE)
      .offset((page - 1) * PAGE),
    db.select({ total: sql<number>`count(*)::int` }).from(schema.funders).where(where),
    db.select({ id: schema.companies.id, name: schema.companies.name }).from(schema.companies).where(eq(schema.companies.orgId, orgId)).orderBy(asc(schema.companies.name)).limit(500),
  ]);

  return (
    <>
      <PageHeader
        title="Financeurs"
        description="OPCO, entreprises, France Travail, Régions, CPF, particuliers : chaque financement d'inscription se rattache à un financeur identifié, avec ses coordonnées de facturation."
        actions={
          <>
            <RibLink orgId={orgId} manage={canManage || ctx.isOwner} />
            {canManage ? (
              <FormDialog action={createFunderAction} trigger="Nouveau financeur" title="Nouveau financeur" submitLabel="Créer le financeur" wide>
                <input type="hidden" name="orgId" value={orgId} />
                <FunderFields companies={companies} />
              </FormDialog>
            ) : null}
          </>
        }
      />
      <Panel>
        <form method="get" className="flex flex-wrap items-end gap-3 border-b border-line px-5 py-3">
          <Field label="Recherche" htmlFor="q" className="w-full max-w-xs">
            <Input id="q" name="q" defaultValue={q} placeholder="Nom, ville, contact" />
          </Field>
          <Field label="Type" htmlFor="kind" className="w-52">
            <Select id="kind" name="kind" defaultValue={kind ?? ""}>
              <option value="">Tous</option>
              {FUNDER_KINDS.map((k) => (
                <option key={k} value={k}>
                  {funderKindLabels[k]}
                </option>
              ))}
            </Select>
          </Field>
          <Button type="submit" variant="secondary">
            Filtrer
          </Button>
        </form>
        {rows.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Financeur</Th>
                <Th>Type</Th>
                <Th>Entreprise</Th>
                <Th>Contact</Th>
                <Th num>Financements</Th>
                <Th num>Accordé</Th>
              </tr>
            </thead>
            <tbody>
              {rows.map(({ f, companyName, fundings, granted }) => (
                <tr key={f.id}>
                  <Td>
                    <Link href={`/app/${orgId}/financeurs/${f.id}`} className="font-medium text-ink hover:underline">
                      {f.name}
                    </Link>
                    <p className="text-[12px] text-ink-3">{[f.postalCode, f.city].filter(Boolean).join(" ")}</p>
                  </Td>
                  <Td>
                    <Badge tone="neutral">{funderKindLabels[f.kind]}</Badge>
                  </Td>
                  <Td>{companyName ?? "-"}</Td>
                  <Td>
                    {f.contactName ?? "-"}
                    {f.email ? <p className="text-[12px] text-ink-3">{f.email}</p> : null}
                  </Td>
                  <Td num>{fundings}</Td>
                  <Td num>{formatCents(granted)}</Td>
                </tr>
              ))}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucun financeur" description={q || kind ? "Aucun résultat pour ces filtres." : "Créez vos financeurs habituels (OPCO, Région, France Travail…) pour les rattacher aux financements."} />
        )}
        <Pagination basePath={`/app/${orgId}/financeurs`} params={{ q, kind }} page={page} pageSize={PAGE} total={total} />
      </Panel>
    </>
  );
}
