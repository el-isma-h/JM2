import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { asc, eq } from "drizzle-orm";
import { ArrowRight, ArrowUpRight } from "@phosphor-icons/react/dist/ssr";
import { db, schema } from "@/db";
import { PageHero, btnContour, btnEncre, btnOsContour, btnPastel } from "@/components/marketing/site";
import { PlanCard } from "@/components/marketing/pricing";
import { Ecran } from "@/components/marketing/ecran";
import { FEATURES, SOLUTIONS } from "@/lib/marketing-data";
import { breadcrumbJsonLd, jsonLdScript, pageMeta } from "@/lib/seo";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const s = SOLUTIONS.find((x) => x.slug === slug);
  if (!s) return {};
  return pageMeta(`/solutions/${s.slug}`, `${s.title} : logiciel de gestion`, s.intro);
}

export default async function SolutionPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const s = SOLUTIONS.find((x) => x.slug === slug);
  if (!s) notFound();
  const feats = s.features.map((k) => FEATURES.find((f) => f.slug === k)!).filter(Boolean);
  const [plan] = await db.select().from(schema.pricingPlans).where(eq(schema.pricingPlans.code, s.plan)).orderBy(asc(schema.pricingPlans.sortOrder)).limit(1);
  const others = SOLUTIONS.filter((x) => x.slug !== s.slug);
  return (
    <article>
      <script type="application/ld+json" dangerouslySetInnerHTML={jsonLdScript(breadcrumbJsonLd([{ name: "Accueil", path: "/" }, { name: "Solutions", path: "/solutions" }, { name: s.short, path: `/solutions/${s.slug}` }]))} />
      <PageHero crumbs={[{ label: "Accueil", href: "/" }, { label: "Solutions", href: "/solutions" }, { label: s.short }]} eyebrow={s.short} title={s.title} description={s.intro}>
        <Link href="/inscription" className={btnPastel}>
          Essai gratuit 15 jours <ArrowRight size={14} />
        </Link>
        <Link href="/demo" className={btnContour}>
          Explorer la démonstration
        </Link>
      </PageHero>

      <section className="conteneur py-16 lg:py-24">
        <div className="grid gap-px border border-line-strong bg-line-strong lg:grid-cols-3">
          {s.points.map((p, i) => (
            <div key={p.t} className={i === 1 ? "sombre bg-[#0a0b0d] p-8 text-[#f3f0e8]" : "bg-bg p-8"}>
              <h2 className="text-[22px] sm:text-[26px]">{p.t}</h2>
              <p className={`mt-4 text-[14px] leading-relaxed ${i === 1 ? "text-[#f3f0e8]/65" : "text-ink-2"}`}>{p.d}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="border-t border-line bg-bg-sunken">
        <div className="conteneur grid gap-12 py-16 lg:grid-cols-[0.9fr_1.1fr] lg:items-start lg:py-24">
          <div>
            <h2 className="text-[26px] sm:text-[32px]">Les fonctions qui comptent pour vous</h2>
            <ul className="mt-8 flex flex-col divide-y divide-line border-t border-line-strong">
              {feats.map((f) => (
                <li key={f.slug}>
                  <Link href={`/fonctionnalites/${f.slug}`} className="group flex items-start justify-between gap-6 py-4">
                    <span>
                      <span className="font-display text-[16px] font-medium">{f.short}</span>
                      <span className="mt-1 block text-[13px] text-ink-2">{f.promise}</span>
                    </span>
                    <ArrowUpRight size={14} className="mt-1 shrink-0 text-ink-3 transition-colors group-hover:text-ink" aria-hidden="true" />
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <Ecran kind={feats[0]?.ecran ?? "sessions"} />
            <p className="mt-3 font-mono text-[9.5px] uppercase tracking-[0.18em] text-ink-3">Aperçu illustratif, données fictives</p>
          </div>
        </div>
      </section>

      {plan ? (
        <section className="conteneur grid gap-10 py-16 lg:grid-cols-[1fr_minmax(0,420px)] lg:items-start lg:py-24">
          <div>
            <h2 className="text-[26px] sm:text-[32px]">Le plan conseillé</h2>
            <p className="mt-4 max-w-[52ch] text-[14.5px] leading-relaxed text-ink-2">Point de départ habituel pour ce profil ; les limites d&apos;apprenants, d&apos;utilisateurs et de formateurs sont indiquées sur chaque plan. Toutes les offres incluent le socle complet.</p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Link href="/tarifs" className={btnEncre}>
                Tous les tarifs <ArrowRight size={14} />
              </Link>
              <Link href="/comparatif/digiforma" className={btnOsContour}>
                Comparer avec Digiforma
              </Link>
            </div>
          </div>
          <div className="border border-line-strong">
            <PlanCard p={plan} annual detailed />
          </div>
        </section>
      ) : null}

      <section className="border-t border-line">
        <div className="conteneur py-14">
          <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">Autres profils</p>
          <ul className="mt-5 flex flex-wrap gap-2">
            {others.map((o) => (
              <li key={o.slug}>
                <Link href={`/solutions/${o.slug}`} className="inline-flex min-h-[38px] items-center border border-line-strong px-4 font-mono text-[10.5px] uppercase tracking-[0.18em] text-ink-2 transition-colors hover:border-ink hover:text-ink">
                  {o.short}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </section>
    </article>
  );
}
