import Link from "next/link";
import { notFound } from "next/navigation";
import { and, asc, desc, eq, inArray, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { activateVersionAction, createVersionAction, deleteModuleAction, generateProgramPdfAction, moveModuleAction, saveModuleAction, setProgramPublishedAction, updateProgramAction, updateVersionAction } from "@/server/actions/catalog";
import { fmtDate } from "@/lib/dates";
import { formatCents } from "@/lib/money";
import { cn } from "@/lib/utils";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { EmptyState, KeyValue, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { ProgrammeFields } from "@/components/ai/programme-fields";
import { Table, Td, Th } from "@/components/ui/table";
import { ActionButton, ActionForm } from "@/components/admin/action-form";
import { FormDialog } from "@/components/admin/form-dialog";
import { readParam } from "@/components/admin/pagination";
import { ModuleFields, ProgramFields, VersionFields, modalityLabels, programKindLabels } from "@/components/catalog/fields";
import { DocumentList } from "@/components/crm/documents";
import { FadeIn } from "@/components/ui/motion";

export const dynamic = "force-dynamic";

export default async function ProgramPage({ params, searchParams }: { params: Promise<{ orgId: string; programId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId, programId } = await params;
  const base = `/app/${orgId}`;
  const ctx = await guardOrg(orgId, `${base}/catalogue/${programId}`, "catalog.view");
  if (!/^[0-9a-f-]{36}$/i.test(programId)) notFound();
  const [program] = await db.select().from(schema.programs).where(and(eq(schema.programs.id, programId), eq(schema.programs.orgId, ctx.org.id))).limit(1);
  if (!program) notFound();
  const sp = await searchParams;
  const canManage = ctx.permissions.has("catalog.manage");

  const versions = await db.select().from(schema.programVersions).where(eq(schema.programVersions.programId, program.id)).orderBy(desc(schema.programVersions.version));
  const requested = readParam(sp.version);
  const selected = versions.find((v) => String(v.version) === requested) ?? versions.find((v) => v.status === "brouillon") ?? versions.find((v) => v.status === "active") ?? versions[0] ?? null;
  const versionIds = versions.map((v) => v.id);

  const [modules, certification, certifications, docs, sessions, enrollmentsByVersion] = await Promise.all([
    selected ? db.select().from(schema.modules).where(eq(schema.modules.programVersionId, selected.id)).orderBy(asc(schema.modules.position), asc(schema.modules.createdAt)) : [],
    program.certificationId ? db.select().from(schema.certifications).where(and(eq(schema.certifications.id, program.certificationId), eq(schema.certifications.orgId, ctx.org.id))).limit(1).then((r) => r[0] ?? null) : null,
    db.select({ id: schema.certifications.id, name: schema.certifications.title }).from(schema.certifications).where(eq(schema.certifications.orgId, ctx.org.id)).orderBy(schema.certifications.title),
    versionIds.length ? db.select().from(schema.documents).where(and(eq(schema.documents.orgId, ctx.org.id), eq(schema.documents.sourceType, "program_version"), inArray(schema.documents.sourceId, versionIds))).orderBy(desc(schema.documents.createdAt)) : [],
    versionIds.length
      ? db
          .select({ id: schema.trainingSessions.id, title: schema.trainingSessions.title, code: schema.trainingSessions.code, startDate: schema.trainingSessions.startDate, endDate: schema.trainingSessions.endDate, status: schema.trainingSessions.status, programVersionId: schema.trainingSessions.programVersionId, isPublished: schema.trainingSessions.isPublished })
          .from(schema.trainingSessions)
          .where(and(eq(schema.trainingSessions.orgId, ctx.org.id), inArray(schema.trainingSessions.programVersionId, versionIds)))
          .orderBy(desc(schema.trainingSessions.startDate))
          .limit(30)
      : [],
    versionIds.length ? db.select({ versionId: schema.enrollments.programVersionId, n: sql<number>`count(*)::int` }).from(schema.enrollments).where(and(eq(schema.enrollments.orgId, ctx.org.id), inArray(schema.enrollments.programVersionId, versionIds))).groupBy(schema.enrollments.programVersionId) : [],
  ]);
  const enrolled = (vid: string) => enrollmentsByVersion.find((e) => e.versionId === vid)?.n ?? 0;
  const moduleHours = modules.reduce((a, m) => a + m.hours, 0);
  const hoursGap = selected ? moduleHours - selected.durationHours : 0;
  const active = versions.find((v) => v.status === "active") ?? null;
  const readOnlyVersion = !canManage || selected?.status === "archivee";

  return (
    <FadeIn>
      <PageHeader
        breadcrumb={[{ label: "Formation" }, { label: "Catalogue", href: `${base}/catalogue` }, { label: program.title }]}
        title={program.title}
        description={[programKindLabels[program.kind], `code ${program.code}`, certification ? `${certification.title}${certification.rncpCode ? ` (RNCP ${certification.rncpCode})` : ""}` : null, program.category].filter(Boolean).join(" · ")}
        actions={
          <>
            <StatusBadge status={program.status} />
            {program.isPublished ? <Badge tone="ok">Publiée</Badge> : <Badge>Non publiée</Badge>}
            {canManage ? (
              <>
                <ActionButton action={setProgramPublishedAction} fields={{ orgId: ctx.org.id, programId: program.id, publish: program.isPublished ? "0" : "1" }} label={program.isPublished ? "Retirer du catalogue public" : "Publier au catalogue public"} size="md" variant={program.isPublished ? "secondary" : "accent"} />
                <FormDialog action={updateProgramAction} trigger="Modifier" triggerVariant="secondary" title="Modifier la formation" submitLabel="Enregistrer" wide>
                  <ProgramFields orgId={ctx.org.id} program={program} certifications={certifications} prefix="epg" />
                </FormDialog>
              </>
            ) : null}
          </>
        }
      />
      <Notice tone={!active ? "warn" : program.isPublished ? "ok" : "info"} title="Prochaine action" className="mb-6">
        {!active
          ? "Aucune version active : complétez la version brouillon puis activez-la pour pouvoir ouvrir des sessions et publier."
          : versions.some((v) => v.status === "brouillon")
            ? "Une version brouillon est en cours : activez-la quand elle est prête (la version active actuelle sera archivée, les parcours contractualisés restent figés)."
            : program.isPublished
              ? `Formation publiée (${`/catalogue-public/${ctx.tenant.slug}`}). Générez le PDF du programme après chaque évolution.`
              : "Version active en place. Publiez la formation au catalogue public ou créez une session."}
      </Notice>

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_280px]">
        <div className="space-y-6">
          <Panel>
            <PanelHeader
              title={selected ? `Version ${selected.version}` : "Versions"}
              description={selected ? `${selected.status === "active" ? "Version active" : selected.status === "brouillon" ? "Brouillon : modifiable librement" : "Archivée : lecture seule"}${selected.effectiveFrom ? `, applicable depuis le ${fmtDate(selected.effectiveFrom)}` : ""}${enrolled(selected.id) ? ` · ${enrolled(selected.id)} inscription(s) contractualisée(s) sur cette version` : ""}` : undefined}
              actions={
                <>
                  {versions.map((v) => (
                    <Button key={v.id} asChild variant={v.id === selected?.id ? "primary" : "ghost"} size="sm">
                      <Link href={`${base}/catalogue/${program.id}?version=${v.version}`}>
                        v{v.version} · {v.status === "active" ? "active" : v.status === "brouillon" ? "brouillon" : "archivée"}
                      </Link>
                    </Button>
                  ))}
                  {canManage ? <ActionButton action={createVersionAction} fields={{ orgId: ctx.org.id, programId: program.id }} label="Nouvelle version" confirm={{ title: "Créer une nouvelle version", description: "Copie de la dernière version (champs et modules) en brouillon. Les inscriptions existantes ne sont pas modifiées.", confirmLabel: "Créer la version" }} /> : null}
                </>
              }
            />
            {selected ? (
              <div className="p-5">
                {selected.status === "brouillon" && canManage ? (
                  <div className="mb-5 flex flex-wrap items-center gap-3 border border-accent px-4 py-3 text-[13px]">
                    <span>Version brouillon : une fois complète, activez-la.</span>
                    <ActionButton action={activateVersionAction} fields={{ orgId: ctx.org.id, versionId: selected.id }} label={`Activer la version ${selected.version}`} variant="accent" confirm={{ title: `Activer la version ${selected.version}`, description: active ? `La version ${active.version} sera archivée. Les ${enrolled(active.id)} inscription(s) rattachée(s) conservent leur contenu.` : "Cette version devient la référence des nouvelles sessions.", confirmLabel: "Activer", input: { name: "effectiveFrom", label: "Applicable à partir du (AAAA-MM-JJ, vide = aujourd'hui)", placeholder: "2026-01-01" } }} />
                  </div>
                ) : null}
                {readOnlyVersion ? (
                  <div className="space-y-5 text-[13.5px]">
                    <KeyValue
                      items={[
                        { k: "Modalité", v: modalityLabels[selected.modality] },
                        { k: "Durée", v: <span className="num">{selected.durationHours} h{selected.durationDays ? ` (${selected.durationDays} j)` : ""}{selected.companyHours ? `, dont ${selected.companyHours} h en entreprise` : ""}{selected.remoteHours ? `, dont ${selected.remoteHours} h à distance` : ""}</span> },
                        { k: "Tarif HT", v: selected.priceCents != null ? <span className="num">{formatCents(selected.priceCents)}{selected.priceNote ? ` (${selected.priceNote})` : ""}</span> : selected.priceNote || "Sur devis" },
                        { k: "Délai d'accès", v: selected.accessDelay },
                      ]}
                    />
                    {(
                      [
                        ["Objectifs", selected.objectives],
                        ["Public visé", selected.audience],
                        ["Prérequis", selected.prerequisites],
                        ["Contenu", selected.content],
                        ["Méthodes", selected.methods],
                        ["Évaluation", selected.evaluationMethods],
                        ["Accessibilité", selected.accessibility],
                        ["Ressources", selected.resources],
                        ["Profil des intervenants", selected.trainerProfile],
                      ] as [string, string | null][]
                    ).map(([k, v]) => (
                      <div key={k}>
                        <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">{k}</p>
                        <p className={cn("mt-1 whitespace-pre-line", v ? "text-ink" : "text-warn-ink")}>{v || "À compléter"}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <ActionForm action={updateVersionAction} submitLabel="Enregistrer la version" className="space-y-5" footerClassName="justify-end border-t border-line pt-4">
                    <VersionFields orgId={ctx.org.id} version={selected} />
                  </ActionForm>
                )}
              </div>
            ) : (
              <EmptyState title="Aucune version" description="Créez une première version du programme." className="py-8" />
            )}
          </Panel>

          {selected ? (
            <Panel>
              <PanelHeader
                title="Modules et blocs"
                description={
                  <span className={cn(hoursGap !== 0 && modules.length ? "text-warn-ink" : "")}>
                    Somme des modules : <span className="num">{moduleHours} h</span> pour une durée de version de <span className="num">{selected.durationHours} h</span>
                    {modules.length && hoursGap !== 0 ? ` : écart de ${hoursGap > 0 ? "+" : ""}${hoursGap} h à vérifier.` : modules.length ? " : cohérent." : "."}
                  </span>
                }
                actions={
                  !readOnlyVersion ? (
                    <FormDialog action={saveModuleAction} trigger="Ajouter un module" triggerVariant="secondary" triggerSize="sm" title="Nouveau module" submitLabel="Ajouter" wide>
                      <ModuleFields orgId={ctx.org.id} versionId={selected.id} />
                    </FormDialog>
                  ) : null
                }
              />
              {modules.length ? (
                <Table>
                  <thead>
                    <tr>
                      <Th num>#</Th>
                      <Th>Module</Th>
                      <Th>Bloc</Th>
                      <Th>Modalité</Th>
                      <Th num>Heures</Th>
                      {!readOnlyVersion ? <Th /> : null}
                    </tr>
                  </thead>
                  <tbody>
                    {modules.map((m, i) => (
                      <tr key={m.id}>
                        <Td num>{i + 1}</Td>
                        <Td>
                          <span className="font-medium text-ink">
                            {m.code ? <span className="num mr-2 text-ink-3">{m.code}</span> : null}
                            {m.title}
                          </span>
                          {m.description ? <p className="text-[12px] text-ink-3">{m.description}</p> : null}
                          {Array.isArray(m.skills) && (m.skills as { label: string }[]).length ? (
                            <div className="mt-1 flex flex-wrap gap-1">
                              {(m.skills as { label: string }[]).map((s) => (
                                <Badge key={s.label}>{s.label}</Badge>
                              ))}
                            </div>
                          ) : null}
                        </Td>
                        <Td className="num">{m.blockCode ?? "-"}</Td>
                        <Td>{m.modality ? modalityLabels[m.modality] : <span className="text-ink-3">Version</span>}</Td>
                        <Td num>{m.hours} h</Td>
                        {!readOnlyVersion ? (
                          <Td>
                            <div className="flex flex-wrap items-center gap-1">
                              <ActionButton action={moveModuleAction} fields={{ orgId: ctx.org.id, moduleId: m.id, direction: "up" }} label="Monter" variant="ghost" />
                              <ActionButton action={moveModuleAction} fields={{ orgId: ctx.org.id, moduleId: m.id, direction: "down" }} label="Descendre" variant="ghost" />
                              <FormDialog action={saveModuleAction} trigger="Modifier" triggerVariant="ghost" triggerSize="sm" title={m.title} submitLabel="Enregistrer" wide>
                                <ModuleFields orgId={ctx.org.id} versionId={selected.id} mod={m} prefix={`m-${m.id.slice(0, 8)}`} />
                              </FormDialog>
                              <ActionButton action={deleteModuleAction} fields={{ orgId: ctx.org.id, moduleId: m.id }} label="Supprimer" variant="ghost" confirm={{ title: `Supprimer le module « ${m.title} »`, confirmLabel: "Supprimer", danger: true }} />
                            </div>
                          </Td>
                        ) : null}
                      </tr>
                    ))}
                  </tbody>
                </Table>
              ) : (
                <EmptyState title="Aucun module" description="Structurez le programme en modules ou blocs de compétences avec leurs heures." className="py-8" />
              )}
            </Panel>
          ) : null}

          <Panel>
            <PanelHeader title="Sessions" description="Sessions rattachées aux versions de cette formation." />
            {sessions.length ? (
              <Table>
                <thead>
                  <tr>
                    <Th>Session</Th>
                    <Th>Version</Th>
                    <Th>Dates</Th>
                    <Th>Statut</Th>
                  </tr>
                </thead>
                <tbody>
                  {sessions.map((s) => (
                    <tr key={s.id}>
                      <Td>
                        <Link href={`${base}/sessions/${s.id}`} className="font-medium text-ink hover:underline">
                          {s.title}
                        </Link>
                        <span className="num block text-[12px] text-ink-3">{s.code}</span>
                      </Td>
                      <Td>v{versions.find((v) => v.id === s.programVersionId)?.version ?? "?"}</Td>
                      <Td className="num whitespace-nowrap">
                        {fmtDate(s.startDate)} au {fmtDate(s.endDate)}
                      </Td>
                      <Td>
                        <StatusBadge status={s.status} /> {s.isPublished ? <Badge tone="ok">Publiée</Badge> : null}
                      </Td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            ) : (
              <EmptyState title="Aucune session" description="Les sessions se créent depuis le module Sessions sur la version active." className="py-8" />
            )}
          </Panel>
        </div>

        <div className="space-y-6">
          <Panel>
            <PanelHeader title="Programme PDF" />
            <div className="space-y-3 p-5 text-[13px] text-ink-2">
              <p>Document « programme de formation » avec l&apos;identité de l&apos;organisme, généré depuis la version sélectionnée. Chaque génération crée une nouvelle version du document.</p>
              {selected && canManage && ctx.permissions.has("documents.generate") ? <ActionButton action={generateProgramPdfAction} fields={{ orgId: ctx.org.id, versionId: selected.id }} label={`Générer le PDF (v${selected.version})`} variant="primary" size="md" /> : null}
            </div>
            <DocumentList orgId={ctx.org.id} docs={docs} emptyTitle="Aucun PDF" emptyDescription="Aucun programme généré pour l'instant." />
          </Panel>
          {canManage ? (
            <Panel>
              <PanelHeader title="Assistant : proposer un programme" description="L'agent rédige une proposition (objectifs, contenu, modalités) à valider par un humain avant toute création de version." />
              <div className="px-5 pb-5">
                <ProgrammeFields orgId={ctx.org.id} programId={program.id} />
              </div>
            </Panel>
          ) : null}
          <Panel>
            <PanelHeader title="Fiche" />
            <div className="p-5">
              <KeyValue
                items={[
                  { k: "Activités", v: [program.availableAsContinuing ? "Formation continue" : null, program.availableAsApprenticeship ? "Apprentissage" : null].filter(Boolean).join(", ") || "Aucune" },
                  { k: "CPF", v: program.cpfEligible ? "Éligible" : "Non" },
                  { k: "Spécialité", v: program.specialty },
                  { k: "Formacode", v: program.formacode ? <span className="num">{program.formacode}</span> : null },
                  { k: "Slug public", v: <span className="num">{program.slug}</span> },
                  { k: "Publiée le", v: program.publishedAt ? fmtDate(program.publishedAt) : null },
                  { k: "Certification", v: certification ? <Link href={`${base}/catalogue/certifications`} className="hover:underline">{certification.title}</Link> : null },
                ]}
              />
              {(program.tags as string[]).length ? (
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {(program.tags as string[]).map((t) => (
                    <Badge key={t}>{t}</Badge>
                  ))}
                </div>
              ) : null}
            </div>
          </Panel>
        </div>
      </div>
    </FadeIn>
  );
}
