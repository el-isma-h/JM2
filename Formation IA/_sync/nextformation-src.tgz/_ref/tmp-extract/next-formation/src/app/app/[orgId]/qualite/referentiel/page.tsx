import Link from "next/link";
import { guardOrg } from "@/server/guard";
import { copyPlatformReferentialAction, retireReferentialAction, updateReferentialAction, validateReferentialAction } from "@/server/actions/quality";
import { listReferentials, memberNames } from "@/server/quality/queries";
import { parseCriteria } from "@/server/quality/referential-data";
import { levelShort } from "@/server/quality/labels";
import { fmtDate, fmtDateTime } from "@/lib/dates";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Checkbox, Field, Input, Select } from "@/components/ui/field";
import { EmptyState, KeyValue, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { ActionButton, ActionForm } from "@/components/admin/action-form";
import { FadeIn } from "@/components/ui/motion";

export const dynamic = "force-dynamic";

export default async function ReferentielPage({ params }: { params: Promise<{ orgId: string }> }) {
  const { orgId } = await params;
  const path = `/app/${orgId}/qualite/referentiel`;
  const ctx = await guardOrg(orgId, path, "quality.view");
  const canManage = ctx.permissions.has("quality.manage");
  const [all, names] = await Promise.all([listReferentials(ctx.org.id), memberNames(ctx.org.id)]);
  const platform = all.filter((r) => r.orgId === null);
  const mine = all.filter((r) => r.orgId === ctx.org.id);
  const draft = mine.find((r) => r.status === "brouillon") ?? null;
  const active = mine.find((r) => r.status === "actif" || r.status === "valide") ?? null;
  const shown = active ?? draft ?? mine[0] ?? platform[0] ?? null;
  const criteria = shown ? parseCriteria(shown.criteria) : [];

  return (
    <FadeIn>
      <PageHeader
        breadcrumb={[{ label: "Qualité", href: `/app/${orgId}/qualite` }, { label: "Référentiel" }]}
        title="Référentiel qualité"
        description="Le référentiel proposé par la plateforme n'est qu'une proposition. Il devient applicable à votre organisme seulement après copie, vérification des textes, saisie de la version et des dates d'effet, puis validation par un responsable habilité."
      />

      <Notice tone="info" className="mb-6" title="Applicabilité réglementaire">
        Les libellés historiques « V9 » ou « RNQ 2026 » sont des références de projet. Vérifiez la version en vigueur du guide de lecture sur le site du ministère du Travail et saisissez-la vous-même : l&apos;application n&apos;affiche jamais une version qu&apos;elle aurait inventée.
      </Notice>

      <div className="mb-6 grid gap-6 lg:grid-cols-2">
        <Panel>
          <PanelHeader title="Référentiels de l'organisme" description="Un seul référentiel applicable à la fois ; les analyses passées gardent le leur." />
          {mine.length ? (
            <Table>
              <thead>
                <tr>
                  <Th>Référentiel</Th>
                  <Th>Version</Th>
                  <Th>Effet</Th>
                  <Th>Statut</Th>
                  <Th>Validation</Th>
                  {canManage ? <Th>Action</Th> : null}
                </tr>
              </thead>
              <tbody>
                {mine.map((r) => (
                  <tr key={r.id}>
                    <Td>
                      {r.title}
                      <p className="text-[12px] text-ink-3">{r.scope === "both" ? "OF et CFA" : r.scope.toUpperCase()}</p>
                    </Td>
                    <Td className="num">{r.version || <span className="text-warn-ink">à saisir</span>}</Td>
                    <Td className="num whitespace-nowrap">{r.effectiveFrom ? fmtDate(r.effectiveFrom) : "-"} au {r.effectiveTo ? fmtDate(r.effectiveTo) : "(sans fin)"}</Td>
                    <Td>
                      <StatusBadge status={r.status} />
                    </Td>
                    <Td className="text-[12.5px]">{r.validatedAt ? `${fmtDateTime(r.validatedAt)} par ${r.validatedBy ? (names.get(r.validatedBy) ?? "membre") : "-"}` : "-"}</Td>
                    {canManage ? (
                      <Td>
                        {r.status !== "retire" ? (
                          <ActionButton
                            action={retireReferentialAction}
                            fields={{ orgId: ctx.org.id, referentialId: r.id }}
                            label="Retirer"
                            variant="danger"
                            confirm={{ title: "Retirer ce référentiel", description: "Il ne sera plus applicable ; les analyses déjà enregistrées restent inchangées.", confirmLabel: "Retirer", danger: true, input: { name: "reason", label: "Motif" } }}
                          />
                        ) : null}
                      </Td>
                    ) : null}
                  </tr>
                ))}
              </tbody>
            </Table>
          ) : (
            <EmptyState title="Aucun référentiel copié" description="Copiez le référentiel proposé par la plateforme pour commencer." />
          )}
        </Panel>

        <Panel>
          <PanelHeader title="Référentiel proposé par la plateforme" description="Statut brouillon : jamais applicable directement." />
          {platform.length ? (
            <div className="px-5 py-4">
              <KeyValue
                items={[
                  { k: "Titre", v: platform[0].title },
                  { k: "Source", v: platform[0].sourceUrl ? <a href={platform[0].sourceUrl} target="_blank" rel="noreferrer" className="underline underline-offset-4">{platform[0].source ?? platform[0].sourceUrl}</a> : (platform[0].source ?? "-") },
                  { k: "Contenu", v: `${parseCriteria(platform[0].criteria).length} critères, ${parseCriteria(platform[0].criteria).reduce((n, c) => n + c.indicators.length, 0)} indicateurs` },
                  { k: "Statut", v: <StatusBadge status={platform[0].status} /> },
                ]}
              />
              {canManage ? (
                <div className="mt-4">
                  {draft ? (
                    <Notice tone="warn">Un brouillon existe déjà : complétez-le ci-dessous ou retirez-le.</Notice>
                  ) : (
                    <ActionButton action={copyPlatformReferentialAction} fields={{ orgId: ctx.org.id }} label="Copier dans mon organisme" variant="primary" size="md" />
                  )}
                </div>
              ) : null}
            </div>
          ) : (
            <EmptyState title="Référentiel plateforme absent" description="L'administrateur plateforme doit exécuter l'initialisation (npm run seed) pour proposer le référentiel." />
          )}
        </Panel>
      </div>

      {draft && canManage ? (
        <Panel className="mb-6">
          <PanelHeader title="Compléter et valider le brouillon" description="Renseignez la version du guide de lecture appliquée, la date de début d'effet (obligatoires) et le périmètre d'activité, puis validez." />
          <div className="grid gap-8 px-5 py-5 lg:grid-cols-2">
            <ActionForm action={updateReferentialAction} submitLabel="Enregistrer le brouillon" submitVariant="secondary" footerClassName="mt-4">
              <input type="hidden" name="orgId" value={ctx.org.id} />
              <input type="hidden" name="referentialId" value={draft.id} />
              <div className="space-y-4">
                <Field label="Version du guide de lecture" required htmlFor="rf-version" help="Telle qu'indiquée par le ministère (ex. « Guide de lecture V9, janvier 2024 »). Saisie par vous, jamais déduite.">
                  <Input id="rf-version" name="version" defaultValue={draft.version} required maxLength={80} />
                </Field>
                <Field label="Source" htmlFor="rf-source">
                  <Input id="rf-source" name="source" defaultValue={draft.source ?? ""} maxLength={300} />
                </Field>
                <div className="grid grid-cols-2 gap-4">
                  <Field label="Début d'effet" required htmlFor="rf-from">
                    <Input id="rf-from" name="effectiveFrom" type="date" defaultValue={draft.effectiveFrom ?? ""} />
                  </Field>
                  <Field label="Fin d'effet" htmlFor="rf-to" help="Facultatif.">
                    <Input id="rf-to" name="effectiveTo" type="date" defaultValue={draft.effectiveTo ?? ""} />
                  </Field>
                </div>
                <Field label="Périmètre d'activité" htmlFor="rf-scope">
                  <Select id="rf-scope" name="scope" defaultValue={draft.scope}>
                    <option value="both">OF et CFA</option>
                    <option value="of">Organisme de formation</option>
                    <option value="cfa">CFA</option>
                  </Select>
                </Field>
              </div>
            </ActionForm>
            <ActionForm
              action={validateReferentialAction}
              submitLabel="Valider et rendre applicable"
              confirm={{ title: "Valider le référentiel", description: "Vous attestez avoir vérifié les textes, la version et les dates d'effet. Le référentiel précédent, s'il existe, sera retiré.", confirmLabel: "Je valide" }}
              footerClassName="mt-4"
            >
              <input type="hidden" name="orgId" value={ctx.org.id} />
              <input type="hidden" name="referentialId" value={draft.id} />
              <div className="space-y-4">
                <KeyValue
                  items={[
                    { k: "Version", v: draft.version || <span className="text-warn-ink">à saisir puis enregistrer</span> },
                    { k: "Début d'effet", v: draft.effectiveFrom ? <span className="num">{fmtDate(draft.effectiveFrom)}</span> : <span className="text-warn-ink">à saisir puis enregistrer</span> },
                    { k: "Périmètre", v: draft.scope === "both" ? "OF et CFA" : draft.scope.toUpperCase() },
                    { k: "Validé par", v: `${ctx.user.firstName} ${ctx.user.lastName} (vous), à la validation` },
                  ]}
                />
                <Checkbox name="attest" label="J'ai vérifié les libellés ci-dessous, la version et les dates d'effet auprès de la source officielle." />
              </div>
            </ActionForm>
          </div>
        </Panel>
      ) : null}

      {shown ? (
        <Panel>
          <PanelHeader
            title={`Contenu : ${shown.title}`}
            description={
              <>
                {shown.orgId ? "Copie de l'organisme" : "Référentiel plateforme (proposition)"} : {criteria.length} critères, {criteria.reduce((n, c) => n + c.indicators.length, 0)} indicateurs. Les indicateurs « appréciation humaine » ne sont jamais prouvés automatiquement.
              </>
            }
          />
          <div className="divide-y divide-line">
            {criteria.map((c) => (
              <section key={c.code}>
                <div className="px-5 py-3">
                  <p className="etiquette text-ink-3">Critère {c.number}</p>
                  <h3 className="mt-1 text-[14px] text-ink">{c.label}</h3>
                </div>
                <Table>
                  <thead>
                    <tr>
                      <Th className="w-16">N°</Th>
                      <Th>Indicateur</Th>
                      <Th>Niveau</Th>
                      <Th>Activité</Th>
                      <Th>Preuves attendues dans le logiciel</Th>
                    </tr>
                  </thead>
                  <tbody>
                    {c.indicators.map((i) => (
                      <tr key={i.code}>
                        <Td className="num align-top">{i.number}</Td>
                        <Td className="max-w-[46ch] align-top text-[13px]">
                          {i.label}
                          {i.condition ? <p className="mt-1 text-[12px] text-ink-3">{i.condition}</p> : null}
                          {i.requiresHuman ? <Badge tone="warn" className="mt-1">Appréciation humaine</Badge> : null}
                        </Td>
                        <Td className="align-top whitespace-nowrap">{levelShort[i.level]}</Td>
                        <Td className="align-top whitespace-nowrap">{i.applicability.length === 2 ? "OF et CFA" : i.applicability.map((a) => a.toUpperCase()).join(" / ")}</Td>
                        <Td className="align-top text-[12.5px] text-ink-2">
                          <ul className="list-disc space-y-0.5 pl-4">
                            {i.evidenceHints.map((h) => (
                              <li key={h}>{h}</li>
                            ))}
                          </ul>
                        </Td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
              </section>
            ))}
          </div>
        </Panel>
      ) : null}
      <p className="mt-6 text-[13px]">
        <Link href={`/app/${orgId}/qualite`} className="underline underline-offset-4">
          Retour au tableau de bord qualité
        </Link>
      </p>
    </FadeIn>
  );
}
