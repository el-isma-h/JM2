import { NextResponse } from "next/server";
import { readPackageFile, resolveElearningAccess } from "@/server/elearning/service";
import { safePackagePath } from "@/server/elearning/scorm";

/**
 * Sert les fichiers d'un paquet SCORM depuis le stockage privé, après contrôle d'accès
 * (personnel de l'organisme ou apprenant inscrit au parcours). Jamais de fichier dans /public.
 */
export async function GET(_req: Request, { params }: { params: Promise<{ orgId: string; moduleId: string; path: string[] }> }) {
  const { orgId, moduleId, path } = await params;
  const access = await resolveElearningAccess(orgId, moduleId);
  if (!access) return new NextResponse("Accès refusé.", { status: 403 });
  if (access.module.kind !== "scorm" || !access.module.packageKey) return new NextResponse("Ce module n'est pas un paquet.", { status: 404 });
  const safe = safePackagePath(path);
  if (!safe) return new NextResponse("Chemin invalide.", { status: 400 });
  const file = await readPackageFile(access.module.packageKey, safe);
  if (!file) return new NextResponse("Fichier introuvable dans le paquet.", { status: 404 });
  return new NextResponse(new Uint8Array(file.data), {
    headers: {
      "Content-Type": file.mime,
      "Cache-Control": "private, max-age=300",
      "X-Frame-Options": "SAMEORIGIN",
      "Content-Security-Policy": "frame-ancestors 'self'",
    },
  });
}
