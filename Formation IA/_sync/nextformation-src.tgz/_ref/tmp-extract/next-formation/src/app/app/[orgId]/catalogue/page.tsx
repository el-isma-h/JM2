import Link from "next/link";
import { and, desc, eq, ilike, or, sql, type SQL } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { createProgramAction } from "@/server/actions/catalog";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/field";
import { EmptyState, PageHeader, Panel } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FormDialog } from "@/components/admin/form-dialog";
import { Pagination, readPage, readParam } from "@/components/admin/pagination";
import { ProgramFields, modalityLabels, programKindLabels, programStatusLabels } from "@/components/catalog/fields";

export const dynamic = "force-dynamic";
const PAGE = 50;

export default async function CataloguePage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const base = `/app/${orgId}`;
  const ctx = await guardOrg(orgId, `${base}/catalogue`, "catalog.view");
  const sp = await searchParams;
  const q = readParam(sp.q);
  const kind = readParam(sp.kind);
  const status = readParam(sp.status);
  const published = readParam(sp.published);
  const page = readPage(sp.page);

  const conds: SQL[] = [eq(schema.programs.orgId, ctx.org.id)];
  if (q) conds.push(or(ilike(schema.programs.title, `%${q}%`), ilike(schema.programs.code, `%${q}%`), ilike(schema.programs.category, `%${q}%`))!);
  if (kind && (schema.programKindEnum.enumValues as readonly string[]).includes(kind)) conds.push(eq(schema.programs.kind, kind as "bts"));
  if (status && (schema.programStatusEnum.enumValues as readonly string[]).includes(status)) conds.push(eq(schema.programs.status, status as "actif"));
  else if (!status) conds.push(sql`${schema.programs.status} <> 'archive'`);
  if (published === "1") conds.push(eq(schema.programs.isPublished, true));
  if (published === "0") conds.push(eq(schema.programs.isPublished, false));
  const where = and(...conds);

  const [rows, [{ total }], certifications] = await Promise.all([
    db
      .select({
        p: schema.programs,
        certTitle: schema.certifications.title,
        activeVersion: sql<number | null>`(select v.version from ${schema.programVersions} v where v.program_id = "programs"."id" and v.status = 'active' limit 1)`,
        activeHours: sql<number | null>`(select v.duration_hours from ${schema.programVersions} v where v.program_id = "programs"."id" and v.status = 'active' limit 1)`,
        activeModality: sql<string | null>`(select v.modality::text from ${schema.programVersions} v where v.program_id = "programs"."id" and v.status = 'active' limit 1)`,
        draft: sql<number>`(select count(*)::int from ${schema.programVersions} v where v.program_id = "programs"."id" and v.status = 'brouillon')`,
        sessions: sql<number>`(select count(*)::int from ${schema.trainingSessions} s join ${schema.programVersions} v on v.id = s.program_version_id where v.program_id = "programs"."id" and s.status not in ('annulee'))`,
      })
      .from(schema.programs)
      .leftJoin(schema.certifications, eq(schema.certifications.id, schema.programs.certificationId))
      .where(where)
      .orderBy(desc(schema.programs.updatedAt))
      .limit(PAGE)
      .offset((page - 1) * PAGE),
    db.select({ total: sql<number>`count(*)::int` }).from(schema.programs).where(where),
    db.select({ id: schema.certifications.id, name: schema.certifications.title }).from(schema.certifications).where(eq(schema.certifications.orgId, ctx.org.id)).orderBy(schema.certifications.title),
  ]);
  const canManage = ctx.permissions.has("catalog.manage");

  return (
    <>
      <PageHeader
        title="Catalogue"
        description="Formations, versions de programme, modules et certifications. Une évolution de programme ne modifie jamais un parcours contractualisé."
        actions={
          <>
            <Button asChild variant="secondary">
              <Link href={`${base}/catalogue/certifications`}>Certifications</Link>
            </Button>
            <Button asChild variant="secondary">
              <Link href={`/catalogue-public/${ctx.tenant.slug}`} target="_blank" rel="noreferrer">
                Catalogue public
              </Link>
            </Button>
            {canManage ? (
              <FormDialog action={createProgramAction} trigger="Nouvelle formation" title="Nouvelle formation" description="La version 1 du programme est créée en brouillon ; complétez-la puis activez-la." submitLabel="Créer la formation" wide>
                <ProgramFields orgId={ctx.org.id} certifications={certifications} />
              </FormDialog>
            ) : null}
          </>
        }
      />
      <Panel>
        <form method="get" className="flex flex-wrap items-end gap-3 border-b border-line px-5 py-3">
          <Field label="Recherche" htmlFor="q" className="w-full max-w-xs">
            <Input id="q" name="q" defaultValue={q} placeholder="Intitulé, code ou catégorie" />
          </Field>
          <Field label="Type" htmlFor="kind" className="w-48">
            <Select id="kind" name="kind" defaultValue={kind ?? ""}>
              <option value="">Tous</option>
              {Object.entries(programKindLabels).map(([v, l]) => (
                <option key={v} value={v}>
                  {l}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Statut" htmlFor="status" className="w-40">
            <Select id="status" name="status" defaultValue={status ?? ""}>
              <option value="">Actifs et brouillons</option>
              {Object.entries(programStatusLabels).map(([v, l]) => (
                <option key={v} value={v}>
                  {l}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Publication" htmlFor="published" className="w-40">
            <Select id="published" name="published" defaultValue={published ?? ""}>
              <option value="">Toutes</option>
              <option value="1">Publiées</option>
              <option value="0">Non publiées</option>
            </Select>
          </Field>
          <Button type="submit" variant="secondary">
            Filtrer
          </Button>
        </form>
        {rows.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Formation</Th>
                <Th>Type</Th>
                <Th>Version active</Th>
                <Th num>Durée</Th>
                <Th>Statut</Th>
                <Th>Publication</Th>
                <Th num>Sessions</Th>
              </tr>
            </thead>
            <tbody>
              {rows.map(({ p, certTitle, activeVersion, activeHours, activeModality, draft, sessions }) => (
                <tr key={p.id}>
                  <Td>
                    <Link href={`${base}/catalogue/${p.id}`} className="font-medium text-ink hover:underline">
                      {p.title}
                    </Link>
                    <p className="text-[12px] text-ink-3">
                      <span className="num">{p.code}</span>
                      {certTitle ? ` · ${certTitle}` : ""}
                      {p.category ? ` · ${p.category}` : ""}
                    </p>
                  </Td>
                  <Td>
                    <Badge>{programKindLabels[p.kind]}</Badge>
                  </Td>
                  <Td>
                    {activeVersion ? (
                      <span>
                        v{activeVersion} · {modalityLabels[activeModality ?? ""] ?? activeModality}
                      </span>
                    ) : (
                      <span className="text-warn-ink">Aucune version active</span>
                    )}
                    {draft ? <span className="block text-[12px] text-ink-3">brouillon en cours</span> : null}
                  </Td>
                  <Td num>{activeHours != null ? `${activeHours} h` : "-"}</Td>
                  <Td>
                    <StatusBadge status={p.status} />
                  </Td>
                  <Td>{p.isPublished ? <Badge tone="ok">Publiée</Badge> : <Badge>Interne</Badge>}</Td>
                  <Td num>{sessions}</Td>
                </tr>
              ))}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucune formation" description={q || kind || status || published ? "Aucun résultat pour ces filtres." : "Créez votre première formation : BTS, titre professionnel, formation courte ou habilitation, sans rythme imposé."} />
        )}
        <Pagination basePath={`${base}/catalogue`} params={{ q, kind, status, published }} page={page} pageSize={PAGE} total={total} />
      </Panel>
    </>
  );
}
