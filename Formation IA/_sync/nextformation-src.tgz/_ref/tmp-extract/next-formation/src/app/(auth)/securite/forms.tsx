"use client";

import { useActionState, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import QRCode from "qrcode";
import { confirmTotpSetupAction, elevateAction, startTotpSetupAction, type ActionState } from "@/server/actions/auth";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/field";
import { Notice } from "@/components/ui/surface";

export function TotpSetup({ next }: { next?: string }) {
  const [secret, setSecret] = useState<{ secret: string; uri: string } | null>(null);
  const [qr, setQr] = useState<string | null>(null);
  const [state, action, pending] = useActionState<ActionState, FormData>(confirmTotpSetupAction, {});
  const router = useRouter();

  useEffect(() => {
    startTotpSetupAction().then((r) => {
      if (r.data) setSecret({ secret: r.data.secret, uri: r.data.uri });
    });
  }, []);
  useEffect(() => {
    if (secret) QRCode.toDataURL(secret.uri, { margin: 1, width: 220 }).then(setQr);
  }, [secret]);
  useEffect(() => {
    if (state.ok) router.push(next ?? "/app");
  }, [state.ok, next, router]);

  return (
    <div className="mt-6 space-y-5">
      <div className="flex flex-wrap items-start gap-5">
        {qr ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={qr} alt="QR code à scanner" width={180} height={180} className="rounded-[var(--radius-sm)] border border-line bg-white p-1" />
        ) : (
          <div className="h-[180px] w-[180px] animate-pulse rounded-[var(--radius-sm)] bg-bg-muted" />
        )}
        <div className="min-w-0 flex-1 text-[13px] text-ink-2">
          <p>Si vous ne pouvez pas scanner, saisissez cette clé manuellement :</p>
          <p className="num mt-2 break-all rounded-[var(--radius-sm)] bg-bg-sunken px-3 py-2 text-ink">{secret?.secret ?? "…"}</p>
        </div>
      </div>
      <form action={action} className="space-y-4">
        <input type="hidden" name="secret" value={secret?.secret ?? ""} />
        <Field label="Code affiché par l'application" htmlFor="code" required>
          <Input id="code" name="code" inputMode="numeric" autoComplete="one-time-code" required className="num" />
        </Field>
        {state.error ? <Notice tone="danger">{state.error}</Notice> : null}
        <Button type="submit" size="lg" className="w-full" loading={pending} disabled={!secret}>
          Activer
        </Button>
      </form>
    </div>
  );
}

export function ElevateForm({ next, totp }: { next: string; totp: boolean }) {
  const [state, action, pending] = useActionState<ActionState, FormData>(elevateAction, {});
  return (
    <form action={action} className="mt-6 space-y-4">
      <input type="hidden" name="next" value={next} />
      {totp ? (
        <Field label="Code de vérification" htmlFor="code" required>
          <Input id="code" name="code" inputMode="numeric" autoComplete="one-time-code" autoFocus required className="num" />
        </Field>
      ) : (
        <Field label="Mot de passe" htmlFor="password" required>
          <Input id="password" name="password" type="password" autoComplete="current-password" autoFocus required />
        </Field>
      )}
      {state.error ? <Notice tone="danger">{state.error}</Notice> : null}
      <Button type="submit" size="lg" className="w-full" loading={pending}>
        Continuer
      </Button>
    </form>
  );
}
