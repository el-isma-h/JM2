import Link from "next/link";
import { desc, eq, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { createCohortAction } from "@/server/actions/exams";
import { todayParis } from "@/lib/time";
import { fmtDate } from "@/lib/dates";
import { Button } from "@/components/ui/button";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { EmptyState, PageHeader, Panel } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FormDialog } from "@/components/admin/form-dialog";
import { CohortFields } from "@/components/pedagogy/cohort-form";
import { loadCohortFormData } from "@/server/exams/service";

export const dynamic = "force-dynamic";

export default async function ExamensPage({ params }: { params: Promise<{ orgId: string }> }) {
  const { orgId } = await params;
  const base = `/app/${orgId}`;
  const ctx = await guardOrg(orgId, `${base}/examens`, "exams.view");
  const canManage = ctx.permissions.has("exams.manage");
  const [cohorts, form] = await Promise.all([
    db
      .select({ c: schema.examCohorts, programTitle: schema.programs.title, members: sql<number>`(select count(*)::int from ${schema.examMembers} m where m.cohort_id = "exam_cohorts"."id")`, results: sql<number>`(select count(*)::int from ${schema.examMembers} m where m.cohort_id = "exam_cohorts"."id" and m.result is not null)` })
      .from(schema.examCohorts)
      .innerJoin(schema.programs, eq(schema.programs.id, schema.examCohorts.programId))
      .where(eq(schema.examCohorts.orgId, orgId))
      .orderBy(desc(schema.examCohorts.date)),
    canManage ? loadCohortFormData(orgId) : Promise.resolve(null),
  ]);
  return (
    <>
      <PageHeader
        title="Cohortes d'examen"
        description="Chaque cohorte se gère sur son propre écran : affectations contrôlées (formation, éligibilité, capacité, doublon), convocations et résultats enregistrés sur le bon membre."
        actions={
          canManage && form ? (
            <FormDialog action={createCohortAction} trigger="Nouvelle cohorte" title="Cohorte d'examen" submitLabel="Créer la cohorte" wide>
              <input type="hidden" name="orgId" value={orgId} />
              <CohortFields data={{ ...form, defaultDate: todayParis() }} idPrefix="new" />
            </FormDialog>
          ) : null
        }
      />
      <Panel>
        {cohorts.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Code</Th>
                <Th>Libellé</Th>
                <Th>Formation</Th>
                <Th>Date</Th>
                <Th>Périmètre</Th>
                <Th num>Membres</Th>
                <Th num>Résultats</Th>
                <Th>État</Th>
                <Th />
              </tr>
            </thead>
            <tbody>
              {cohorts.map(({ c, programTitle, members, results }) => (
                <tr key={c.id}>
                  <Td className="num">
                    <Link href={`${base}/examens/${c.id}`} className="font-medium hover:underline">
                      {c.code}
                    </Link>
                  </Td>
                  <Td>{c.label}</Td>
                  <Td>{programTitle}</Td>
                  <Td className="whitespace-nowrap">
                    {fmtDate(c.date)}
                    {c.endDate && c.endDate !== c.date ? ` au ${fmtDate(c.endDate)}` : ""}
                  </Td>
                  <Td>{c.scope === "complet" ? <Badge>Complet</Badge> : <Badge tone="info">{(c.blocks as string[]).length} bloc(s)</Badge>}</Td>
                  <Td num>
                    {members} / {c.capacity}
                  </Td>
                  <Td num>{results}</Td>
                  <Td>
                    <StatusBadge status={c.status} />
                  </Td>
                  <Td>
                    <Button asChild variant="secondary" size="sm">
                      <Link href={`${base}/examens/${c.id}`}>Gérer</Link>
                    </Button>
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucune cohorte" description={canManage ? "Créez une cohorte pour une formation, une date et une capacité." : "Aucune cohorte d'examen n'a été créée."} />
        )}
      </Panel>
    </>
  );
}
