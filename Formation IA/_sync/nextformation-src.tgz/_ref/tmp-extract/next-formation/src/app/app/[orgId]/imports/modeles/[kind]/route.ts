import { NextResponse, type NextRequest } from "next/server";
import { requireOrg } from "@/server/authz";
import { AuthError } from "@/server/auth";
import { isImportKind, templateCsv } from "@/server/imports/kinds";

export const dynamic = "force-dynamic";

/** Modèle CSV téléchargeable (en-têtes attendus + une ligne d'exemple), par type d'import. */
export async function GET(req: NextRequest, { params }: { params: Promise<{ orgId: string; kind: string }> }) {
  const { orgId, kind } = await params;
  try {
    const ctx = await requireOrg(orgId, "enrollments.manage");
    if (ctx.trainerOnly) return new NextResponse("Accès refusé", { status: 403 });
  } catch (e) {
    if (e instanceof AuthError && e.code === "unauthenticated") return NextResponse.redirect(new URL(`/connexion?next=${encodeURIComponent(`/app/${orgId}/imports`)}`, req.url));
    return new NextResponse("Accès refusé", { status: 403 });
  }
  if (!isImportKind(kind)) return new NextResponse("Modèle inconnu", { status: 404 });
  return new NextResponse(templateCsv(kind), { headers: { "content-type": "text/csv; charset=utf-8", "content-disposition": `attachment; filename="modele-${kind}.csv"` } });
}
