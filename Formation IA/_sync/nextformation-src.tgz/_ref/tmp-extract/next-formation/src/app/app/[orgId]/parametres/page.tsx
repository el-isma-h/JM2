import Link from "next/link";
import { asc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardOrg } from "@/server/guard";
import { canEditSettings } from "@/server/security/rules";
import { setOnboardingStepAction, updateIdentityAction, updateNumberingAction, updateRetentionAction, updateRhythmsAction, updateScheduleAction } from "@/server/actions/settings";
import { fmtDateTime } from "@/lib/dates";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea } from "@/components/ui/field";
import { KeyValue, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FadeIn } from "@/components/ui/motion";
import { ActionButton, ActionForm } from "@/components/admin/action-form";
import { ONBOARDING_STEPS, onboardingIndex } from "@/components/dashboard/onboarding";
import { RgpdExport } from "./rgpd-export";

export const dynamic = "force-dynamic";

type Settings = { morning?: { start: string; end: string }; afternoon?: { start: string; end: string }; timezone?: string; rhythms?: { label: string; centerDays: number; companyDays: number; weekdays: number[] }[]; numbering?: Record<string, string> };

export default async function SettingsPage({ params }: { params: Promise<{ orgId: string }> }) {
  const { orgId } = await params;
  const ctx = await guardOrg(orgId, `/app/${orgId}/parametres`, "org.view");
  const canEdit = canEditSettings(ctx);
  const s = (ctx.org.settings ?? {}) as Settings;
  const morning = s.morning ?? { start: "09:00", end: "12:00" };
  const afternoon = s.afternoon ?? { start: "14:00", end: "17:00" };
  const numbering = { enrollment: "INS", session: "SES", invoice: "F", credit: "AV", quote: "DEV", ...(s.numbering ?? {}) };
  const [policies, sites] = await Promise.all([
    db.select().from(schema.retentionPolicies).where(eq(schema.retentionPolicies.orgId, orgId)).orderBy(asc(schema.retentionPolicies.category)),
    db.select({ id: schema.sites.id, name: schema.sites.name, city: schema.sites.city, isMain: schema.sites.isMain }).from(schema.sites).where(eq(schema.sites.orgId, orgId)).orderBy(asc(schema.sites.name)),
  ]);
  const onboardingDone = Boolean(ctx.org.onboardingCompletedAt);
  const stepIndex = onboardingIndex(ctx.org.onboardingStep);
  const ro = !canEdit;

  return (
    <FadeIn>
      <PageHeader
        title="Paramètres"
        description={`${ctx.org.tradeName ?? ctx.org.legalName}. ${canEdit ? "Vous pouvez modifier ces paramètres (direction ou propriétaire)." : "Lecture seule : la direction ou le propriétaire modifie ces paramètres."} La charte institutionnelle (logo, couleurs, signataire, SIRET, NDA) est gérée par le propriétaire sur la page Charte.`}
        actions={
          <Button asChild variant="secondary">
            <Link href={`/app/${orgId}/charte`}>Charte institutionnelle</Link>
          </Button>
        }
      />

      {!onboardingDone ? (
        <Panel className="mb-6" id="onboarding">
          <PanelHeader title="Mise en route guidée" description="Étapes dans l'ordre conseillé ; chaque lien ouvre la page concernée. Marquez l'étape faite pour avancer." />
          <ol className="divide-y divide-line">
            {ONBOARDING_STEPS.filter((st) => st.key !== "termine").map((st, i) => {
              const state = i < stepIndex ? "fait" : i === stepIndex ? "en_cours" : "a_venir";
              const nextKey = ONBOARDING_STEPS[i + 1]?.key ?? "termine";
              return (
                <li key={st.key} className="flex flex-wrap items-center justify-between gap-3 px-5 py-3 text-[13.5px]">
                  <span className="flex items-center gap-3">
                    <span className="num w-5 text-ink-3">{i + 1}</span>
                    {state === "fait" ? <Badge tone="ok">Fait</Badge> : state === "en_cours" ? <Badge tone="accent">En cours</Badge> : <Badge tone="neutral">À venir</Badge>}
                    <Link href={`/app/${orgId}${st.href}`} className="hover:underline">
                      {st.label}
                    </Link>
                  </span>
                  {canEdit && state === "en_cours" ? <ActionButton action={setOnboardingStepAction} fields={{ orgId, step: nextKey }} label={nextKey === "termine" ? "Terminer la mise en route" : "Étape faite"} variant="primary" /> : null}
                  {canEdit && state === "fait" ? <ActionButton action={setOnboardingStepAction} fields={{ orgId, step: st.key }} label="Revenir ici" variant="ghost" /> : null}
                </li>
              );
            })}
          </ol>
        </Panel>
      ) : (
        <p className="mb-6 text-[12.5px] text-ink-3">Mise en route terminée le {fmtDateTime(ctx.org.onboardingCompletedAt)}.</p>
      )}

      <div className="grid gap-6 lg:grid-cols-2">
        <Panel>
          <PanelHeader title="Identité" description="Coordonnées et activité. Raison sociale, SIRET, NDA et signataire : voir la charte." />
          <ActionForm action={updateIdentityAction} submitLabel="Enregistrer" className="space-y-4 px-5 py-4" footerClassName="pt-1">
            <input type="hidden" name="orgId" value={orgId} />
            <KeyValue items={[{ k: "Raison sociale", v: ctx.org.legalName }, { k: "Nom commercial", v: ctx.org.tradeName ?? "-" }, { k: "SIRET", v: <span className="num">{ctx.org.siret ?? "-"}</span> }, { k: "NDA", v: <span className="num">{ctx.org.nda ?? "-"}</span> }]} />
            <Field label="Activité" htmlFor="id-kind">
              <Select id="id-kind" name="kind" defaultValue={ctx.org.kind} disabled={ro}>
                <option value="of">Organisme de formation</option>
                <option value="cfa">CFA</option>
                <option value="of_cfa">Organisme de formation et CFA</option>
              </Select>
            </Field>
            <Field label="E-mail de contact" htmlFor="id-email">
              <Input id="id-email" name="email" type="email" defaultValue={ctx.org.email ?? ""} readOnly={ro} />
            </Field>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Téléphone" htmlFor="id-phone">
                <Input id="id-phone" name="phone" defaultValue={ctx.org.phone ?? ""} readOnly={ro} className="num" />
              </Field>
              <Field label="Site web" htmlFor="id-web">
                <Input id="id-web" name="website" type="url" defaultValue={ctx.org.website ?? ""} readOnly={ro} placeholder="https://" />
              </Field>
            </div>
            {ro ? <input type="hidden" name="kind" value={ctx.org.kind} /> : null}
          </ActionForm>
        </Panel>

        <Panel id="sites">
          <PanelHeader title="Sites et salles" description="Lieux de formation utilisés par le planning." actions={<Button asChild variant="ghost" size="sm"><Link href={`/app/${orgId}/planning`}>Planning</Link></Button>} />
          {sites.length ? (
            <Table>
              <tbody>
                {sites.map((x) => (
                  <tr key={x.id}>
                    <Td className="font-medium">
                      {x.name}
                      {x.isMain ? (
                        <Badge tone="neutral" className="ml-2">
                          Principal
                        </Badge>
                      ) : null}
                    </Td>
                    <Td className="text-ink-2">{x.city ?? "-"}</Td>
                  </tr>
                ))}
              </tbody>
            </Table>
          ) : (
            <p className="px-5 py-4 text-[13.5px] text-ink-2">Aucun site.</p>
          )}
        </Panel>

        <Panel>
          <PanelHeader title="Horaires par défaut" description="Matin et après-midi, Europe/Paris. Une journée 9h-12h / 14h-17h compte 6 h : la pause méridienne n'est jamais comptée." />
          <ActionForm action={updateScheduleAction} submitLabel="Enregistrer" className="space-y-4 px-5 py-4" footerClassName="pt-1">
            <input type="hidden" name="orgId" value={orgId} />
            <div className="grid grid-cols-2 gap-4">
              <Field label="Matin : début" htmlFor="sc-ms">
                <Input id="sc-ms" name="morningStart" type="time" defaultValue={morning.start} readOnly={ro} className="num" />
              </Field>
              <Field label="Matin : fin" htmlFor="sc-me">
                <Input id="sc-me" name="morningEnd" type="time" defaultValue={morning.end} readOnly={ro} className="num" />
              </Field>
              <Field label="Après-midi : début" htmlFor="sc-as">
                <Input id="sc-as" name="afternoonStart" type="time" defaultValue={afternoon.start} readOnly={ro} className="num" />
              </Field>
              <Field label="Après-midi : fin" htmlFor="sc-ae">
                <Input id="sc-ae" name="afternoonEnd" type="time" defaultValue={afternoon.end} readOnly={ro} className="num" />
              </Field>
            </div>
            <Field label="Fuseau" htmlFor="sc-tz" help="Le serveur est la référence temporelle (heure de Paris, changements d'heure inclus).">
              <Select id="sc-tz" name="timezone" defaultValue={s.timezone ?? "Europe/Paris"} disabled={ro}>
                <option value="Europe/Paris">Europe/Paris</option>
              </Select>
            </Field>
          </ActionForm>
        </Panel>

        <Panel>
          <PanelHeader title="Rythmes types" description="Alternance centre / entreprise proposée à la création d'une session." />
          <ActionForm action={updateRhythmsAction} submitLabel="Enregistrer" className="space-y-4 px-5 py-4" footerClassName="pt-1">
            <input type="hidden" name="orgId" value={orgId} />
            <Field label="Un rythme par ligne" htmlFor="rh-list" help="Format : libellé | jours centre | jours entreprise | jours de la semaine (1 = lundi … 7 = dimanche, séparés par des virgules).">
              <Textarea id="rh-list" name="rhythms" readOnly={ro} className="num min-h-28" defaultValue={(s.rhythms ?? []).map((r) => `${r.label} | ${r.centerDays} | ${r.companyDays} | ${(r.weekdays ?? []).join(",")}`).join("\n")} placeholder={"2 jours centre / 3 jours entreprise | 2 | 3 | 1,2\n1 semaine / 3 semaines | 5 | 15 | 1,2,3,4,5"} />
            </Field>
          </ActionForm>
        </Panel>

        <Panel>
          <PanelHeader title="Numérotation" description="Préfixes des références. Les compteurs sont continus par organisme et par année." />
          <Notice tone="info" className="mx-5 mt-4">
            Les modules Inscriptions, Sessions et Factures utilisent aujourd&apos;hui les préfixes INS, SES, F et AV ; les préfixes enregistrés ici seront appliqués quand ces modules liront ce paramètre.
          </Notice>
          <ActionForm action={updateNumberingAction} submitLabel="Enregistrer" className="space-y-4 px-5 py-4" footerClassName="pt-1">
            <input type="hidden" name="orgId" value={orgId} />
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
              {(["enrollment", "session", "invoice", "credit", "quote"] as const).map((k) => (
                <Field key={k} label={{ enrollment: "Inscriptions", session: "Sessions", invoice: "Factures", credit: "Avoirs", quote: "Devis" }[k]} htmlFor={`nb-${k}`}>
                  <Input id={`nb-${k}`} name={k} defaultValue={numbering[k]} readOnly={ro} className="num" maxLength={6} />
                </Field>
              ))}
            </div>
          </ActionForm>
        </Panel>

        <Panel className="lg:col-span-2">
          <PanelHeader title="Politiques de conservation (RGPD)" description="Durée et action par catégorie. Les durées, responsabilités et sous-traitants sont à valider dans le cadrage de protection des données." />
          <Table>
            <thead>
              <tr>
                <Th>Catégorie</Th>
                <Th>Base ou référence</Th>
                <Th num>Durée (mois)</Th>
                <Th>Action à l&apos;échéance</Th>
                {canEdit ? <Th /> : null}
              </tr>
            </thead>
            <tbody>
              {policies.map((p) => (
                <tr key={p.id}>
                  <Td className="font-medium">{p.label}</Td>
                  <Td className="text-ink-2">{p.legalBasis ?? "-"}</Td>
                  <Td num>{p.retentionMonths}</Td>
                  <Td>{p.action === "anonymiser" ? "Anonymiser" : p.action === "supprimer" ? "Supprimer" : "Conserver"}</Td>
                  {canEdit ? (
                    <Td>
                      <ActionForm action={updateRetentionAction} submitLabel="Enregistrer" submitVariant="ghost" submitSize="sm" className="flex flex-wrap items-end gap-2" footerClassName="mb-0.5">
                        <input type="hidden" name="orgId" value={orgId} />
                        <input type="hidden" name="policyId" value={p.id} />
                        <Input name="retentionMonths" type="number" min={1} max={1200} defaultValue={p.retentionMonths} className="num h-8 w-24 text-[12.5px]" aria-label={`Durée en mois : ${p.label}`} />
                        <Select name="action" defaultValue={p.action} className="h-8 w-36 text-[12.5px]" aria-label={`Action : ${p.label}`}>
                          <option value="anonymiser">Anonymiser</option>
                          <option value="supprimer">Supprimer</option>
                          <option value="conserver">Conserver</option>
                        </Select>
                        <Input name="legalBasis" defaultValue={p.legalBasis ?? ""} className="h-8 w-56 text-[12.5px]" aria-label={`Base : ${p.label}`} placeholder="Base légale ou référence" />
                      </ActionForm>
                    </Td>
                  ) : null}
                </tr>
              ))}
            </tbody>
          </Table>
        </Panel>

        <Panel className="lg:col-span-2">
          <PanelHeader title="Export des données d'une personne (RGPD)" description="Archive ZIP : données structurées (JSON) et documents de la personne. Réservé à la permission « Exporter des données » (vérification renforcée) ; chaque export est journalisé avec son motif." />
          <div className="px-5 py-4">
            {ctx.permissions.has("exports.run") && (canEdit || ctx.permissions.has("dossier.admin_docs.manage")) ? (
              <RgpdExport orgId={orgId} />
            ) : (
              <Notice tone="info">Export réservé à la direction, au propriétaire ou à l&apos;administratif disposant de la permission « Exporter des données » après vérification renforcée.</Notice>
            )}
          </div>
        </Panel>
      </div>
    </FadeIn>
  );
}
