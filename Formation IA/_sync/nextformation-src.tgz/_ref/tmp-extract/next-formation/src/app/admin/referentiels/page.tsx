import { asc, desc, isNotNull, isNull, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardAdmin } from "@/server/guard";
import { importReferentialAction, seedReferentialsAction, updateReferentialDatesAction, withdrawReferentialAction } from "@/server/actions/admin-referentials";
import { fmtDate, fmtDateTime } from "@/lib/dates";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Field, Input, Textarea } from "@/components/ui/field";
import { EmptyState, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { ActionButton, ActionForm } from "@/components/admin/action-form";
import { FormDialog } from "@/components/admin/form-dialog";

export const dynamic = "force-dynamic";

type Criterion = { code: string; label: string; indicators?: { code: string; label: string; requiresHuman?: boolean }[] };

export default async function ReferentialsAdminPage() {
  await guardAdmin("/admin/referentiels");
  const [platform, adoption] = await Promise.all([
    db.select().from(schema.referentials).where(isNull(schema.referentials.orgId)).orderBy(asc(schema.referentials.code), desc(schema.referentials.version)),
    db.select({ code: schema.referentials.code, version: schema.referentials.version, status: schema.referentials.status, n: sql<number>`count(*)::int` }).from(schema.referentials).where(isNotNull(schema.referentials.orgId)).groupBy(schema.referentials.code, schema.referentials.version, schema.referentials.status),
  ]);

  return (
    <>
      <PageHeader
        title="Référentiels qualité"
        description="Référentiels proposés par la plateforme (Qualiopi RNQ…). Ils ne s'appliquent jamais d'eux-mêmes : chaque organisme en copie une version, la relit et la valide par un humain habilité avant activation."
        actions={
          <>
            <ActionButton action={seedReferentialsAction} fields={{}} label="Charger le référentiel fourni" />
            <FormDialog action={importReferentialAction} trigger="Importer un JSON" title="Importer un référentiel (JSON)" description="Structure : { code, title, version, source, sourceUrl, scope (of | cfa | both), effectiveFrom, criteria: [{ code, label, indicators: [{ code, label, level, requiresHuman, evidenceHints }] }] }." submitLabel="Importer" wide>
              <Field label="JSON" htmlFor="rf-json" required>
                <Textarea id="rf-json" name="json" required className="num min-h-64 text-[12px]" />
              </Field>
            </FormDialog>
          </>
        }
      />
      <Panel className="mb-6">
        <PanelHeader title="Référentiels plateforme" />
        {platform.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Référentiel</Th>
                <Th>Version</Th>
                <Th>Périmètre</Th>
                <Th num>Critères</Th>
                <Th num>Indicateurs</Th>
                <Th>Effet</Th>
                <Th>Statut</Th>
                <Th>Adopté par</Th>
                <Th />
              </tr>
            </thead>
            <tbody>
              {platform.map((r) => {
                const criteria = (Array.isArray(r.criteria) ? r.criteria : []) as Criterion[];
                const indicators = criteria.reduce((a, c) => a + (c.indicators?.length ?? 0), 0);
                const adopted = adoption.filter((a) => a.code === r.code && a.version === r.version);
                return (
                  <tr key={r.id}>
                    <Td>
                      <span className="font-medium">{r.title}</span>
                      <p className="num text-[11.5px] text-ink-3">{r.code}</p>
                      {r.source ? <p className="text-[11.5px] text-ink-3">{r.source}</p> : null}
                    </Td>
                    <Td className="num">{r.version}</Td>
                    <Td>{r.scope === "both" ? "OF et CFA" : r.scope.toUpperCase()}</Td>
                    <Td num>{criteria.length}</Td>
                    <Td num>{indicators}</Td>
                    <Td>
                      <ActionForm action={updateReferentialDatesAction} submitLabel="Enregistrer" submitVariant="ghost" submitSize="sm" className="flex flex-wrap items-end gap-2" footerClassName="mb-0.5">
                        <input type="hidden" name="id" value={r.id} />
                        <Input name="effectiveFrom" type="date" defaultValue={r.effectiveFrom ?? ""} className="num h-8 w-36 text-[12px]" aria-label="Date d'effet" />
                        <Input name="effectiveTo" type="date" defaultValue={r.effectiveTo ?? ""} className="num h-8 w-36 text-[12px]" aria-label="Fin d'effet" />
                      </ActionForm>
                    </Td>
                    <Td>
                      <StatusBadge status={r.status} />
                      <p className="text-[11px] text-ink-3">mis à jour {fmtDateTime(r.updatedAt)}</p>
                    </Td>
                    <Td className="text-[12px] text-ink-2">
                      {adopted.length ? (
                        adopted.map((a) => (
                          <span key={a.status} className="block">
                            {a.n} organisme(s) <Badge tone={a.status === "actif" ? "ok" : "neutral"}>{a.status}</Badge>
                          </span>
                        ))
                      ) : (
                        <span className="text-ink-3">Aucun</span>
                      )}
                    </Td>
                    <Td className="text-right">
                      <ActionButton action={withdrawReferentialAction} fields={{ id: r.id }} label={r.status === "retire" ? "Proposer de nouveau" : "Retirer"} variant="ghost" confirm={r.status === "retire" ? undefined : { title: "Retirer le référentiel", description: "Il ne sera plus proposé aux organismes ; les copies déjà validées restent intactes.", confirmLabel: "Retirer", danger: true }} />
                    </Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucun référentiel plateforme" description="Chargez le référentiel fourni ou importez un JSON." />
        )}
      </Panel>
      <Notice tone="info">
        Les dates d&apos;effet d&apos;un référentiel plateforme sont indicatives : seule la copie validée par un organisme (textes, version, dates) est applicable à ses analyses. Première ligne du référentiel fourni : {platform[0] ? `${platform[0].code} ${platform[0].version}, effet ${platform[0].effectiveFrom ? fmtDate(platform[0].effectiveFrom) : "non daté"}` : "aucune"}.
      </Notice>
    </>
  );
}
