import { guardOrg } from "@/server/guard";
import { notFound } from "next/navigation";
import { sessionFormData } from "@/server/sessions/queries";
import { normalizeRhythm } from "@/server/sessions/rules";
import { SessionForm } from "@/components/sessions/session-form";
import { PageHeader, Panel, EmptyState } from "@/components/ui/surface";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { readParam } from "@/components/admin/pagination";
import { FadeIn } from "@/components/ui/motion";

export const dynamic = "force-dynamic";

export default async function NewSessionPage({ params, searchParams }: { params: Promise<{ orgId: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { orgId } = await params;
  const ctx = await guardOrg(orgId, `/app/${orgId}/sessions/nouvelle`, "sessions.manage");
  if (ctx.trainerOnly) notFound();
  const sp = await searchParams;
  const data = await sessionFormData(orgId);
  const settings = (ctx.org.settings ?? {}) as { morning?: { start: string; end: string }; afternoon?: { start: string; end: string } };
  const rhythm = normalizeRhythm({ preset: "continu" }, settings);
  const programVersionId = readParam(sp.version);

  return (
    <FadeIn>
      <PageHeader title="Nouvelle session" breadcrumb={[{ label: "Sessions", href: `/app/${orgId}/sessions` }, { label: "Nouvelle" }]} description="Dates, site, capacité, modalité, rythme et responsables. La session est créée en brouillon ; ouvrez-la ensuite aux inscriptions." />
      <Panel className="p-6">
        {data.versions.length ? (
          <SessionForm orgId={orgId} rhythm={rhythm} orgKind={ctx.org.kind} defaults={{ programVersionId }} {...data} />
        ) : (
          <EmptyState
            title="Aucune version de programme"
            description="Une session s'appuie sur une version de programme du catalogue (objectifs, durée, modalités)."
            action={
              <Button asChild variant="secondary">
                <Link href={`/app/${orgId}/catalogue`}>Ouvrir le catalogue</Link>
              </Button>
            }
          />
        )}
      </Panel>
    </FadeIn>
  );
}
