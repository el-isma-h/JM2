"use client";

import { useEffect } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function ErrorPage({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    console.error(error);
  }, [error]);
  return (
    <main className="flex min-h-[70dvh] flex-col items-start justify-center gap-6 px-5 text-ink sm:px-16">
      <p className="etiquette">Erreur</p>
      <h1 className="titre-geant text-[40px] sm:text-[60px]">Un problème est survenu.</h1>
      <p className="max-w-[56ch] text-[15px] text-ink-2">
        L&apos;opération n&apos;a pas abouti et rien n&apos;a été enregistré à moitié : aucune présence, aucun document, aucune facture n&apos;est dans un état incohérent.
        Réessayez ; si le problème persiste, communiquez la référence ci-dessous au support.
      </p>
      {error.digest ? <p className="font-mono text-[12px] text-ink-3">Référence : {error.digest}</p> : null}
      <div className="flex flex-wrap gap-3">
        <Button onClick={reset}>Réessayer</Button>
        <Button asChild variant="secondary">
          <Link href="/app">Mon espace</Link>
        </Button>
        <Button asChild variant="ghost">
          <Link href="/">Accueil</Link>
        </Button>
      </div>
    </main>
  );
}
