import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { requireUser } from "@/server/auth";
import { getOrgContext, listAccessibleOrgs, STAFF_ROLES } from "@/server/authz";
import { AppShell } from "@/components/app/shell";
import { orgNav } from "@/components/app/nav";
import { OrgSwitcher } from "@/components/app/org-switcher";
import { Badge } from "@/components/ui/badge";
import { Logo } from "@/components/ui/logo";
import { Notifications } from "@/components/app/notifications";
import { listNotifications } from "@/server/tasks/notifications";

const kindLabels = { of: "Organisme de formation", cfa: "CFA", of_cfa: "Organisme de formation et CFA" } as const;

export default async function OrgLayout({ children, params }: { children: React.ReactNode; params: Promise<{ orgId: string }> }) {
  const { orgId } = await params;
  if (!/^[0-9a-f-]{36}$/.test(orgId)) notFound();
  const user = await requireUser();
  const ctx = await getOrgContext(orgId);
  if (!ctx) notFound();
  if (!ctx.isPlatformAdmin && !ctx.isOwner && !ctx.roles.some((r) => STAFF_ROLES.includes(r))) {
    if (ctx.roles.includes("learner")) redirect("/moi");
    if (ctx.roles.includes("employer")) redirect("/entreprise");
    notFound();
  }
  const orgs = await listAccessibleOrgs(user);
  const items = orgNav.filter((it) => (it.ownerOnly ? ctx.isOwner : it.anyPerm ? it.anyPerm.some((p) => ctx.permissions.has(p)) : !it.perm || ctx.permissions.has(it.perm)));
  const notifications = await listNotifications(ctx);

  return (
    <AppShell
      base={`/app/${orgId}`}
      items={items}
      brand={
        <Link href="/app" className="flex items-center gap-3 text-ink">
          <Logo />
          {ctx.org.isDemo ? <Badge tone="warn">Démo</Badge> : null}
        </Link>
      }
      context={<OrgSwitcher orgs={orgs.map((o) => ({ id: o.id, name: o.tradeName ?? o.legalName }))} currentId={orgId} isDemo={ctx.org.isDemo} kindLabel={kindLabels[ctx.org.kind]} />}
      user={{ name: `${user.firstName} ${user.lastName}`, email: user.email, isAdmin: user.platformRole === "platform_admin" }}
      topRight={<Notifications orgId={orgId} items={notifications.items} unread={notifications.unread} />}
    >
      {children}
    </AppShell>
  );
}
