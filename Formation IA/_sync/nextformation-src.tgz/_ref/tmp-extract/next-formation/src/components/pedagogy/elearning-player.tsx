"use client";

import * as React from "react";
import { useActionState } from "react";
import { recordProgressAction } from "@/server/actions/elearning";
import { Button } from "@/components/ui/button";
import { Notice } from "@/components/ui/surface";
import type { ActionState } from "@/server/actions/auth";

/** Compteur de temps basique : envoie les minutes écoulées (onglet visible) toutes les 60 s. Le temps reste à valider par un humain. */
export function ElearningTimer({ orgId, moduleId, enrollmentId }: { orgId: string; moduleId: string; enrollmentId: string }) {
  const [elapsed, setElapsed] = React.useState(0);
  const [sent, setSent] = React.useState(0);
  const [error, setError] = React.useState<string | null>(null);
  const pending = React.useRef(0);

  React.useEffect(() => {
    const tick = setInterval(() => {
      if (document.visibilityState === "visible") {
        setElapsed((s) => s + 1);
        pending.current += 1;
      }
    }, 1000);
    const flush = setInterval(async () => {
      const minutes = Math.floor(pending.current / 60);
      if (!minutes) return;
      pending.current -= minutes * 60;
      const fd = new FormData();
      fd.set("orgId", orgId);
      fd.set("moduleId", moduleId);
      fd.set("enrollmentId", enrollmentId);
      fd.set("minutes", String(minutes));
      const r = await recordProgressAction({}, fd);
      if (r.error) setError(r.error);
      else setSent((m) => m + minutes);
    }, 60_000);
    return () => {
      clearInterval(tick);
      clearInterval(flush);
    };
  }, [orgId, moduleId, enrollmentId]);

  return (
    <div className="flex flex-wrap items-center gap-4 border border-line bg-bg-elev px-4 py-2 text-[12.5px]">
      <span className="num">
        Temps sur cette page : {Math.floor(elapsed / 60)}:{String(elapsed % 60).padStart(2, "0")}
      </span>
      <span className="num text-ink-3">{sent} min transmise(s)</span>
      <span className="text-ink-3">Le temps est enregistré chaque minute et compté comme heures seulement après validation humaine.</span>
      {error ? <span className="text-danger-ink">{error}</span> : null}
    </div>
  );
}

export type QuizQuestion = { question: string; choices: string[]; answer: number };

/** Quiz à choix unique : score calculé puis transmis (statut terminé / échoué selon le seuil de 50 %). */
export function QuizPlayer({ orgId, moduleId, enrollmentId, questions }: { orgId: string; moduleId: string; enrollmentId: string | null; questions: QuizQuestion[] }) {
  const [answers, setAnswers] = React.useState<Record<number, number>>({});
  const [result, setResult] = React.useState<number | null>(null);
  const [state, formAction, pendingState] = useActionState(recordProgressAction, {} as ActionState);
  const score = Object.entries(answers).filter(([i, a]) => questions[Number(i)]?.answer === a).length;
  return (
    <div className="space-y-5">
      {questions.map((q, i) => (
        <fieldset key={i} className="border border-line p-4">
          <legend className="px-1 text-[13.5px] font-medium text-ink">
            {i + 1}. {q.question}
          </legend>
          <div className="mt-2 space-y-1.5">
            {q.choices.map((c, j) => (
              <label key={j} className="flex cursor-pointer items-center gap-2 text-[13.5px]">
                <input type="radio" name={`q${i}`} checked={answers[i] === j} onChange={() => setAnswers((a) => ({ ...a, [i]: j }))} disabled={result !== null} className="accent-[var(--accent)]" />
                <span className={result !== null && q.answer === j ? "font-medium text-ok-ink" : result !== null && answers[i] === j ? "text-danger-ink" : ""}>{c}</span>
              </label>
            ))}
          </div>
        </fieldset>
      ))}
      {result === null ? (
        <Button type="button" onClick={() => setResult(score)} disabled={Object.keys(answers).length < questions.length}>
          Valider mes réponses
        </Button>
      ) : (
        <div className="space-y-3">
          <Notice tone={result >= questions.length / 2 ? "ok" : "warn"}>
            Score : {result} / {questions.length}.
          </Notice>
          {enrollmentId ? (
            <form action={formAction}>
              <input type="hidden" name="orgId" value={orgId} />
              <input type="hidden" name="moduleId" value={moduleId} />
              <input type="hidden" name="enrollmentId" value={enrollmentId} />
              <input type="hidden" name="minutes" value="0" />
              <input type="hidden" name="status" value={result >= questions.length / 2 ? "termine" : "echoue"} />
              <input type="hidden" name="score" value={result} />
              <input type="hidden" name="maxScore" value={questions.length} />
              <Button type="submit" variant="secondary" loading={pendingState} disabled={Boolean(state.ok)}>
                {state.ok ? "Résultat enregistré" : "Enregistrer le résultat"}
              </Button>
              {state.error ? <p className="mt-2 text-[12.5px] text-danger-ink">{state.error}</p> : null}
            </form>
          ) : (
            <p className="text-[12.5px] text-ink-3">Aperçu : aucun résultat enregistré (pas d&apos;inscription sélectionnée).</p>
          )}
        </div>
      )}
    </div>
  );
}
