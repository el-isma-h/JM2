import Link from "next/link";
import { trainerRespondMissionAction, trainerSetFirstLessonAction } from "@/server/actions/missions";
import type { MissionRow } from "@/server/missions/queries";
import { fmtDate } from "@/lib/dates";
import { formatCents } from "@/lib/money";
import { Field, Input } from "@/components/ui/field";
import { EmptyState } from "@/components/ui/surface";
import { ActionButton, ActionForm } from "@/components/admin/action-form";
import { MissionStatusBadge } from "./mission-ui";

/** Missions du formateur connecté (extranet) : accepter / refuser une proposition, indiquer la date du premier cours. */
export function TrainerMissionList({ rows, emptyTitle = "Aucune mission", emptyDescription }: { rows: MissionRow[]; emptyTitle?: string; emptyDescription?: string }) {
  if (!rows.length) return <EmptyState title={emptyTitle} description={emptyDescription} className="py-8" />;
  return (
    <ul className="divide-y divide-line">
      {rows.map((row) => {
        const m = row.m;
        const waiting = (m.status === "proposee" || m.status === "sans_reponse") && !m.replacedByMissionId;
        return (
          <li key={m.id} className="space-y-3 px-5 py-4">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <p className="font-medium text-ink">{m.theme}</p>
                <p className="text-[12.5px] text-ink-3">
                  {[row.learner?.lastName ? `${row.learner.firstName} ${row.learner.lastName}` : null, row.session?.title ?? null, m.location].filter(Boolean).join(" · ") || "Détails communiqués par l'organisme"}
                </p>
                <p className="mt-1 text-[12.5px] text-ink-2">
                  <span className="num">{m.startDate ? `Du ${fmtDate(m.startDate)} au ${fmtDate(m.endDate ?? m.startDate)}` : "Dates à convenir"}</span>
                  {" · "}
                  <span className="num">{m.hours} h</span> avec formateur · <span className="num">{formatCents(m.hourlyRateCents)}</span> HT/h · total <span className="num">{formatCents(m.amountCents)}</span> HT
                </p>
                {m.firstLessonDate ? (
                  <p className="text-[12.5px] text-ink-3">
                    Premier cours le <span className="num">{fmtDate(m.firstLessonDate)}</span>
                  </p>
                ) : null}
              </div>
              <MissionStatusBadge status={m.replacedByMissionId && m.status !== "refusee" ? "annulee" : m.status} />
            </div>
            {waiting ? (
              <div className="flex flex-wrap items-end gap-3">
                <ActionForm action={trainerRespondMissionAction} submitLabel="Accepter la mission" submitSize="sm" footerClassName="mt-0" className="flex flex-wrap items-end gap-3">
                  <input type="hidden" name="missionId" value={m.id} />
                  <input type="hidden" name="decision" value="acceptee" />
                  <Field label="Date du premier cours" htmlFor={`tm-fl-${m.id}`} help="Facultatif : vous pourrez la transmettre plus tard." className="w-56">
                    <Input id={`tm-fl-${m.id}`} name="firstLessonDate" type="date" />
                  </Field>
                </ActionForm>
                <ActionButton
                  action={trainerRespondMissionAction}
                  fields={{ missionId: m.id, decision: "refusee" }}
                  label="Refuser"
                  variant="danger"
                  confirm={{ title: "Refuser cette mission ?", description: "L'organisme sera informé et mobilisera un autre formateur.", confirmLabel: "Refuser la mission", danger: true, input: { name: "note", label: "Motif (facultatif)", placeholder: "Indisponible sur ces dates…" } }}
                />
              </div>
            ) : null}
            {m.status === "acceptee" && !m.firstLessonDate ? (
              <ActionForm action={trainerSetFirstLessonAction} submitLabel="Transmettre" submitVariant="secondary" submitSize="sm" footerClassName="mt-0" className="flex flex-wrap items-end gap-3">
                <input type="hidden" name="missionId" value={m.id} />
                <Field label="Date du premier cours" required htmlFor={`tm-fl2-${m.id}`} className="w-56">
                  <Input id={`tm-fl2-${m.id}`} name="firstLessonDate" type="date" required />
                </Field>
              </ActionForm>
            ) : null}
            {row.contract?.id && row.contract.status !== "genere" && row.contract.status !== "brouillon" ? (
              <p className="text-[12.5px]">
                Contrat de prestation disponible dans{" "}
                <Link href="/formateur/documents" className="font-medium underline underline-offset-4">
                  Mes documents
                </Link>
                .
              </p>
            ) : null}
          </li>
        );
      })}
    </ul>
  );
}
