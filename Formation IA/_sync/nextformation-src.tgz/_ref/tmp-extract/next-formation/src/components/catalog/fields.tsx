import { Checkbox, Field, Input, Select, Textarea } from "@/components/ui/field";
import type { schema } from "@/db";
import type { Option } from "@/components/crm/fields";

type Program = typeof schema.programs.$inferSelect;
type Version = typeof schema.programVersions.$inferSelect;
type Module = typeof schema.modules.$inferSelect;
type Certification = typeof schema.certifications.$inferSelect;

export const programKindLabels: Record<string, string> = {
  bts: "BTS",
  titre_professionnel: "Titre professionnel",
  cqp: "CQP",
  formation_courte: "Formation courte",
  certifiante: "Formation certifiante",
  habilitation: "Habilitation",
  dpc: "DPC",
  bilan: "Bilan de compétences",
  vae: "VAE",
  autre: "Autre",
};
export const programStatusLabels: Record<string, string> = { brouillon: "Brouillon", actif: "Actif", archive: "Archivé" };
export const modalityLabels: Record<string, string> = { presentiel: "Présentiel", distanciel: "À distance", mixte: "Mixte", afest: "AFEST", elearning: "E-learning" };

function tags(v: unknown): string {
  return Array.isArray(v) ? (v as string[]).join(", ") : "";
}

export function ProgramFields({ orgId, program, certifications, prefix = "pg" }: { orgId: string; program?: Program | null; certifications: Option[]; prefix?: string }) {
  const id = (k: string) => `${prefix}-${k}`;
  return (
    <>
      <input type="hidden" name="orgId" value={orgId} />
      {program ? <input type="hidden" name="programId" value={program.id} /> : null}
      <Field label="Intitulé" required htmlFor={id("title")}>
        <Input id={id("title")} name="title" required defaultValue={program?.title ?? ""} />
      </Field>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Code" required htmlFor={id("code")} help="Référence interne unique (ex. BTS-MCO, EXC-N2).">
          <Input id={id("code")} name="code" required defaultValue={program?.code ?? ""} className="num" />
        </Field>
        <Field label="Adresse publique (slug)" htmlFor={id("slug")} help="Généré depuis l'intitulé si vide.">
          <Input id={id("slug")} name="slug" defaultValue={program?.slug ?? ""} className="num" />
        </Field>
        <Field label="Type" htmlFor={id("kind")}>
          <Select id={id("kind")} name="kind" defaultValue={program?.kind ?? "formation_courte"}>
            {Object.entries(programKindLabels).map(([v, l]) => (
              <option key={v} value={v}>
                {l}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Statut" htmlFor={id("status")}>
          <Select id={id("status")} name="status" defaultValue={program?.status ?? "brouillon"}>
            {Object.entries(programStatusLabels).map(([v, l]) => (
              <option key={v} value={v}>
                {l}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Catégorie" htmlFor={id("cat")}>
          <Input id={id("cat")} name="category" defaultValue={program?.category ?? ""} placeholder="Bureautique, commerce, sécurité…" />
        </Field>
        <Field label="Certification visée" htmlFor={id("cert")}>
          <Select id={id("cert")} name="certificationId" defaultValue={program?.certificationId ?? ""}>
            <option value="">Aucune</option>
            {certifications.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Spécialité (NSF)" htmlFor={id("spec")}>
          <Input id={id("spec")} name="specialty" defaultValue={program?.specialty ?? ""} />
        </Field>
        <Field label="Formacode" htmlFor={id("formacode")}>
          <Input id={id("formacode")} name="formacode" defaultValue={program?.formacode ?? ""} className="num" />
        </Field>
      </div>
      {!program ? (
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Modalité (version 1)" htmlFor={id("mod")}>
            <Select id={id("mod")} name="modality" defaultValue="presentiel">
              {Object.entries(modalityLabels).map(([v, l]) => (
                <option key={v} value={v}>
                  {l}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Durée (heures, version 1)" htmlFor={id("dur")}>
            <Input id={id("dur")} name="durationHours" type="number" min={0} defaultValue={0} className="num" />
          </Field>
        </div>
      ) : null}
      <Field label="Étiquettes" htmlFor={id("tags")} help="Séparées par des virgules.">
        <Input id={id("tags")} name="tags" defaultValue={tags(program?.tags)} />
      </Field>
      <div className="flex flex-wrap gap-5">
        <Checkbox name="availableAsContinuing" defaultChecked={program ? program.availableAsContinuing : true} label="Formation continue (OF)" />
        <Checkbox name="availableAsApprenticeship" defaultChecked={program?.availableAsApprenticeship} label="Apprentissage (CFA)" />
        <Checkbox name="cpfEligible" defaultChecked={program?.cpfEligible} label="Éligible CPF" />
      </div>
    </>
  );
}

/** Champs Qualiopi d'une version de programme. */
export function VersionFields({ orgId, version, prefix = "v" }: { orgId: string; version: Version; prefix?: string }) {
  const id = (k: string) => `${prefix}-${k}`;
  const ro = version.status === "archivee";
  const rhythm = (version.rhythm ?? {}) as { label?: string };
  return (
    <>
      <input type="hidden" name="orgId" value={orgId} />
      <input type="hidden" name="versionId" value={version.id} />
      <div className="grid gap-4 md:grid-cols-4">
        <Field label="Modalité" htmlFor={id("mod")}>
          <Select id={id("mod")} name="modality" defaultValue={version.modality} disabled={ro}>
            {Object.entries(modalityLabels).map(([v, l]) => (
              <option key={v} value={v}>
                {l}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Durée totale (h)" required htmlFor={id("dur")}>
          <Input id={id("dur")} name="durationHours" type="number" min={0} defaultValue={version.durationHours} className="num" readOnly={ro} />
        </Field>
        <Field label="Durée (jours)" htmlFor={id("days")}>
          <Input id={id("days")} name="durationDays" type="number" min={0} defaultValue={version.durationDays ?? ""} className="num" readOnly={ro} />
        </Field>
        <Field label="Applicable à partir du" htmlFor={id("eff")}>
          <Input id={id("eff")} name="effectiveFrom" type="date" defaultValue={version.effectiveFrom ?? ""} readOnly={ro} />
        </Field>
        <Field label="Dont heures en entreprise" htmlFor={id("ch")} help="CFA / alternance.">
          <Input id={id("ch")} name="companyHours" type="number" min={0} defaultValue={version.companyHours} className="num" readOnly={ro} />
        </Field>
        <Field label="Dont heures à distance" htmlFor={id("rh")}>
          <Input id={id("rh")} name="remoteHours" type="number" min={0} defaultValue={version.remoteHours} className="num" readOnly={ro} />
        </Field>
        <Field label="Rythme par défaut" htmlFor={id("rhythm")} help="Modifiable par session.">
          <Input id={id("rhythm")} name="rhythmLabel" defaultValue={rhythm.label ?? ""} placeholder="1 semaine / 3 semaines" readOnly={ro} />
        </Field>
        <Field label="Délai d'accès" htmlFor={id("delay")}>
          <Input id={id("delay")} name="accessDelay" defaultValue={version.accessDelay ?? ""} placeholder="15 jours après accord de financement" readOnly={ro} />
        </Field>
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        <Field label="Objectifs" htmlFor={id("obj")} help="Compétences visées, formulées en résultats observables.">
          <Textarea id={id("obj")} name="objectives" defaultValue={version.objectives ?? ""} rows={5} readOnly={ro} />
        </Field>
        <Field label="Public visé" htmlFor={id("aud")}>
          <Textarea id={id("aud")} name="audience" defaultValue={version.audience ?? ""} rows={5} readOnly={ro} />
        </Field>
        <Field label="Prérequis" htmlFor={id("pre")}>
          <Textarea id={id("pre")} name="prerequisites" defaultValue={version.prerequisites ?? ""} rows={4} readOnly={ro} />
        </Field>
        <Field label="Méthodes et moyens pédagogiques" htmlFor={id("meth")}>
          <Textarea id={id("meth")} name="methods" defaultValue={version.methods ?? ""} rows={4} readOnly={ro} />
        </Field>
        <Field label="Modalités d'évaluation" htmlFor={id("eval")}>
          <Textarea id={id("eval")} name="evaluationMethods" defaultValue={version.evaluationMethods ?? ""} rows={4} readOnly={ro} />
        </Field>
        <Field label="Accessibilité (handicap)" htmlFor={id("acc")}>
          <Textarea id={id("acc")} name="accessibility" defaultValue={version.accessibility ?? ""} rows={4} readOnly={ro} />
        </Field>
      </div>
      <Field label="Contenu détaillé" htmlFor={id("content")} help="Les modules ci-dessous structurent le contenu par bloc.">
        <Textarea id={id("content")} name="content" defaultValue={version.content ?? ""} rows={8} readOnly={ro} />
      </Field>
      <div className="grid gap-4 md:grid-cols-3">
        <Field label="Ressources" htmlFor={id("res")}>
          <Textarea id={id("res")} name="resources" defaultValue={version.resources ?? ""} rows={3} readOnly={ro} />
        </Field>
        <Field label="Profil des intervenants" htmlFor={id("tp")}>
          <Textarea id={id("tp")} name="trainerProfile" defaultValue={version.trainerProfile ?? ""} rows={3} readOnly={ro} />
        </Field>
        <div className="space-y-4">
          <Field label="Tarif public HT" htmlFor={id("price")} help="Vide = sur devis.">
            <Input id={id("price")} name="priceEuros" defaultValue={version.priceCents != null ? (version.priceCents / 100).toFixed(2).replace(".", ",") : ""} className="num" inputMode="decimal" readOnly={ro} />
          </Field>
          <Field label="Précision tarifaire" htmlFor={id("pn")}>
            <Input id={id("pn")} name="priceNote" defaultValue={version.priceNote ?? ""} placeholder="par participant, net de TVA…" readOnly={ro} />
          </Field>
        </div>
      </div>
    </>
  );
}

export function ModuleFields({ orgId, versionId, mod, prefix = "m" }: { orgId: string; versionId: string; mod?: Module | null; prefix?: string }) {
  const id = (k: string) => `${prefix}-${k}`;
  const skills = Array.isArray(mod?.skills) ? (mod!.skills as { label: string }[]).map((s) => s.label).join(", ") : "";
  return (
    <>
      <input type="hidden" name="orgId" value={orgId} />
      <input type="hidden" name="versionId" value={versionId} />
      {mod ? <input type="hidden" name="moduleId" value={mod.id} /> : null}
      <Field label="Intitulé du module" required htmlFor={id("title")}>
        <Input id={id("title")} name="title" required defaultValue={mod?.title ?? ""} />
      </Field>
      <div className="grid gap-4 sm:grid-cols-4">
        <Field label="Bloc" htmlFor={id("block")} help="Code du bloc de compétences (RNCP).">
          <Input id={id("block")} name="blockCode" defaultValue={mod?.blockCode ?? ""} className="num" />
        </Field>
        <Field label="Code" htmlFor={id("code")}>
          <Input id={id("code")} name="code" defaultValue={mod?.code ?? ""} className="num" />
        </Field>
        <Field label="Heures" required htmlFor={id("hours")}>
          <Input id={id("hours")} name="hours" type="number" min={0} required defaultValue={mod?.hours ?? 0} className="num" />
        </Field>
        <Field label="Modalité" htmlFor={id("mod")}>
          <Select id={id("mod")} name="modality" defaultValue={mod?.modality ?? ""}>
            <option value="">Celle de la version</option>
            {Object.entries(modalityLabels).map(([v, l]) => (
              <option key={v} value={v}>
                {l}
              </option>
            ))}
          </Select>
        </Field>
      </div>
      <Field label="Description" htmlFor={id("desc")}>
        <Textarea id={id("desc")} name="description" defaultValue={mod?.description ?? ""} rows={3} />
      </Field>
      <Field label="Compétences visées" htmlFor={id("skills")} help="Séparées par des virgules.">
        <Input id={id("skills")} name="skills" defaultValue={skills} />
      </Field>
    </>
  );
}

export function CertificationFields({ orgId, cert, prefix = "cf" }: { orgId: string; cert?: Certification | null; prefix?: string }) {
  const id = (k: string) => `${prefix}-${k}`;
  const blocks = Array.isArray(cert?.blocks) ? (cert!.blocks as { code: string; label: string; description?: string }[]).map((b) => [b.code, b.label, b.description].filter(Boolean).join(" | ")).join("\n") : "";
  return (
    <>
      <input type="hidden" name="orgId" value={orgId} />
      {cert ? <input type="hidden" name="certificationId" value={cert.id} /> : null}
      <Field label="Intitulé" required htmlFor={id("title")}>
        <Input id={id("title")} name="title" required defaultValue={cert?.title ?? ""} />
      </Field>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Code RNCP" htmlFor={id("rncp")}>
          <Input id={id("rncp")} name="rncpCode" defaultValue={cert?.rncpCode ?? ""} className="num" placeholder="RNCP38362" />
        </Field>
        <Field label="Code RS" htmlFor={id("rs")}>
          <Input id={id("rs")} name="rsCode" defaultValue={cert?.rsCode ?? ""} className="num" placeholder="RS6563" />
        </Field>
        <Field label="Certificateur" htmlFor={id("certifier")}>
          <Input id={id("certifier")} name="certifier" defaultValue={cert?.certifier ?? ""} />
        </Field>
        <Field label="Niveau" htmlFor={id("level")}>
          <Input id={id("level")} name="level" defaultValue={cert?.level ?? ""} placeholder="5 (Bac+2)" />
        </Field>
        <Field label="Fin d'enregistrement" htmlFor={id("valid")}>
          <Input id={id("valid")} name="validUntil" type="date" defaultValue={cert?.validUntil ?? ""} />
        </Field>
        <Field label="Référence d'habilitation" htmlFor={id("hab")} help="Habilitation de l'organisme à préparer ou évaluer.">
          <Input id={id("hab")} name="habilitationRef" defaultValue={cert?.habilitationRef ?? ""} />
        </Field>
        <Field label="Habilitation valable jusqu'au" htmlFor={id("habv")}>
          <Input id={id("habv")} name="habilitationValidUntil" type="date" defaultValue={cert?.habilitationValidUntil ?? ""} />
        </Field>
      </div>
      <Field label="Blocs de compétences" htmlFor={id("blocks")} help="Un bloc par ligne : code | intitulé | description.">
        <Textarea id={id("blocks")} name="blocks" defaultValue={blocks} rows={4} placeholder="RNCP38362BC01 | Développer la relation client | …" />
      </Field>
    </>
  );
}
