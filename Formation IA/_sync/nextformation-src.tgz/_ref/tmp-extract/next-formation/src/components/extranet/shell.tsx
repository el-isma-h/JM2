import Link from "next/link";
import { AppShell } from "@/components/app/shell";
import type { NavItem } from "@/components/app/nav";
import { Badge } from "@/components/ui/badge";
import { Logo } from "@/components/ui/logo";
import { EmptyState, Panel } from "@/components/ui/surface";
import { Button } from "@/components/ui/button";
import type { SessionUser } from "@/server/auth";
import { ExtranetSwitcher } from "./extranet-switcher";

/** Coquille commune des extranets : AppShell + nav du rôle + badge Démo + sélecteur d'organisme. */
export function ExtranetShell({
  base,
  items,
  user,
  org,
  choices,
  subtitle,
  children,
}: {
  base: string;
  items: NavItem[];
  user: SessionUser;
  org: { id: string; isDemo: boolean; tradeName: string | null; legalName: string } | null;
  choices: { orgId: string; orgName: string }[];
  subtitle?: string;
  children: React.ReactNode;
}) {
  return (
    <AppShell
      base={base}
      items={items}
      brand={
        <Link href={base} className="flex items-center gap-3 text-ink">
          <Logo />
          {org?.isDemo ? <Badge tone="warn">Démo</Badge> : null}
        </Link>
      }
      context={org ? <ExtranetSwitcher choices={choices.length ? choices : [{ orgId: org.id, orgName: org.tradeName ?? org.legalName }]} currentId={org.id} subtitle={subtitle} isDemo={org.isDemo} /> : null}
      user={{ name: `${user.firstName} ${user.lastName}`, email: user.email, isAdmin: user.platformRole === "platform_admin" }}
    >
      {children}
    </AppShell>
  );
}

const noAccessCopy = {
  learner: {
    title: "Aucun dossier apprenant rattaché à votre compte",
    description: "Votre compte existe mais n'est relié à aucune fiche apprenant. Demandez à l'organisme de formation de rattacher votre inscription à votre adresse e-mail.",
  },
  employer: {
    title: "Aucune entreprise rattachée à votre compte",
    description: "Votre compte existe mais n'est relié à aucune entreprise cliente. Demandez à l'organisme de formation de vous rattacher comme contact ou tuteur de votre entreprise.",
  },
  trainer: {
    title: "Aucune fiche formateur rattachée à votre compte",
    description: "Votre compte existe mais n'est relié à aucune fiche formateur, ou aucune session ne vous est affectée. Rapprochez-vous du responsable pédagogique de l'organisme.",
  },
} as const;

/** État vide explicite quand l'utilisateur est connecté mais sans rattachement exploitable. */
export function NoAttachment({ kind }: { kind: keyof typeof noAccessCopy }) {
  const c = noAccessCopy[kind];
  return (
    <Panel>
      <EmptyState
        title={c.title}
        description={c.description}
        action={
          <div className="flex flex-wrap justify-center gap-2">
            <Button asChild variant="secondary" size="sm">
              <Link href="/app">Retour à l&apos;accueil</Link>
            </Button>
            <form action="/deconnexion" method="post">
              <Button type="submit" variant="ghost" size="sm">
                Se déconnecter
              </Button>
            </form>
          </div>
        }
      />
    </Panel>
  );
}
