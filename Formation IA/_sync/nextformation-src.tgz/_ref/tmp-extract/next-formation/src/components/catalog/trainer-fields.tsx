import { Checkbox, Field, Input, Select, Textarea } from "@/components/ui/field";
import type { schema } from "@/db";

type Trainer = typeof schema.trainers.$inferSelect;

export const trainerKindLabels: Record<string, string> = { interne: "Interne (salarié)", externe: "Externe (indépendant)", sous_traitant: "Sous-traitant (organisme)" };

export function TrainerFields({ orgId, trainer, prefix = "t" }: { orgId: string; trainer?: Trainer | null; prefix?: string }) {
  const id = (k: string) => `${prefix}-${k}`;
  const skills = Array.isArray(trainer?.skills) ? (trainer!.skills as string[]).join(", ") : "";
  return (
    <>
      <input type="hidden" name="orgId" value={orgId} />
      {trainer ? <input type="hidden" name="trainerId" value={trainer.id} /> : null}
      <div className="grid gap-4 sm:grid-cols-[110px_1fr_1fr]">
        <Field label="Civilité" htmlFor={id("civ")}>
          <Select id={id("civ")} name="civility" defaultValue={trainer?.civility ?? ""}>
            <option value="">-</option>
            <option value="Mme">Mme</option>
            <option value="M">M.</option>
          </Select>
        </Field>
        <Field label="Prénom" required htmlFor={id("fn")}>
          <Input id={id("fn")} name="firstName" required defaultValue={trainer?.firstName ?? ""} />
        </Field>
        <Field label="Nom" required htmlFor={id("ln")}>
          <Input id={id("ln")} name="lastName" required defaultValue={trainer?.lastName ?? ""} />
        </Field>
      </div>
      <div className="grid gap-4 sm:grid-cols-3">
        <Field label="E-mail" htmlFor={id("email")} help="Utilisé pour l'invitation à l'espace formateur.">
          <Input id={id("email")} name="email" type="email" defaultValue={trainer?.email ?? ""} />
        </Field>
        <Field label="Téléphone" htmlFor={id("phone")}>
          <Input id={id("phone")} name="phone" defaultValue={trainer?.phone ?? ""} />
        </Field>
        <Field label="Statut" htmlFor={id("kind")}>
          <Select id={id("kind")} name="kind" defaultValue={trainer?.kind ?? "interne"}>
            {Object.entries(trainerKindLabels).map(([v, l]) => (
              <option key={v} value={v}>
                {l}
              </option>
            ))}
          </Select>
        </Field>
      </div>
      <div className="grid gap-4 sm:grid-cols-3">
        <Field label="Structure (externe)" htmlFor={id("company")}>
          <Input id={id("company")} name="companyName" defaultValue={trainer?.companyName ?? ""} />
        </Field>
        <Field label="SIRET" htmlFor={id("siret")}>
          <Input id={id("siret")} name="siret" defaultValue={trainer?.siret ?? ""} className="num" inputMode="numeric" />
        </Field>
        <Field label="NDA (sous-traitant)" htmlFor={id("nda")}>
          <Input id={id("nda")} name="nda" defaultValue={trainer?.nda ?? ""} className="num" />
        </Field>
      </div>
      <Field label="Domaines d'intervention" htmlFor={id("skills")} help="Séparés par des virgules (bureautique, management, sécurité…).">
        <Input id={id("skills")} name="skills" defaultValue={skills} />
      </Field>
      <Field label="Qualifications" htmlFor={id("qual")} help="Diplômes, titres, habilitations, expérience : preuve Qualiopi (indicateur 21).">
        <Textarea id={id("qual")} name="qualifications" defaultValue={trainer?.qualifications ?? ""} rows={3} />
      </Field>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Tarif horaire HT" htmlFor={id("rate")} help="En euros, ex. 65,00.">
          <Input id={id("rate")} name="hourlyRateEuros" defaultValue={trainer?.hourlyRateCents != null ? (trainer.hourlyRateCents / 100).toFixed(2).replace(".", ",") : ""} className="num" inputMode="decimal" />
        </Field>
        {trainer ? (
          <div className="pt-7">
            <input type="hidden" name="isActivePresent" value="1" />
            <Checkbox name="isActive" defaultChecked={trainer.isActive} label="Formateur actif (affectable aux sessions)" />
          </div>
        ) : null}
      </div>
      <Field label="Notes" htmlFor={id("notes")}>
        <Textarea id={id("notes")} name="notes" defaultValue={trainer?.notes ?? ""} rows={2} />
      </Field>
    </>
  );
}
