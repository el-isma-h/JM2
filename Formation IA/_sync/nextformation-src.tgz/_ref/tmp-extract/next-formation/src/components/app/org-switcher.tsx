"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { CaretUpDown } from "@phosphor-icons/react";
import { Select } from "@/components/ui/field";

export function OrgSwitcher({ orgs, currentId, isDemo, kindLabel }: { orgs: { id: string; name: string }[]; currentId: string; isDemo?: boolean; kindLabel?: string }) {
  const router = useRouter();
  if (orgs.length <= 1) {
    const o = orgs[0];
    return (
      <div className="px-2">
        <p className="truncate text-[13px] font-medium text-ink">{o?.name ?? "Organisme"}</p>
        {kindLabel ? <p className="text-[11.5px] text-ink-3">{kindLabel}</p> : null}
        {isDemo ? <p className="text-[11.5px] text-warn-ink">Démonstration (données fictives)</p> : null}
      </div>
    );
  }
  return (
    <div className="relative">
      <Select value={currentId} onChange={(e) => router.push(`/app/${e.target.value}`)} aria-label="Changer d'organisme" className="h-9 pr-8 text-[13px] font-medium">
        {orgs.map((o) => (
          <option key={o.id} value={o.id}>
            {o.name}
          </option>
        ))}
      </Select>
      <CaretUpDown size={14} className="pointer-events-none absolute right-2.5 top-1/2 -translate-y-1/2 text-ink-3" />
      <Link href="/app/organismes" className="mt-1.5 block px-1 text-[12px] text-ink-3 hover:text-ink">
        Tous les organismes
      </Link>
    </div>
  );
}
