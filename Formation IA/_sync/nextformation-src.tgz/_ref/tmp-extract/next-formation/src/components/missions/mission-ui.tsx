import Link from "next/link";
import { closeMissionAction, generateMissionContractAction, proposeMissionAction, replaceMissionAction, respondMissionAction, sendMissionContractAction, setMissionFirstLessonAction } from "@/server/actions/missions";
import { downloadDocumentAction } from "@/server/actions/crm";
import type { MissionOptions, MissionRow } from "@/server/missions/queries";
import { MISSION_STATUS_LABELS, MISSION_STATUS_TONES } from "@/server/missions/rules";
import { fmtDate } from "@/lib/dates";
import { formatCents } from "@/lib/money";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Field, Input, Select, Textarea } from "@/components/ui/field";
import { EmptyState } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { ActionButton } from "@/components/admin/action-form";
import { FormDialog } from "@/components/admin/form-dialog";

/** Pastille de statut de mission (libellés propres aux missions : « proposée » n'est pas une proposition IA). */
export function MissionStatusBadge({ status }: { status: string }) {
  return <Badge tone={MISSION_STATUS_TONES[status] ?? "neutral"}>{MISSION_STATUS_LABELS[status] ?? status}</Badge>;
}

const rateHint = (cents: number | null) => (cents != null ? ` · fiche : ${formatCents(cents)}/h` : "");
const centsToInput = (cents: number | null | undefined) => (cents != null ? (cents / 100).toFixed(2).replace(".", ",") : "");

/** Dialogue « Proposer une mission » (formateur, session ou inscription, thème, dates, heures, taux, lieu). */
export function ProposeMissionDialog({ orgId, options, fixedTrainer, triggerVariant = "primary", triggerSize = "md" }: { orgId: string; options: MissionOptions; fixedTrainer?: { id: string; firstName: string; lastName: string; hourlyRateCents: number | null } | null; triggerVariant?: "primary" | "secondary" | "accent"; triggerSize?: "sm" | "md" }) {
  const byId = new Map(options.sessions.map((s) => [s.id, s]));
  return (
    <FormDialog
      action={proposeMissionAction}
      trigger="Proposer une mission"
      triggerVariant={triggerVariant}
      triggerSize={triggerSize}
      title="Proposer une mission"
      description="Un e-mail « Proposition de mission » part au formateur (rien ne part en démonstration). Sans réponse sous 5 jours ouvrés, il est relancé, puis la mission passe « sans réponse » avec une tâche « Trouver un remplaçant »."
      submitLabel="Proposer la mission"
      wide
    >
      <input type="hidden" name="orgId" value={orgId} />
      {fixedTrainer ? (
        <>
          <input type="hidden" name="trainerId" value={fixedTrainer.id} />
          <p className="text-[13.5px] text-ink-2">
            Formateur : <span className="font-medium text-ink">{fixedTrainer.firstName} {fixedTrainer.lastName}</span>
          </p>
        </>
      ) : (
        <Field label="Formateur" required htmlFor="pm-trainer">
          <Select id="pm-trainer" name="trainerId" required defaultValue="">
            <option value="" disabled>
              Choisir un formateur
            </option>
            {options.trainers.map((t) => (
              <option key={t.id} value={t.id}>
                {t.lastName} {t.firstName}
                {rateHint(t.hourlyRateCents)}
                {t.email ? "" : " · sans e-mail"}
              </option>
            ))}
          </Select>
        </Field>
      )}
      <Field label="Session ou inscription" htmlFor="pm-target" help="Pour une formation individuelle, choisissez l'inscription de l'apprenant : son nom figurera dans la proposition et le contrat.">
        <Select id="pm-target" name="target" defaultValue="">
          <option value="">Aucune (à rattacher plus tard)</option>
          {options.enrollments.length ? (
            <optgroup label="Inscriptions">
              {options.enrollments.map((e) => (
                <option key={e.id} value={`e:${e.id}`}>
                  {e.lastName} {e.firstName} · {e.reference}
                  {byId.get(e.sessionId) ? ` · ${byId.get(e.sessionId)!.code}` : ""}
                </option>
              ))}
            </optgroup>
          ) : null}
          {options.sessions.length ? (
            <optgroup label="Sessions">
              {options.sessions.map((s) => (
                <option key={s.id} value={`s:${s.id}`}>
                  {s.code} · {s.title} ({fmtDate(s.startDate)} au {fmtDate(s.endDate)})
                </option>
              ))}
            </optgroup>
          ) : null}
        </Select>
      </Field>
      <Field label="Thème de la formation" required htmlFor="pm-theme">
        <Input id="pm-theme" name="theme" required maxLength={200} placeholder="Anglais professionnel, Excel avancé…" />
      </Field>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Du" htmlFor="pm-start">
          <Input id="pm-start" name="startDate" type="date" />
        </Field>
        <Field label="Au" htmlFor="pm-end" help="Vide = même jour que le début.">
          <Input id="pm-end" name="endDate" type="date" />
        </Field>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Heures avec formateur" required htmlFor="pm-hours" help="Heures en visio ou présentiel uniquement (hors e-learning et certification).">
          <Input id="pm-hours" name="hours" inputMode="numeric" required placeholder="21" className="num" />
        </Field>
        <Field label="Taux horaire HT (€)" required htmlFor="pm-rate" help="Taux convenu avec le formateur. Montant = heures × taux.">
          <Input id="pm-rate" name="hourlyRateEuros" inputMode="decimal" required defaultValue={centsToInput(fixedTrainer?.hourlyRateCents)} placeholder="0,00" className="num" />
        </Field>
      </div>
      <Field label="Lieu ou modalité" htmlFor="pm-location">
        <Input id="pm-location" name="location" maxLength={200} placeholder="Visioconférence, adresse du site…" />
      </Field>
      <Field label="Notes internes" htmlFor="pm-notes">
        <Textarea id="pm-notes" name="notes" rows={2} maxLength={2000} />
      </Field>
    </FormDialog>
  );
}

function RespondDialog({ orgId, missionId }: { orgId: string; missionId: string }) {
  return (
    <FormDialog action={respondMissionAction} trigger="Réponse reçue" triggerVariant="secondary" triggerSize="sm" title="Enregistrer la réponse du formateur" description="Réponse reçue par téléphone ou par e-mail." submitLabel="Enregistrer">
      <input type="hidden" name="orgId" value={orgId} />
      <input type="hidden" name="missionId" value={missionId} />
      <Field label="Réponse" required htmlFor={`rd-${missionId}`}>
        <Select id={`rd-${missionId}`} name="decision" required defaultValue="acceptee">
          <option value="acceptee">Acceptée</option>
          <option value="refusee">Refusée</option>
        </Select>
      </Field>
      <Field label="Date du premier cours" htmlFor={`rf-${missionId}`} help="Si le formateur l'a déjà communiquée.">
        <Input id={`rf-${missionId}`} name="firstLessonDate" type="date" />
      </Field>
      <Field label="Commentaire" htmlFor={`rn-${missionId}`}>
        <Input id={`rn-${missionId}`} name="note" maxLength={1000} />
      </Field>
    </FormDialog>
  );
}

function ReplaceDialog({ orgId, row, trainers }: { orgId: string; row: MissionRow; trainers: MissionOptions["trainers"] }) {
  const m = row.m;
  const others = trainers.filter((t) => t.id !== m.trainerId);
  return (
    <FormDialog
      action={replaceMissionAction}
      trigger="Remplacer"
      triggerVariant="secondary"
      triggerSize="sm"
      title="Mobiliser un autre formateur"
      description={`Une nouvelle mission « ${m.theme} » est proposée au formateur choisi ; ${row.trainer.firstName} ${row.trainer.lastName} est informé(e) s'il ou elle n'avait pas répondu.`}
      submitLabel="Proposer au remplaçant"
      wide
    >
      <input type="hidden" name="orgId" value={orgId} />
      <input type="hidden" name="missionId" value={m.id} />
      <input type="hidden" name="reason" value={m.status === "refusee" ? "refusee" : "sans_reponse"} />
      <Field label="Nouveau formateur" required htmlFor={`rp-t-${m.id}`}>
        <Select id={`rp-t-${m.id}`} name="newTrainerId" required defaultValue="">
          <option value="" disabled>
            Choisir un formateur
          </option>
          {others.map((t) => (
            <option key={t.id} value={t.id}>
              {t.lastName} {t.firstName}
              {rateHint(t.hourlyRateCents)}
            </option>
          ))}
        </Select>
      </Field>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Heures avec formateur" htmlFor={`rp-h-${m.id}`} help={`Vide = ${m.hours} h (mission initiale).`}>
          <Input id={`rp-h-${m.id}`} name="hours" inputMode="numeric" className="num" />
        </Field>
        <Field label="Taux horaire HT (€)" required htmlFor={`rp-r-${m.id}`} help="Taux convenu avec le nouveau formateur.">
          <Input id={`rp-r-${m.id}`} name="hourlyRateEuros" inputMode="decimal" required placeholder="0,00" className="num" />
        </Field>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Du" htmlFor={`rp-s-${m.id}`} help="Vide = dates initiales.">
          <Input id={`rp-s-${m.id}`} name="startDate" type="date" defaultValue={m.startDate ?? ""} />
        </Field>
        <Field label="Au" htmlFor={`rp-e-${m.id}`}>
          <Input id={`rp-e-${m.id}`} name="endDate" type="date" defaultValue={m.endDate ?? ""} />
        </Field>
      </div>
    </FormDialog>
  );
}

function FirstLessonDialog({ orgId, missionId, current }: { orgId: string; missionId: string; current: string | null }) {
  return (
    <FormDialog action={setMissionFirstLessonAction} trigger={current ? "Modifier le 1er cours" : "Date du 1er cours"} triggerVariant="secondary" triggerSize="sm" title="Date du premier cours" description="Retour du formateur (date du premier cours et planning prévisionnel)." submitLabel="Enregistrer">
      <input type="hidden" name="orgId" value={orgId} />
      <input type="hidden" name="missionId" value={missionId} />
      <Field label="Date du premier cours" required htmlFor={`fl-${missionId}`}>
        <Input id={`fl-${missionId}`} name="firstLessonDate" type="date" required defaultValue={current ?? ""} />
      </Field>
    </FormDialog>
  );
}

function contractMissing(row: MissionRow): number {
  const g = row.contract?.generationData as { missing?: unknown } | null | undefined;
  return Array.isArray(g?.missing) ? g.missing.length : 0;
}

/** Actions disponibles pour une mission selon son statut et les droits de l'utilisateur. */
export function MissionActions({ orgId, row, canManage, canGenerate, canDownload, own, trainers }: { orgId: string; row: MissionRow; canManage: boolean; canGenerate: boolean; canDownload: boolean; own: boolean; trainers: MissionOptions["trainers"] }) {
  const m = row.m;
  const waiting = (m.status === "proposee" || m.status === "sans_reponse") && !m.replacedByMissionId;
  const replaceable = (m.status === "proposee" || m.status === "sans_reponse" || m.status === "refusee") && !m.replacedByMissionId;
  const missing = contractMissing(row);
  return (
    <div className="flex flex-wrap items-start gap-2">
      {waiting && (canManage || own) ? <RespondDialog orgId={orgId} missionId={m.id} /> : null}
      {replaceable && canManage ? <ReplaceDialog orgId={orgId} row={row} trainers={trainers} /> : null}
      {m.status === "acceptee" && (canManage || own) ? <FirstLessonDialog orgId={orgId} missionId={m.id} current={m.firstLessonDate} /> : null}
      {(m.status === "acceptee" || m.status === "terminee") && canManage && canGenerate ? (
        <ActionButton action={generateMissionContractAction} fields={{ orgId, missionId: m.id }} label={row.contract?.id ? "Régénérer le contrat" : "Générer le contrat"} />
      ) : null}
      {row.contract?.id && canDownload ? <ActionButton action={downloadDocumentAction} fields={{ orgId, documentId: row.contract.id }} label="Télécharger" variant="ghost" /> : null}
      {row.contract?.id && canManage && m.status === "acceptee" && row.contract.status === "genere" ? (
        <ActionButton
          action={sendMissionContractAction}
          fields={{ orgId, missionId: m.id, hasMissing: missing ? "1" : "0" }}
          label="Envoyer le contrat"
          variant="accent"
          confirm={{
            title: "Envoyer le contrat au formateur ?",
            description: `Vérifiez dates, durée et rémunération globale dans le PDF avant l'envoi. Le contrat passe au statut « transmis » et apparaît dans l'espace du formateur.${missing ? ` Il contient ${missing} champ(s) « à compléter » (clauses ou informations absentes des fiches).` : ""}`,
            confirmLabel: "Envoyer",
            ...(missing ? { checkbox: { name: "checkedMissing", label: "J'ai vérifié les champs à compléter avec le formateur" } } : {}),
          }}
        />
      ) : null}
      {m.status === "acceptee" && canManage ? (
        <ActionButton action={closeMissionAction} fields={{ orgId, missionId: m.id, status: "terminee" }} label="Terminer" variant="ghost" confirm={{ title: "Marquer la mission terminée ?", description: "À faire une fois le dernier cours effectué.", confirmLabel: "Marquer terminée" }} />
      ) : null}
      {(m.status === "proposee" || m.status === "acceptee" || m.status === "sans_reponse") && !m.replacedByMissionId && canManage ? (
        <ActionButton action={closeMissionAction} fields={{ orgId, missionId: m.id, status: "annulee" }} label="Annuler" variant="ghost" confirm={{ title: "Annuler cette mission ?", description: "La mission reste dans l'historique avec le statut « annulée ».", danger: true, confirmLabel: "Annuler la mission", input: { name: "reason", label: "Motif", placeholder: "Formation reportée, apprenant désisté…" } }} />
      ) : null}
    </div>
  );
}

/** Tableau des missions (page missions et fiche formateur). */
export function MissionsTable({ orgId, rows, canManage, canGenerate, canDownload, ownTrainerId, trainers, showTrainer = true, emptyTitle, emptyDescription }: { orgId: string; rows: MissionRow[]; canManage: boolean; canGenerate: boolean; canDownload: boolean; ownTrainerId: string | null; trainers: MissionOptions["trainers"]; showTrainer?: boolean; emptyTitle: string; emptyDescription?: string }) {
  const base = `/app/${orgId}`;
  if (!rows.length) return <EmptyState title={emptyTitle} description={emptyDescription} className="py-8" />;
  return (
    <Table>
      <thead>
        <tr>
          {showTrainer ? <Th>Formateur</Th> : null}
          <Th>Mission</Th>
          <Th>Dates</Th>
          <Th num>Heures</Th>
          <Th num>Taux HT</Th>
          <Th num>Montant HT</Th>
          <Th>Statut</Th>
          <Th>Actions</Th>
        </tr>
      </thead>
      <tbody>
        {rows.map((row) => {
          const m = row.m;
          return (
            <tr key={m.id}>
              {showTrainer ? (
                <Td>
                  <Link href={`${base}/formateurs/${row.trainer.id}`} className="font-medium text-ink hover:underline">
                    {row.trainer.firstName} {row.trainer.lastName}
                  </Link>
                  {!row.trainer.email ? <span className="block text-[12px] text-warn-ink">Sans e-mail</span> : null}
                </Td>
              ) : null}
              <Td>
                <p className="font-medium text-ink">{m.theme}</p>
                <p className="text-[12px] text-ink-3">
                  {row.learner?.lastName && row.enrollment?.id ? (
                    <Link href={`${base}/inscriptions/${row.enrollment.id}`} className="hover:underline">
                      {row.learner.firstName} {row.learner.lastName} · <span className="num">{row.enrollment.reference}</span>
                    </Link>
                  ) : row.session?.id ? (
                    <Link href={`${base}/sessions/${row.session.id}`} className="hover:underline">
                      <span className="num">{row.session.code}</span> · {row.session.title}
                    </Link>
                  ) : (
                    "Sans session rattachée"
                  )}
                  {m.location ? ` · ${m.location}` : ""}
                </p>
                <p className="text-[12px] text-ink-3">
                  Proposée le <span className="num">{fmtDate(m.proposedAt)}</span>
                  {m.reminderSentAt ? (
                    <>
                      , relancée le <span className="num">{fmtDate(m.reminderSentAt)}</span>
                    </>
                  ) : null}
                  {m.firstLessonDate ? (
                    <>
                      {" "}· 1er cours le <span className="num">{fmtDate(m.firstLessonDate)}</span>
                    </>
                  ) : null}
                </p>
              </Td>
              <Td className="num whitespace-nowrap">{m.startDate ? `${fmtDate(m.startDate)} au ${fmtDate(m.endDate ?? m.startDate)}` : "À convenir"}</Td>
              <Td num>{m.hours} h</Td>
              <Td num>{formatCents(m.hourlyRateCents)}</Td>
              <Td num>{formatCents(m.amountCents)}</Td>
              <Td>
                <div className="flex flex-col items-start gap-1">
                  <MissionStatusBadge status={m.status} />
                  {row.replacedBy?.lastName ? <span className="text-[12px] text-ink-3">Remplacé(e) par {row.replacedBy.firstName} {row.replacedBy.lastName}</span> : null}
                  {row.contract?.id ? (
                    <span className="flex items-center gap-1 text-[12px] text-ink-3">
                      Contrat v<span className="num">{row.contract.version}</span> <StatusBadge status={row.contract.status} />
                    </span>
                  ) : null}
                  {contractMissing(row) ? <span className="text-[12px] text-warn-ink">{contractMissing(row)} champ(s) à compléter</span> : null}
                </div>
              </Td>
              <Td>
                <MissionActions orgId={orgId} row={row} canManage={canManage} canGenerate={canGenerate} canDownload={canDownload} own={Boolean(ownTrainerId && ownTrainerId === m.trainerId)} trainers={trainers} />
              </Td>
            </tr>
          );
        })}
      </tbody>
    </Table>
  );
}
