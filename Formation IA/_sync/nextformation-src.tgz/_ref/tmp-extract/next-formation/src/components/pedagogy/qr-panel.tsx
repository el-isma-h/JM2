"use client";

import * as React from "react";
import { getSignCodeAction } from "@/server/actions/attendance";
import { Button } from "@/components/ui/button";
import { Notice } from "@/components/ui/surface";

/** QR code et code à 6 chiffres renouvelés toutes les 2 minutes (génération serveur, hash stocké). */
export function QrPanel({ orgId, periodId }: { orgId: string; periodId: string }) {
  const [state, setState] = React.useState<{ code?: string; expiresAt?: string; url?: string; qr?: string; error?: string } | null>(null);
  const [active, setActive] = React.useState(false);
  const [left, setLeft] = React.useState(0);

  const refresh = React.useCallback(async () => {
    const r = await getSignCodeAction(orgId, periodId);
    setState(r);
  }, [orgId, periodId]);

  React.useEffect(() => {
    if (!active) return;
    const first = setTimeout(() => void refresh(), 0);
    const id = setInterval(() => void refresh(), 2 * 60 * 1000);
    return () => {
      clearTimeout(first);
      clearInterval(id);
    };
  }, [active, refresh]);

  React.useEffect(() => {
    if (!state?.expiresAt) return;
    const tick = () => setLeft(Math.max(0, Math.round((new Date(state.expiresAt!).getTime() - Date.now()) / 1000)));
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [state?.expiresAt]);

  if (!active) {
    return (
      <div className="space-y-3">
        <p className="text-[13px] text-ink-2">Affichez un QR code et un code à 6 chiffres renouvelé toutes les 2 minutes : chaque apprenant signe depuis son téléphone avec son adresse e-mail.</p>
        <Button type="button" variant="secondary" onClick={() => setActive(true)}>
          Afficher le QR code
        </Button>
      </div>
    );
  }
  if (!state) return <p className="text-[13px] text-ink-3">Génération du code…</p>;
  if (state.error) return <Notice tone="danger">{state.error}</Notice>;
  return (
    <div className="flex flex-wrap items-center gap-6">
      {state.qr ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={state.qr} alt="QR code d'émargement" width={180} height={180} className="border border-line bg-white" />
      ) : null}
      <div>
        <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">Code de la période</p>
        <p className="num mt-1 font-display text-[44px] font-semibold tracking-[0.2em] text-ink">{state.code}</p>
        <p className="num mt-1 text-[12px] text-ink-3">Renouvelé dans {Math.floor(left / 60)}:{String(left % 60).padStart(2, "0")}</p>
        <p className="mt-2 break-all text-[12px] text-ink-2">{state.url}</p>
        <Button type="button" variant="ghost" size="sm" className="mt-2" onClick={() => void refresh()}>
          Nouveau code
        </Button>
      </div>
    </div>
  );
}
