"use client";

import { FormDialog } from "@/components/admin/form-dialog";
import type { ServerAction } from "@/components/admin/action-form";
import { Field, Input, Textarea } from "@/components/ui/field";
import { ACCEPT_ATTR, ALLOWED_LABEL } from "@/server/documents/upload-rules";

/** Dépôt d'un fichier (justificatif, pièce attendue) dans un dialogue, avec champs cachés et message facultatif. */
export function UploadDialog({
  action,
  trigger,
  title,
  description,
  fields,
  withNote,
  triggerVariant = "secondary",
}: {
  action: ServerAction;
  trigger: string;
  title: string;
  description?: string;
  fields: Record<string, string>;
  withNote?: { label: string; help?: string };
  triggerVariant?: "primary" | "secondary";
}) {
  const id = Object.values(fields).join("-").slice(0, 24);
  return (
    <FormDialog action={action} trigger={trigger} triggerVariant={triggerVariant} triggerSize="sm" title={title} description={description} submitLabel="Déposer">
      {Object.entries(fields).map(([k, v]) => (
        <input key={k} type="hidden" name={k} value={v} />
      ))}
      <Field label="Fichier" required htmlFor={`file-${id}`} help={`Formats acceptés : ${ALLOWED_LABEL}. 20 Mo maximum.`}>
        <Input id={`file-${id}`} name="file" type="file" accept={ACCEPT_ATTR} required className="h-auto py-2 file:mr-3 file:border-0 file:bg-transparent file:font-mono file:text-[10px] file:uppercase file:tracking-[0.18em] file:text-ink" />
      </Field>
      {withNote ? (
        <Field label={withNote.label} htmlFor={`note-${id}`} help={withNote.help}>
          <Textarea id={`note-${id}`} name="note" maxLength={500} />
        </Field>
      ) : null}
    </FormDialog>
  );
}
