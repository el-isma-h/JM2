"use client";

import { useActionState } from "react";
import { submitSurveyAction } from "@/server/actions/surveys";
import type { SurveyQuestion } from "@/server/quality/indicator-math";
import { Button } from "@/components/ui/button";
import { Label, Select, Textarea } from "@/components/ui/field";
import { Notice } from "@/components/ui/surface";
import type { ActionState } from "@/server/actions/auth";

/** Formulaire public d'enquête : sans session, une seule soumission par jeton, champs conservés en cas d'erreur. */
export function SurveyPublicForm({ token, questions }: { token: string; questions: SurveyQuestion[] }) {
  const [state, formAction, pending] = useActionState<ActionState, FormData>(submitSurveyAction, {});
  if (state.ok) {
    return (
      <Notice tone="ok" title="Merci">
        {state.message}
      </Notice>
    );
  }
  return (
    <form action={formAction} className="space-y-8">
      <input type="hidden" name="token" value={token} />
      {questions.map((q, i) => {
        const name = `q_${q.key}`;
        const id = `sq-${q.key}`;
        return (
          <fieldset key={q.key} className="border-t border-line pt-5">
            <legend className="sr-only">Question {i + 1}</legend>
            <Label htmlFor={q.type === "scale" || q.type === "yesno" ? undefined : id} required={q.required}>
              <span className="num mr-2">{i + 1}.</span>
              <span className="normal-case tracking-normal text-[14px] text-ink">{q.label}</span>
            </Label>
            {q.type === "scale" ? (
              <div className="flex flex-wrap gap-2" role="radiogroup" aria-label={q.label}>
                {Array.from({ length: q.max ?? 5 }, (_, k) => k + 1).map((v) => (
                  <label key={v} className="flex h-11 w-11 cursor-pointer items-center justify-center border border-line-strong font-mono text-[13px] text-ink transition-colors has-[:checked]:border-accent has-[:checked]:bg-accent has-[:checked]:text-accent-ink hover:border-ink">
                    <input type="radio" name={name} value={v} required={q.required} className="sr-only" />
                    {v}
                  </label>
                ))}
                <p className="w-full text-[11.5px] text-ink-3">1 = pas du tout, {q.max ?? 5} = tout à fait</p>
              </div>
            ) : q.type === "yesno" ? (
              <div className="flex gap-2" role="radiogroup" aria-label={q.label}>
                {(["oui", "non"] as const).map((v) => (
                  <label key={v} className="flex h-11 cursor-pointer items-center justify-center border border-line-strong px-5 font-sans text-[12px] uppercase tracking-[0.16em] text-ink has-[:checked]:border-accent has-[:checked]:bg-accent has-[:checked]:text-accent-ink hover:border-ink">
                    <input type="radio" name={name} value={v} required={q.required} className="sr-only" />
                    {v}
                  </label>
                ))}
              </div>
            ) : q.type === "choice" ? (
              <Select id={id} name={name} required={q.required} defaultValue="">
                <option value="">Choisir…</option>
                {(q.options ?? []).map((o) => (
                  <option key={o} value={o}>
                    {o}
                  </option>
                ))}
              </Select>
            ) : (
              <Textarea id={id} name={name} required={q.required} maxLength={4000} />
            )}
          </fieldset>
        );
      })}
      {state.error ? <Notice tone="danger">{state.error}</Notice> : null}
      <div className="flex items-center justify-between gap-4 border-t border-line pt-6">
        <p className="text-[12px] text-ink-3">Vos réponses sont enregistrées une seule fois et ne peuvent plus être modifiées ensuite.</p>
        <Button type="submit" loading={pending}>
          Envoyer mes réponses
        </Button>
      </div>
    </form>
  );
}
