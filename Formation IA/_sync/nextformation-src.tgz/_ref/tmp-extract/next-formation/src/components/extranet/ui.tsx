import Link from "next/link";
import { StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { EmptyState, Stat } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { fmtDate } from "@/lib/dates";
import { fmtMinutes } from "@/lib/time";
import type { HoursAggregate } from "@/server/planning/hours";
import type { SlotWithPeriods } from "@/server/extranet/queries";

export const categoryLabels: Record<string, string> = {
  convention: "Convention",
  contrat: "Contrat",
  cerfa: "Cerfa",
  convocation: "Convocation",
  annexe_parcours: "Annexe du parcours",
  programme: "Programme",
  reglement_interieur: "Règlement intérieur",
  attestation: "Attestation",
  certificat_realisation: "Certificat de réalisation",
  feuille_emargement: "Feuille d'émargement",
  livret: "Livret",
  releve_heures: "Relevé d'heures",
  evaluation: "Évaluation",
  enquete: "Enquête",
  devis: "Devis",
  facture: "Facture",
  avoir: "Avoir",
  rib: "RIB",
  piece_identite: "Pièce d'identité",
  cv: "CV",
  diplome: "Diplôme",
  justificatif: "Justificatif",
  kbis: "Kbis",
  charte: "Charte",
  plan_acces: "Plan d'accès",
  preuve: "Preuve",
  procedure: "Procédure",
  bpf: "BPF",
  export: "Export",
  autre: "Autre",
};

/** Types d'entrées du livret. */
export const recordKindLabels: Record<string, string> = {
  objectif: "Objectif",
  activite: "Activité",
  competence: "Compétence",
  bilan: "Bilan",
  observation: "Observation",
  entreprise: "Entreprise",
  aide: "Aide / accompagnement",
};

/** Heure Postgres `HH:mm:ss` → `HH:mm`. */
export const hhmm = (t: string | null | undefined) => (t ? t.slice(0, 5) : "");

export const partLabels: Record<string, string> = { matin: "Matin", apres_midi: "Après-midi", journee: "Journée", soir: "Soir" };

type DocRow = { id: string; title: string; category: string; status: string; fileName: string; createdAt: Date; version: number };

/** Liste de documents avec lien de téléchargement (route de l'extranet qui vérifie le périmètre). */
export function DocumentTable({ docs, downloadBase, emptyTitle, emptyDescription }: { docs: DocRow[]; downloadBase: string; emptyTitle: string; emptyDescription: string }) {
  if (!docs.length) return <EmptyState title={emptyTitle} description={emptyDescription} />;
  return (
    <Table>
      <thead>
        <tr>
          <Th>Document</Th>
          <Th>Type</Th>
          <Th>État</Th>
          <Th>Date</Th>
          <Th className="text-right">Fichier</Th>
        </tr>
      </thead>
      <tbody>
        {docs.map((d) => (
          <tr key={d.id}>
            <Td>
              <span className="font-medium text-ink">{d.title}</span>
              {d.version > 1 ? <span className="num ml-2 text-[11px] text-ink-3">v{d.version}</span> : null}
            </Td>
            <Td>{categoryLabels[d.category] ?? d.category}</Td>
            <Td>
              <StatusBadge status={d.status} />
            </Td>
            <Td className="num">{fmtDate(d.createdAt)}</Td>
            <Td className="text-right">
              <Button asChild variant="secondary" size="sm">
                <a href={`${downloadBase}/${d.id}/telecharger`}>Télécharger</a>
              </Button>
            </Td>
          </tr>
        ))}
      </tbody>
    </Table>
  );
}

/** Compteurs d'heures distincts (F05/F06) : jamais additionnés. */
export function HoursStats({ hours, className }: { hours: HoursAggregate; className?: string }) {
  return (
    <div className={className ?? "grid grid-cols-2 gap-6 px-5 py-5 sm:grid-cols-4"}>
      <Stat label="Prévues" value={<span className="num">{fmtMinutes(hours.planned)}</span>} hint="Durée contractuelle" />
      <Stat label="Programmées" value={<span className="num">{fmtMinutes(hours.scheduled)}</span>} hint="Séances planifiées" />
      <Stat label="Effectuées" value={<span className="num">{fmtMinutes(hours.done)}</span>} hint="Présences comptées" />
      <Stat label="Justifiées" value={<span className="num">{fmtMinutes(hours.justified)}</span>} hint="Absences justifiées" />
    </div>
  );
}

/** Tableau de séances (planning apprenant / formateur). */
export function SlotTable({ slots, emptyTitle, emptyDescription, periodHref, showSession = true }: { slots: SlotWithPeriods[]; emptyTitle: string; emptyDescription: string; periodHref?: (periodId: string) => string; showSession?: boolean }) {
  if (!slots.length) return <EmptyState title={emptyTitle} description={emptyDescription} />;
  return (
    <Table>
      <thead>
        <tr>
          <Th>Date</Th>
          {showSession ? <Th>Session</Th> : null}
          <Th>Périodes</Th>
          <Th>Lieu</Th>
          <Th>Formateur</Th>
          <Th>État</Th>
        </tr>
      </thead>
      <tbody>
        {slots.map((s) => (
          <tr key={s.slot.id}>
            <Td className="num whitespace-nowrap">{fmtDate(s.slot.date, "EEE d MMM yyyy")}</Td>
            {showSession ? (
              <Td>
                <span className="font-medium text-ink">{s.slot.title ?? s.moduleTitle ?? s.sessionTitle}</span>
                {s.slot.title || s.moduleTitle ? <span className="block text-[12px] text-ink-3">{s.sessionTitle}</span> : null}
              </Td>
            ) : null}
            <Td>
              <ul className="space-y-1">
                {s.periods.map((p) => (
                  <li key={p.id} className="flex flex-wrap items-center gap-2 text-[13px]">
                    <span className="num">
                      {partLabels[p.part] ?? p.part} {hhmm(p.startTime)} - {hhmm(p.endTime)}
                    </span>
                    <StatusBadge status={p.status} />
                    {periodHref ? (
                      <Link href={periodHref(p.id)} className="text-accent underline-offset-4 hover:underline">
                        Émargement
                      </Link>
                    ) : null}
                  </li>
                ))}
                {!s.periods.length ? <li className="text-[12.5px] text-ink-3">Horaires à préciser par l&apos;organisme</li> : null}
              </ul>
            </Td>
            <Td>
              {s.siteName ?? (s.slot.modality === "distanciel" ? "À distance" : "-")}
              {s.roomName ? <span className="block text-[12px] text-ink-3">{s.roomName}</span> : null}
            </Td>
            <Td>{s.trainerName ?? "-"}</Td>
            <Td>
              <StatusBadge status={s.slot.status} />
            </Td>
          </tr>
        ))}
      </tbody>
    </Table>
  );
}
