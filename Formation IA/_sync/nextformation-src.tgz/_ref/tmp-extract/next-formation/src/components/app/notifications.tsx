"use client";

import * as React from "react";
import Link from "next/link";
import * as Popover from "@radix-ui/react-popover";
import { Bell } from "@phosphor-icons/react";
import { ActionButton } from "@/components/admin/action-form";
import { markNotificationsReadAction } from "@/server/actions/agenda";
import { cn } from "@/lib/utils";

export type NotificationItem = { id: string; title: string; body: string | null; href: string | null; kind: string; createdAt: string; read: boolean };

/** Cloche de l'en-tête : notifications internes non lues (relais, affectations, échéances). */
export function Notifications({ orgId, items, unread }: { orgId: string; items: NotificationItem[]; unread: number }) {
  const [open, setOpen] = React.useState(false);
  return (
    <Popover.Root open={open} onOpenChange={setOpen}>
      <Popover.Trigger asChild>
        <button type="button" className="relative p-2 text-ink-3 transition-colors hover:text-ink" aria-label={unread ? `${unread} notification(s) non lue(s)` : "Notifications"}>
          <Bell size={18} />
          {unread ? <span className="absolute -right-0.5 top-0.5 min-w-[16px] border border-bg bg-accent px-1 text-center font-mono text-[9px] leading-[14px] text-accent-ink">{unread > 99 ? "99+" : unread}</span> : null}
        </button>
      </Popover.Trigger>
      <Popover.Portal>
        <Popover.Content align="end" sideOffset={8} className="z-40 w-[360px] max-w-[calc(100vw-24px)] border border-line-strong bg-bg shadow-[var(--shadow-2)] focus:outline-none">
          <div className="flex items-center justify-between border-b border-line px-4 py-3">
            <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">Notifications</p>
            {unread ? <ActionButton action={markNotificationsReadAction} fields={{ orgId }} label="Tout marquer lu" variant="ghost" /> : null}
          </div>
          {items.length ? (
            <ul className="max-h-[60dvh] divide-y divide-line overflow-y-auto">
              {items.map((n) => (
                <li key={n.id} className={cn("px-4 py-3 text-[13px]", n.read ? "text-ink-3" : "text-ink")}>
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      {n.href ? (
                        <Link href={n.href} className="font-medium hover:underline" onClick={() => setOpen(false)}>
                          {n.title}
                        </Link>
                      ) : (
                        <p className="font-medium">{n.title}</p>
                      )}
                      {n.body ? <p className="mt-0.5 text-[12.5px] text-ink-2">{n.body}</p> : null}
                      <p className="num mt-1 text-[11px] text-ink-3">{n.createdAt}</p>
                    </div>
                    {!n.read ? <ActionButton action={markNotificationsReadAction} fields={{ orgId, notificationId: n.id }} label="Lu" variant="ghost" /> : null}
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <p className="px-4 py-6 text-center text-[13px] text-ink-2">Aucune notification.</p>
          )}
          <div className="border-t border-line px-4 py-2 text-right">
            <Link href={`/app/${orgId}/taches`} className="font-mono text-[10px] uppercase tracking-[0.18em] text-ink-3 hover:text-ink" onClick={() => setOpen(false)}>
              Mes tâches
            </Link>
          </div>
        </Popover.Content>
      </Popover.Portal>
    </Popover.Root>
  );
}
