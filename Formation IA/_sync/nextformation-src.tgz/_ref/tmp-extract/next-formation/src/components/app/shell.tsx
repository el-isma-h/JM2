"use client";

import * as React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import * as Icons from "@phosphor-icons/react";
import { cn } from "@/lib/utils";
import type { NavItem } from "./nav";
import { Button } from "@/components/ui/button";

function subscribeTheme(cb: () => void) {
  const obs = new MutationObserver(cb);
  obs.observe(document.documentElement, { attributes: true, attributeFilter: ["class"] });
  return () => obs.disconnect();
}

export function ThemeToggle() {
  const dark = React.useSyncExternalStore(
    subscribeTheme,
    () => document.documentElement.classList.contains("dark"),
    () => false,
  );
  return (
    <button
      type="button"
      onClick={() => {
        const next = !dark;
        document.documentElement.classList.toggle("dark", next);
        try {
          localStorage.setItem("nextformation-theme", next ? "dark" : "light");
        } catch {}
      }}
      className="p-2 text-ink-3 transition-colors hover:text-ink"
      aria-label={dark ? "Passer en mode clair" : "Passer en mode sombre"}
      title={dark ? "Mode clair" : "Mode sombre"}
    >
      {dark ? <Icons.Sun size={16} /> : <Icons.Moon size={16} />}
    </button>
  );
}

export function AppShell({
  base,
  items,
  brand,
  context,
  user,
  children,
  topRight,
}: {
  base: string;
  items: NavItem[];
  brand: React.ReactNode;
  context?: React.ReactNode;
  user: { name: string; email: string; isAdmin: boolean };
  children: React.ReactNode;
  topRight?: React.ReactNode;
}) {
  const pathname = usePathname();
  const [open, setOpen] = React.useState(false);
  const groups = React.useMemo(() => {
    const out: { group?: string; items: NavItem[] }[] = [];
    for (const it of items) {
      const last = out[out.length - 1];
      if (last && last.group === it.group) last.items.push(it);
      else out.push({ group: it.group, items: [it] });
    }
    return out;
  }, [items]);

  const isActive = (href: string) => {
    const full = `${base}${href}`;
    return href === "" ? pathname === full : pathname === full || pathname.startsWith(`${full}/`);
  };

  let n = 0;
  const nav = (
    <nav className="flex-1 overflow-y-auto px-5 py-4" aria-label="Navigation principale">
      {groups.map((g, gi) => (
        <div key={gi} className={cn(gi > 0 && "mt-6")}>
          {g.group ? <p className="etiquette mb-2">{g.group}</p> : null}
          <ul>
            {g.items.map((it) => {
              n += 1;
              const active = isActive(it.href);
              return (
                <li key={it.href}>
                  <Link
                    href={`${base}${it.href}`}
                    onClick={() => setOpen(false)}
                    className={cn(
                      "flex items-center gap-3 border-b border-line py-2.5 font-mono text-[10px] uppercase tracking-[0.12em] transition-colors duration-500",
                      active ? "text-ink" : "text-ink-3 hover:text-ink",
                    )}
                    aria-current={active ? "page" : undefined}
                  >
                    <span className={cn("block h-px w-3 shrink-0 transition-colors duration-500", active ? "bg-accent" : "bg-transparent")} />
                    <span className="w-4 shrink-0 opacity-50">{String(n).padStart(2, "0")}</span>
                    <span className="truncate">{it.label}</span>
                  </Link>
                </li>
              );
            })}
          </ul>
        </div>
      ))}
    </nav>
  );

  const initials = user.name
    .split(" ")
    .map((s) => s[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();

  const userBlock = (
    <div className="border-t border-line px-5 py-4">
      <div className="flex items-center gap-3">
        <div className="flex h-8 w-8 shrink-0 items-center justify-center border border-line-strong font-mono text-[10px] font-medium tracking-[0.1em] text-ink">{initials}</div>
        <div className="min-w-0 flex-1">
          <p className="truncate text-[13px] font-medium text-ink">{user.name}</p>
          <p className="truncate text-[11px] text-ink-3">{user.email}</p>
        </div>
        <ThemeToggle />
      </div>
      <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 font-mono text-[10px] uppercase tracking-[0.18em]">
        {user.isAdmin ? (
          <Link href="/admin" className="text-ink-3 transition-colors hover:text-ink">
            Administration
          </Link>
        ) : null}
        <form action="/deconnexion" method="post">
          <button type="submit" className="text-ink-3 transition-colors hover:text-ink">
            Déconnexion
          </button>
        </form>
      </div>
    </div>
  );

  return (
    <div className="flex min-h-[100dvh]">
      <aside className="sticky top-0 hidden h-[100dvh] w-[272px] shrink-0 flex-col border-r border-line bg-bg-sunken lg:flex">
        <div className="flex h-16 items-center border-b border-line px-5">{brand}</div>
        {context ? <div className="border-b border-line px-5 py-4">{context}</div> : null}
        {nav}
        {userBlock}
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-20 flex h-16 items-center gap-3 border-b border-line bg-bg/92 px-4 backdrop-blur-sm lg:px-10">
          <button type="button" className="p-1.5 text-ink-2 lg:hidden" onClick={() => setOpen(true)} aria-label="Ouvrir le menu">
            <Icons.List size={20} />
          </button>
          <div className="min-w-0 flex-1 lg:hidden">{brand}</div>
          <div className="hidden min-w-0 flex-1 lg:block" />
          {topRight}
        </header>
        <main className="mx-auto w-full max-w-[1320px] flex-1 px-4 py-8 lg:px-10 lg:py-10">{children}</main>
      </div>

      {open ? (
        <div className="fixed inset-0 z-40 lg:hidden" role="dialog" aria-modal="true">
          <div className="absolute inset-0 bg-encre/60" onClick={() => setOpen(false)} />
          <div className="absolute inset-y-0 left-0 flex w-[290px] flex-col bg-bg-sunken shadow-[var(--shadow-2)]">
            <div className="flex h-16 items-center justify-between border-b border-line px-5">
              {brand}
              <button type="button" onClick={() => setOpen(false)} className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3 hover:text-ink" aria-label="Fermer le menu">
                [ Fermer ]
              </button>
            </div>
            {context ? <div className="border-b border-line px-5 py-4">{context}</div> : null}
            {nav}
            <div className="border-t border-line p-4">
              <form action="/deconnexion" method="post">
                <Button type="submit" variant="secondary" size="sm" className="w-full">
                  Déconnexion
                </Button>
              </form>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
