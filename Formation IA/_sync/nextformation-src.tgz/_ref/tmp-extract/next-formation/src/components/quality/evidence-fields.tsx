import { Field, Input, Select, Textarea } from "@/components/ui/field";
import { ACCEPT_ATTR, ALLOWED_LABEL } from "@/server/documents/upload-rules";
import { levelLabels } from "@/server/quality/labels";
import type { IndicatorDef } from "@/server/quality/referential-data";

export type SessionOpt = { id: string; code: string; title: string };
export type EnrollmentOpt = { id: string; reference: string; firstName: string; lastName: string };
export type ProgramOpt = { id: string; code: string; title: string };
export type DocumentOpt = { id: string; title: string; category: string };

/** Champs d'une preuve manuelle : indicateur, niveau, date, rattachements et source réelle (document existant ou fichier déposé). */
export function EvidenceFields({
  indicators,
  sessions,
  enrollments,
  programs,
  documents,
  today,
  defaults,
  idPrefix = "ev",
}: {
  indicators: IndicatorDef[];
  sessions: SessionOpt[];
  enrollments: EnrollmentOpt[];
  programs: ProgramOpt[];
  documents: DocumentOpt[];
  today: string;
  defaults?: { indicatorCode?: string; level?: string; sessionId?: string | null; enrollmentId?: string | null; programId?: string | null; title?: string };
  idPrefix?: string;
}) {
  return (
    <>
      <Field label="Indicateur" required htmlFor={`${idPrefix}-ind`}>
        <Select id={`${idPrefix}-ind`} name="indicatorCode" defaultValue={defaults?.indicatorCode ?? ""} required>
          <option value="">Choisir…</option>
          {indicators.map((i) => (
            <option key={i.code} value={i.code}>
              {i.number}. {i.label.slice(0, 90)}
              {i.label.length > 90 ? "…" : ""}
            </option>
          ))}
        </Select>
      </Field>
      <Field label="Niveau de preuve" required htmlFor={`${idPrefix}-level`} help="Individuel : relié à une inscription. Collectif : session ou programme (compté une fois, jamais par apprenant). Organisationnel : l'organisme.">
        <Select id={`${idPrefix}-level`} name="level" defaultValue={defaults?.level ?? "organisationnel"} required>
          {(["individuel", "collectif", "organisationnel"] as const).map((l) => (
            <option key={l} value={l}>
              {levelLabels[l]}
            </option>
          ))}
        </Select>
      </Field>
      <Field label="Intitulé" required htmlFor={`${idPrefix}-title`}>
        <Input id={`${idPrefix}-title`} name="title" defaultValue={defaults?.title ?? ""} required maxLength={200} />
      </Field>
      <Field label="Date de la preuve" required htmlFor={`${idPrefix}-date`} help="Date de l'action réelle (signature, séance, publication). Jamais dans le futur.">
        <Input id={`${idPrefix}-date`} name="evidenceDate" type="date" defaultValue={today} max={today} required />
      </Field>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Session" htmlFor={`${idPrefix}-session`}>
          <Select id={`${idPrefix}-session`} name="sessionId" defaultValue={defaults?.sessionId ?? ""}>
            <option value="">Aucune</option>
            {sessions.map((s) => (
              <option key={s.id} value={s.id}>
                {s.code} : {s.title}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Inscription" htmlFor={`${idPrefix}-enr`}>
          <Select id={`${idPrefix}-enr`} name="enrollmentId" defaultValue={defaults?.enrollmentId ?? ""}>
            <option value="">Aucune</option>
            {enrollments.map((e) => (
              <option key={e.id} value={e.id}>
                {e.lastName.toUpperCase()} {e.firstName} ({e.reference})
              </option>
            ))}
          </Select>
        </Field>
      </div>
      <Field label="Programme" htmlFor={`${idPrefix}-prog`}>
        <Select id={`${idPrefix}-prog`} name="programId" defaultValue={defaults?.programId ?? ""}>
          <option value="">Aucun</option>
          {programs.map((p) => (
            <option key={p.id} value={p.id}>
              {p.code} : {p.title}
            </option>
          ))}
        </Select>
      </Field>
      <Field label="Document existant" htmlFor={`${idPrefix}-doc`} help="Une preuve est toujours reliée à une action réelle : choisissez un document existant ou déposez un fichier ci-dessous.">
        <Select id={`${idPrefix}-doc`} name="documentId" defaultValue="">
          <option value="">Aucun (déposer un fichier)</option>
          {documents.map((d) => (
            <option key={d.id} value={d.id}>
              {d.title} ({d.category})
            </option>
          ))}
        </Select>
      </Field>
      <Field label="Fichier à déposer" htmlFor={`${idPrefix}-file`} help={`Formats : ${ALLOWED_LABEL}. 20 Mo maximum. Enregistré comme document de catégorie « preuve ».`}>
        <Input id={`${idPrefix}-file`} name="file" type="file" accept={ACCEPT_ATTR} className="h-auto py-2" />
      </Field>
      <Field label="Note" htmlFor={`${idPrefix}-note`}>
        <Textarea id={`${idPrefix}-note`} name="note" maxLength={2000} />
      </Field>
    </>
  );
}
