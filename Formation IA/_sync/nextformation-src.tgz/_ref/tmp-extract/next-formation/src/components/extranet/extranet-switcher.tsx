"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { CaretUpDown } from "@phosphor-icons/react";
import { Select } from "@/components/ui/field";
import { switchExtranetOrgAction } from "@/server/actions/self";

/** Sélecteur d'organisme pour un utilisateur rattaché à plusieurs organismes (apprenant, entreprise ou formateur). */
export function ExtranetSwitcher({ choices, currentId, subtitle, isDemo }: { choices: { orgId: string; orgName: string }[]; currentId: string; subtitle?: string; isDemo?: boolean }) {
  const router = useRouter();
  const [pending, startTransition] = React.useTransition();
  if (choices.length <= 1) {
    return (
      <div className="px-2">
        <p className="truncate text-[13px] font-medium text-ink">{choices[0]?.orgName ?? "Organisme"}</p>
        {subtitle ? <p className="text-[11.5px] text-ink-3">{subtitle}</p> : null}
        {isDemo ? <p className="text-[11.5px] text-warn-ink">Démonstration (données fictives)</p> : null}
      </div>
    );
  }
  return (
    <div className="relative">
      <Select
        value={currentId}
        disabled={pending}
        aria-label="Changer d'organisme"
        className="h-9 pr-8 text-[13px] font-medium"
        onChange={(e) => {
          const fd = new FormData();
          fd.set("orgId", e.target.value);
          startTransition(async () => {
            await switchExtranetOrgAction({}, fd);
            router.refresh();
          });
        }}
      >
        {choices.map((c) => (
          <option key={c.orgId} value={c.orgId}>
            {c.orgName}
          </option>
        ))}
      </Select>
      <CaretUpDown size={14} className="pointer-events-none absolute right-2.5 top-1/2 -translate-y-1/2 text-ink-3" />
      {subtitle ? <p className="mt-1.5 px-1 text-[11.5px] text-ink-3">{subtitle}</p> : null}
    </div>
  );
}
