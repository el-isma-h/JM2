import { Badge, type Tone } from "@/components/ui/badge";
import { surveyStatusLabels } from "@/server/quality/labels";

const tones: Record<string, Tone> = { brouillon: "neutral", active: "ok", cloturee: "neutral" };

export function SurveyStatusBadge({ status }: { status: string }) {
  return <Badge tone={tones[status] ?? "neutral"}>{surveyStatusLabels[status] ?? status}</Badge>;
}
