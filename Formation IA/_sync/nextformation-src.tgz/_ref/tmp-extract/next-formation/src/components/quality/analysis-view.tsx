import Link from "next/link";
import { StatusBadge } from "@/components/ui/badge";
import { Notice, Stat } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { fmtDate, fmtDateTime } from "@/lib/dates";
import type { Control, Summary } from "@/server/quality/engine";
import { QUALIOPI_CRITERIA_LABELS } from "@/server/quality/referential-data";
import { levelShort } from "@/server/quality/labels";

type EvidenceLite = { id: string; title: string; status: string; evidenceDate: string | null; level: string; invalidationReason: string | null };

/** Synthèse chiffrée d'une photographie : les compteurs n'attestent jamais la conformité. */
export function AnalysisSummary({ summary, referenceDate, engineVersion, analysedAt }: { summary: Summary; referenceDate: string; engineVersion: string; analysedAt: Date }) {
  return (
    <div>
      <div className="grid grid-cols-2 gap-6 px-5 py-5 sm:grid-cols-3 lg:grid-cols-6">
        <Stat label="Indicateurs" value={<span className="num">{summary.total}</span>} />
        <Stat label="Prouvés" value={<span className="num">{summary.proven}</span>} />
        <Stat label="Absents" value={<span className="num">{summary.missing}</span>} />
        <Stat label="À examiner" value={<span className="num">{summary.humanReview}</span>} hint="Appréciation humaine" />
        <Stat label="Non applicables" value={<span className="num">{summary.notApplicable}</span>} />
        <Stat label="Preuves détectées" value={<span className="num">{summary.coveragePct} %</span>} hint="prouvés / applicables" />
      </div>
      <div className="border-t border-line px-5 py-3 text-[12.5px] text-ink-2">
        <span className="font-medium text-ink">{summary.disclaimer}</span> Date de référence <span className="num">{fmtDate(referenceDate)}</span>, moteur <span className="num">{engineVersion}</span>, photographie du <span className="num">{fmtDateTime(analysedAt)}</span>.
      </div>
    </div>
  );
}

export function StaleNotice({ orgId, scopeFields }: { orgId: string; scopeFields?: React.ReactNode }) {
  return (
    <Notice tone="warn" title="Preuves modifiées depuis l'analyse">
      Des preuves du périmètre ont été ajoutées, invalidées ou remplacées après cette photographie. Celle-ci reste inchangée : relancez une analyse pour en tenir compte.
      {scopeFields}
      <Link href={`/app/${orgId}/qualite`} className="ml-2 underline underline-offset-4">
        Tableau de bord qualité
      </Link>
    </Notice>
  );
}

/** Tableau complet des contrôles, groupés par critère, avec preuves reliées (lecture seule : une photographie ne se modifie pas). */
export function ControlsTable({ controls, evidences, orgId }: { controls: Control[]; evidences: Map<string, EvidenceLite>; orgId: string }) {
  const criteria = [...new Set(controls.map((c) => c.criterion))].sort((a, b) => a - b);
  return (
    <div className="divide-y divide-line">
      {criteria.map((n) => {
        const rows = controls.filter((c) => c.criterion === n).sort((a, b) => a.number - b.number);
        return (
          <section key={n}>
            <div className="px-5 py-3">
              <p className="etiquette text-ink-3">Critère {n}</p>
              <h3 className="mt-1 text-[14px] text-ink">{QUALIOPI_CRITERIA_LABELS[n] ?? ""}</h3>
            </div>
            <Table>
              <thead>
                <tr>
                  <Th className="w-16">N°</Th>
                  <Th>Indicateur</Th>
                  <Th>Niveau</Th>
                  <Th>Statut</Th>
                  <Th num>Preuves</Th>
                  <Th>Explication et preuves reliées</Th>
                </tr>
              </thead>
              <tbody>
                {rows.map((c) => (
                  <tr key={c.indicator} id={c.indicator}>
                    <Td className="num align-top">{c.number}</Td>
                    <Td className="max-w-[34ch] align-top text-[13px]">{c.label}</Td>
                    <Td className="align-top whitespace-nowrap">{levelShort[c.level]}</Td>
                    <Td className="align-top">
                      <StatusBadge status={c.status} />
                      {c.requiresHuman ? <p className="mt-1 text-[11px] text-ink-3">Appréciation humaine requise</p> : null}
                    </Td>
                    <Td num className="align-top">
                      {c.evidenceCount}
                    </Td>
                    <Td className="align-top text-[12.5px] text-ink-2">
                      <p>{c.note}</p>
                      {c.evidenceIds.length ? (
                        <ul className="mt-1.5 space-y-0.5">
                          {c.evidenceIds.map((id) => {
                            const e = evidences.get(id);
                            return (
                              <li key={id}>
                                <Link href={`/app/${orgId}/qualite/preuves?evidence=${id}`} className="text-ink underline-offset-4 hover:underline">
                                  {e?.title ?? "Preuve"}
                                </Link>{" "}
                                <span className="num text-ink-3">{e?.evidenceDate ? fmtDate(e.evidenceDate) : ""}</span>
                                {e && e.status !== "valide" ? <StatusBadge status={e.status} className="ml-1" /> : null}
                              </li>
                            );
                          })}
                        </ul>
                      ) : null}
                    </Td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </section>
        );
      })}
    </div>
  );
}
