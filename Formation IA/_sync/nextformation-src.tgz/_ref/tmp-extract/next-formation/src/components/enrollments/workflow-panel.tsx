import Link from "next/link";
import { roleLabels, type OrgRole } from "@/server/authz";
import { workflowProgress, type WorkflowStepProgress } from "@/server/workflows/service";
import { WORKFLOW_CODES, workflowLabels } from "@/server/workflows/templates";
import { applyWorkflowAction, completeWorkflowStepAction } from "@/server/actions/workflows";
import { ActionButton, ActionForm } from "@/components/admin/action-form";
import { Badge, type Tone } from "@/components/ui/badge";
import { Field, Select } from "@/components/ui/field";
import { EmptyState, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { fmtDate, fmtDateTime } from "@/lib/dates";

const statusView: Record<WorkflowStepProgress["status"], { label: string; tone: Tone }> = {
  a_faire: { label: "À faire", tone: "warn" },
  en_cours: { label: "En cours", tone: "info" },
  bloquee: { label: "Bloquée", tone: "danger" },
  terminee: { label: "Faite", tone: "ok" },
  annulee: { label: "Annulée", tone: "neutral" },
  absente: { label: "Non créée", tone: "neutral" },
};

const edofLabels: Record<string, string> = { valide: "Commande validée", entree: "Entrée déclarée", sortie: "Sortie déclarée", facture: "Facturé" };
const kairosLabels: Record<string, string> = { transmis: "Devis transmis", valide_de: "Validé par le demandeur", accorde: "Accordé", entree: "Entrée déclarée", sortie: "Sortie déclarée" };

function roleLabel(role: string) {
  return role in roleLabels ? roleLabels[role as OrgRole] : role;
}

/**
 * Panneau « Parcours » du dossier d'inscription : étapes du parcours de financement, statut de leur tâche,
 * échéance, bouton « Marquer fait » et changement de parcours.
 */
export async function WorkflowPanel({ orgId, enrollmentId, canManage }: { orgId: string; enrollmentId: string; canManage: boolean }) {
  const progress = await workflowProgress(orgId, enrollmentId);
  if (!progress) return null;
  const changeForm = canManage ? (
    <ActionForm
      action={applyWorkflowAction}
      submitLabel={progress.code ? "Changer de parcours" : "Appliquer le parcours"}
      submitVariant="secondary"
      submitSize="sm"
      className="space-y-3"
      confirm={{
        title: progress.code ? "Changer de parcours" : "Appliquer un parcours",
        description: progress.code
          ? "Les étapes faites sont conservées. Les étapes ouvertes absentes du nouveau parcours sont annulées (jamais supprimées) ; le changement est journalisé."
          : "Une tâche de relais est créée pour chaque étape, avec responsable et échéance.",
        confirmLabel: "Confirmer",
      }}
    >
      <input type="hidden" name="orgId" value={orgId} />
      <input type="hidden" name="enrollmentId" value={enrollmentId} />
      <Field label="Parcours" htmlFor={`wf-code-${enrollmentId}`} help={progress.suggested ? `Suggéré d'après le contrat et les financements : ${workflowLabels[progress.suggested]}.` : "Aucun parcours ne peut être déduit du contrat ni des financements connus."}>
        <Select id={`wf-code-${enrollmentId}`} name="code" defaultValue={progress.code ?? progress.suggested ?? WORKFLOW_CODES[0]}>
          {WORKFLOW_CODES.map((c) => (
            <option key={c} value={c}>
              {workflowLabels[c]}
            </option>
          ))}
        </Select>
      </Field>
    </ActionForm>
  ) : null;

  if (!progress.code || !progress.template) {
    return (
      <Panel>
        <PanelHeader title="Parcours" description="Parcours de financement : étapes, responsables et échéances." />
        <div className="p-5">
          <EmptyState
            title="Aucun parcours appliqué"
            description={canManage ? "Choisissez le parcours de financement pour créer les tâches de suivi de ce dossier." : "Un gestionnaire des inscriptions peut appliquer le parcours de financement."}
            action={changeForm}
          />
        </div>
      </Panel>
    );
  }

  const e = progress.enrollment;
  const facts = [
    e.edofStatus ? `EDOF : ${edofLabels[e.edofStatus] ?? e.edofStatus}` : null,
    e.edofEntryAt ? `entrée ${fmtDate(e.edofEntryAt)}` : null,
    e.edofExitAt ? `sortie ${fmtDate(e.edofExitAt)}` : null,
    e.kairosStatus ? `Kairos : ${kairosLabels[e.kairosStatus] ?? e.kairosStatus}${e.kairosDevisRef ? ` (devis ${e.kairosDevisRef})` : ""}` : null,
    e.elearningAccessSentAt ? `accès e-learning envoyés le ${fmtDateTime(e.elearningAccessSentAt)}` : null,
    e.elearningFirstLoginAt ? `première connexion le ${fmtDateTime(e.elearningFirstLoginAt)}` : null,
  ].filter(Boolean);

  return (
    <Panel>
      <PanelHeader
        title="Parcours"
        description={
          <>
            {progress.template.label} : <span className="num">{progress.done}</span> sur <span className="num">{progress.total}</span> étape(s) faite(s)
            {progress.late ? (
              <>
                , <span className="num">{progress.late}</span> en retard
              </>
            ) : null}
            .{progress.next ? ` Prochaine étape : ${progress.next.label}.` : " Toutes les étapes sont faites."}
          </>
        }
      />
      {facts.length ? <p className="border-b border-line px-5 py-3 text-[12.5px] text-ink-2">{facts.join(" · ")}</p> : null}
      <Table>
        <thead>
          <tr>
            <Th>Étape</Th>
            <Th>Responsable</Th>
            <Th>Échéance</Th>
            <Th>Statut</Th>
            {canManage ? <Th></Th> : null}
          </tr>
        </thead>
        <tbody>
          {progress.steps.map((s) => {
            const view = statusView[s.status];
            const pending = s.prerequisites.filter((p) => !p.done);
            const open = s.status !== "terminee" && s.status !== "annulee";
            return (
              <tr key={s.code}>
                <Td>
                  <Link href={s.href} className="hover:underline">
                    {s.label}
                  </Link>
                  {pending.length && open ? <span className="block text-[12px] text-ink-3">Après : {pending.map((p) => p.label).join(", ")}</span> : null}
                  {s.status === "terminee" && s.completedAt ? <span className="block text-[12px] text-ink-3">Faite le {fmtDateTime(s.completedAt)}</span> : null}
                </Td>
                <Td className="text-ink-2">{roleLabel(s.role)}</Td>
                <Td>
                  <span className="num">{s.dueDate ? fmtDate(s.dueDate) : "-"}</span>
                  <span className="block text-[12px] text-ink-3">{s.delay}</span>
                </Td>
                <Td>
                  <span className="inline-flex flex-wrap items-center gap-1.5">
                    <Badge tone={view.tone}>{view.label}</Badge>
                    {s.late ? <Badge tone="danger">En retard</Badge> : null}
                  </span>
                </Td>
                {canManage ? (
                  <Td className="text-right">
                    {open ? (
                      <ActionButton
                        action={completeWorkflowStepAction}
                        fields={{ orgId, enrollmentId, stepCode: s.code }}
                        label="Marquer fait"
                        confirm={
                          pending.length
                            ? {
                                title: `Marquer fait : ${s.label}`,
                                description: `Prérequis non faits : ${pending.map((p) => p.label).join(", ")}. La dérogation, son motif et son auteur sont conservés.`,
                                input: { name: "override", label: "Motif de dérogation", help: "Obligatoire" },
                                confirmLabel: "Marquer fait",
                              }
                            : {
                                title: `Marquer fait : ${s.label}`,
                                description: "La tâche de relais est clôturée et l'action journalisée.",
                                input: { name: "note", label: "Note", help: "Facultatif" },
                                confirmLabel: "Marquer fait",
                              }
                        }
                      />
                    ) : null}
                  </Td>
                ) : null}
              </tr>
            );
          })}
        </tbody>
      </Table>
      {changeForm ? <div className="border-t border-line p-5">{changeForm}</div> : null}
    </Panel>
  );
}
