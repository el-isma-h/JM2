import type { Permission } from "@/server/authz";

export type NavItem = {
  label: string;
  href: string;
  icon: string;
  perm?: Permission;
  /** Visible si l'une de ces permissions est détenue (prioritaire sur `perm`). */
  anyPerm?: Permission[];
  group?: string;
  ownerOnly?: boolean;
};

/** Navigation d'un organisme ; `href` est relatif à /app/[orgId]. Filtrée par permission (et propriétaire pour la sécurité / charte). */
export const orgNav: NavItem[] = [
  { label: "Tableau de bord", href: "", icon: "SquaresFour", perm: "dashboards.view" },
  { label: "Mes tâches", href: "/taches", icon: "CheckSquare" },
  { label: "Agenda", href: "/agenda", icon: "CalendarDots" },
  { label: "Assistant IA", href: "/assistant", icon: "Sparkle" },

  { label: "Entreprises", href: "/entreprises", icon: "Buildings", perm: "crm.view", group: "Commercial" },
  { label: "Contacts", href: "/contacts", icon: "AddressBook", perm: "crm.view", group: "Commercial" },
  { label: "Besoins et pipeline", href: "/besoins", icon: "Funnel", perm: "crm.view", group: "Commercial" },
  { label: "Candidats", href: "/candidats", icon: "UserPlus", perm: "crm.view", group: "Commercial" },
  { label: "Devis", href: "/devis", icon: "FileText", perm: "crm.view", group: "Commercial" },

  { label: "Catalogue", href: "/catalogue", icon: "BookOpenText", perm: "catalog.view", group: "Formation" },
  { label: "Sessions", href: "/sessions", icon: "CalendarCheck", perm: "sessions.view", group: "Formation" },
  { label: "Inscriptions", href: "/inscriptions", icon: "Student", anyPerm: ["enrollments.view", "dossier.pedagogy.view"], group: "Formation" },
  { label: "Apprenants", href: "/apprenants", icon: "Users", anyPerm: ["enrollments.view", "dossier.pedagogy.view"], group: "Formation" },
  { label: "Formateurs", href: "/formateurs", icon: "ChalkboardTeacher", perm: "sessions.view", group: "Formation" },
  { label: "Missions formateurs", href: "/formateurs/missions", icon: "Briefcase", perm: "planning.view", group: "Formation" },

  { label: "Planning", href: "/planning", icon: "CalendarBlank", perm: "planning.view", group: "Pédagogie" },
  { label: "Émargement", href: "/emargement", icon: "PenNib", perm: "attendance.record", group: "Pédagogie" },
  { label: "Évaluations et livrets", href: "/evaluations", icon: "ClipboardText", perm: "dossier.pedagogy.view", group: "Pédagogie" },
  { label: "Suivi en entreprise", href: "/suivi-entreprise", icon: "Handshake", perm: "dossier.pedagogy.view", group: "Pédagogie" },
  { label: "E-learning", href: "/elearning", icon: "MonitorPlay", perm: "catalog.view", group: "Pédagogie" },
  { label: "Examens", href: "/examens", icon: "Certificate", perm: "exams.view", group: "Pédagogie" },
  { label: "Certifications externes", href: "/examens/certifications", icon: "Medal", perm: "exams.view", group: "Pédagogie" },

  { label: "Documents", href: "/documents", icon: "Files", perm: "documents.view", group: "Administratif" },
  { label: "Pièces attendues", href: "/pieces", icon: "Tray", perm: "dossier.admin_docs.view", group: "Administratif" },
  { label: "Déclarations (Carif, Kairos, EDOF)", href: "/declarations", icon: "FileArrowUp", perm: "enrollments.view", group: "Administratif" },
  { label: "Signatures", href: "/signatures", icon: "Signature", perm: "documents.view", group: "Administratif" },
  { label: "Modèles d'e-mails", href: "/modeles-emails", icon: "EnvelopeSimpleOpen", perm: "documents.generate", group: "Administratif" },
  { label: "Enquêtes", href: "/enquetes", icon: "ChatsCircle", perm: "quality.view", group: "Administratif" },

  { label: "Financements", href: "/financements", icon: "HandCoins", perm: "finance.view", group: "Finance" },
  { label: "Factures et règlements", href: "/factures", icon: "Receipt", perm: "finance.view", group: "Finance" },
  { label: "Financeurs", href: "/financeurs", icon: "Bank", perm: "finance.view", group: "Finance" },
  { label: "BPF et exports", href: "/bpf", icon: "ChartBar", perm: "finance.view", group: "Finance" },
  { label: "RIB central", href: "/finance/rib", icon: "CreditCard", perm: "finance.view", group: "Finance" },

  { label: "Conformité qualité", href: "/qualite", icon: "SealCheck", perm: "quality.view", group: "Qualité" },
  { label: "Preuves", href: "/qualite/preuves", icon: "Archive", perm: "quality.view", group: "Qualité" },
  { label: "Actions et réclamations", href: "/qualite/actions", icon: "Wrench", perm: "quality.view", group: "Qualité" },
  { label: "Veille", href: "/qualite/veille", icon: "Binoculars", perm: "quality.view", group: "Qualité" },

  { label: "Pilotage", href: "/pilotage", icon: "ChartLineUp", perm: "dashboards.view", group: "Organisation" },
  { label: "Supervision des tâches", href: "/taches/supervision", icon: "UsersThree", perm: "tasks.view_all", group: "Organisation" },
  { label: "Imports et exports", href: "/imports", icon: "ArrowsDownUp", perm: "enrollments.manage", group: "Organisation" },
  { label: "Intégrations", href: "/integrations", icon: "Plugs", perm: "org.view", group: "Organisation" },
  { label: "Paramètres", href: "/parametres", icon: "GearSix", perm: "org.view", group: "Organisation" },
  { label: "Utilisateurs et rôles", href: "/securite", icon: "ShieldCheck", group: "Organisation", ownerOnly: true },
  { label: "Charte institutionnelle", href: "/charte", icon: "PaintBrush", perm: "org.view", group: "Organisation" },
  { label: "Journal d'audit", href: "/audit", icon: "ListMagnifyingGlass", group: "Organisation", ownerOnly: true },
];

/** Extranet apprenant (/moi). */
export const learnerNav: NavItem[] = [
  { label: "Mon parcours", href: "", icon: "SquaresFour" },
  { label: "Mon planning", href: "/planning", icon: "CalendarBlank" },
  { label: "Mes présences", href: "/presences", icon: "PenNib" },
  { label: "Mes documents", href: "/documents", icon: "Files" },
  { label: "Mes pièces à fournir", href: "/pieces", icon: "Tray" },
  { label: "Mon livret", href: "/livret", icon: "BookOpenText" },
  { label: "E-learning", href: "/elearning", icon: "MonitorPlay" },
  { label: "Mes évaluations", href: "/evaluations", icon: "ClipboardText" },
  { label: "Enquêtes", href: "/enquetes", icon: "ChatsCircle" },
  { label: "Mes informations", href: "/informations", icon: "IdentificationCard" },
];

/** Extranet entreprise / tuteur (/entreprise). */
export const employerNav: NavItem[] = [
  { label: "Vue d'ensemble", href: "", icon: "SquaresFour" },
  { label: "Nos apprenants", href: "/apprenants", icon: "Users" },
  { label: "Documents et conventions", href: "/documents", icon: "Files" },
  { label: "Factures", href: "/factures", icon: "Receipt" },
  { label: "Suivi et livrets", href: "/suivi", icon: "Handshake" },
  { label: "Enquêtes", href: "/enquetes", icon: "ChatsCircle" },
];

/** Espace formateur externe (/formateur). */
export const trainerNav: NavItem[] = [
  { label: "Mes séances", href: "", icon: "SquaresFour" },
  { label: "Mes missions", href: "/missions", icon: "Briefcase" },
  { label: "Émargement", href: "/emargement", icon: "PenNib" },
  { label: "Mes apprenants", href: "/apprenants", icon: "Users" },
  { label: "Évaluations", href: "/evaluations", icon: "ClipboardText" },
  { label: "Mes documents", href: "/documents", icon: "Files" },
];

export const adminNav: NavItem[] = [
  { label: "Vue d'ensemble", href: "", icon: "SquaresFour" },
  { label: "Organisations", href: "/organisations", icon: "Buildings" },
  { label: "Utilisateurs", href: "/utilisateurs", icon: "Users" },
  { label: "Tarifs", href: "/tarifs", icon: "Tag" },
  { label: "Référentiels qualité", href: "/referentiels", icon: "SealCheck" },
  { label: "Modèles de documents", href: "/modeles", icon: "FileText" },
  { label: "Boîte d'envoi", href: "/boite-envoi", icon: "EnvelopeSimple" },
  { label: "Tâches de fond", href: "/taches", icon: "Queue" },
  { label: "Journal d'audit", href: "/audit", icon: "ShieldCheck" },
  { label: "Sauvegardes", href: "/sauvegardes", icon: "Database" },
  { label: "Registre des traitements", href: "/registre", icon: "Notebook" },
  { label: "Intégrations", href: "/integrations", icon: "Plugs" },
  { label: "Clés API", href: "/cles-api", icon: "Key" },
];
