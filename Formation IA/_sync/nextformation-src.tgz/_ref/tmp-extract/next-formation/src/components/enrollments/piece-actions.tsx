"use client";

import * as React from "react";
import { ActionButton, ActionForm } from "@/components/admin/action-form";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Field, Input } from "@/components/ui/field";
import { ACCEPT_ATTR, ALLOWED_LABEL } from "@/server/documents/upload-rules";
import { reviewPieceAction, uploadPieceAction } from "@/server/actions/enrollments";
import { remindPieceAction } from "@/server/actions/pieces";

/** Dépôt d'une pièce (nouvelle version si une pièce existe déjà) dans un dialogue. */
export function PieceUpload({ orgId, submissionId, label, hasVersion }: { orgId: string; submissionId: string; label: string; hasVersion: boolean }) {
  const [open, setOpen] = React.useState(false);
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="secondary" size="sm">
          {hasVersion ? "Nouvelle version" : "Déposer"}
        </Button>
      </DialogTrigger>
      <DialogContent title={`Déposer : ${label}`} description={hasVersion ? "Le dépôt précédent est conservé comme version antérieure ; la pièce repasse « déposée » et devra être contrôlée." : "La pièce sera à contrôler (accepter ou refuser avec motif)."}>
        <ActionForm action={uploadPieceAction} submitLabel="Déposer" footerClassName="mt-4 justify-end" onDone={(s) => s.ok && setOpen(false)}>
          <input type="hidden" name="orgId" value={orgId} />
          <input type="hidden" name="submissionId" value={submissionId} />
          <Field label="Fichier" required htmlFor={`f-${submissionId}`} help={`Formats : ${ALLOWED_LABEL}. 20 Mo maximum.`}>
            <Input id={`f-${submissionId}`} name="file" type="file" required accept={ACCEPT_ATTR} className="py-1.5" />
          </Field>
        </ActionForm>
      </DialogContent>
    </Dialog>
  );
}

export function PieceReview({ orgId, submissionId, status, label, canRemind }: { orgId: string; submissionId: string; status: string; label: string; canRemind: boolean }) {
  return (
    <div className="flex flex-wrap items-center justify-end gap-1.5">
      {status === "deposee" ? (
        <>
          <ActionButton action={reviewPieceAction} fields={{ orgId, submissionId, decision: "acceptee" }} label="Accepter" variant="primary" confirm={{ title: `Accepter « ${label} »`, description: "La pièce est validée et la tâche de relais associée est résolue.", confirmLabel: "Accepter" }} />
          <ActionButton action={reviewPieceAction} fields={{ orgId, submissionId, decision: "refusee" }} label="Refuser" variant="danger" confirm={{ title: `Refuser « ${label} »`, description: "Le motif est transmis et conservé ; une nouvelle version pourra être déposée.", input: { name: "reason", label: "Motif du refus", help: "Obligatoire" }, danger: true, confirmLabel: "Refuser" }} />
        </>
      ) : null}
      {status === "attendue" || status === "refusee" ? (
        <>
          <ActionButton action={reviewPieceAction} fields={{ orgId, submissionId, decision: "non_applicable" }} label="Non applicable" variant="ghost" confirm={{ title: `« ${label} » non applicable`, description: "La pièce n'est pas exigée pour ce dossier : le motif est conservé et la tâche est résolue.", input: { name: "reason", label: "Motif", help: "Obligatoire" }, confirmLabel: "Confirmer" }} />
          {canRemind ? <ActionButton action={remindPieceAction} fields={{ orgId, submissionId }} label="Relancer" variant="ghost" confirm={{ title: `Relancer pour « ${label} »`, description: "Un e-mail est adressé à la personne ou à l'entreprise selon qui fournit la pièce. En démonstration, rien ne part.", confirmLabel: "Envoyer la relance" }} /> : null}
        </>
      ) : null}
      {status === "non_applicable" || status === "acceptee" ? (
        <ActionButton action={reviewPieceAction} fields={{ orgId, submissionId, decision: "attendue" }} label="Remettre en attente" variant="ghost" confirm={{ title: `Remettre « ${label} » en attente`, description: "La pièce redevient attendue ; la tâche de relais n'est pas recréée automatiquement (utilisez « Recalculer »)." }} />
      ) : null}
    </div>
  );
}
