import { Checkbox, Field, Input, Select, Textarea } from "@/components/ui/field";

export type CohortFormData = {
  programs: { id: string; title: string; code: string }[];
  sites: { id: string; name: string }[];
  members: { userId: string; name: string }[];
  blocks: { programId: string; code: string; label: string }[];
  cohort?: {
    programId: string;
    code: string;
    label: string;
    date: string;
    endDate: string | null;
    capacity: number;
    managerUserId: string | null;
    siteId: string | null;
    scope: "complet" | "blocs";
    blocks: string[];
    allowsPartial: { partial?: boolean; retake?: boolean };
    notes: string | null;
    status: string;
  };
  defaultDate: string;
};

/** Champs d'une cohorte d'examen (création et modification de la cohorte sélectionnée uniquement). */
export function CohortFields({ data, idPrefix }: { data: CohortFormData; idPrefix: string }) {
  const c = data.cohort;
  const p = (s: string) => `${idPrefix}-${s}`;
  return (
    <>
      <Field label="Formation" required htmlFor={p("program")} help={c ? "Modifiable tant qu'aucun membre n'est affecté." : "Seules les inscriptions de cette formation seront affectables."}>
        <Select id={p("program")} name="programId" required defaultValue={c?.programId ?? ""}>
          <option value="">Choisir</option>
          {data.programs.map((x) => (
            <option key={x.id} value={x.id}>
              {x.code} : {x.title}
            </option>
          ))}
        </Select>
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Code" required htmlFor={p("code")} help="Unique dans l'organisme.">
          <Input id={p("code")} name="code" required maxLength={40} defaultValue={c?.code ?? ""} className="num" />
        </Field>
        <Field label="Libellé" required htmlFor={p("label")}>
          <Input id={p("label")} name="label" required maxLength={160} defaultValue={c?.label ?? ""} />
        </Field>
        <Field label="Date" required htmlFor={p("date")}>
          <Input id={p("date")} name="date" type="date" required defaultValue={c?.date ?? data.defaultDate} />
        </Field>
        <Field label="Date de fin (facultatif)" htmlFor={p("end")}>
          <Input id={p("end")} name="endDate" type="date" defaultValue={c?.endDate ?? ""} />
        </Field>
        <Field label="Capacité" required htmlFor={p("cap")}>
          <Input id={p("cap")} name="capacity" type="number" min={1} required defaultValue={c?.capacity ?? 20} className="num" />
        </Field>
        <Field label="Responsable" htmlFor={p("manager")}>
          <Select id={p("manager")} name="managerUserId" defaultValue={c?.managerUserId ?? ""}>
            <option value="">Non désigné</option>
            {data.members.map((m) => (
              <option key={m.userId} value={m.userId}>
                {m.name}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Site" htmlFor={p("site")}>
          <Select id={p("site")} name="siteId" defaultValue={c?.siteId ?? ""}>
            <option value="">Non précisé</option>
            {data.sites.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Périmètre" required htmlFor={p("scope")}>
          <Select id={p("scope")} name="scope" defaultValue={c?.scope ?? "complet"}>
            <option value="complet">Examen complet</option>
            <option value="blocs">Blocs de compétences</option>
          </Select>
        </Field>
      </div>
      {data.blocks.length ? (
        <Field label="Blocs concernés (périmètre « blocs »)">
          <div className="grid gap-1.5 sm:grid-cols-2">
            {data.blocks.map((b) => (
              <Checkbox key={`${b.programId}-${b.code}`} name="blocks" value={b.code} defaultChecked={c?.blocks.includes(b.code)} label={`${b.code} · ${b.label}`} />
            ))}
          </div>
        </Field>
      ) : (
        <p className="text-[12px] text-ink-3">Aucun bloc défini sur les certifications des formations : le périmètre « blocs » restera vide.</p>
      )}
      <div className="flex flex-wrap gap-5">
        <Checkbox name="allowPartial" value="1" defaultChecked={c ? c.allowsPartial.partial !== false : true} label="Résultats partiels admis" />
        <Checkbox name="allowRetake" value="1" defaultChecked={c ? c.allowsPartial.retake !== false : true} label="Rattrapage admis" />
      </div>
      {c ? (
        <Field label="Statut" htmlFor={p("status")}>
          <Select id={p("status")} name="status" defaultValue={c.status}>
            <option value="preparation">Préparation</option>
            <option value="ouverte">Ouverte</option>
            <option value="convoquee">Convoquée</option>
            <option value="terminee">Terminée</option>
            <option value="annulee">Annulée</option>
          </Select>
        </Field>
      ) : null}
      <Field label="Notes (reprises sur la convocation)" htmlFor={p("notes")}>
        <Textarea id={p("notes")} name="notes" defaultValue={c?.notes ?? ""} className="min-h-16" />
      </Field>
    </>
  );
}
