"use client";

import * as React from "react";
import { Button } from "@/components/ui/button";

/**
 * Pavé de signature (tablette ou souris) : trace dans un canvas et dépose l'image PNG dans un champ caché `signature`.
 * À placer dans un formulaire (ActionForm). Le serveur vérifie l'image et l'heure réelle : rien n'est décidé ici.
 */
export function SignaturePad({ name = "signature", label = "Signez dans le cadre", height = 140 }: { name?: string; label?: string; height?: number }) {
  const canvasRef = React.useRef<HTMLCanvasElement>(null);
  const inputRef = React.useRef<HTMLInputElement>(null);
  const drawing = React.useRef(false);
  const [dirty, setDirty] = React.useState(false);

  const ctx = () => {
    const c = canvasRef.current;
    if (!c) return null;
    const g = c.getContext("2d");
    if (!g) return null;
    g.lineWidth = 2.2;
    g.lineCap = "round";
    g.lineJoin = "round";
    g.strokeStyle = "#0a0b0d";
    return g;
  };

  React.useEffect(() => {
    const c = canvasRef.current;
    if (!c) return;
    const ratio = window.devicePixelRatio || 1;
    const w = c.clientWidth;
    c.width = Math.round(w * ratio);
    c.height = Math.round(height * ratio);
    const g = c.getContext("2d");
    if (g) {
      g.scale(ratio, ratio);
      g.fillStyle = "#ffffff";
      g.fillRect(0, 0, w, height);
    }
  }, [height]);

  const pos = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const r = e.currentTarget.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  };
  const commit = () => {
    const c = canvasRef.current;
    if (c && inputRef.current) inputRef.current.value = dirty || drawing.current ? c.toDataURL("image/png") : "";
  };
  const clear = () => {
    const c = canvasRef.current;
    const g = ctx();
    if (!c || !g) return;
    g.save();
    g.setTransform(1, 0, 0, 1, 0, 0);
    g.fillStyle = "#ffffff";
    g.fillRect(0, 0, c.width, c.height);
    g.restore();
    if (inputRef.current) inputRef.current.value = "";
    setDirty(false);
  };

  return (
    <div className="space-y-2">
      <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">{label}</p>
      <canvas
        ref={canvasRef}
        className="w-full touch-none border border-line-strong bg-white"
        style={{ height }}
        onPointerDown={(e) => {
          const g = ctx();
          if (!g) return;
          drawing.current = true;
          e.currentTarget.setPointerCapture(e.pointerId);
          const p = pos(e);
          g.beginPath();
          g.moveTo(p.x, p.y);
        }}
        onPointerMove={(e) => {
          if (!drawing.current) return;
          const g = ctx();
          if (!g) return;
          const p = pos(e);
          g.lineTo(p.x, p.y);
          g.stroke();
          if (!dirty) setDirty(true);
        }}
        onPointerUp={() => {
          drawing.current = false;
          setDirty(true);
          commit();
        }}
        onPointerLeave={() => {
          if (drawing.current) {
            drawing.current = false;
            commit();
          }
        }}
        aria-label={label}
        role="img"
      />
      <input ref={inputRef} type="hidden" name={name} />
      <Button type="button" variant="ghost" size="sm" onClick={clear}>
        Effacer
      </Button>
    </div>
  );
}
