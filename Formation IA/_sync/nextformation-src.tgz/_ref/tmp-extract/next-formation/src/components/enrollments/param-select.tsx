"use client";

import * as React from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { Select } from "@/components/ui/field";

/**
 * Sélecteur qui reporte sa valeur dans l'URL (`?param=valeur`) : la page serveur recharge les données
 * dépendantes (groupes d'une session, tuteurs d'une entreprise) sans perdre les autres paramètres.
 */
export function ParamSelect({ param, clears = [], children, ...props }: React.SelectHTMLAttributes<HTMLSelectElement> & { param: string; clears?: string[] }) {
  const router = useRouter();
  const pathname = usePathname();
  const sp = useSearchParams();
  const [value, setValue] = React.useState(String(props.defaultValue ?? ""));
  return (
    <Select
      {...props}
      defaultValue={undefined}
      value={value}
      onChange={(e) => {
        const v = e.target.value;
        setValue(v);
        const q = new URLSearchParams(sp.toString());
        if (v) q.set(param, v);
        else q.delete(param);
        for (const c of clears) q.delete(c);
        router.replace(`${pathname}?${q.toString()}`, { scroll: false });
      }}
    >
      {children}
    </Select>
  );
}
