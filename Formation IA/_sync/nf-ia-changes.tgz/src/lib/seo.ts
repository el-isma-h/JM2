import type { Metadata } from "next";
import { appUrl } from "@/lib/env";

/** Référentiel SEO : titres, descriptions et données structurées (schema.org) des pages publiques. */
export const SITE = {
  name: "Next Formation",
  title: "Next Formation : logiciel de gestion pour organismes de formation et CFA",
  description:
    "Logiciel français de gestion d'organisme de formation et de CFA : CRM, catalogue, sessions, émargement par demi-journée, documents, financements, facturation, conformité Qualiopi explicable, extranets et assistant IA avec validation humaine.",
  keywords: [
    "logiciel organisme de formation",
    "logiciel CFA",
    "gestion de la formation",
    "émargement électronique",
    "Qualiopi",
    "BPF bilan pédagogique et financier",
    "convention de formation",
    "catalogue de formation",
    "extranet apprenant",
    "alternative Digiforma",
    "facturation OPCO",
    "suivi apprentissage",
  ],
  locale: "fr_FR",
};

export type Offer = { code: string; name: string; priceCents: number | null; priceMonthlyCents?: number | null; description: string | null; isOption: boolean };

/** Métadonnées d'une page publique : titre, description, canonique et OpenGraph cohérents. */
export function pageMeta(path: string, title: string, description: string): Metadata {
  return {
    title,
    description,
    alternates: { canonical: path },
    openGraph: { type: "website", locale: SITE.locale, siteName: SITE.name, title: `${title} · ${SITE.name}`, description, url: path },
    twitter: { card: "summary_large_image", title: `${title} · ${SITE.name}`, description },
  };
}

/** Fil d'Ariane schema.org. */
export function breadcrumbJsonLd(items: { name: string; path: string }[]) {
  const url = appUrl();
  return { "@context": "https://schema.org", "@type": "BreadcrumbList", itemListElement: items.map((it, i) => ({ "@type": "ListItem", position: i + 1, name: it.name, item: `${url}${it.path}` })) };
}

export function faqJsonLd(items: { q: string; a: string }[]) {
  return { "@context": "https://schema.org", "@type": "FAQPage", mainEntity: items.map((f) => ({ "@type": "Question", name: f.q, acceptedAnswer: { "@type": "Answer", text: f.a } })) };
}

export const FAQ: { q: string; a: string }[] = [
  {
    q: "Next Formation remplace-t-il Digiforma ?",
    a: "Oui. Next Formation couvre le même périmètre (CRM, catalogue, sessions, émargement, documents, facturation, qualité, extranets, e-learning, API) avec des règles métier plus strictes : heures prévues, réalisées, justifiées et validées distinguées, périodes verrouillées après clôture, analyses qualité immuables et droits par rôle additifs. Les tarifs sont publiés à 90 % de la grille Digiforma, source et date de relevé affichées.",
  },
  {
    q: "L'émargement est-il juridiquement solide ?",
    a: "Chaque demi-journée a ses propres horaires, présences, signatures et clôture. Le serveur est la référence temporelle (Europe/Paris) : aucune présence ne peut être saisie avant le début réel de la période ni clôturée avant sa fin. Une période clôturée ne se modifie plus ; toute correction passe par un circuit tracé qui conserve l'original.",
  },
  {
    q: "Comment la conformité Qualiopi est-elle suivie ?",
    a: "Un référentiel versionné (validé par votre responsable qualité avant activation) relie chaque indicateur aux preuves réelles de vos dossiers. Chaque analyse est une photographie immuable : version du moteur, date, contrôles, preuves et résultat. Un pourcentage de preuves n'est jamais présenté comme une attestation de conformité ; les points à apprécier humainement restent signalés.",
  },
  {
    q: "Gérez-vous l'apprentissage (CFA) et la formation continue dans le même outil ?",
    a: "Oui. Un tenant peut regrouper plusieurs organismes isolés (par exemple un OF et un CFA). Les rythmes d'alternance sont paramétrables (1 jour / 4 jours, 2 jours / 8 jours ou tout autre calendrier), le suivi en entreprise, le livret et les cohortes d'examen sont intégrés.",
  },
  {
    q: "Que fait l'IA exactement ?",
    a: "Des agents préparent des propositions : documents pré-remplis, relances, contrôle des pièces manquantes, lecture d'un dossier, synthèses qualité explicables. Rien ne part et rien ne se modifie sans validation humaine. Le système n'invente jamais une preuve ni une présence et ne considère jamais un document généré comme signé.",
  },
  {
    q: "Puis-je reprendre mes données depuis Galaxy, Excel ou un autre outil ?",
    a: "Oui. L'import Excel / CSV guidé reprend entreprises, contacts, apprenants, inscriptions et historiques d'heures (conservés comme soldes non réconciliés, distincts des heures justifiées). Un rapport d'erreurs et une détection des doublons accompagnent chaque import, sans fusion automatique risquée.",
  },
  {
    q: "Peut-on essayer sans s'inscrire ?",
    a: "Oui. La démonstration ouvre en quelques secondes un organisme fictif complet (OF et CFA) côté direction, administratif, pédagogie, formateur, finance, qualité, apprenant ou entreprise. Elle est supprimée automatiquement au bout de 24 heures.",
  },
];

/** Données structurées de la page d'accueil : organisation, site, application et FAQ. */
export function homeJsonLd(offers: Offer[]) {
  const url = appUrl();
  const priced = offers.filter((o) => !o.isOption && o.priceCents && o.priceCents > 0).map((o) => ({ name: o.name, value: o.priceCents! / 100 }));
  return [
    { "@context": "https://schema.org", "@type": "Organization", "@id": `${url}/#organisation`, name: SITE.name, url, logo: `${url}/icon.svg` },
    { "@context": "https://schema.org", "@type": "WebSite", "@id": `${url}/#site`, name: SITE.name, url, inLanguage: "fr-FR", publisher: { "@id": `${url}/#organisation` } },
    {
      "@context": "https://schema.org",
      "@type": "SoftwareApplication",
      name: SITE.name,
      url,
      description: SITE.description,
      applicationCategory: "BusinessApplication",
      applicationSubCategory: "Logiciel de gestion d'organisme de formation",
      operatingSystem: "Web",
      inLanguage: "fr-FR",
      publisher: { "@id": `${url}/#organisation` },
      ...(priced.length
        ? {
            offers: {
              "@type": "AggregateOffer",
              priceCurrency: "EUR",
              lowPrice: Math.min(...priced.map((o) => o.value)).toFixed(2),
              highPrice: Math.max(...priced.map((o) => o.value)).toFixed(2),
              offerCount: priced.length,
              offers: priced.map((o) => ({ "@type": "Offer", name: o.name, price: o.value.toFixed(2), priceCurrency: "EUR", url: `${url}/tarifs` })),
            },
          }
        : {}),
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      mainEntity: FAQ.map((f) => ({ "@type": "Question", name: f.q, acceptedAnswer: { "@type": "Answer", text: f.a } })),
    },
  ];
}

/*
  Formation IA (NF-IA-150) : FAQ de la page vitrine et données structurées Course.
  Source des textes : /home/claude/formation-ia (README, programme.json, guide-apprenant.md, dossier RS).
  Règles du contrat d'intégration : jamais « éligible CPF », jamais « certifié Qualiopi », jamais « équivalent » à une certification tierce.
*/
export const FORMATION_IA_PRIX = { niveau: 1490, parcours: 4990, n5: 1290 } as const;

export const FORMATION_IA_FAQ: { q: string; a: string }[] = [
  {
    q: "Ai-je besoin de savoir coder ?",
    a: "Non pour les niveaux 1 et 2 : tout se fait avec des outils sans code (ChatGPT, Claude, n8n, Make, Ollama). Oui à partir du niveau 3, qui demande des bases de Python ou de JavaScript/TypeScript et des notions HTTP/JSON ; le module 16 propose une remise à niveau. Le niveau 4 reprend les mathématiques nécessaires dans le module 24.",
  },
  {
    q: "Puis-je commencer directement au niveau 3 ?",
    a: "Oui si vous avez les prérequis. Vous pouvez suivre un seul niveau ou tout le parcours. Un test de positionnement vérifie vos acquis à l'entrée ; le formateur-référent peut alors ouvrir directement le niveau qui vous correspond.",
  },
  {
    q: "Que se passe-t-il si j'échoue à un quiz ou à l'examen ?",
    a: "Les quiz de module (seuil 70 %) sont illimités : chaque question est corrigée avec une explication et une source. L'examen de niveau (40 questions tirées dans une banque de 80, 60 minutes, seuil 70 %) autorise 3 tentatives, avec 7 jours d'attente entre deux. Le résultat détaillé par compétence vous indique quoi retravailler. Après 3 échecs, le formateur étudie la suite avec vous.",
  },
  {
    q: "Combien de temps faut-il pour finir ?",
    a: "Le parcours complet représente 150 heures à distance. Trois rythmes types servent de repères : intensif en 4 semaines (environ 37 h 30 par semaine), standard en 12 semaines (environ 12 h 30 par semaine) ou temps partiel en 6 mois (environ 6 h par semaine). Le délai contractuel est fixé dans votre convention ou votre contrat de formation.",
  },
  {
    q: "Y a-t-il des coûts annexes (abonnements, API) ?",
    a: "Aucun abonnement n'est requis aux niveaux 1 et 2 : les comptes gratuits suffisent. Au niveau 3, comptez environ 20 à 40 € de crédits d'API pour tout le niveau ; au niveau 4, environ 10 à 30 € de GPU dans le cloud. La spécialisation N5 tourne gratuitement en local (Docker Compose). Chaque leçon concernée explique comment plafonner vos dépenses.",
  },
  {
    q: "Les certificats Next Formation sont-ils reconnus ?",
    a: "Ce sont des certificats d'organisme, délivrés par niveau quand toutes les compétences sont validées (examen réussi et épreuves pratiques validées, sans compensation). Chaque certificat PDF porte un numéro unique et un QR code vérifiable en ligne par tout employeur. Leur enregistrement au Répertoire spécifique de France Compétences est en cours. Ils ne valent pas équivalence des certifications des éditeurs (Anthropic, n8n, Microsoft, AWS, Google) : la formation couvre leurs référentiels publics et vous prépare à les passer en complément.",
  },
  {
    q: "Puis-je financer la formation avec mon CPF ?",
    a: "Certification en cours d'enregistrement au Répertoire spécifique (France Compétences) : financement CPF bientôt disponible. Dès aujourd'hui, la formation peut être financée par votre OPCO, par votre entreprise (plan de développement des compétences), par France Travail ou à titre personnel. Le prix de chaque niveau (1 490 € TTC) est fixé sous le plafond de prise en charge des certifications du Répertoire spécifique.",
  },
  {
    q: "Le niveau 5 est-il obligatoire ?",
    a: "Non. C'est une spécialisation de 30 heures, « Data engineering et Big Data pour l'IA », hors parcours certifiant de 150 heures. Elle s'ouvre dès que le niveau 3 est validé et peut être suivie avant, après ou à la place du niveau 4. Elle donne lieu à son propre certificat « Data engineer IA ».",
  },
];

/** Données structurées de la page /formation-ia : cours, offres par niveau et FAQ. */
export function formationIaJsonLd() {
  const url = appUrl();
  const page = `${url}/formation-ia`;
  const offer = (name: string, price: number) => ({ "@type": "Offer", name, price: price.toFixed(2), priceCurrency: "EUR", category: "Formation", availability: "https://schema.org/InStock", url: page });
  return [
    {
      "@context": "https://schema.org",
      "@type": "Course",
      "@id": `${page}#cours`,
      name: "Formation IA : 4 niveaux certifiants (150 h)",
      courseCode: "NF-IA-150",
      description:
        "Formation à l'intelligence artificielle 100 % à distance en 4 niveaux certifiants (Fondamentaux, Praticien IA et automatisation, Développeur IA, Expert IA) et une spécialisation Data engineering et Big Data pour l'IA : 184 leçons, 525 quiz éclair, 339 missions documentation, tuteur IA, examens de niveau et certificat Next Formation par niveau.",
      inLanguage: "fr-FR",
      url: page,
      provider: { "@type": "Organization", name: "Next Formation Académie", url },
      educationalLevel: "Débutant à expert",
      numberOfCredits: 0,
      hasCourseInstance: [
        { "@type": "CourseInstance", name: "Niveau 1 : Fondamentaux de l'IA", courseMode: "online", courseWorkload: "PT25H" },
        { "@type": "CourseInstance", name: "Niveau 2 : Praticien IA et automatisation", courseMode: "online", courseWorkload: "PT35H" },
        { "@type": "CourseInstance", name: "Niveau 3 : Développeur IA", courseMode: "online", courseWorkload: "PT45H" },
        { "@type": "CourseInstance", name: "Niveau 4 : Expert IA", courseMode: "online", courseWorkload: "PT45H" },
        { "@type": "CourseInstance", name: "Niveau 5 : Data engineering et Big Data pour l'IA (spécialisation)", courseMode: "online", courseWorkload: "PT30H" },
      ],
      offers: [
        offer("Un niveau (N1, N2, N3 ou N4)", FORMATION_IA_PRIX.niveau),
        offer("Parcours complet N1 à N4 (150 h)", FORMATION_IA_PRIX.parcours),
        offer("Spécialisation N5 (30 h)", FORMATION_IA_PRIX.n5),
      ],
    },
    breadcrumbJsonLd([
      { name: "Accueil", path: "/" },
      { name: "Formation IA", path: "/formation-ia" },
    ]),
    faqJsonLd(FORMATION_IA_FAQ),
  ];
}

/** Sérialise du JSON-LD pour une balise <script> sans risque d'injection (« </script> »). */
export function jsonLdScript(data: unknown) {
  return { __html: JSON.stringify(data).replace(/</g, "\\u003c") };
}
