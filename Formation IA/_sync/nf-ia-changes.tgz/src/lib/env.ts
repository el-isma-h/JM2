/**
 * Envoi d'e-mails réellement actif : coupé par défaut. Il faut à la fois MAIL_ENABLED=true et une clé Resend
 * (variables d'environnement ou admin, Clés API). Sinon les e-mails restent dans la boîte d'envoi (admin/boite-envoi)
 * avec le statut « non envoyé (non configuré) » et les écrans affichent le lien à transmettre.
 */
export function mailEnabled(env: Record<string, string | undefined> = process.env): boolean {
  return env.MAIL_ENABLED === "true" && Boolean(env.RESEND_API_KEY);
}

/** État de configuration des services externes : utilisé pour afficher « configuration manquante » au lieu de boutons morts. */
export const integrations = {
  mail: () => process.env.MAIL_ENABLED === "true" && Boolean(process.env.RESEND_API_KEY),
  /** Assistant IA : une seule clé suffit (Anthropic, OpenAI ou xAI Grok). */
  ai: () => Boolean(process.env.ANTHROPIC_API_KEY?.trim() || process.env.OPENAI_API_KEY?.trim() || process.env.XAI_API_KEY?.trim()),
  s3: () => Boolean(process.env.S3_ENDPOINT && process.env.S3_BUCKET && process.env.S3_ACCESS_KEY),
  esign: () => Boolean(process.env.ESIGN_PROVIDER && process.env.ESIGN_API_KEY),
  /** Espace e-learning de la Formation IA (connexion unique signée) : adresse et secret partagé (32 caractères minimum). */
  ia: () => iaConfig().ok,
};

/**
 * Connexion unique vers l'espace e-learning de la Formation IA (`docs/formation-ia-integration.md`).
 * `IA_APP_URL` : adresse publique de l'app e-learning (ex. https://formation.nikaholding.world/ia) ;
 * `IA_SSO_SECRET` : secret HMAC partagé, identique à NF_SSO_SECRET côté e-learning, 32 caractères minimum.
 */
export function iaConfig(env: Record<string, string | undefined> = process.env): { ok: true; appUrl: string; secret: string } | { ok: false; appUrl: string; secret: string } {
  const appUrl = (env.IA_APP_URL ?? "").trim().replace(/\/+$/, "");
  const secret = (env.IA_SSO_SECRET ?? "").trim();
  const ok = /^https?:\/\/\S+$/.test(appUrl) && secret.length >= 32;
  return { ok, appUrl, secret };
}

/**
 * Vérification de l'adresse e-mail à l'inscription.
 * REQUIRE_EMAIL_VERIFICATION="true" : toujours exigée ; "false" : jamais ; sinon exigée seulement si l'envoi
 * d'e-mails est actif (MAIL_ENABLED=true et RESEND_API_KEY : sans envoi, personne ne recevrait le lien). Les comptes créés pendant que la vérification
 * n'était pas exigée ont déjà `email_verified_at` posé : ils restent valides si elle le redevient.
 */
export function requireEmailVerification(env: Record<string, string | undefined> = process.env): boolean {
  const v = (env.REQUIRE_EMAIL_VERIFICATION ?? "").trim().toLowerCase();
  if (v === "true") return true;
  if (v === "false") return false;
  return mailEnabled(env);
}

/** Vrai si l'utilisateur peut accéder à l'application : adresse vérifiée, ou vérification non exigée. */
export function emailAccessOk(user: { emailVerified: boolean }): boolean {
  return user.emailVerified || !requireEmailVerification();
}

export const appUrl = () => process.env.APP_URL ?? "http://localhost:3000";

export type IntegrationName = keyof typeof integrations;

export const integrationLabels: Record<IntegrationName, { label: string; envVars: string[]; effect: string }> = {
  mail: {
    label: "E-mail transactionnel (Resend, coupé par défaut)",
    envVars: ["RESEND_API_KEY", "MAIL_FROM", "MAIL_ENABLED"],
    effect: "Envoi coupé : les e-mails restent dans la boîte d'envoi (Admin, Boîte d'envoi) et les liens s'affichent à l'écran pour être transmis à la main. Pour l'activer : Admin, Clés API, renseigner RESEND_API_KEY et MAIL_FROM puis MAIL_ENABLED=true.",
  },
  ai: {
    label: "Assistant et agents IA (Anthropic, OpenAI ou xAI Grok : une seule clé suffit)",
    envVars: ["ANTHROPIC_API_KEY", "OPENAI_API_KEY", "XAI_API_KEY"],
    effect: "L'assistant répond avec les actions déterministes uniquement (résumé de dossier, calendrier, gabarits de relance) ; aucune réponse libre ni rédaction par modèle.",
  },
  s3: {
    label: "Stockage documentaire S3",
    envVars: ["S3_ENDPOINT", "S3_BUCKET", "S3_ACCESS_KEY", "S3_SECRET_KEY"],
    effect: "Les documents sont stockés sur le disque local du serveur (STORAGE_DIR), hors du dossier public.",
  },
  esign: {
    label: "Signature électronique",
    envVars: ["ESIGN_PROVIDER", "ESIGN_API_KEY"],
    effect: "Les demandes de signature sont enregistrées avec le statut « non configuré ».",
  },
  ia: {
    label: "Espace e-learning Formation IA (connexion unique)",
    envVars: ["IA_APP_URL", "IA_SSO_SECRET"],
    effect: "Le bouton « Ouvrir mon espace e-learning » explique la configuration manquante au lieu d'ouvrir l'espace : renseigner IA_APP_URL (adresse de l'app e-learning, ex. https://formation.nikaholding.world/ia) et IA_SSO_SECRET (32 caractères minimum, identique à NF_SSO_SECRET côté e-learning).",
  },
};

/**
 * Porte HPT (protocole HPT-Next v1, produit `next-formation`). Fermée par défaut :
 * sans HPT_SSO_SECRET, /sso/hpt répond 404 ; sans HPT_CLE_SERVICE, les routes /api/hpt/* répondent 404.
 */
export function hptConfig(env: Record<string, string | undefined> = process.env) {
  return {
    ssoSecret: (env.HPT_SSO_SECRET ?? "").trim(),
    cleService: (env.HPT_CLE_SERVICE ?? "").trim(),
    url: (env.HPT_URL ?? "").trim(),
  };
}
