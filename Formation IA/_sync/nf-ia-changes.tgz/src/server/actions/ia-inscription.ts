"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { requireEmailVerification } from "@/lib/env";
import { checkPostalCode, checkSiret, parseDateInput } from "@/lib/validators";
import { getCurrentUser, requireUser, validatePasswordStrength } from "@/server/auth";
import { requireOrg } from "@/server/authz";
import { checkUpload } from "@/server/documents/upload-rules";
import { getLearnerContext } from "@/server/extranet/context";
import { authErrorMessage } from "@/server/guard";
import { clientIp, hit, RATE_LIMITS, tooManyMessage } from "@/server/rate-limit";
import {
  closeIaAccess,
  contractualiseIa,
  createIaEnrollment,
  createIaIdentity,
  IA_INSCRIPTION_PATH,
  IaEmailExistsError,
  iaLearnerSsoLink,
  iaSignNowLink,
  isIaFunding,
  isIaOffer,
  learnerIaDossier,
  loadIaFlow,
  openIaAccess,
  uploadIaPiece,
  type IaIdentityInput,
} from "@/server/ia/enrollment";
import type { ActionState } from "./auth";

/**
 * Actions du parcours d'inscription public à la Formation IA, de l'extranet apprenant (bouton e-learning)
 * et du dossier côté organisme (ouverture / fermeture de l'accès). Les erreurs sont renvoyées près du champ
 * (`data.field`) et les valeurs saisies sont conservées (`data.*`).
 */

const str = (fd: FormData, k: string) => String(fd.get(k) ?? "").trim();

function echo(fd: FormData, keys: string[]): Record<string, string> {
  const out: Record<string, string> = {};
  for (const k of keys) out[k] = str(fd, k);
  return out;
}

function fail(e: unknown, fallback: string, data?: Record<string, string>): ActionState {
  if (e instanceof z.ZodError) return { error: e.issues[0]?.message ?? "Paramètres invalides.", data };
  return { error: authErrorMessage(e) ?? (e instanceof Error && e.message ? e.message : fallback), data };
}

/* ------------------------------------------------------------------ */
/* Étape 1 : identité et compte                                        */
/* ------------------------------------------------------------------ */

const IDENTITY_KEYS = ["civility", "firstName", "lastName", "email", "phone", "birthDate", "birthPlace", "addressLine1", "postalCode", "city", "situation", "employerName", "employerSiret", "employerContactFirstName", "employerContactLastName", "employerContactEmail", "employerContactJobTitle", "employerAddressLine1", "employerPostalCode", "employerCity", "consent"];

const identitySchema = z.object({
  civility: z.enum(["M", "Mme", "autre"], { message: "Civilité requise." }),
  firstName: z.string().trim().min(1, "Prénom requis.").max(80),
  lastName: z.string().trim().min(1, "Nom requis.").max(80),
  email: z.string().trim().toLowerCase().email("Adresse e-mail invalide."),
  phone: z.string().trim().min(6, "Téléphone requis.").max(30),
  birthDate: z.string().trim().min(1, "Date de naissance requise."),
  birthPlace: z.string().trim().max(120).default(""),
  addressLine1: z.string().trim().min(3, "Adresse requise.").max(160),
  postalCode: z.string().trim().min(1, "Code postal requis."),
  city: z.string().trim().min(1, "Ville requise.").max(80),
  situation: z.enum(["particulier", "salarie", "demandeur_emploi", "independant"], { message: "Situation requise." }),
  employerName: z.string().trim().max(160).default(""),
  employerSiret: z.string().trim().max(20).default(""),
  employerContactFirstName: z.string().trim().max(80).default(""),
  employerContactLastName: z.string().trim().max(80).default(""),
  employerContactEmail: z.string().trim().max(160).default(""),
  employerContactJobTitle: z.string().trim().max(120).default(""),
  employerAddressLine1: z.string().trim().max(160).default(""),
  employerPostalCode: z.string().trim().max(10).default(""),
  employerCity: z.string().trim().max(80).default(""),
  password: z.string(),
  consent: z.string().optional(),
});

export async function iaIdentityAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const data = echo(formData, IDENTITY_KEYS);
  const parsed = identitySchema.safeParse({ ...Object.fromEntries(formData), password: String(formData.get("password") ?? "") });
  if (!parsed.success) {
    const issue = parsed.error.issues[0];
    return { error: issue?.message ?? "Formulaire invalide.", data: { ...data, field: String(issue?.path[0] ?? "") } };
  }
  const d = parsed.data;
  const current = await getCurrentUser();
  if (!current) {
    if (d.consent !== "on") return { error: "Vous devez accepter les conditions générales et la politique de confidentialité.", data: { ...data, field: "consent" } };
    const pwErr = validatePasswordStrength(d.password);
    if (pwErr) return { error: `Mot de passe : ${pwErr}`, data: { ...data, field: "password" } };
    const rl = await hit("signup:ip", await clientIp(), RATE_LIMITS.signupIp);
    if (!rl.ok) return { error: tooManyMessage(rl), data };
  }
  const birthDate = parseDateInput(d.birthDate);
  if (!birthDate) return { error: "Date de naissance invalide (JJ/MM/AAAA).", data: { ...data, field: "birthDate" } };
  if (birthDate > new Date(Date.now() - 16 * 365.25 * 86400_000).toISOString().slice(0, 10)) return { error: "Vous devez avoir au moins 16 ans pour vous inscrire.", data: { ...data, field: "birthDate" } };
  const cp = checkPostalCode(d.postalCode);
  if (!cp.ok) return { error: cp.error, data: { ...data, field: "postalCode" } };
  let employer: IaIdentityInput["employer"] = null;
  if (d.situation === "salarie") {
    if (!d.employerName) return { error: "Raison sociale de votre employeur requise.", data: { ...data, field: "employerName" } };
    const siret = checkSiret(d.employerSiret);
    if (!siret.ok) return { error: siret.error, data: { ...data, field: "employerSiret" } };
    if (!d.employerContactFirstName || !d.employerContactLastName) return { error: "Prénom et nom du contact employeur requis.", data: { ...data, field: "employerContactLastName" } };
    const emailOk = z.string().email().safeParse(d.employerContactEmail).success;
    if (!emailOk) return { error: "Adresse e-mail du contact employeur invalide.", data: { ...data, field: "employerContactEmail" } };
    employer = { name: d.employerName, siret: siret.value!, addressLine1: d.employerAddressLine1 || null, postalCode: d.employerPostalCode || null, city: d.employerCity || null, contactFirstName: d.employerContactFirstName, contactLastName: d.employerContactLastName, contactEmail: d.employerContactEmail, contactJobTitle: d.employerContactJobTitle || null };
  }
  try {
    await createIaIdentity(
      {
        civility: d.civility,
        firstName: d.firstName,
        lastName: d.lastName,
        email: current?.email ?? d.email,
        phone: d.phone,
        birthDate,
        birthPlace: d.birthPlace || null,
        addressLine1: d.addressLine1,
        postalCode: cp.value!,
        city: d.city,
        situation: d.situation,
        employer,
        password: current ? null : d.password,
        verificationRequired: requireEmailVerification(),
      },
      current,
    );
  } catch (e) {
    if (e instanceof IaEmailExistsError) return { error: e.message, data: { ...data, field: "email", emailExists: "1" } };
    return fail(e, "La création du compte a échoué.", data);
  }
  redirect(`${IA_INSCRIPTION_PATH}?etape=2`);
}

/* ------------------------------------------------------------------ */
/* Étape 2 : offre                                                     */
/* ------------------------------------------------------------------ */

export async function iaOfferAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const offer = str(formData, "offer");
  if (!isIaOffer(offer)) return { error: "Choisissez une offre.", data: { field: "offer" } };
  await requireUser().catch(() => redirect(`${IA_INSCRIPTION_PATH}?etape=1`));
  redirect(`${IA_INSCRIPTION_PATH}?etape=3&offre=${offer}`);
}

/* ------------------------------------------------------------------ */
/* Étape 3 : financement                                               */
/* ------------------------------------------------------------------ */

const FUNDING_KEYS = ["offer", "funding", "cpfAck", "opcoName", "franceTravailId", "employerName", "employerSiret", "employerContactFirstName", "employerContactLastName", "employerContactEmail", "employerContactJobTitle", "employerAddressLine1", "employerPostalCode", "employerCity"];

export async function iaFundingAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const data = echo(formData, FUNDING_KEYS);
  let user;
  try {
    user = await requireUser();
  } catch {
    redirect(`${IA_INSCRIPTION_PATH}?etape=1`);
  }
  const offer = data.offer;
  if (!isIaOffer(offer)) return { error: "Offre inconnue : revenez à l'étape 2.", data: { ...data, field: "offer" } };
  const funding = data.funding;
  if (!isIaFunding(funding)) return { error: "Choisissez un mode de financement.", data: { ...data, field: "funding" } };
  if (data.funding === "cpf" && str(formData, "cpfAck") !== "on") return { error: "Confirmez avoir lu que le financement CPF n'est pas encore disponible et que votre dossier est une pré-réservation.", data: { ...data, field: "cpfAck" } };
  let employer: IaIdentityInput["employer"] = null;
  if (funding === "opco" || funding === "entreprise") {
    if (!data.employerName) return { error: "Raison sociale de l'employeur requise.", data: { ...data, field: "employerName" } };
    const siret = checkSiret(data.employerSiret);
    if (!siret.ok) return { error: siret.error, data: { ...data, field: "employerSiret" } };
    if (!data.employerContactFirstName || !data.employerContactLastName) return { error: "Prénom et nom du contact employeur requis (signataire de la convention).", data: { ...data, field: "employerContactLastName" } };
    if (!z.string().email().safeParse(data.employerContactEmail).success) return { error: "Adresse e-mail du contact employeur invalide.", data: { ...data, field: "employerContactEmail" } };
    if (funding === "opco" && !data.opcoName) return { error: "Indiquez l'OPCO de votre employeur.", data: { ...data, field: "opcoName" } };
    if (!data.employerContactJobTitle) return { error: "Fonction du signataire requise (figure sur la convention).", data: { ...data, field: "employerContactJobTitle" } };
    if (!data.employerAddressLine1 || !data.employerCity) return { error: "Adresse de l'entreprise requise (figure sur la convention).", data: { ...data, field: "employerAddressLine1" } };
    const cp = checkPostalCode(data.employerPostalCode);
    if (!cp.ok) return { error: cp.error, data: { ...data, field: "employerPostalCode" } };
    employer = { name: data.employerName, siret: siret.value!, addressLine1: data.employerAddressLine1, postalCode: cp.value!, city: data.employerCity, contactFirstName: data.employerContactFirstName, contactLastName: data.employerContactLastName, contactEmail: data.employerContactEmail.toLowerCase(), contactJobTitle: data.employerContactJobTitle };
  }
  if (funding === "france_travail" && !data.franceTravailId) return { error: "Indiquez votre identifiant France Travail.", data: { ...data, field: "franceTravailId" } };
  try {
    await createIaEnrollment(user!, { offer, funding, opcoName: data.opcoName || null, franceTravailId: data.franceTravailId || null, employer });
  } catch (e) {
    return fail(e, "L'inscription n'a pas pu être enregistrée.", data);
  }
  revalidatePath("/moi");
  redirect(`${IA_INSCRIPTION_PATH}?etape=4`);
}

/* ------------------------------------------------------------------ */
/* Étape 4 : pièces                                                    */
/* ------------------------------------------------------------------ */

export async function iaPieceUploadAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const submissionId = str(formData, "submissionId");
  try {
    const user = await requireUser();
    const flow = await loadIaFlow(user);
    if (!flow.dossier) return { error: "Aucun dossier Formation IA en cours." };
    if (!/^[0-9a-f-]{36}$/i.test(submissionId)) return { error: "Pièce invalide." };
    const f = formData.get("file");
    if (!(f instanceof File) || !f.size) return { error: "Sélectionnez un fichier à déposer.", data: { field: `file-${submissionId}` } };
    const buf = Buffer.from(await f.arrayBuffer());
    const check = checkUpload({ name: f.name, type: f.type, size: f.size, head: buf.subarray(0, 8) });
    if (!check.ok) return { error: check.error, data: { field: `file-${submissionId}` } };
    const label = await uploadIaPiece(user, flow.dossier, submissionId, { name: f.name, mime: check.mime, data: buf });
    revalidatePath(IA_INSCRIPTION_PATH);
    revalidatePath("/moi/pieces");
    return { ok: true, message: `« ${label} » déposée. L'organisme la contrôle et vous informe en cas de refus.` };
  } catch (e) {
    return fail(e, "Le dépôt a échoué.");
  }
}

/* ------------------------------------------------------------------ */
/* Étape 5 : contractualisation                                        */
/* ------------------------------------------------------------------ */

export async function iaContractAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const user = await requireUser();
    const flow = await loadIaFlow(user);
    if (!flow.dossier) return { error: "Aucun dossier Formation IA en cours : reprenez à l'étape 2." };
    if (str(formData, "accept") !== "on") return { error: "Cochez la case pour confirmer avoir lu le récapitulatif, le programme et les conditions.", data: { field: "accept" } };
    const res = await contractualiseIa(user, flow.dossier);
    revalidatePath(IA_INSCRIPTION_PATH);
    revalidatePath("/moi");
    if (res.state === "sent" && res.links.length) {
      return { ok: true, message: res.notConfigured ?? "Document généré et transmis pour signature électronique.", data: { links: res.links.map((l) => `${l.name} : ${l.url}`).join("\n") } };
    }
    return { ok: true, message: res.state === "prepared" ? "Document généré : l'organisme complète les informations manquantes puis vous l'envoie à signer." : res.state === "cpf" ? "Pré-réservation CPF enregistrée." : "Votre contrat existe déjà." };
  } catch (e) {
    return fail(e, "La contractualisation a échoué.");
  }
}

export async function iaSignNowAction(): Promise<ActionState> {
  let url: string | null = null;
  try {
    const user = await requireUser();
    const flow = await loadIaFlow(user);
    if (!flow.dossier) return { error: "Aucun dossier Formation IA en cours." };
    url = await iaSignNowLink(user, flow.dossier);
    if (!url) return { error: "Aucune signature n'est attendue de votre part pour le moment." };
  } catch (e) {
    return fail(e, "Le lien de signature n'a pas pu être généré.");
  }
  redirect(url);
}

/* ------------------------------------------------------------------ */
/* Extranet apprenant : espace e-learning                              */
/* ------------------------------------------------------------------ */

export async function openIaSpaceAction(): Promise<ActionState> {
  let url: string | null = null;
  try {
    const ctx = await getLearnerContext();
    if (!ctx) return { error: "Aucun dossier apprenant rattaché à votre compte." };
    const dossier = await learnerIaDossier(ctx);
    if (!dossier) return { error: "Aucun dossier Formation IA." };
    if (!dossier.enrollment.iaAccessOpenedAt) return { error: `Accès non ouvert. ${dossier.blockers.join(" ")}`.trim() };
    url = iaLearnerSsoLink(ctx.user, dossier);
    if (!url) return { error: "Connexion à l'espace e-learning non configurée sur cette installation (variables IA_APP_URL et IA_SSO_SECRET)." };
  } catch (e) {
    return fail(e, "L'ouverture de l'espace e-learning a échoué.");
  }
  redirect(url);
}

/* ------------------------------------------------------------------ */
/* Dossier côté organisme : accès e-learning                           */
/* ------------------------------------------------------------------ */

const accessSchema = z.object({ orgId: z.string().uuid("Organisme invalide"), enrollmentId: z.string().uuid("Inscription invalide"), reason: z.string().trim().max(500).optional() });

export async function openIaAccessAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const d = accessSchema.parse(Object.fromEntries(formData));
    const ctx = await requireOrg(d.orgId, "enrollments.manage");
    if (ctx.trainerOnly) return { error: "Un formateur seul ne peut pas ouvrir l'accès e-learning." };
    await openIaAccess(ctx.org.id, d.enrollmentId, { userId: ctx.user.id, reason: d.reason?.trim() || `Ouverture par ${ctx.user.firstName} ${ctx.user.lastName} depuis le dossier.` });
    revalidatePath(`/app/${ctx.org.id}/inscriptions/${d.enrollmentId}`);
    revalidatePath("/moi");
    return { ok: true, message: "Accès e-learning ouvert : l'apprenant est notifié et peut ouvrir son espace depuis l'extranet." };
  } catch (e) {
    return fail(e, "L'ouverture de l'accès a échoué.");
  }
}

export async function closeIaAccessAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const d = accessSchema.parse(Object.fromEntries(formData));
    const ctx = await requireOrg(d.orgId, "enrollments.manage");
    if (ctx.trainerOnly) return { error: "Un formateur seul ne peut pas fermer l'accès e-learning." };
    const reason = d.reason?.trim();
    if (!reason) return { error: "Indiquez le motif de la fermeture : il est conservé dans le journal du dossier." };
    await closeIaAccess(ctx.org.id, d.enrollmentId, { userId: ctx.user.id, reason });
    revalidatePath(`/app/${ctx.org.id}/inscriptions/${d.enrollmentId}`);
    revalidatePath("/moi");
    return { ok: true, message: "Accès e-learning fermé. Le motif est journalisé." };
  } catch (e) {
    return fail(e, "La fermeture de l'accès a échoué.");
  }
}
