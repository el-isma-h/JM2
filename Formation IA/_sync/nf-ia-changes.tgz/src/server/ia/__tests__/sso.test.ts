import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { createHmac } from "node:crypto";
import { buildIaSsoPayload, iaSsoLink, iaSsoNonce, iaSsoUrl, signIaSsoToken, verifyIaSsoToken, IA_SSO_TTL_SECONDS, type IaSsoInput } from "../sso";
import { entitlementsForOffer, IA_LEVELS, IA_OFFERS, getIaOffer } from "../catalog";

const SECRET = "secret-de-test-formation-ia-0123456789abcdef";
const NOW = new Date("2026-11-05T10:00:00Z");

const camille: IaSsoInput = {
  userId: "5c0d3a6e-2b4f-4f0e-9a11-0d1f3b6c9e21",
  email: "Camille.Fontaine@Exemple.fr",
  firstName: "Camille",
  lastName: "Fontaine",
  entitlements: ["N1", "N2"],
  demo: true,
  enrollmentId: "d2b4b0c3-1e5f-4c7a-8b3d-5a6e7f8c9d01",
  back: "https://formation.nikaholding.world/moi",
};

describe("Jeton SSO Formation IA", () => {
  it("encode le contenu en base64url et signe en HMAC-SHA256 (base64url)", () => {
    const payload = buildIaSsoPayload(camille, NOW);
    const token = signIaSsoToken(payload, SECRET);
    const [p, s] = token.split(".");
    expect(token.split(".")).toHaveLength(2);
    expect(p).toMatch(/^[A-Za-z0-9_-]+$/);
    expect(s).toMatch(/^[A-Za-z0-9_-]+$/);
    expect(JSON.parse(Buffer.from(p, "base64url").toString("utf8"))).toEqual(payload);
    expect(s).toBe(createHmac("sha256", SECRET).update(p).digest("base64url"));
  });

  it("respecte le format du contrat : v 1, e-mail normalisé, exp = iat + 300 s, nonce de 24 caractères, orgSlug", () => {
    const payload = buildIaSsoPayload(camille, NOW);
    expect(payload.v).toBe(1);
    expect(payload.sub).toBe(camille.userId);
    expect(payload.email).toBe("camille.fontaine@exemple.fr");
    expect(payload.iat).toBe(Math.floor(NOW.getTime() / 1000));
    expect(payload.exp - payload.iat).toBe(IA_SSO_TTL_SECONDS);
    expect(payload.nonce).toMatch(/^[A-Za-z0-9]{24}$/);
    expect(payload.demo).toBe(true);
    expect(payload.entitlements).toEqual(["N1", "N2"]);
    expect(payload.orgSlug).toBe("next-formation-academie");
    expect(payload.enrollmentId).toBe(camille.enrollmentId);
    expect(payload.back).toBe(camille.back);
    expect(Object.keys(payload).sort()).toEqual(["back", "demo", "email", "enrollmentId", "entitlements", "exp", "firstName", "iat", "lastName", "nonce", "orgSlug", "sub", "v"]);
  });

  it("produit un nonce différent à chaque jeton", () => {
    const a = iaSsoNonce();
    const b = iaSsoNonce();
    expect(a).not.toBe(b);
    expect(new Set(Array.from({ length: 50 }, () => iaSsoNonce())).size).toBe(50);
  });

  it("se vérifie avec le même secret et se refuse avec un autre", () => {
    const token = signIaSsoToken(buildIaSsoPayload(camille, NOW), SECRET);
    expect(verifyIaSsoToken(token, SECRET, NOW).ok).toBe(true);
    expect(verifyIaSsoToken(token, `${SECRET}x`, NOW)).toEqual({ ok: false, reason: "signature" });
    const [p, s] = token.split(".");
    const tampered = `${Buffer.from(JSON.stringify({ ...JSON.parse(Buffer.from(p, "base64url").toString()), demo: false })).toString("base64url")}.${s}`;
    expect(verifyIaSsoToken(tampered, SECRET, NOW)).toEqual({ ok: false, reason: "signature" });
    expect(verifyIaSsoToken("abc", SECRET, NOW)).toEqual({ ok: false, reason: "format" });
  });

  it("expire après 5 minutes", () => {
    const token = signIaSsoToken(buildIaSsoPayload(camille, NOW), SECRET);
    expect(verifyIaSsoToken(token, SECRET, new Date(NOW.getTime() + 299_000)).ok).toBe(true);
    expect(verifyIaSsoToken(token, SECRET, new Date(NOW.getTime() + 300_000))).toEqual({ ok: false, reason: "expire" });
  });

  it("transmet null pour « tous les niveaux » et conserve un tableau vide tel quel", () => {
    expect(buildIaSsoPayload({ ...camille, entitlements: null }, NOW).entitlements).toBeNull();
    expect(buildIaSsoPayload({ ...camille, entitlements: [] }, NOW).entitlements).toEqual([]);
  });

  it("construit l'URL `${IA_APP_URL}/sso?token=` sans double barre", () => {
    expect(iaSsoUrl("http://localhost:3001/ia/", "a.b")).toBe("http://localhost:3001/ia/sso?token=a.b");
    expect(iaSsoUrl("https://formation.nikaholding.world/ia", "a.b")).toBe("https://formation.nikaholding.world/ia/sso?token=a.b");
  });
});

describe("iaSsoLink et configuration", () => {
  const saved = { url: process.env.IA_APP_URL, secret: process.env.IA_SSO_SECRET };
  beforeEach(() => {
    delete process.env.IA_APP_URL;
    delete process.env.IA_SSO_SECRET;
  });
  afterEach(() => {
    if (saved.url === undefined) delete process.env.IA_APP_URL;
    else process.env.IA_APP_URL = saved.url;
    if (saved.secret === undefined) delete process.env.IA_SSO_SECRET;
    else process.env.IA_SSO_SECRET = saved.secret;
  });

  it("renvoie null sans IA_APP_URL ou sans IA_SSO_SECRET, ou avec un secret trop court", () => {
    expect(iaSsoLink(camille, NOW)).toBeNull();
    process.env.IA_APP_URL = "http://localhost:3001/ia";
    expect(iaSsoLink(camille, NOW)).toBeNull();
    process.env.IA_SSO_SECRET = "court";
    expect(iaSsoLink(camille, NOW)).toBeNull();
    delete process.env.IA_APP_URL;
    process.env.IA_SSO_SECRET = SECRET;
    expect(iaSsoLink(camille, NOW)).toBeNull();
  });

  it("renvoie un lien vérifiable quand les deux variables sont renseignées", () => {
    process.env.IA_APP_URL = "http://localhost:3001/ia";
    process.env.IA_SSO_SECRET = SECRET;
    const link = iaSsoLink(camille, NOW);
    expect(link).not.toBeNull();
    const url = new URL(link!);
    expect(url.pathname).toBe("/ia/sso");
    const v = verifyIaSsoToken(url.searchParams.get("token")!, SECRET, NOW);
    expect(v.ok).toBe(true);
    if (v.ok) expect(v.payload.sub).toBe(camille.userId);
  });
});

describe("Catalogue : niveaux, offres et droits", () => {
  it("expose les cinq niveaux avec leurs durées et 1 490 € par niveau N1-N4", () => {
    expect(IA_LEVELS.map((l) => [l.code, l.hours])).toEqual([
      ["N1", 25],
      ["N2", 35],
      ["N3", 45],
      ["N4", 45],
      ["N5", 30],
    ]);
    for (const l of IA_LEVELS.filter((x) => x.code !== "N5")) expect(l.priceCents).toBe(149_000);
    expect(IA_LEVELS.every((l) => !/[–—]/.test(l.title))).toBe(true);
  });

  it("définit les offres N1 à N4, PARCOURS (4 990 €, provisoire) et N5 (1 290 €, provisoire)", () => {
    expect(IA_OFFERS.map((o) => o.code)).toEqual(["N1", "N2", "N3", "N4", "PARCOURS", "N5"]);
    expect(getIaOffer("PARCOURS")).toMatchObject({ priceCents: 499_000, provisional: true, hours: 150 });
    expect(getIaOffer("N5")).toMatchObject({ priceCents: 129_000, provisional: true, requiresLevel: "N3" });
    expect(getIaOffer("N2")).toMatchObject({ priceCents: 149_000, provisional: false, requiresLevel: "N1" });
  });

  it("déduit les droits e-learning d'une offre", () => {
    expect(entitlementsForOffer("N3")).toEqual(["N3"]);
    expect(entitlementsForOffer("PARCOURS")).toEqual(["N1", "N2", "N3", "N4"]);
    expect(entitlementsForOffer("N5")).toEqual(["N5"]);
    expect(entitlementsForOffer("inconnue")).toEqual([]);
    expect(entitlementsForOffer(null)).toEqual([]);
  });
});
