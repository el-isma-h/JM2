import { describe, expect, it } from "vitest";
import { entitlementsForOffer, IA_OFFERS } from "../catalog";
import * as rules from "../enrollment-rules";
import { CPF_WORDING, IA_FUNDING_META, IA_FUNDINGS, IA_PIECES, IA_PUBLIC_TEXTS, iaAccessBlockers, iaAccessShouldOpen, iaContractTemplate, iaExpectedPieces, iaPaymentTerms } from "../enrollment-rules";

describe("ouverture de l'accès e-learning", () => {
  it("s'ouvre quand le contrat est signé et que le financement n'est pas CPF", () => {
    for (const f of ["particulier", "entreprise", "opco", "france_travail"] as const) {
      expect(iaAccessShouldOpen({ contractSigned: true, funding: f })).toBe(true);
    }
  });

  it("ne s'ouvre jamais sans signature", () => {
    for (const f of IA_FUNDINGS) expect(iaAccessShouldOpen({ contractSigned: false, funding: f })).toBe(false);
  });

  it("ne s'ouvre jamais automatiquement pour un dossier CPF, même signé", () => {
    expect(iaAccessShouldOpen({ contractSigned: true, funding: "cpf" })).toBe(false);
  });

  it("ne s'ouvre pas sans financement connu", () => {
    expect(iaAccessShouldOpen({ contractSigned: true, funding: null })).toBe(false);
  });

  it("explique ce qui manque sans promettre d'accès", () => {
    const cpf = iaAccessBlockers({ contractSigned: false, contractExists: false, funding: "cpf" });
    expect(cpf.join(" ")).toContain("pré-réservation CPF");
    expect(iaAccessBlockers({ contractSigned: false, contractExists: true, funding: "particulier" })).toEqual(["Le contrat ou la convention attend la signature de toutes les parties."]);
    expect(iaAccessBlockers({ contractSigned: false, contractExists: false, funding: "particulier" })).toEqual(["Le contrat ou la convention n'a pas encore été généré."]);
  });
});

describe("pièces attendues par financement", () => {
  const codes = (f: rules.IaFunding) => iaExpectedPieces(f).map((p) => p.code);

  it("exige toujours la pièce d'identité", () => {
    for (const f of IA_FUNDINGS) expect(codes(f)).toContain("piece_identite");
  });

  it("attend l'attestation OPCO uniquement en financement OPCO", () => {
    expect(codes("opco")).toEqual(["piece_identite", "attestation_prise_en_charge_opco"]);
    expect(codes("entreprise")).not.toContain("attestation_prise_en_charge_opco");
  });

  it("attend le bon de commande ou l'accord de l'employeur en financement entreprise", () => {
    expect(codes("entreprise")).toEqual(["piece_identite", "bon_commande_entreprise"]);
  });

  it("attend l'attestation France Travail en financement France Travail", () => {
    expect(codes("france_travail")).toEqual(["piece_identite", "attestation_france_travail"]);
  });

  it("n'attend que la pièce d'identité en financement personnel et en pré-réservation CPF", () => {
    expect(codes("particulier")).toEqual(["piece_identite"]);
    expect(codes("cpf")).toEqual(["piece_identite"]);
  });

  it("déclare des déclencheurs cohérents pour le paramétrage required_pieces", () => {
    for (const p of IA_PIECES) {
      expect(p.code).toMatch(/^[a-z_]+$/);
      for (const k of p.fundingKinds) expect(IA_FUNDINGS).toContain(k);
    }
  });
});

describe("offres et prix (centimes)", () => {
  const price = (code: string) => IA_OFFERS.find((o) => o.code === code)?.priceCents;

  it("vend chaque niveau N1 à N4 à 1 490 € TTC (sous le plafond CPF RS de 1 500 €)", () => {
    for (const c of ["N1", "N2", "N3", "N4"]) {
      expect(price(c)).toBe(149_000);
      expect(price(c)!).toBeLessThan(150_000);
    }
  });

  it("vend le parcours complet 4 990 € et la spécialisation N5 1 290 € (tarifs provisoires)", () => {
    expect(price("PARCOURS")).toBe(499_000);
    expect(price("N5")).toBe(129_000);
    expect(IA_OFFERS.find((o) => o.code === "PARCOURS")?.provisional).toBe(true);
    expect(IA_OFFERS.find((o) => o.code === "N5")?.provisional).toBe(true);
  });

  it("transmet les droits e-learning attendus (PARCOURS = N1 à N4)", () => {
    expect(entitlementsForOffer("PARCOURS")).toEqual(["N1", "N2", "N3", "N4"]);
    expect(entitlementsForOffer("N2")).toEqual(["N2"]);
    expect(entitlementsForOffer("N5")).toEqual(["N5"]);
  });

  it("formate les conditions de règlement avec le prix transmis, sans calcul de TVA à 20 %", () => {
    const t = iaPaymentTerms("particulier", "1 490,00 €");
    expect(t).toContain("1 490,00 €");
    expect(t).toContain("14 jours");
    expect(t).not.toContain("1 788");
  });
});

describe("contractualisation par financement", () => {
  it("contrat de formation professionnelle pour un particulier ou France Travail, convention pour entreprise et OPCO, rien pour le CPF", () => {
    expect(iaContractTemplate("particulier")).toBe("contrat_formation_particulier");
    expect(iaContractTemplate("france_travail")).toBe("contrat_formation_particulier");
    expect(iaContractTemplate("entreprise")).toBe("convention_formation");
    expect(iaContractTemplate("opco")).toBe("convention_formation");
    expect(iaContractTemplate("cpf")).toBeNull();
  });

  it("aligne le type de contrat de l'inscription sur le modèle", () => {
    expect(IA_FUNDING_META.particulier.contractKind).toBe("contrat_particulier");
    expect(IA_FUNDING_META.entreprise.contractKind).toBe("convention_formation");
    expect(IA_FUNDING_META.cpf.contractKind).toBe("cpf");
  });
});

describe("formulation CPF et mentions interdites", () => {
  function allStrings(v: unknown, out: string[] = []): string[] {
    if (typeof v === "string") out.push(v);
    else if (Array.isArray(v)) for (const x of v) allStrings(x, out);
    else if (v && typeof v === "object") for (const x of Object.values(v as Record<string, unknown>)) allStrings(x, out);
    return out;
  }

  it("utilise la formulation exacte du contrat entre chantiers", () => {
    expect(CPF_WORDING).toBe("Certification en cours d'enregistrement au Répertoire spécifique (France Compétences) : financement CPF bientôt disponible.");
    expect(IA_FUNDING_META.cpf.description).toContain(CPF_WORDING);
    expect(IA_FUNDING_META.cpf.description).toContain("pré-réservation CPF");
    expect(IA_PUBLIC_TEXTS.cpf).toBe(CPF_WORDING);
  });

  it("n'exporte aucune chaîne « éligible CPF », « certifié Qualiopi » ou « équivaut à une certification »", () => {
    const texts = [...allStrings(rules), ...allStrings(IA_OFFERS), ...IA_FUNDINGS.map((f) => iaPaymentTerms(f, "1 490,00 €"))];
    expect(texts.length).toBeGreaterThan(20);
    for (const t of texts) {
      expect(t.toLowerCase()).not.toContain("éligible cpf");
      expect(t.toLowerCase()).not.toContain("eligible cpf");
      expect(t.toLowerCase()).not.toContain("certifié qualiopi");
      expect(t.toLowerCase()).not.toContain("équivaut à une certification");
    }
  });

  it("n'utilise ni tiret cadratin ni demi-cadratin dans les libellés", () => {
    for (const t of allStrings(rules)) expect(t).not.toMatch(/[—–]/);
  });
});
