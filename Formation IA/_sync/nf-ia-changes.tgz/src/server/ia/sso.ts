import "server-only";
import { createHmac, randomBytes, timingSafeEqual } from "node:crypto";
import { iaConfig } from "@/lib/env";
import { IA_LEVEL_CODES, IA_ORG_SLUG, type IaLevelCode } from "./catalog";

/**
 * Connexion unique Next Formation → espace e-learning (contrat `docs/formation-ia-integration.md`, « Jeton SSO »).
 * URL : `${IA_APP_URL}/sso?token=<payload>.<signature>` avec payload = base64url(JSON) et
 * signature = base64url(HMAC-SHA256(payload, IA_SSO_SECRET)). Durée de vie : 5 minutes. Nonce de 24 caractères.
 */

export const IA_SSO_TTL_SECONDS = 300;
export const IA_SSO_NONCE_LENGTH = 24;

export type IaSsoPayload = {
  v: 1;
  sub: string;
  email: string;
  firstName: string;
  lastName: string;
  iat: number;
  exp: number;
  nonce: string;
  demo: boolean;
  /** Niveaux ouverts ; null = tous les niveaux (comportement des comptes invités côté e-learning). */
  entitlements: IaLevelCode[] | null;
  orgSlug: string;
  enrollmentId: string | null;
  back: string;
};

export type IaSsoInput = {
  userId: string;
  email: string;
  firstName: string;
  lastName: string;
  /** Niveaux ouverts (codes inconnus ignorés) ; null = tous les niveaux. */
  entitlements: readonly string[] | null;
  demo?: boolean;
  enrollmentId?: string | null;
  /** Lien de retour vers Next Formation (ex. `${APP_URL}/moi`). */
  back: string;
  /** Slug de l'organisme vendeur (par défaut `next-formation-academie`). */
  orgSlug?: string;
};

const ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

/** Nonce aléatoire alphanumérique de 24 caractères (jamais vu deux fois : table `sso_nonces` côté e-learning). */
export function iaSsoNonce(length = IA_SSO_NONCE_LENGTH): string {
  const bytes = randomBytes(length);
  let out = "";
  for (let i = 0; i < length; i++) out += ALPHABET[bytes[i] % ALPHABET.length];
  return out;
}

export function base64url(input: string | Buffer): string {
  return Buffer.from(input).toString("base64url");
}

export function iaSsoSignature(payloadB64: string, secret: string): string {
  return createHmac("sha256", secret).update(payloadB64).digest("base64url");
}

/** Construit le contenu du jeton (sans le signer) : `iat` = maintenant, `exp` = iat + 300 s. */
export function buildIaSsoPayload(input: IaSsoInput, now: Date = new Date()): IaSsoPayload {
  const iat = Math.floor(now.getTime() / 1000);
  return {
    v: 1,
    sub: input.userId,
    email: input.email.trim().toLowerCase(),
    firstName: input.firstName.trim(),
    lastName: input.lastName.trim(),
    iat,
    exp: iat + IA_SSO_TTL_SECONDS,
    nonce: iaSsoNonce(),
    demo: Boolean(input.demo),
    entitlements: input.entitlements === null ? null : input.entitlements.filter((c): c is IaLevelCode => (IA_LEVEL_CODES as readonly string[]).includes(c)),
    orgSlug: input.orgSlug ?? IA_ORG_SLUG,
    enrollmentId: input.enrollmentId ?? null,
    back: input.back,
  };
}

/** Jeton signé `<payload>.<signature>` pour un contenu donné (fonction pure, testable). */
export function signIaSsoToken(payload: IaSsoPayload, secret: string): string {
  const p = base64url(JSON.stringify(payload));
  return `${p}.${iaSsoSignature(p, secret)}`;
}

export type IaSsoVerification = { ok: true; payload: IaSsoPayload } | { ok: false; reason: "format" | "signature" | "expire" | "contenu" };

/**
 * Vérification du jeton (même algorithme que l'app e-learning) : signature en temps constant, expiration,
 * contenu minimal. Utilisée par les tests et disponible pour une recette locale ; le nonce n'est pas contrôlé ici.
 */
export function verifyIaSsoToken(token: string, secret: string, now: Date = new Date()): IaSsoVerification {
  const parts = token.split(".");
  if (parts.length !== 2 || !parts[0] || !parts[1]) return { ok: false, reason: "format" };
  const expected = Buffer.from(iaSsoSignature(parts[0], secret));
  const given = Buffer.from(parts[1]);
  if (expected.length !== given.length || !timingSafeEqual(expected, given)) return { ok: false, reason: "signature" };
  let payload: IaSsoPayload;
  try {
    payload = JSON.parse(Buffer.from(parts[0], "base64url").toString("utf8")) as IaSsoPayload;
  } catch {
    return { ok: false, reason: "contenu" };
  }
  if (payload?.v !== 1 || typeof payload.sub !== "string" || typeof payload.email !== "string" || typeof payload.nonce !== "string" || payload.nonce.length !== IA_SSO_NONCE_LENGTH) return { ok: false, reason: "contenu" };
  if (typeof payload.exp !== "number" || payload.exp * 1000 <= now.getTime()) return { ok: false, reason: "expire" };
  return { ok: true, payload };
}

/** Base de l'URL e-learning sans barre finale (`IA_APP_URL`, ex. `https://formation.nikaholding.world/ia`). */
export function iaSsoUrl(appUrl: string, token: string): string {
  return `${appUrl.replace(/\/+$/, "")}/sso?token=${encodeURIComponent(token)}`;
}

/**
 * Lien de connexion unique vers l'espace e-learning pour un utilisateur Next Formation.
 * null si `IA_APP_URL` ou `IA_SSO_SECRET` (32 caractères minimum) manquent : le bouton explique alors la
 * configuration manquante (`integrations.ia` dans `src/lib/env.ts`). Chaque appel produit un jeton neuf (nonce).
 */
export function iaSsoLink(input: IaSsoInput, now: Date = new Date()): string | null {
  const cfg = iaConfig();
  if (!cfg.ok) return null;
  return iaSsoUrl(cfg.appUrl, signIaSsoToken(buildIaSsoPayload(input, now), cfg.secret));
}
