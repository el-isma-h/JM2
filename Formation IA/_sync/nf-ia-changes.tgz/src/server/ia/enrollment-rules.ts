/**
 * Règles pures de l'inscription publique à la Formation IA (NF-IA-150) : financements proposés,
 * pièces attendues par financement, modèle de contrat, règle d'ouverture de l'accès e-learning,
 * formulations publiques. Aucune dépendance serveur : testé dans `__tests__/enrollment.test.ts`.
 *
 * Règles de formulation (contrat entre chantiers) : jamais « éligible CPF », jamais « certifié Qualiopi »,
 * jamais « équivaut à une certification ».
 */

export type IaFunding = "cpf" | "opco" | "entreprise" | "france_travail" | "particulier";
export const IA_FUNDINGS: IaFunding[] = ["particulier", "entreprise", "opco", "france_travail", "cpf"];

/** Formulation exacte imposée pour le CPF (contrat entre chantiers). */
export const CPF_WORDING = "Certification en cours d'enregistrement au Répertoire spécifique (France Compétences) : financement CPF bientôt disponible.";
export const CPF_PRERESERVATION = "Votre dossier est enregistré comme pré-réservation CPF. L'organisme vous recontacte dès l'enregistrement de la certification ; aucun accès n'est ouvert d'ici là.";

export const IA_FUNDING_META: Record<
  IaFunding,
  {
    label: string;
    description: string;
    /** Type de contrat de l'inscription (`enrollments.contractKind`). */
    contractKind: "contrat_particulier" | "convention_formation" | "cpf";
    /** Type de financeur (`fundings.kind`). */
    funderKind: "particulier" | "entreprise" | "opco" | "france_travail" | "cpf";
    /** Modèle de document de contractualisation ; null : aucune contractualisation automatique (CPF). */
    templateCode: "contrat_formation_particulier" | "convention_formation" | null;
    /** L'inscription passe-t-elle par une entreprise (convention) ? */
    needsCompany: boolean;
  }
> = {
  particulier: {
    label: "Financement personnel",
    description: "Contrat de formation professionnelle signé en ligne, délai de rétractation de 14 jours à compter de la signature, échéancier possible en plusieurs fois sans frais (convenu avec l'organisme).",
    contractKind: "contrat_particulier",
    funderKind: "particulier",
    templateCode: "contrat_formation_particulier",
    needsCompany: false,
  },
  entreprise: {
    label: "Entreprise (plan de développement des compétences)",
    description: "Convention de formation établie entre l'organisme et votre employeur, signée par les deux parties. Votre employeur règle la formation.",
    contractKind: "convention_formation",
    funderKind: "entreprise",
    templateCode: "convention_formation",
    needsCompany: true,
  },
  opco: {
    label: "OPCO (prise en charge via votre employeur)",
    description: "Convention de formation avec votre employeur ; l'organisme prépare la demande de prise en charge auprès de l'OPCO. L'attestation de prise en charge est attendue avant le début.",
    contractKind: "convention_formation",
    funderKind: "opco",
    templateCode: "convention_formation",
    needsCompany: true,
  },
  france_travail: {
    label: "France Travail (aide individuelle à la formation)",
    description: "Devis transmis à votre conseiller France Travail pour une aide individuelle à la formation ; contrat de formation professionnelle signé en ligne. L'accord de France Travail est attendu avant le début.",
    contractKind: "contrat_particulier",
    funderKind: "france_travail",
    templateCode: "contrat_formation_particulier",
    needsCompany: false,
  },
  cpf: {
    label: "Compte personnel de formation (pré-réservation)",
    description: `${CPF_WORDING} ${CPF_PRERESERVATION}`,
    contractKind: "cpf",
    funderKind: "cpf",
    templateCode: null,
    needsCompany: false,
  },
};

export function isIaFunding(v: unknown): v is IaFunding {
  return typeof v === "string" && (IA_FUNDINGS as string[]).includes(v);
}

/* ---------- Pièces attendues ---------- */

export type IaPieceSpec = {
  code: string;
  label: string;
  description: string;
  category: "piece_identite" | "justificatif" | "convention";
  providedBy: "apprenant" | "entreprise" | "financeur";
  isRequired: boolean;
  /** Financements qui déclenchent la pièce (`required_pieces.appliesTo.fundingKinds`) ; vide : tous. */
  fundingKinds: IaFunding[];
};

/** Pièces attendues par la Formation IA, référencées par code dans `required_pieces` de l'organisme vendeur. */
export const IA_PIECES: IaPieceSpec[] = [
  { code: "piece_identite", label: "Pièce d'identité", description: "Carte nationale d'identité, passeport ou titre de séjour en cours de validité (recto-verso).", category: "piece_identite", providedBy: "apprenant", isRequired: true, fundingKinds: [] },
  { code: "attestation_prise_en_charge_opco", label: "Attestation de prise en charge OPCO", description: "Accord de prise en charge délivré par l'OPCO de votre employeur. Peut être déposée plus tard.", category: "justificatif", providedBy: "financeur", isRequired: true, fundingKinds: ["opco"] },
  { code: "bon_commande_entreprise", label: "Bon de commande ou accord de l'employeur", description: "Bon de commande, ou tout écrit de l'employeur validant l'inscription. La convention signée le remplace.", category: "convention", providedBy: "entreprise", isRequired: true, fundingKinds: ["entreprise"] },
  { code: "attestation_france_travail", label: "Attestation France Travail", description: "Attestation d'inscription ou notification d'aide individuelle à la formation. Peut être déposée plus tard.", category: "justificatif", providedBy: "financeur", isRequired: true, fundingKinds: ["france_travail"] },
];

/** Pièces attendues pour un financement donné (la pièce d'identité est toujours attendue). */
export function iaExpectedPieces(funding: IaFunding): IaPieceSpec[] {
  return IA_PIECES.filter((p) => !p.fundingKinds.length || p.fundingKinds.includes(funding));
}

/* ---------- Contractualisation ---------- */

export function iaContractTemplate(funding: IaFunding): "contrat_formation_particulier" | "convention_formation" | null {
  return IA_FUNDING_META[funding].templateCode;
}

/** Conditions de règlement inscrites dans le contrat ou la convention selon le financement (jamais inventées : issues du choix de l'apprenant). */
export function iaPaymentTerms(funding: IaFunding, priceLabel: string): string {
  switch (funding) {
    case "particulier":
      return `Prix TTC de ${priceLabel} (TVA non applicable, article 261-4-4° du CGI, sous réserve de l'exonération de l'organisme). Aucune somme n'est exigible avant l'expiration du délai de rétractation de 14 jours. Règlement en une fois à l'issue de ce délai, ou selon un échéancier en plusieurs fois sans frais convenu avec l'organisme.`;
    case "france_travail":
      return `Prix TTC de ${priceLabel}. Prise en charge demandée auprès de France Travail (aide individuelle à la formation) sur devis ; aucune somme n'est due par le stagiaire si l'aide est accordée. À défaut d'accord, le stagiaire peut renoncer sans frais avant le début de la formation.`;
    case "entreprise":
      return `Prix TTC de ${priceLabel} (TVA non applicable, article 261-4-4° du CGI, sous réserve de l'exonération de l'organisme). Facturation à l'entreprise à l'ouverture de l'accès à la formation, paiement à 30 jours.`;
    case "opco":
      return `Prix TTC de ${priceLabel}. Prise en charge demandée auprès de l'OPCO de l'entreprise ; l'entreprise reste redevable de toute somme non prise en charge. Facturation à réception de l'accord de prise en charge.`;
    case "cpf":
      return `Prix TTC de ${priceLabel}. ${CPF_WORDING}`;
  }
}

/* ---------- Ouverture de l'accès e-learning ---------- */

/**
 * Règle du contrat entre chantiers : l'accès s'ouvre automatiquement quand le contrat ou la convention est signé
 * ET que le financement n'est pas CPF. Un dossier CPF attend l'enregistrement RS et la décision de l'organisme.
 */
export function iaAccessShouldOpen(input: { contractSigned: boolean; funding: IaFunding | null }): boolean {
  if (!input.contractSigned) return false;
  if (!input.funding || input.funding === "cpf") return false;
  return true;
}

/** Explication, lisible par l'apprenant, de ce qui manque pour que l'accès s'ouvre. */
export function iaAccessBlockers(input: { contractSigned: boolean; contractExists: boolean; funding: IaFunding | null; signaturePending?: boolean }): string[] {
  const out: string[] = [];
  if (input.funding === "cpf") out.push(CPF_PRERESERVATION);
  if (!input.contractExists) out.push(input.funding === "cpf" ? "Le contrat sera établi après l'enregistrement de la certification." : "Le contrat ou la convention n'a pas encore été généré.");
  else if (!input.contractSigned) out.push(input.signaturePending === false ? "Le contrat ou la convention est en préparation par l'organisme, qui l'enverra en signature." : "Le contrat ou la convention attend la signature de toutes les parties.");
  return out;
}

/* ---------- Libellés exportés (vérifiés par les tests : aucune formulation interdite) ---------- */

export const IA_PUBLIC_TEXTS = {
  qualiopi: "Formation conçue selon le référentiel national qualité (Qualiopi).",
  cpf: CPF_WORDING,
  cpfPrereservation: CPF_PRERESERVATION,
  n5Hint: "Spécialisation conseillée après le niveau 3.",
  price: "Prix TTC, TVA non applicable (article 261-4-4° du CGI) si l'organisme en bénéficie ; précisé sur le devis.",
  confirmationMail: "Votre dossier d'inscription à la Formation IA est enregistré. Vous retrouvez son avancement, vos pièces et vos documents dans votre espace apprenant.",
};
