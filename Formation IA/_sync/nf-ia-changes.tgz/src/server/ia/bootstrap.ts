import "server-only";
import { and, asc, desc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { audit } from "@/server/audit";
import { bootstrapOrgDefaults } from "@/server/org-defaults";
import { recordEvidence } from "@/server/quality/evidence";
import { todayParis } from "@/lib/time";
import { IA_LEVELS, IA_OFFERS, IA_ORG_NAME, IA_ORG_SLUG, IA_PROGRAMME_DATA, IA_PROGRAM_CODE, IA_PROGRAM_SLUG, IA_PROGRAM_TITLE, iaSessionCode, iaSkillLabel, type IaLevelCode } from "./catalog";

/**
 * Amorçage de la Formation IA (NF-IA-150) : idempotent et relançable (`npm run setup` / `npm run seed`).
 * - `bootstrapIa()` : tenant et organisme vendeur réel `next-formation-academie` (`isDemo = false`, champs légaux
 *   laissés vides : à renseigner dans Paramètres, jamais inventés), puis le catalogue ci-dessous ;
 * - `ensureIaCatalog(orgId)` : certification, programme, version active, modules par niveau, sessions FOAD
 *   « entrées permanentes » de l'année, pièces requises, financeurs, preuve qualité IND_1. Réutilisé par la
 *   démonstration Camille (`src/server/demo/ia.ts`) sur un organisme de démonstration.
 * Rien n'est supprimé ni écrasé : une ligne existante (programme, version, session) est conservée telle quelle
 * pour ne pas défaire une modification faite dans l'administration ; les modules sont mis à jour par code.
 */

export type IaCatalogReport = {
  programId: string;
  versionId: string;
  certificationId: string;
  created: string[];
  existing: string[];
  sessionIds: Record<IaLevelCode, string>;
};

export type IaBootstrapReport = IaCatalogReport & { tenantId: string; orgId: string; ownerUserId: string | null; toComplete: string[] };

const join = (parts: (string | null | undefined)[], sep = "\n") => parts.filter((p): p is string => Boolean(p && p.trim())).join(sep);

function levelData(code: IaLevelCode) {
  const l = IA_PROGRAMME_DATA.levels.find((x) => x.id === code);
  if (!l) throw new Error(`Niveau ${code} absent du programme`);
  return l;
}

/** Texte de la version de programme (objectifs, contenu, méthodes…) construit depuis le JSON du programme. */
function versionTexts() {
  const levels = IA_LEVELS.map((l) => ({ ...l, data: levelData(l.code) }));
  const objectives = join([
    "Acquérir, niveau après niveau, les compétences d'usage, d'automatisation, de développement et d'ingénierie de l'intelligence artificielle, et obtenir un certificat par niveau validé.",
    ...levels.map((l) => `${l.title} (${l.hours} h) : ${l.certificate}.`),
  ]);
  const prerequisites = join(levels.map((l) => `${l.title} : ${l.prerequisites}`));
  const audience = join(levels.map((l) => `${l.title} : ${l.audience}`));
  const content = join(
    levels.map((l) => join([`${l.title} (${l.hours} h, ${l.data.modules.length} modules)`, ...l.data.modules.map((m) => `- ${m.code} ${m.title} (${m.hours} h)`)])),
    "\n\n",
  );
  const methods = join([
    "Formation ouverte et à distance (FOAD) sur l'espace e-learning Next Formation, suivie à son rythme : leçons, quiz de 10 questions à la fin de chaque module, missions pratiques corrigées, tuteur IA, examen de 40 questions à la fin de chaque niveau (70 % requis).",
    "Entrées permanentes : chaque niveau s'ouvre dès la contractualisation et la confirmation du financement.",
  ]);
  const evaluationMethods = join([
    "Quiz par module (10 questions), examen par niveau (40 questions, seuil de réussite 70 %), projets et mises en situation évalués sur grille selon le référentiel de compétences (6 compétences par niveau).",
    "Certificat Next Formation IA délivré par niveau validé. Certification en cours d'enregistrement au Répertoire spécifique (France Compétences) : financement CPF bientôt disponible.",
  ]);
  const resources = "Espace e-learning Next Formation (leçons, quiz, missions, tuteur IA, suivi de progression), supports téléchargeables, accès aux outils et interfaces de programmation étudiés (comptes à créer par l'apprenant selon le niveau).";
  const accessibility = "Formation entièrement en ligne, suivie à son rythme depuis un ordinateur connecté. Situation de handicap : contactez l'organisme avant l'inscription pour étudier les adaptations possibles.";
  const accessDelay = "Entrées permanentes toute l'année : accès à l'espace e-learning ouvert dès la signature du contrat ou de la convention et la confirmation du financement (OPCO, entreprise, France Travail, personnel).";
  const priceNote = `1 490 € par niveau (N1 à N4) ; parcours complet N1-N4 : ${(IA_OFFERS.find((o) => o.code === "PARCOURS")!.priceCents / 100).toLocaleString("fr-FR")} € ; spécialisation N5 : ${(IA_OFFERS.find((o) => o.code === "N5")!.priceCents / 100).toLocaleString("fr-FR")} €. Prix TTC ; TVA non applicable (art. 261-4-4° du CGI) si l'organisme en bénéficie, sinon régime à préciser dans Paramètres.`;
  return { objectives, prerequisites, audience, content, methods, evaluationMethods, resources, accessibility, accessDelay, priceNote };
}

/** Description d'un module de catalogue (un par niveau) : public, prérequis, modules et objectifs, compétences. */
function levelModuleDescription(code: IaLevelCode) {
  const l = IA_LEVELS.find((x) => x.code === code)!;
  const d = levelData(code);
  return join(
    [
      `Public : ${l.audience}`,
      `Prérequis : ${l.prerequisites}`,
      `Certificat : ${l.certificate}.`,
      ...d.modules.map((m) => join([`${m.code} ${m.title} (${m.hours} h)`, ...m.objectives.map((o) => `- ${o}`)])),
      d.alignedWith.length ? `Repères : ${d.alignedWith.join(" ; ")}.` : null,
    ],
    "\n\n",
  );
}

function levelSkills(code: IaLevelCode): { code: string; label: string }[] {
  const codes = [...new Set(levelData(code).modules.flatMap((m) => m.skills))].sort();
  return codes.map((c) => ({ code: c, label: iaSkillLabel(c) }));
}

/** Pièces requises propres à la Formation IA (en plus des pièces par défaut de l'organisme). */
const IA_REQUIRED_PIECES = [
  { code: "attestation_france_travail", label: "Attestation d'inscription France Travail", description: "Demandeur d'emploi : attestation d'inscription à jour, pour la demande d'aide individuelle à la formation.", category: "justificatif" as const, providedBy: "apprenant", appliesTo: { contractKinds: ["*"], fundingKinds: ["france_travail"] }, dueDaysBeforeStart: 7 },
  { code: "contrat_formation_signe", label: "Contrat de formation signé (particulier)", description: "Contrat de formation professionnelle conclu avec un particulier (art. L6353-3 du Code du travail), signé après le délai de rétractation.", category: "contrat" as const, providedBy: "apprenant", appliesTo: { contractKinds: ["contrat_particulier", "cpf"], fundingKinds: ["*"] }, dueDaysBeforeStart: 1 },
];

const IA_FUNDERS = [
  { key: "cpf", name: "Caisse des Dépôts (Mon compte formation)", kind: "cpf" as const, notes: "Financement CPF bientôt disponible : certification en cours d'enregistrement au Répertoire spécifique." },
  { key: "france_travail", name: "France Travail", kind: "france_travail" as const, notes: "Aide individuelle à la formation (AIF), sur devis transmis au conseiller." },
];

/**
 * Catalogue NF-IA-150 d'un organisme : crée ce qui manque, met à jour les modules par code, renouvelle les
 * sessions « entrées permanentes » de l'année en cours. `isDemo` marque les lignes de démonstration.
 */
export async function ensureIaCatalog(orgId: string, opts: { isDemo?: boolean; createdBy?: string | null; year?: number } = {}): Promise<IaCatalogReport> {
  const isDemo = Boolean(opts.isDemo);
  const createdBy = opts.createdBy ?? null;
  const year = opts.year ?? Number(todayParis().slice(0, 4));
  const created: string[] = [];
  const existing: string[] = [];

  /* ---------- Certification (RS en cours d'enregistrement : aucun code inventé) ---------- */
  const certTitle = "Certificat Next Formation IA (quatre niveaux ; enregistrement au Répertoire spécifique en cours)";
  let [cert] = await db.select({ id: schema.certifications.id }).from(schema.certifications).where(and(eq(schema.certifications.orgId, orgId), eq(schema.certifications.title, certTitle))).limit(1);
  if (cert) existing.push("certification");
  else {
    [cert] = await db
      .insert(schema.certifications)
      .values({
        orgId,
        title: certTitle,
        rncpCode: null,
        rsCode: null,
        certifier: IA_ORG_NAME,
        level: null,
        blocks: IA_LEVELS.filter((l) => !l.specialisation).map((l) => ({ code: l.code, label: l.certificate, description: `${l.title} (${l.hours} h)` })),
      })
      .returning({ id: schema.certifications.id });
    created.push("certification");
  }

  /* ---------- Programme et version active ---------- */
  let [program] = await db.select({ id: schema.programs.id }).from(schema.programs).where(and(eq(schema.programs.orgId, orgId), eq(schema.programs.code, IA_PROGRAM_CODE))).limit(1);
  if (program) existing.push("programme");
  else {
    [program] = await db
      .insert(schema.programs)
      .values({
        orgId,
        code: IA_PROGRAM_CODE,
        title: IA_PROGRAM_TITLE,
        slug: IA_PROGRAM_SLUG,
        kind: "certifiante",
        category: IA_PROGRAMME_DATA.category,
        certificationId: cert.id,
        availableAsApprenticeship: false,
        availableAsContinuing: true,
        status: "actif",
        isPublished: true,
        publishedAt: new Date(),
        specialty: IA_PROGRAMME_DATA.specialty,
        formacode: IA_PROGRAMME_DATA.formacode,
        cpfEligible: false,
        tags: IA_PROGRAMME_DATA.tags,
        isDemo,
      })
      .returning({ id: schema.programs.id });
    created.push("programme");
    await audit({ action: "ia.bootstrap.program", userId: createdBy, orgId, entityType: "program", entityId: program.id, after: { code: IA_PROGRAM_CODE, isDemo } });
  }

  let [version] = await db
    .select({ id: schema.programVersions.id })
    .from(schema.programVersions)
    .where(and(eq(schema.programVersions.orgId, orgId), eq(schema.programVersions.programId, program.id), eq(schema.programVersions.status, "active")))
    .orderBy(asc(schema.programVersions.version))
    .limit(1);
  if (version) existing.push("version");
  else {
    const t = versionTexts();
    const totalHours = IA_LEVELS.filter((l) => !l.specialisation).reduce((a, l) => a + l.hours, 0);
    [version] = await db
      .insert(schema.programVersions)
      .values({
        orgId,
        programId: program.id,
        version: 1,
        status: "active",
        effectiveFrom: `${year}-01-01`,
        objectives: t.objectives,
        prerequisites: t.prerequisites,
        audience: t.audience,
        modality: "elearning",
        durationHours: totalHours,
        durationDays: null,
        companyHours: 0,
        remoteHours: totalHours,
        content: t.content,
        methods: t.methods,
        evaluationMethods: t.evaluationMethods,
        resources: t.resources,
        accessibility: t.accessibility,
        accessDelay: t.accessDelay,
        priceCents: IA_LEVELS[0].priceCents,
        priceNote: t.priceNote,
        rhythm: { label: "Entrées permanentes, à son rythme (FOAD)" },
        trainerProfile: "Formateurs et tuteurs spécialisés en intelligence artificielle, automatisation et développement ; tuteur IA intégré à l'espace e-learning.",
        createdBy,
        validatedBy: createdBy,
        validatedAt: createdBy ? new Date() : null,
      })
      .returning({ id: schema.programVersions.id });
    created.push("version");
  }

  /* ---------- Modules de catalogue : un par niveau, mis à jour par code ---------- */
  const existingModules = await db.select({ id: schema.modules.id, code: schema.modules.code }).from(schema.modules).where(and(eq(schema.modules.orgId, orgId), eq(schema.modules.programVersionId, version.id)));
  for (const [i, l] of IA_LEVELS.entries()) {
    const values = { blockCode: l.moduleCode, code: l.code, title: l.title, description: levelModuleDescription(l.code), hours: l.hours, position: i, modality: "elearning" as const, skills: levelSkills(l.code) };
    const found = existingModules.find((m) => m.code === l.code);
    if (found) {
      await db.update(schema.modules).set(values).where(eq(schema.modules.id, found.id));
      existing.push(`module ${l.code}`);
    } else {
      await db.insert(schema.modules).values({ orgId, programVersionId: version.id, ...values });
      created.push(`module ${l.code}`);
    }
  }

  /* ---------- Sessions FOAD « entrées permanentes » de l'année ---------- */
  const [mainSite] = await db.select({ id: schema.sites.id }).from(schema.sites).where(and(eq(schema.sites.orgId, orgId), eq(schema.sites.isMain, true))).limit(1);
  const sessionIds = {} as Record<IaLevelCode, string>;
  for (const l of IA_LEVELS) {
    const code = iaSessionCode(l.code, year);
    const [found] = await db.select({ id: schema.trainingSessions.id }).from(schema.trainingSessions).where(and(eq(schema.trainingSessions.orgId, orgId), eq(schema.trainingSessions.code, code))).limit(1);
    if (found) {
      sessionIds[l.code] = found.id;
      existing.push(`session ${code}`);
      continue;
    }
    const [row] = await db
      .insert(schema.trainingSessions)
      .values({
        orgId,
        programVersionId: version.id,
        code,
        title: `Formation IA ${l.code} (${l.shortTitle}) : entrées permanentes ${year}`,
        kind: "individuel",
        isApprenticeship: false,
        startDate: `${year}-01-01`,
        endDate: `${year}-12-31`,
        siteId: mainSite?.id ?? null,
        modality: "elearning",
        capacity: 500,
        minCapacity: 1,
        rhythm: { label: "Entrées permanentes, à son rythme (FOAD)" },
        status: "ouverte",
        priceCents: l.priceCents,
        isPublished: true,
        notes: `Session à entrées permanentes du niveau ${l.code} (${l.hours} h en ligne). Chaque inscription porte ses propres dates de parcours ; la session est renouvelée chaque année par l'amorçage.`,
        isDemo,
      })
      .returning({ id: schema.trainingSessions.id });
    sessionIds[l.code] = row.id;
    created.push(`session ${code}`);
  }

  /* ---------- Pièces requises et financeurs ---------- */
  const [lastPiece] = await db.select({ position: schema.requiredPieces.position }).from(schema.requiredPieces).where(eq(schema.requiredPieces.orgId, orgId)).orderBy(desc(schema.requiredPieces.position)).limit(1);
  let position = (lastPiece?.position ?? 0) + 100;
  for (const p of IA_REQUIRED_PIECES) {
    const [found] = await db.select({ id: schema.requiredPieces.id }).from(schema.requiredPieces).where(and(eq(schema.requiredPieces.orgId, orgId), eq(schema.requiredPieces.code, p.code))).limit(1);
    if (found) {
      existing.push(`pièce ${p.code}`);
      continue;
    }
    await db.insert(schema.requiredPieces).values({ orgId, code: p.code, label: p.label, description: p.description, category: p.category, providedBy: p.providedBy, appliesTo: p.appliesTo, isRequired: true, dueDaysBeforeStart: p.dueDaysBeforeStart, position: position++ });
    created.push(`pièce ${p.code}`);
  }
  for (const f of IA_FUNDERS) {
    const [found] = await db.select({ id: schema.funders.id }).from(schema.funders).where(and(eq(schema.funders.orgId, orgId), eq(schema.funders.kind, f.kind), eq(schema.funders.name, f.name))).limit(1);
    if (found) {
      existing.push(`financeur ${f.key}`);
      continue;
    }
    await db.insert(schema.funders).values({ orgId, name: f.name, kind: f.kind, notes: f.notes });
    created.push(`financeur ${f.key}`);
  }

  /* ---------- Preuve qualité : information du public (indicateur 1) ---------- */
  const ev = await recordEvidence({
    orgId,
    indicatorCode: "IND_1",
    level: "organisationnel",
    title: `Fiche catalogue publique : ${IA_PROGRAM_TITLE}`,
    note: "Programme publié au catalogue public (/catalogue-public) avec objectifs, prérequis, durée, modalité, tarifs, délai d'accès et accessibilité.",
    evidenceDate: todayParis(),
    sourceType: "program",
    sourceId: program.id,
    programId: program.id,
    createdBy,
  });
  (ev.created ? created : existing).push("preuve IND_1");

  return { programId: program.id, versionId: version.id, certificationId: cert.id, created, existing, sessionIds };
}

/**
 * Tenant et organisme vendeur réel de la Formation IA, puis son catalogue. Les champs légaux (SIRET, NDA,
 * adresse, forme juridique, Qualiopi, signataire) restent vides : à renseigner dans Paramètres.
 * Si le compte ADMIN_EMAIL existe et que l'organisme n'a pas encore de propriétaire, il en devient propriétaire
 * (rôle direction) afin que l'organisme soit administrable immédiatement.
 */
export async function bootstrapIa(): Promise<IaBootstrapReport> {
  let [tenant] = await db.select().from(schema.tenants).where(eq(schema.tenants.slug, IA_ORG_SLUG)).limit(1);
  if (!tenant) {
    [tenant] = await db.insert(schema.tenants).values({ name: IA_ORG_NAME, kind: "organisme", slug: IA_ORG_SLUG, isDemo: false }).returning();
  }
  let [org] = await db.select().from(schema.organismes).where(and(eq(schema.organismes.tenantId, tenant.id), eq(schema.organismes.isDemo, false))).orderBy(asc(schema.organismes.createdAt)).limit(1);
  let orgCreated = false;
  if (!org) {
    org = await db.transaction(async (tx) => {
      const [o] = await tx
        .insert(schema.organismes)
        .values({
          tenantId: tenant.id,
          kind: "of",
          legalName: IA_ORG_NAME,
          tradeName: IA_ORG_NAME,
          country: "FR",
          qualiopiScopes: [],
          onboardingStep: "identite",
          isDemo: false,
        })
        .returning();
      await bootstrapOrgDefaults(tx, o.id);
      await tx.update(schema.sites).set({ name: "Formation à distance (FOAD)" }).where(and(eq(schema.sites.orgId, o.id), eq(schema.sites.isMain, true)));
      return o;
    });
    orgCreated = true;
    await audit({ action: "ia.bootstrap.org", orgId: org.id, tenantId: tenant.id, entityType: "organisme", entityId: org.id, after: { slug: IA_ORG_SLUG } });
  }

  let ownerUserId = org.ownerUserId;
  const adminEmail = process.env.ADMIN_EMAIL?.trim().toLowerCase();
  if (!ownerUserId && adminEmail) {
    const [admin] = await db.select({ id: schema.users.id }).from(schema.users).where(eq(schema.users.email, adminEmail)).limit(1);
    if (admin) {
      await db.insert(schema.memberships).values({ orgId: org.id, userId: admin.id, roles: ["direction"], title: "Propriétaire (amorçage)" }).onConflictDoNothing();
      await db.update(schema.organismes).set({ ownerUserId: admin.id }).where(eq(schema.organismes.id, org.id));
      await audit({ action: "ia.bootstrap.owner", userId: admin.id, orgId: org.id, entityType: "organisme", entityId: org.id, after: { ownerUserId: admin.id } });
      ownerUserId = admin.id;
    }
  }

  const catalog = await ensureIaCatalog(org.id, { isDemo: false, createdBy: ownerUserId });
  const toComplete: string[] = [];
  if (!org.legalForm) toComplete.push("forme juridique");
  if (!org.siren || !org.siret) toComplete.push("SIREN et SIRET");
  if (!org.nda) toComplete.push("numéro de déclaration d'activité (NDA) et région");
  if (!org.addressLine1 || !org.postalCode || !org.city) toComplete.push("adresse du siège");
  if (!org.email || !org.phone) toComplete.push("e-mail et téléphone de contact");
  if (!org.signatoryName) toComplete.push("signataire des conventions et contrats");
  if (!org.qualiopiNumber) toComplete.push("certification Qualiopi (numéro, certificateur, validité) le moment venu");
  if (!org.vatNumber) toComplete.push("régime de TVA (exonération art. 261-4-4° CGI ou numéro de TVA)");
  if (!ownerUserId) toComplete.push("propriétaire de l'organisme (aucun compte ADMIN_EMAIL trouvé)");
  return { ...catalog, tenantId: tenant.id, orgId: org.id, ownerUserId, toComplete, created: orgCreated ? ["tenant et organisme", ...catalog.created] : catalog.created };
}
