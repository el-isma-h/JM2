import "server-only";
import { and, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import programmeData from "./programme-catalogue.json";

/**
 * Formation IA (NF-IA-150) : constantes partagées entre la vitrine, l'inscription publique, le dossier,
 * l'extranet apprenant, l'amorçage et la démonstration Camille. Identifiants fixés par
 * `docs/formation-ia-integration.md` : ne pas les changer sans mettre à jour le contrat.
 *
 * Source du contenu pédagogique : `programme-catalogue.json` (copie de
 * `/home/claude/formation-ia/export/programme-catalogue.json`, tirets cadratins remplacés).
 */

/** Slug du tenant et de l'organisme vendeur réel (`isDemo = false`). */
export const IA_ORG_SLUG = "next-formation-academie";
export const IA_ORG_NAME = "Next Formation Académie";
/** Préfixe du slug des organismes de démonstration Camille (`seedIaDemo`). */
export const IA_DEMO_SLUG_PREFIX = `${IA_ORG_SLUG}-demo-`;

export const IA_PROGRAM_CODE = "NF-IA-150";
export const IA_PROGRAM_TITLE = "Formation IA : 4 niveaux certifiants (150 h)";
export const IA_PROGRAM_SLUG = "formation-ia-4-niveaux-certifiants-150-h";

export type IaLevelCode = "N1" | "N2" | "N3" | "N4" | "N5";
export const IA_LEVEL_CODES: readonly IaLevelCode[] = ["N1", "N2", "N3", "N4", "N5"] as const;

export type IaLevel = {
  code: IaLevelCode;
  /** Code catalogue du niveau (module de catalogue). */
  moduleCode: string;
  title: string;
  /** Intitulé court (sans le préfixe « Niveau n : »). */
  shortTitle: string;
  hours: number;
  /** Prix public TTC en centimes (TVA non applicable si l'organisme en bénéficie, art. 261-4-4° CGI). */
  priceCents: number;
  prerequisites: string;
  audience: string;
  certificate: string;
  /** Niveau exigé avant celui-ci (null = aucun). */
  requiresLevel: IaLevelCode | null;
  /** Spécialisation hors parcours N1-N4 (après N3). */
  specialisation: boolean;
};

const LEVEL_PRICE_CENTS = 149_000;

function shortTitleOf(title: string): string {
  return title.replace(/^Niveau \d\s*:\s*/u, "").trim();
}

const levelMeta: Record<IaLevelCode, { requiresLevel: IaLevelCode | null; specialisation: boolean }> = {
  N1: { requiresLevel: null, specialisation: false },
  N2: { requiresLevel: "N1", specialisation: false },
  N3: { requiresLevel: "N2", specialisation: false },
  N4: { requiresLevel: "N3", specialisation: false },
  N5: { requiresLevel: "N3", specialisation: true },
};

/** Niveaux N1 à N5 : 25 h, 35 h, 45 h, 45 h, 30 h ; 1 490 € par niveau (N5 : voir IA_OFFERS, tarif provisoire). */
export const IA_LEVELS: readonly IaLevel[] = IA_LEVEL_CODES.map((code) => {
  const src = programmeData.levels.find((l) => l.id === code);
  if (!src) throw new Error(`Niveau ${code} absent de programme-catalogue.json`);
  return {
    code,
    moduleCode: src.code,
    title: src.title,
    shortTitle: shortTitleOf(src.title),
    hours: src.hours,
    priceCents: code === "N5" ? 129_000 : LEVEL_PRICE_CENTS,
    prerequisites: src.prerequisites,
    audience: src.audience,
    certificate: src.certificate,
    ...levelMeta[code],
  };
});

export function getIaLevel(code: string): IaLevel | null {
  return IA_LEVELS.find((l) => l.code === code) ?? null;
}

export type IaOfferCode = "N1" | "N2" | "N3" | "N4" | "PARCOURS" | "N5";
export const IA_OFFER_CODES: readonly IaOfferCode[] = ["N1", "N2", "N3", "N4", "PARCOURS", "N5"] as const;

export type IaOffer = {
  code: IaOfferCode;
  label: string;
  description: string;
  /** Prix public TTC en centimes. */
  priceCents: number;
  hours: number;
  /** Niveaux ouverts dans l'espace e-learning (droits transmis dans le jeton SSO). */
  entitlements: readonly IaLevelCode[];
  /** Tarif de lancement à confirmer par Nika : mention affichée dans l'administration uniquement, jamais sur le site public. */
  provisional: boolean;
  /** Niveau à avoir validé avant d'acheter cette offre (null = aucun). */
  requiresLevel: IaLevelCode | null;
};

const hoursOf = (codes: readonly IaLevelCode[]) => codes.reduce((a, c) => a + (getIaLevel(c)?.hours ?? 0), 0);

/** Offres achetables : un niveau N1 à N4 (1 490 €), le parcours complet N1-N4 (4 990 €, provisoire) ou la spécialisation N5 (1 290 €, provisoire). */
export const IA_OFFERS: readonly IaOffer[] = [
  ...(["N1", "N2", "N3", "N4"] as const).map((code): IaOffer => {
    const level = getIaLevel(code)!;
    return { code, label: `Niveau ${code.slice(1)} : ${level.shortTitle}`, description: `${level.hours} h en ligne, certificat ${code} à l'issue de l'examen du niveau.`, priceCents: LEVEL_PRICE_CENTS, hours: level.hours, entitlements: [code], provisional: false, requiresLevel: level.requiresLevel };
  }),
  { code: "PARCOURS", label: "Parcours complet : niveaux 1 à 4", description: "Les quatre niveaux certifiants (150 h) : du grand public à l'expert IA.", priceCents: 499_000, hours: hoursOf(["N1", "N2", "N3", "N4"]), entitlements: ["N1", "N2", "N3", "N4"], provisional: true, requiresLevel: null },
  { code: "N5", label: `Spécialisation : ${getIaLevel("N5")!.shortTitle}`, description: `${getIaLevel("N5")!.hours} h en ligne, après le niveau 3.`, priceCents: 129_000, hours: getIaLevel("N5")!.hours, entitlements: ["N5"], provisional: true, requiresLevel: "N3" },
];

export function getIaOffer(code: string): IaOffer | null {
  return IA_OFFERS.find((o) => o.code === code) ?? null;
}

export function isIaOfferCode(v: unknown): v is IaOfferCode {
  return typeof v === "string" && (IA_OFFER_CODES as readonly string[]).includes(v);
}

/** Droits e-learning d'une offre (PARCOURS = N1 à N4). Tableau vide si l'offre est inconnue. */
export function entitlementsForOffer(offer: string | IaOffer | null | undefined): IaLevelCode[] {
  const o = typeof offer === "string" ? getIaOffer(offer) : offer ?? null;
  return o ? [...o.entitlements] : [];
}

/** Mention de prix pour l'administration : « tarif de lancement, à confirmer » pour les offres provisoires. */
export function iaOfferPriceNote(offer: IaOffer): string | null {
  return offer.provisional ? "Tarif de lancement, à confirmer" : null;
}

/** Code d'une session FOAD « entrées permanentes » d'un niveau pour une année. */
export function iaSessionCode(level: IaLevelCode, year: number): string {
  return `IA-${level}-${year}`;
}

/** Contenu pédagogique du JSON (niveaux, modules, objectifs, compétences). */
export type IaProgrammeData = typeof programmeData;
export const IA_PROGRAMME_DATA: IaProgrammeData = programmeData;

export function iaSkillLabel(code: string): string {
  return (programmeData.skills as Record<string, string>)[code] ?? code;
}

/* ---------- Accès aux lignes réelles (organisme vendeur) ---------- */

/** Organisme vendeur réel (tenant `next-formation-academie`, `isDemo = false`). null tant que l'amorçage n'a pas tourné. */
export async function getIaOrg() {
  const [tenant] = await db.select().from(schema.tenants).where(eq(schema.tenants.slug, IA_ORG_SLUG)).limit(1);
  if (!tenant) return null;
  const [org] = await db
    .select()
    .from(schema.organismes)
    .where(and(eq(schema.organismes.tenantId, tenant.id), eq(schema.organismes.isDemo, false)))
    .orderBy(schema.organismes.createdAt)
    .limit(1);
  return org ? { tenant, org } : null;
}

/** Programme NF-IA-150 d'un organisme (réel ou de démonstration) avec sa version active et ses modules. */
export async function getIaProgram(orgId: string) {
  const [program] = await db
    .select()
    .from(schema.programs)
    .where(and(eq(schema.programs.orgId, orgId), eq(schema.programs.code, IA_PROGRAM_CODE)))
    .limit(1);
  if (!program) return null;
  const [version] = await db
    .select()
    .from(schema.programVersions)
    .where(and(eq(schema.programVersions.orgId, orgId), eq(schema.programVersions.programId, program.id), eq(schema.programVersions.status, "active")))
    .orderBy(schema.programVersions.version)
    .limit(1);
  const modules = version
    ? await db
        .select()
        .from(schema.modules)
        .where(and(eq(schema.modules.orgId, orgId), eq(schema.modules.programVersionId, version.id)))
        .orderBy(schema.modules.position)
    : [];
  return { program, version: version ?? null, modules };
}

/** Session FOAD « entrées permanentes » d'un niveau pour une année (code `IA-<niveau>-<année>`). */
export async function getIaSession(orgId: string, level: IaLevelCode, year: number) {
  const [session] = await db
    .select()
    .from(schema.trainingSessions)
    .where(and(eq(schema.trainingSessions.orgId, orgId), eq(schema.trainingSessions.code, iaSessionCode(level, year))))
    .limit(1);
  return session ?? null;
}
