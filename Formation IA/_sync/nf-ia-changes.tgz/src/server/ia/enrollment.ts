import "server-only";
import { and, desc, eq, inArray, isNull, ne, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { randomToken, sha256 } from "@/lib/crypto";
import { appUrl, integrations } from "@/lib/env";
import { formatCents } from "@/lib/money";
import { todayParis } from "@/lib/time";
import { TERMS_VERSION } from "@/lib/legal";
import { createSession, hashPassword, type SessionUser } from "@/server/auth";
import { getOrgContext } from "@/server/authz";
import { audit } from "@/server/audit";
import { collectTemplateData, DEFAULT_VISIBILITY, getTemplate } from "@/server/documents/generate";
import { brandFromOrg } from "@/server/documents/brand";
import { renderBrandedDocx, renderBrandedPdf } from "@/server/documents/pdf";
import { renderTemplate, type MissingItem } from "@/server/documents/render";
import { getESignAdapter } from "@/server/documents/esign";
import { REQUEST_TTL_DAYS, type Signer, type SignerRole } from "@/server/documents/signatures";
import { createDocument } from "@/server/documents/store";
import { TEMPLATE_VARIABLES } from "@/server/documents/templates-data";
import { createEnrollment, syncEnrollmentPieces } from "@/server/enrollments/service";
import { recalcEnrollmentFundingState } from "@/server/finance/service";
import { formatQuoteNumber } from "@/server/crm/quote-math";
import { numberingPrefix } from "@/server/numbering";
import { layoutMail, sendMail } from "@/server/mail";
import { notify } from "@/server/notify";
import { recordEvidence } from "@/server/quality/evidence";
import { getObject } from "@/server/storage";
import { createTaskOnce, resolveTaskByKey } from "@/server/tasks/service";
import { applyWorkflow } from "@/server/workflows/service";
import { entitlementsForOffer, getIaOrg as getIaOrgRow, getIaSession, IA_OFFERS, type IaOfferCode } from "./catalog";
import { iaSsoLink } from "./sso";
import { CPF_PRERESERVATION, CPF_WORDING, IA_FUNDING_META, IA_PIECES, IA_PUBLIC_TEXTS, iaAccessBlockers, iaAccessShouldOpen, iaPaymentTerms, isIaFunding, type IaFunding } from "./enrollment-rules";

export * from "./enrollment-rules";

/**
 * Inscription publique à la Formation IA (chantier B2) : identité et compte, offre, financement, pièces,
 * contractualisation, puis suivi (extranet apprenant et dossier côté organisme) et ouverture de l'accès e-learning.
 * Toutes les requêtes sont filtrées par l'organisme vendeur (`getIaOrg()`), jamais par un identifiant seul.
 */

type Org = typeof schema.organismes.$inferSelect;
type Person = typeof schema.persons.$inferSelect;
type Enrollment = typeof schema.enrollments.$inferSelect;
type Company = typeof schema.companies.$inferSelect;
type Funding = typeof schema.fundings.$inferSelect;
type Document = typeof schema.documents.$inferSelect;
type SignatureRequest = typeof schema.signatureRequests.$inferSelect;

export const IA_INSCRIPTION_PATH = "/formation-ia/inscription";

/** Organisme vendeur réel (ligne `organismes`), null tant que l'amorçage NF-IA-150 n'a pas tourné. */
async function getIaOrg(): Promise<Org | null> {
  return (await getIaOrgRow())?.org ?? null;
}
export const IA_ACTIVE_STATUSES = ["preinscrit", "inscrit", "en_cours"] as const;

export function iaOfferMeta(code: string | null | undefined) {
  return IA_OFFERS.find((o) => o.code === code) ?? null;
}

export function isIaOffer(v: unknown): v is IaOfferCode {
  return typeof v === "string" && IA_OFFERS.some((o) => o.code === v);
}

/* ------------------------------------------------------------------ */
/* Pièces attendues de l'organisme vendeur                             */
/* ------------------------------------------------------------------ */

/** Garantit l'existence des pièces attendues propres à la Formation IA dans `required_pieces` (idempotent par code ; ne modifie jamais une pièce existante). */
export async function ensureIaRequiredPieces(orgId: string) {
  const existing = await db.select({ code: schema.requiredPieces.code }).from(schema.requiredPieces).where(eq(schema.requiredPieces.orgId, orgId));
  const have = new Set(existing.map((p) => p.code));
  const [{ max }] = await db.select({ max: sql<number>`coalesce(max(${schema.requiredPieces.position}), 0)::int` }).from(schema.requiredPieces).where(eq(schema.requiredPieces.orgId, orgId));
  let position = max;
  for (const p of IA_PIECES) {
    if (have.has(p.code)) continue;
    position += 1;
    await db.insert(schema.requiredPieces).values({
      orgId,
      code: p.code,
      label: p.label,
      description: p.description,
      category: p.category,
      providedBy: p.providedBy,
      appliesTo: { contractKinds: ["*"], fundingKinds: p.fundingKinds.length ? p.fundingKinds : ["*"] },
      isRequired: p.isRequired,
      dueDaysBeforeStart: p.code === "piece_identite" ? 7 : null,
      position,
    });
  }
}

/* ------------------------------------------------------------------ */
/* Lecture du dossier                                                  */
/* ------------------------------------------------------------------ */

export type IaContractState = {
  document: Document;
  request: SignatureRequest | null;
  /** Contrat ou convention signé par toutes les parties (document `signe` ou `valide` sur l'inscription). */
  signed: boolean;
  signedDocumentId: string | null;
  missing: string[];
  /** Signataires (vue publique) : nom, rôle, signé ou non. */
  signers: { name: string; email: string; role: string; signedAt: string | null }[];
};

export type IaDossier = {
  org: Org;
  enrollment: Enrollment;
  person: Person;
  session: typeof schema.trainingSessions.$inferSelect;
  company: Company | null;
  offer: (typeof IA_OFFERS)[number] | null;
  entitlements: string[];
  funding: Funding | null;
  iaFunding: IaFunding | null;
  pieces: { submission: typeof schema.pieceSubmissions.$inferSelect; piece: typeof schema.requiredPieces.$inferSelect; document: Document | null }[];
  contract: IaContractState | null;
  accessOpen: boolean;
  blockers: string[];
  nextAction: string;
};

function iaFundingOf(f: Funding | null): IaFunding | null {
  if (!f) return null;
  return isIaFunding(f.kind) ? f.kind : null;
}

/** Charge le dossier Formation IA d'une inscription (filtré par organisme). Null si l'inscription n'est pas une inscription IA. */
export async function loadIaDossier(orgId: string, enrollmentId: string): Promise<IaDossier | null> {
  const [row] = await db
    .select({ e: schema.enrollments, p: schema.persons, s: schema.trainingSessions, o: schema.organismes, c: schema.companies })
    .from(schema.enrollments)
    .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
    .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.enrollments.sessionId))
    .innerJoin(schema.organismes, eq(schema.organismes.id, schema.enrollments.orgId))
    .leftJoin(schema.companies, eq(schema.companies.id, schema.enrollments.companyId))
    .where(and(eq(schema.enrollments.id, enrollmentId), eq(schema.enrollments.orgId, orgId)))
    .limit(1);
  if (!row || !row.e.iaOffer) return null;
  const { e, p, s, o, c } = row;
  const [funding] = await db
    .select()
    .from(schema.fundings)
    .where(and(eq(schema.fundings.orgId, orgId), eq(schema.fundings.enrollmentId, e.id), ne(schema.fundings.status, "annule")))
    .orderBy(desc(schema.fundings.amountCents), desc(schema.fundings.createdAt))
    .limit(1);
  const pieces = await db
    .select({ submission: schema.pieceSubmissions, piece: schema.requiredPieces, document: schema.documents })
    .from(schema.pieceSubmissions)
    .innerJoin(schema.requiredPieces, eq(schema.requiredPieces.id, schema.pieceSubmissions.requiredPieceId))
    .leftJoin(schema.documents, eq(schema.documents.id, schema.pieceSubmissions.documentId))
    .where(and(eq(schema.pieceSubmissions.orgId, orgId), eq(schema.pieceSubmissions.enrollmentId, e.id)))
    .orderBy(schema.requiredPieces.position);
  const contract = await loadIaContract(orgId, e);
  const iaFunding = iaFundingOf(funding ?? null);
  const offer = iaOfferMeta(e.iaOffer);
  const accessOpen = Boolean(e.iaAccessOpenedAt);
  const blockers = accessOpen ? [] : iaAccessBlockers({ contractSigned: Boolean(contract?.signed), contractExists: Boolean(contract), funding: iaFunding, signaturePending: contract ? Boolean(contract.request && ["envoyee", "signee_partiellement", "non_configure"].includes(contract.request.status)) : undefined });
  const missingPieces = pieces.filter((x) => x.piece.isRequired && (x.submission.status === "attendue" || x.submission.status === "refusee"));
  let nextAction = "Rien ne bloque : votre dossier est à jour.";
  if (accessOpen) nextAction = "Votre accès e-learning est ouvert : ouvrez votre espace depuis le bouton ci-dessous.";
  else if (iaFunding === "cpf") nextAction = CPF_PRERESERVATION;
  else if (!contract) nextAction = "Terminez votre inscription : récapitulatif et contractualisation.";
  else if (!contract.signed) nextAction = contract.request && ["envoyee", "signee_partiellement"].includes(contract.request.status) ? "Signez votre contrat ou convention depuis le lien reçu par e-mail." : "Votre contrat est en préparation par l'organisme ; vous recevrez un lien de signature.";
  else if (missingPieces.length) nextAction = `Déposez les pièces attendues : ${missingPieces.map((x) => x.piece.label).join(", ")}.`;
  return { org: o, enrollment: e, person: p, session: s, company: c ?? null, offer, entitlements: offer ? entitlementsForOffer(offer.code) : [], funding: funding ?? null, iaFunding, pieces, contract, accessOpen, blockers, nextAction };
}

async function loadIaContract(orgId: string, e: Enrollment): Promise<IaContractState | null> {
  const [doc] = await db
    .select()
    .from(schema.documents)
    .where(and(eq(schema.documents.orgId, orgId), eq(schema.documents.enrollmentId, e.id), inArray(schema.documents.category, ["contrat", "convention"]), isNull(schema.documents.sourceType), ne(schema.documents.status, "archive")))
    .orderBy(desc(schema.documents.version), desc(schema.documents.createdAt))
    .limit(1);
  if (!doc) return null;
  const [signedDoc] = await db
    .select({ id: schema.documents.id })
    .from(schema.documents)
    .where(and(eq(schema.documents.orgId, orgId), eq(schema.documents.enrollmentId, e.id), inArray(schema.documents.category, ["contrat", "convention"]), inArray(schema.documents.status, ["signe", "valide"])))
    .orderBy(desc(schema.documents.createdAt))
    .limit(1);
  const [request] = await db
    .select()
    .from(schema.signatureRequests)
    .where(and(eq(schema.signatureRequests.orgId, orgId), eq(schema.signatureRequests.documentId, doc.id)))
    .orderBy(desc(schema.signatureRequests.createdAt))
    .limit(1);
  const gen = (doc.generationData ?? {}) as { missing?: MissingItem[] };
  const signers = Array.isArray(request?.signers) ? (request!.signers as Signer[]) : [];
  return {
    document: doc,
    request: request ?? null,
    signed: Boolean(signedDoc) || request?.status === "signee",
    signedDocumentId: signedDoc?.id ?? request?.signedDocumentId ?? null,
    missing: (gen.missing ?? []).map((m) => m.label),
    signers: signers.map((s) => ({ name: s.name, email: s.email, role: s.role, signedAt: s.signedAt ?? null })),
  };
}

/* ------------------------------------------------------------------ */
/* Parcours public : état courant                                      */
/* ------------------------------------------------------------------ */

export type IaFlow = {
  org: Org | null;
  user: SessionUser | null;
  person: Person | null;
  company: Company | null;
  enrollment: Enrollment | null;
  dossier: IaDossier | null;
  /** Première étape non terminée (1 à 5 ; 6 : parcours terminé). */
  firstIncomplete: number;
};

/** État du parcours d'inscription pour l'utilisateur courant (null si non connecté). */
export async function loadIaFlow(user: SessionUser | null): Promise<IaFlow> {
  const org = await getIaOrg();
  if (!org || !user) return { org, user, person: null, company: null, enrollment: null, dossier: null, firstIncomplete: 1 };
  const [person] = await db.select().from(schema.persons).where(and(eq(schema.persons.orgId, org.id), eq(schema.persons.userId, user.id))).orderBy(desc(schema.persons.createdAt)).limit(1);
  if (!person) return { org, user, person: null, company: null, enrollment: null, dossier: null, firstIncomplete: 1 };
  const [m] = await db.select({ id: schema.memberships.id }).from(schema.memberships).where(and(eq(schema.memberships.orgId, org.id), eq(schema.memberships.userId, user.id), eq(schema.memberships.active, true))).limit(1);
  if (!m) return { org, user, person: null, company: null, enrollment: null, dossier: null, firstIncomplete: 1 };
  const company = person.companyId ? ((await db.select().from(schema.companies).where(and(eq(schema.companies.id, person.companyId), eq(schema.companies.orgId, org.id))).limit(1))[0] ?? null) : null;
  const [enrollment] = await db
    .select()
    .from(schema.enrollments)
    .where(and(eq(schema.enrollments.orgId, org.id), eq(schema.enrollments.personId, person.id), inArray(schema.enrollments.status, [...IA_ACTIVE_STATUSES]), sql`${schema.enrollments.iaOffer} is not null`))
    .orderBy(desc(schema.enrollments.createdAt))
    .limit(1);
  if (!enrollment) return { org, user, person, company, enrollment: null, dossier: null, firstIncomplete: 2 };
  const dossier = await loadIaDossier(org.id, enrollment.id);
  const firstIncomplete = !dossier?.funding ? 3 : dossier.contract ? 6 : 4;
  return { org, user, person, company, enrollment, dossier, firstIncomplete };
}

/* ------------------------------------------------------------------ */
/* Étape 1 : identité et compte                                        */
/* ------------------------------------------------------------------ */

export type IaIdentityInput = {
  civility: "M" | "Mme" | "autre";
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  birthDate: string;
  birthPlace: string | null;
  addressLine1: string;
  postalCode: string;
  city: string;
  situation: "particulier" | "salarie" | "demandeur_emploi" | "independant";
  employer: { name: string; siret: string; addressLine1: string | null; postalCode: string | null; city: string | null; contactFirstName: string; contactLastName: string; contactEmail: string; contactJobTitle: string | null } | null;
  /** Mot de passe : requis pour un nouveau compte, ignoré si l'utilisateur est déjà connecté. */
  password: string | null;
  verificationRequired: boolean;
};

/**
 * Crée (ou rattache) le candidat : utilisateur si nécessaire, personne (statut candidat) dans l'organisme vendeur,
 * employeur (entreprise et contact) si salarié, affectation `learner`, puis ouvre la session.
 * Retourne l'identifiant utilisateur et si la vérification e-mail est attendue.
 */
export async function createIaIdentity(input: IaIdentityInput, current: SessionUser | null): Promise<{ userId: string; created: boolean }> {
  const org = await getIaOrg();
  if (!org) throw new Error("L'organisme vendeur de la Formation IA n'est pas encore amorcé sur cette installation (voir l'amorçage NF-IA-150).");
  const email = input.email.trim().toLowerCase();
  let userId = current?.id ?? null;
  let created = false;
  if (!userId) {
    const [existing] = await db.select({ id: schema.users.id }).from(schema.users).where(eq(schema.users.email, email)).limit(1);
    if (existing) throw new IaEmailExistsError();
    if (!input.password) throw new Error("Mot de passe requis.");
    const [u] = await db
      .insert(schema.users)
      .values({
        email,
        passwordHash: await hashPassword(input.password),
        firstName: input.firstName,
        lastName: input.lastName,
        tenantId: org.tenantId,
        termsAcceptedAt: new Date(),
        termsVersion: TERMS_VERSION,
        emailVerifiedAt: input.verificationRequired ? null : new Date(),
      })
      .returning({ id: schema.users.id });
    userId = u.id;
    created = true;
  }

  await db.transaction(async (tx) => {
    let companyId: string | null = null;
    if (input.employer) {
      const emp = input.employer;
      const [found] = await tx.select({ id: schema.companies.id }).from(schema.companies).where(and(eq(schema.companies.orgId, org.id), eq(schema.companies.siret, emp.siret))).limit(1);
      if (found) companyId = found.id;
      else {
        const [c] = await tx.insert(schema.companies).values({ orgId: org.id, name: emp.name, siret: emp.siret, siren: emp.siret.slice(0, 9), addressLine1: emp.addressLine1, postalCode: emp.postalCode, city: emp.city, status: "prospect", source: "inscription_ia", isDemo: org.isDemo }).returning({ id: schema.companies.id });
        companyId = c.id;
      }
      const [contact] = await tx
        .select({ id: schema.contacts.id })
        .from(schema.contacts)
        .where(and(eq(schema.contacts.orgId, org.id), eq(schema.contacts.companyId, companyId), eq(schema.contacts.email, emp.contactEmail.toLowerCase())))
        .limit(1);
      if (!contact) {
        await tx.insert(schema.contacts).values({ orgId: org.id, companyId, firstName: emp.contactFirstName, lastName: emp.contactLastName, email: emp.contactEmail.toLowerCase(), jobTitle: emp.contactJobTitle, isSignatory: true });
      }
    }
    const [existingPerson] = await tx.select({ id: schema.persons.id }).from(schema.persons).where(and(eq(schema.persons.orgId, org.id), eq(schema.persons.userId, userId!))).limit(1);
    const values = {
      civility: input.civility,
      firstName: input.firstName,
      lastName: input.lastName,
      birthDate: input.birthDate,
      birthPlace: input.birthPlace,
      email,
      phone: input.phone,
      addressLine1: input.addressLine1,
      postalCode: input.postalCode,
      city: input.city,
      companyId,
      situation: input.situation,
      source: "inscription_ia",
      gdprConsentAt: new Date(),
    };
    let personId: string;
    if (existingPerson) {
      await tx.update(schema.persons).set(values).where(eq(schema.persons.id, existingPerson.id));
      personId = existingPerson.id;
    } else {
      const [p] = await tx.insert(schema.persons).values({ orgId: org.id, userId: userId!, status: "candidat", isDemo: org.isDemo, ...values }).returning({ id: schema.persons.id });
      personId = p.id;
    }
    const [m] = await tx.select().from(schema.memberships).where(and(eq(schema.memberships.orgId, org.id), eq(schema.memberships.userId, userId!))).limit(1);
    if (!m) await tx.insert(schema.memberships).values({ orgId: org.id, userId: userId!, roles: ["learner"], personId });
    else {
      const roles = [...new Set([...(Array.isArray(m.roles) ? (m.roles as string[]) : []), "learner"])];
      await tx.update(schema.memberships).set({ roles, active: true, personId: m.personId ?? personId }).where(eq(schema.memberships.id, m.id));
    }
  });

  await audit({ action: created ? "auth.signup" : "ia.identity_attach", userId, orgId: org.id, tenantId: org.tenantId, after: { source: "formation-ia", emailVerification: input.verificationRequired && created ? "required" : "not_required" } });
  if (created) {
    if (input.verificationRequired) {
      const { issueToken } = await import("@/server/auth");
      const token = await issueToken("verify_email", { userId, email, ttlMinutes: 60 * 24 });
      await sendMail({
        to: email,
        subject: "Vérifiez votre adresse e-mail",
        html: layoutMail("Bienvenue", `<p>Bonjour ${input.firstName},</p><p>Confirmez votre adresse e-mail pour activer votre espace apprenant. Vous pouvez poursuivre votre inscription à la Formation IA en attendant.</p>`, { label: "Vérifier mon adresse", url: `${appUrl()}/verification?token=${token}` }),
        isDemo: org.isDemo,
      });
    }
    await createSession(userId);
  }
  return { userId, created };
}

export class IaEmailExistsError extends Error {
  constructor() {
    super("Un compte existe déjà avec cette adresse.");
    this.name = "IaEmailExistsError";
  }
}

/* ------------------------------------------------------------------ */
/* Étapes 2 et 3 : offre et financement → inscription                  */
/* ------------------------------------------------------------------ */

export type IaFundingInput = {
  offer: IaOfferCode;
  funding: IaFunding;
  opcoName: string | null;
  franceTravailId: string | null;
  employer: IaIdentityInput["employer"];
};

/**
 * Crée l'inscription (statut préinscrit, offre IA, prix TTC en centimes), le financement, le devis,
 * l'entreprise le cas échéant, les pièces attendues et leurs tâches, puis confirme par e-mail.
 */
export async function createIaEnrollment(user: SessionUser, input: IaFundingInput): Promise<Enrollment> {
  const org = await getIaOrg();
  if (!org) throw new Error("Organisme vendeur introuvable.");
  const ctx = await getOrgContext(org.id);
  if (!ctx || ctx.user.id !== user.id || !ctx.personId) throw new Error("Commencez par l'étape 1 : identité et compte.");
  const [person] = await db.select().from(schema.persons).where(and(eq(schema.persons.id, ctx.personId), eq(schema.persons.orgId, org.id))).limit(1);
  if (!person) throw new Error("Candidat introuvable : reprenez l'étape 1.");
  const offer = iaOfferMeta(input.offer);
  if (!offer) throw new Error("Offre inconnue.");
  const meta = IA_FUNDING_META[input.funding];
  const [dup] = await db
    .select({ id: schema.enrollments.id })
    .from(schema.enrollments)
    .where(and(eq(schema.enrollments.orgId, org.id), eq(schema.enrollments.personId, person.id), inArray(schema.enrollments.status, [...IA_ACTIVE_STATUSES]), sql`${schema.enrollments.iaOffer} is not null`))
    .limit(1);
  if (dup) throw new Error("Vous avez déjà un dossier Formation IA en cours : retrouvez-le dans votre espace apprenant.");
  const year = new Date().getFullYear();
  const firstLevel = entitlementsForOffer(offer.code)[0] ?? "N1";
  const session = await getIaSession(org.id, firstLevel as Parameters<typeof getIaSession>[1], year);
  if (!session) throw new Error(`La session ${firstLevel} ${year} de la Formation IA n'est pas ouverte sur cette installation (amorçage NF-IA-150 à exécuter).`);

  // Employeur (entreprise, OPCO) : créé ou réutilisé par SIRET ; contact signataire.
  let companyId: string | null = null;
  let tutorContactId: string | null = null;
  if (meta.needsCompany) {
    const emp = input.employer;
    if (!emp) throw new Error("Renseignez votre employeur (raison sociale, SIRET, contact).");
    const [found] = await db.select().from(schema.companies).where(and(eq(schema.companies.orgId, org.id), eq(schema.companies.siret, emp.siret))).limit(1);
    if (found) {
      companyId = found.id;
      // Complète sans écraser : OPCO déclaré, adresse si absente.
      await db
        .update(schema.companies)
        .set({ opco: input.funding === "opco" && input.opcoName ? input.opcoName : found.opco, addressLine1: found.addressLine1 ?? emp.addressLine1, postalCode: found.postalCode ?? emp.postalCode, city: found.city ?? emp.city })
        .where(eq(schema.companies.id, found.id));
    } else {
      const [c] = await db.insert(schema.companies).values({ orgId: org.id, name: emp.name, siret: emp.siret, siren: emp.siret.slice(0, 9), addressLine1: emp.addressLine1, postalCode: emp.postalCode, city: emp.city, opco: input.funding === "opco" ? input.opcoName : null, status: "prospect", source: "inscription_ia", isDemo: org.isDemo }).returning({ id: schema.companies.id });
      companyId = c.id;
    }
    const [contact] = await db.select({ id: schema.contacts.id }).from(schema.contacts).where(and(eq(schema.contacts.orgId, org.id), eq(schema.contacts.companyId, companyId), eq(schema.contacts.email, emp.contactEmail.toLowerCase()))).limit(1);
    if (contact) {
      tutorContactId = contact.id;
      if (emp.contactJobTitle) await db.update(schema.contacts).set({ jobTitle: emp.contactJobTitle, isSignatory: true }).where(eq(schema.contacts.id, contact.id));
    } else {
      const [c] = await db.insert(schema.contacts).values({ orgId: org.id, companyId, firstName: emp.contactFirstName, lastName: emp.contactLastName, email: emp.contactEmail.toLowerCase(), jobTitle: emp.contactJobTitle, isSignatory: true }).returning({ id: schema.contacts.id });
      tutorContactId = c.id;
    }
    if (person.companyId !== companyId) await db.update(schema.persons).set({ companyId }).where(eq(schema.persons.id, person.id));
  }
  if (input.funding === "france_travail" && input.franceTravailId) {
    const ids = { ...((person.identifiers as Record<string, unknown>) ?? {}), franceTravail: input.franceTravailId };
    await db.update(schema.persons).set({ identifiers: ids }).where(eq(schema.persons.id, person.id));
  }

  await ensureIaRequiredPieces(org.id);
  const { enrollment: e } = await createEnrollment(ctx, {
    personId: person.id,
    sessionId: session.id,
    companyId,
    tutorContactId: null,
    contractKind: meta.contractKind,
    hoursPlanned: offer.hours,
    priceCents: offer.priceCents,
    commercialStatus: "devis_envoye",
    status: "preinscrit",
  });
  void tutorContactId;

  // Devis (DEV-AAAA-NNNN), une ligne TTC = HT (TVA non applicable, à confirmer par l'organisme).
  const quoteId = await db.transaction(async (tx) => {
    const res = await tx.execute<{ next: number }>(sql`
      insert into invoice_sequences (org_id, kind, year, next) values (${org.id}, 'devis', ${year}, 2)
      on conflict (org_id, kind, year) do update set next = invoice_sequences.next + 1
      returning next - 1 as next
    `);
    const number = formatQuoteNumber(year, Number(res.rows[0]?.next ?? 1), await numberingPrefix(org.id, "quote", "DEV"));
    const validUntil = new Date(Date.now() + 30 * 86400_000).toISOString().slice(0, 10);
    const [q] = await tx
      .insert(schema.quotes)
      .values({
        orgId: org.id,
        number,
        companyId,
        contactId: tutorContactId,
        personId: person.id,
        title: `Formation IA : ${offer.label}`,
        status: "envoye",
        lines: [{ label: `Formation IA : ${offer.label} (${offer.hours} h, formation ouverte à distance)`, description: IA_PUBLIC_TEXTS.price, qty: 1, unitCents: offer.priceCents, vatRateBp: 0 }],
        totalHtCents: offer.priceCents,
        vatCents: 0,
        totalTtcCents: offer.priceCents,
        issueDate: todayParis(),
        validUntil,
        sentAt: new Date(),
        notes: "Devis établi automatiquement par l'inscription en ligne à la Formation IA.",
        createdBy: user.id,
      })
      .returning({ id: schema.quotes.id });
    return q.id;
  });

  // Financement : un seul, montant = prix de l'offre ; statut selon la nature (demande en attente d'accord pour OPCO et France Travail).
  const fundingStatus = input.funding === "opco" || input.funding === "france_travail" ? "demande" : "prevu";
  const fundingLabel =
    input.funding === "cpf"
      ? "Pré-réservation CPF (en attente d'enregistrement au Répertoire spécifique)"
      : input.funding === "opco"
        ? `Prise en charge OPCO${input.opcoName ? ` : ${input.opcoName}` : ""}`
        : input.funding === "france_travail"
          ? "Aide individuelle à la formation (France Travail)"
          : input.funding === "entreprise"
            ? "Plan de développement des compétences (entreprise)"
            : "Financement personnel";
  await db.insert(schema.fundings).values({
    orgId: org.id,
    enrollmentId: e.id,
    kind: meta.funderKind,
    label: fundingLabel,
    amountCents: offer.priceCents,
    status: fundingStatus,
    notes: input.funding === "cpf" ? `${CPF_WORDING} ${CPF_PRERESERVATION}` : input.funding === "france_travail" && input.franceTravailId ? `Identifiant France Travail : ${input.franceTravailId}` : null,
  });
  await recalcEnrollmentFundingState(org.id, e.id, user.id);
  await db.update(schema.enrollments).set({ iaOffer: offer.code, quoteId }).where(and(eq(schema.enrollments.id, e.id), eq(schema.enrollments.orgId, org.id)));

  // Pièces liées au financement (maintenant connu) et parcours automatique recalculé ; un échec ne remet pas l'inscription en cause.
  await syncEnrollmentPieces(org.id, e.id, user.id);
  try {
    await applyWorkflow({ orgId: org.id, userId: user.id }, e.id);
  } catch (err) {
    console.error(`[ia] Parcours non appliqué à ${e.reference} :`, err);
  }

  const personLabel = `${person.firstName} ${person.lastName}`;
  const href = `/app/${org.id}/inscriptions/${e.id}`;
  await createTaskOnce({
    orgId: org.id,
    title: `Inscription en ligne Formation IA : ${personLabel} (${offer.label})`,
    description: `Dossier créé depuis le site. Financement : ${meta.label}. Vérifier l'identité, le financement et les pièces.`,
    family: "administratif",
    entityType: "enrollment",
    entityId: e.id,
    entityLabel: `${e.reference} · ${personLabel}`,
    href,
    assigneeRole: "admin_staff",
    priority: "normale",
    createdBy: user.id,
    source: "inscription_ia",
    isDemo: org.isDemo,
    idempotencyKey: `ia:${e.id}:nouvelle_inscription`,
  });
  if (input.funding === "cpf") {
    await createTaskOnce({
      orgId: org.id,
      title: `Pré-réservation CPF à recontacter : ${personLabel}`,
      description: `${CPF_WORDING} Recontacter l'apprenant dès l'enregistrement de la certification ; aucun accès e-learning n'est ouvert d'ici là.`,
      family: "administratif",
      entityType: "enrollment",
      entityId: e.id,
      entityLabel: `${e.reference} · ${personLabel}`,
      href,
      assigneeRole: "admin_staff",
      priority: "normale",
      createdBy: user.id,
      source: "inscription_ia",
      isDemo: org.isDemo,
      idempotencyKey: `ia:${e.id}:cpf_prereservation`,
    });
  }
  await recordEvidence({
    orgId: org.id,
    indicatorCode: "IND_1",
    level: "individuel",
    title: `Information préalable acceptée en ligne : ${offer.label}, ${formatCents(offer.priceCents)} TTC, ${meta.label}`,
    note: "Programme, durée, tarif, modalités de financement et délai d'accès consultés et acceptés par le candidat lors de l'inscription en ligne.",
    sourceType: "ia_enrollment_information",
    sourceId: e.id,
    evidenceDate: todayParis(),
    enrollmentId: e.id,
    sessionId: session.id,
    createdBy: user.id,
  });
  await audit({ action: "ia.enrollment_create", userId: user.id, orgId: org.id, entityType: "enrollment", entityId: e.id, after: { reference: e.reference, offer: offer.code, funding: input.funding, priceCents: offer.priceCents, quoteId } });
  await notify({ orgId: org.id, userId: user.id, title: "Dossier Formation IA enregistré", body: `Référence ${e.reference}. Suivez l'avancement dans votre espace apprenant.`, href: "/moi/formation-ia", dedupeKey: `ia:${e.id}:created` });
  await sendMail({
    to: user.email,
    subject: `Votre inscription à la Formation IA (${e.reference})`,
    html: layoutMail(
      "Inscription enregistrée",
      `<p>Bonjour ${person.firstName},</p><p>${IA_PUBLIC_TEXTS.confirmationMail}</p><p>Offre : <strong>${offer.label}</strong> (${offer.hours} h), ${formatCents(offer.priceCents)} TTC. Financement : ${meta.label}.</p>${input.funding === "cpf" ? `<p>${CPF_WORDING} ${CPF_PRERESERVATION}</p>` : ""}<p>Référence du dossier : ${e.reference}.</p>`,
      { label: "Ouvrir mon espace apprenant", url: `${appUrl()}/moi/formation-ia` },
    ),
    text: `${IA_PUBLIC_TEXTS.confirmationMail} Référence : ${e.reference}.`,
    isDemo: org.isDemo,
  });
  return (await db.select().from(schema.enrollments).where(eq(schema.enrollments.id, e.id)).limit(1))[0];
}

/* ------------------------------------------------------------------ */
/* Étape 4 : pièces                                                    */
/* ------------------------------------------------------------------ */

/** Dépôt d'une pièce attendue par le candidat lui-même (pièces de son dossier IA uniquement, quel que soit le déposant attendu : il peut détenir l'attestation). */
export async function uploadIaPiece(user: SessionUser, dossier: IaDossier, submissionId: string, file: { name: string; mime: string; data: Buffer }) {
  const row = dossier.pieces.find((p) => p.submission.id === submissionId);
  if (!row) throw new Error("Pièce introuvable dans votre dossier.");
  if (row.submission.status === "acceptee") throw new Error("Cette pièce a déjà été acceptée par l'organisme.");
  if (row.submission.status === "non_applicable") throw new Error("Cette pièce n'est pas applicable à votre dossier.");
  const orgId = dossier.org.id;
  const doc = await createDocument({
    orgId,
    personId: dossier.person.id,
    enrollmentId: dossier.enrollment.id,
    category: row.piece.category,
    visibility: "administratif",
    status: "transmis",
    title: row.piece.label,
    fileName: file.name,
    mimeType: file.mime,
    data: file.data,
    sourceType: "piece_submission",
    sourceId: row.submission.id,
    uploadedBy: user.id,
    previousVersionId: row.submission.documentId ?? null,
    isDemo: dossier.org.isDemo,
  });
  const before = { status: row.submission.status, documentId: row.submission.documentId };
  await db
    .update(schema.pieceSubmissions)
    .set({ status: "deposee", documentId: doc.id, submittedAt: new Date(), submittedBy: user.id, refusalReason: null, version: row.submission.version + (row.submission.documentId ? 1 : 0) })
    .where(and(eq(schema.pieceSubmissions.id, row.submission.id), eq(schema.pieceSubmissions.orgId, orgId)));
  await resolveTaskByKey(orgId, `piece:${dossier.enrollment.id}:${row.piece.code}`, "Pièce déposée par le candidat lors de l'inscription en ligne.", user.id);
  const personLabel = `${dossier.person.firstName} ${dossier.person.lastName}`;
  await createTaskOnce({
    orgId,
    title: `Pièce à contrôler : ${row.piece.label} (${personLabel})`,
    description: "Pièce déposée lors de l'inscription en ligne à la Formation IA : accepter ou refuser avec motif.",
    family: "administratif",
    entityType: "enrollment",
    entityId: dossier.enrollment.id,
    entityLabel: `${dossier.enrollment.reference} · ${personLabel}`,
    href: `/app/${orgId}/inscriptions/${dossier.enrollment.id}?onglet=pieces`,
    assigneeRole: "admin_staff",
    idempotencyKey: `piece_controle:${row.submission.id}:v${doc.version}`,
    createdBy: user.id,
    source: "inscription_ia",
    isDemo: dossier.org.isDemo,
  });
  await audit({ action: "piece.submit", userId: user.id, orgId, entityType: "piece_submission", entityId: row.submission.id, before, after: { status: "deposee", documentId: doc.id, source: "inscription_ia" } });
  return row.piece.label;
}

/* ------------------------------------------------------------------ */
/* Étape 5 : contractualisation                                        */
/* ------------------------------------------------------------------ */

export type IaContractResult = { state: "cpf" | "prepared" | "sent" | "existing"; missing: string[]; links: { name: string; email: string; url: string }[]; notConfigured?: string };

/**
 * Génère le contrat de formation (particulier, France Travail) ou la convention (entreprise, OPCO) depuis le modèle
 * plateforme existant : variables absentes → marqueurs, jamais inventées. Statut `genere`. Si aucune variable ne manque,
 * la demande de signature électronique part aussitôt (mécanisme existant : /signer/[token]) ; sinon le document
 * reste à compléter par l'organisme (tâche), qui l'envoie à signer depuis le dossier.
 */
export async function contractualiseIa(user: SessionUser, dossier: IaDossier): Promise<IaContractResult> {
  const { org, enrollment: e, person } = dossier;
  if (dossier.iaFunding === "cpf") return { state: "cpf", missing: [], links: [] };
  if (dossier.contract) return { state: "existing", missing: dossier.contract.missing, links: [] };
  const funding = dossier.iaFunding ?? "particulier";
  const meta = IA_FUNDING_META[funding];
  const templateCode = meta.templateCode;
  if (!templateCode) return { state: "cpf", missing: [], links: [] };
  const template = await getTemplate(org.id, templateCode);
  if (!template || !template.isActive) throw new Error(`Le modèle « ${templateCode} » est introuvable ou désactivé : l'organisme doit le réactiver dans Documents, Modèles.`);
  const priceLabel = formatCents(e.priceCents ?? dossier.offer?.priceCents ?? 0);
  const answers = { signaturePlace: "en ligne (signature électronique)", paymentTerms: iaPaymentTerms(funding, priceLabel) };
  const collected = await collectTemplateData(org.id, { enrollmentId: e.id }, answers);
  // Formation ouverte à distance : le lieu est la plateforme ; le prix TTC est celui de l'offre (TVA non applicable), pas un calcul à 20 %.
  const sessionData = (collected.data.session as Record<string, unknown>) ?? {};
  const site = (sessionData.site as Record<string, unknown>) ?? {};
  if (dossier.session.modality === "elearning" || dossier.session.modality === "distanciel") {
    collected.data.session = { ...sessionData, site: { ...site, name: site.name ?? "Formation ouverte à distance (plateforme e-learning)", address: site.address ?? `plateforme en ligne, ${appUrl()}` } };
  }
  const enr = (collected.data.enrollment as Record<string, unknown>) ?? {};
  collected.data.enrollment = { ...enr, price: priceLabel, priceTtc: priceLabel };
  const labels = { ...TEMPLATE_VARIABLES };
  for (const q of Array.isArray(template.questions) ? (template.questions as { key: string; label: string }[]) : []) labels[`answers.${q.key}`] = q.label;
  const { text, missing } = renderTemplate(template.body, collected.data, { labels });

  const brand = await brandFromOrg(org);
  const title = `${template.title} : ${person.firstName} ${person.lastName}`;
  const [pdf, docxBuf] = await Promise.all([renderBrandedPdf(text, { title, brand, reference: e.reference }), renderBrandedDocx(text, { title, brand, reference: e.reference })]);
  const base = `${template.code}-${e.reference.replace(/[^a-zA-Z0-9-]/g, "_")}-v1`;
  const visibility = DEFAULT_VISIBILITY[template.category] ?? "apprenant";
  const generationData = { templateId: template.id, templateVersion: template.version, scope: { enrollmentId: e.id, sessionId: e.sessionId, personId: person.id, companyId: e.companyId }, answers, missing, text, generatedAt: new Date().toISOString(), generatedBy: user.id, orgId: org.id, source: "inscription_ia" };
  const common = { orgId: org.id, enrollmentId: e.id, sessionId: e.sessionId, personId: person.id, companyId: e.companyId, category: template.category, visibility, status: "genere" as const, templateCode: template.code, uploadedBy: user.id, isDemo: org.isDemo };
  const document = await createDocument({ ...common, title, fileName: `${base}.pdf`, mimeType: "application/pdf", data: pdf, generationData });
  await createDocument({ ...common, title: `${title} (Word)`, fileName: `${base}.docx`, mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document", data: docxBuf, generationData: { pdfDocumentId: document.id }, sourceType: "docx_of", sourceId: document.id });
  await audit({ action: "document.generate", userId: user.id, orgId: org.id, entityType: "document", entityId: document.id, after: { templateCode: template.code, version: 1, source: "inscription_ia", missing: missing.map((m) => m.key) } });
  await recordEvidence({
    orgId: org.id,
    indicatorCode: "IND_1",
    level: "individuel",
    title: `Contractualisation engagée en ligne : ${template.title}`,
    note: missing.length ? `Document généré avec ${missing.length} information(s) à compléter par l'organisme avant signature.` : "Document généré et transmis pour signature électronique.",
    sourceType: "ia_contract_document",
    sourceId: document.id,
    evidenceDate: todayParis(),
    enrollmentId: e.id,
    sessionId: e.sessionId,
    documentId: document.id,
    createdBy: user.id,
  });

  const personLabel = `${person.firstName} ${person.lastName}`;
  const href = `/app/${org.id}/documents/${document.id}`;
  if (missing.length) {
    await createTaskOnce({
      orgId: org.id,
      title: `Compléter et envoyer en signature : ${template.title} (${personLabel})`,
      description: `Informations manquantes dans le document généré en ligne : ${missing.map((m) => m.label).join(", ")}. Compléter (Paramètres, programme, session) puis régénérer et envoyer en signature.`,
      family: "administratif",
      entityType: "enrollment",
      entityId: e.id,
      entityLabel: `${e.reference} · ${personLabel}`,
      href,
      assigneeRole: "admin_staff",
      priority: "haute",
      createdBy: user.id,
      source: "inscription_ia",
      isDemo: org.isDemo,
      idempotencyKey: `ia:${e.id}:contrat_a_completer`,
    });
    return { state: "prepared", missing: missing.map((m) => m.label), links: [] };
  }

  // Signataires : apprenant (contrat) ou signataire de l'entreprise (convention), et l'organisme si son signataire est renseigné.
  const signers: { name: string; email: string; role: SignerRole }[] = [];
  if (template.category === "contrat") signers.push({ name: personLabel, email: user.email, role: "apprenant" });
  else {
    const [sig] = dossier.company ? await db.select().from(schema.contacts).where(and(eq(schema.contacts.orgId, org.id), eq(schema.contacts.companyId, dossier.company.id), eq(schema.contacts.isSignatory, true))).limit(1) : [];
    if (sig?.email) signers.push({ name: `${sig.firstName} ${sig.lastName}`, email: sig.email, role: "entreprise" });
    else signers.push({ name: personLabel, email: user.email, role: "apprenant" });
  }
  if (org.signatoryName && org.email) signers.push({ name: org.signatoryName, email: org.email, role: "organisme" });
  const sent = await createIaSignatureRequest({ org, document, signers, requestedBy: user.id, message: "Document établi lors de votre inscription en ligne à la Formation IA." });
  await createTaskOnce({
    orgId: org.id,
    title: `Suivre la signature : ${template.title} (${personLabel})`,
    description: `Demande de signature électronique envoyée aux signataires (${signers.map((s) => s.name).join(", ")}). ${sent.notConfigured ?? ""}`.trim(),
    family: "administratif",
    entityType: "enrollment",
    entityId: e.id,
    entityLabel: `${e.reference} · ${personLabel}`,
    href,
    assigneeRole: "admin_staff",
    createdBy: user.id,
    source: "inscription_ia",
    isDemo: org.isDemo,
    idempotencyKey: `ia:${e.id}:signature_a_suivre`,
  });
  return { state: "sent", missing: [], links: sent.links, notConfigured: sent.notConfigured };
}

/** Demande de signature sans contexte d'organisme (le candidat n'a pas `documents.generate`) : même mécanisme que `createSignatureRequest`. */
async function createIaSignatureRequest(input: { org: Org; document: Document; signers: { name: string; email: string; role: SignerRole }[]; requestedBy: string; message?: string }) {
  const { org, document: doc } = input;
  const expiresAt = new Date(Date.now() + REQUEST_TTL_DAYS * 86400_000);
  const tokens = input.signers.map((s) => {
    const token = randomToken(32);
    return { token, signer: { id: randomToken(8), name: s.name, email: s.email.toLowerCase(), role: s.role, tokenHash: sha256(token), otpAttempts: 0 } satisfies Signer };
  });
  const esign = getESignAdapter();
  let provider = "interne";
  let providerRef: string | null = null;
  let status: SignatureRequest["status"] = "envoyee";
  let notConfigured: string | undefined;
  if (process.env.ESIGN_PROVIDER) {
    if (esign.ok) {
      const res = await esign.adapter.send({ documentId: doc.id, fileName: doc.fileName, data: await getObject(doc.storageKey), title: doc.title, signers: tokens.map((t) => ({ name: t.signer.name, email: t.signer.email, role: t.signer.role === "entreprise" ? "employer" : t.signer.role === "apprenant" ? "employee" : "other" })) });
      provider = esign.adapter.name;
      providerRef = res.providerRef;
    } else {
      provider = process.env.ESIGN_PROVIDER;
      status = "non_configure";
      notConfigured = esign.message;
    }
  }
  const [request] = await db.insert(schema.signatureRequests).values({ orgId: org.id, documentId: doc.id, provider, providerRef, status, signers: tokens.map((t) => t.signer), expiresAt, requestedBy: input.requestedBy }).returning();
  const links: { name: string; email: string; url: string }[] = [];
  if (provider === "interne") {
    for (const t of tokens) {
      const url = `${appUrl()}/signer/${t.token}`;
      links.push({ name: t.signer.name, email: t.signer.email, url });
      await sendMail({
        to: t.signer.email,
        subject: `Document à signer : ${doc.title}`,
        html: layoutMail("Un document attend votre signature", `<p>Bonjour ${t.signer.name},</p><p>${org.legalName} vous invite à signer électroniquement le document <strong>${doc.title}</strong>.</p>${input.message ? `<p>${input.message}</p>` : ""}<p>Le lien est personnel et valable ${REQUEST_TTL_DAYS} jours. Un code de confirmation vous sera envoyé par e-mail au moment de signer.</p>`, { label: "Lire et signer", url }),
        text: `Bonjour ${t.signer.name}, ${org.legalName} vous invite à signer le document « ${doc.title} » : ${url}`,
        isDemo: org.isDemo,
      });
    }
    await db.update(schema.documents).set({ status: "transmis", transmittedAt: new Date() }).where(and(eq(schema.documents.id, doc.id), eq(schema.documents.orgId, org.id)));
  }
  await audit({ action: "signature.request", userId: input.requestedBy, orgId: org.id, entityType: "signature_request", entityId: request.id, after: { documentId: doc.id, provider, status, source: "inscription_ia", signers: tokens.map((t) => ({ name: t.signer.name, email: t.signer.email, role: t.signer.role })) } });
  return { request, links, notConfigured };
}

/**
 * Lien de signature pour l'apprenant connecté : son jeton est renouvelé (l'ancien devient invalide, comme une relance)
 * et l'URL /signer/[token] est retournée. Null si aucune signature n'est attendue de lui.
 */
export async function iaSignNowLink(user: SessionUser, dossier: IaDossier): Promise<string | null> {
  const r = dossier.contract?.request;
  if (!r || r.provider !== "interne" || !["envoyee", "signee_partiellement"].includes(r.status)) return null;
  const signers = Array.isArray(r.signers) ? (r.signers as Signer[]) : [];
  const index = signers.findIndex((s) => s.email.toLowerCase() === user.email.toLowerCase() && !s.signedAt);
  if (index < 0) return null;
  const token = randomToken(32);
  signers[index] = { ...signers[index], tokenHash: sha256(token), otpHash: null, otpExpiresAt: null, otpAttempts: 0 };
  await db.update(schema.signatureRequests).set({ signers }).where(and(eq(schema.signatureRequests.id, r.id), eq(schema.signatureRequests.orgId, dossier.org.id)));
  await audit({ action: "signature.resend", userId: user.id, orgId: dossier.org.id, entityType: "signature_request", entityId: r.id, after: { to: [user.email], source: "inscription_ia" } });
  return `${appUrl()}/signer/${token}`;
}

/* ------------------------------------------------------------------ */
/* Accès e-learning                                                    */
/* ------------------------------------------------------------------ */

/** Ouvre l'accès e-learning (audit `enrollment.ia_access_open`, preuve IND_9, notification apprenant). Idempotent. */
export async function openIaAccess(orgId: string, enrollmentId: string, actor: { userId: string | null; reason: string }) {
  const dossier = await loadIaDossier(orgId, enrollmentId);
  if (!dossier) throw new Error("Inscription Formation IA introuvable dans cet organisme.");
  if (dossier.enrollment.iaAccessOpenedAt) return dossier;
  const now = new Date();
  await db.update(schema.enrollments).set({ iaAccessOpenedAt: now, iaAccessOpenedBy: actor.userId, elearningAccessSentAt: dossier.enrollment.elearningAccessSentAt ?? now }).where(and(eq(schema.enrollments.id, enrollmentId), eq(schema.enrollments.orgId, orgId)));
  await db.insert(schema.enrollmentEvents).values({ enrollmentId, kind: "acces_elearning", fromValue: "ferme", toValue: "ouvert", reason: actor.reason, userId: actor.userId });
  await audit({ action: "enrollment.ia_access_open", userId: actor.userId, orgId, entityType: "enrollment", entityId: enrollmentId, before: { iaAccessOpenedAt: null }, after: { iaAccessOpenedAt: now.toISOString(), entitlements: dossier.entitlements, reason: actor.reason } });
  await recordEvidence({
    orgId,
    indicatorCode: "IND_9",
    level: "individuel",
    title: `Accès e-learning ouvert : ${dossier.offer?.label ?? dossier.enrollment.iaOffer} (${dossier.person.firstName} ${dossier.person.lastName})`,
    note: actor.reason,
    sourceType: "ia_access",
    sourceId: enrollmentId,
    evidenceDate: todayParis(),
    enrollmentId,
    sessionId: dossier.session.id,
    createdBy: actor.userId,
  });
  if (dossier.person.userId) {
    await notify({ orgId, userId: dossier.person.userId, title: "Votre espace e-learning est ouvert", body: `Formation IA : ${dossier.offer?.label ?? ""}. Ouvrez votre espace depuis « Ma formation IA ».`, href: "/moi/formation-ia", dedupeKey: `ia:${enrollmentId}:access_open` });
    if (dossier.person.email) {
      await sendMail({
        to: dossier.person.email,
        subject: "Votre espace e-learning Formation IA est ouvert",
        html: layoutMail("Accès ouvert", `<p>Bonjour ${dossier.person.firstName},</p><p>Votre accès à l'espace e-learning de la Formation IA (${dossier.offer?.label ?? ""}) est ouvert. Connectez-vous à votre espace apprenant puis cliquez sur « Ouvrir mon espace e-learning ».</p>`, { label: "Ouvrir mon espace apprenant", url: `${appUrl()}/moi/formation-ia` }),
        isDemo: dossier.org.isDemo,
      });
    }
  }
  await resolveTaskByKey(orgId, `ia:${enrollmentId}:acces_a_ouvrir`, actor.reason, actor.userId);
  return (await loadIaDossier(orgId, enrollmentId))!;
}

/** Ferme l'accès (audit `enrollment.ia_access_close`, motif conservé). Idempotent. */
export async function closeIaAccess(orgId: string, enrollmentId: string, actor: { userId: string; reason: string }) {
  const dossier = await loadIaDossier(orgId, enrollmentId);
  if (!dossier) throw new Error("Inscription Formation IA introuvable dans cet organisme.");
  if (!dossier.enrollment.iaAccessOpenedAt) return dossier;
  await db.update(schema.enrollments).set({ iaAccessOpenedAt: null, iaAccessOpenedBy: null }).where(and(eq(schema.enrollments.id, enrollmentId), eq(schema.enrollments.orgId, orgId)));
  await db.insert(schema.enrollmentEvents).values({ enrollmentId, kind: "acces_elearning", fromValue: "ouvert", toValue: "ferme", reason: actor.reason, userId: actor.userId });
  await audit({ action: "enrollment.ia_access_close", userId: actor.userId, orgId, entityType: "enrollment", entityId: enrollmentId, before: { iaAccessOpenedAt: dossier.enrollment.iaAccessOpenedAt?.toISOString() }, after: { iaAccessOpenedAt: null, reason: actor.reason } });
  if (dossier.person.userId) await notify({ orgId, userId: dossier.person.userId, title: "Votre accès e-learning a été fermé", body: actor.reason, href: "/moi/formation-ia", dedupeKey: `ia:${enrollmentId}:access_close:${Date.now()}` });
  return (await loadIaDossier(orgId, enrollmentId))!;
}

/**
 * Règle d'ouverture automatique : contrat ou convention signé ET financement différent du CPF → accès ouvert,
 * sinon tâche « accès à ouvrir » pour l'organisme quand le contrat est signé (CPF : en attente d'enregistrement RS).
 * Appelée à chaque consultation du dossier (extranet, dossier organisme) : la signature est finalisée hors de ce module.
 */
export async function syncIaAccess(dossier: IaDossier): Promise<IaDossier> {
  if (dossier.enrollment.iaAccessOpenedAt) return dossier;
  const signed = Boolean(dossier.contract?.signed);
  if (iaAccessShouldOpen({ contractSigned: signed, funding: dossier.iaFunding })) {
    // Jamais de réouverture automatique après une fermeture décidée par l'organisme : l'ouverture automatique n'a lieu qu'une fois.
    const [prior] = await db.select({ id: schema.enrollmentEvents.id }).from(schema.enrollmentEvents).where(and(eq(schema.enrollmentEvents.enrollmentId, dossier.enrollment.id), eq(schema.enrollmentEvents.kind, "acces_elearning"))).limit(1);
    if (prior) return dossier;
    return openIaAccess(dossier.org.id, dossier.enrollment.id, { userId: null, reason: "Ouverture automatique : contrat ou convention signé, financement hors CPF." });
  }
  if (signed && dossier.iaFunding === "cpf") {
    await createTaskOnce({
      orgId: dossier.org.id,
      title: `Accès e-learning à décider (dossier CPF) : ${dossier.person.firstName} ${dossier.person.lastName}`,
      description: `${CPF_WORDING} Le contrat est signé ; l'ouverture de l'accès relève d'une décision de l'organisme depuis le dossier.`,
      family: "administratif",
      entityType: "enrollment",
      entityId: dossier.enrollment.id,
      entityLabel: `${dossier.enrollment.reference} · ${dossier.person.firstName} ${dossier.person.lastName}`,
      href: `/app/${dossier.org.id}/inscriptions/${dossier.enrollment.id}`,
      assigneeRole: "admin_staff",
      source: "inscription_ia",
      isDemo: dossier.org.isDemo,
      idempotencyKey: `ia:${dossier.enrollment.id}:acces_a_ouvrir`,
    });
  }
  return dossier;
}

/** Lien SSO vers l'espace e-learning pour l'apprenant (null si l'intégration n'est pas configurée ou si l'accès n'est pas ouvert). */
export function iaLearnerSsoLink(user: SessionUser, dossier: IaDossier): string | null {
  if (!dossier.enrollment.iaAccessOpenedAt) return null;
  return iaSsoLink({ userId: user.id, email: user.email, firstName: user.firstName, lastName: user.lastName, entitlements: dossier.entitlements, demo: dossier.org.isDemo, enrollmentId: dossier.enrollment.id, back: `${appUrl()}/moi` });
}

/** État de l'intégration e-learning (variables IA_APP_URL et IA_SSO_SECRET), lu sans dépendre de `integrations.ia` (chantier B1). */
export function iaIntegrationConfigured(): boolean {
  const reg = integrations as unknown as Record<string, (() => boolean) | undefined>;
  if (typeof reg.ia === "function") return reg.ia();
  return Boolean((process.env.IA_APP_URL ?? "").trim() && (process.env.IA_SSO_SECRET ?? "").trim().length >= 32);
}

/* ------------------------------------------------------------------ */
/* Extranet apprenant                                                  */
/* ------------------------------------------------------------------ */

/** Dossier Formation IA de l'apprenant connecté (parmi ses inscriptions, périmètre du contexte), accès synchronisé. */
export async function learnerIaDossier(ctx: { org: { id: string }; enrollments: { enrollment: Enrollment }[] }): Promise<IaDossier | null> {
  // Dossier « actif » : accès e-learning ouvert le plus récent d'abord (démo Camille : un dossier par niveau), sinon le plus récent.
  const rank = (e: Enrollment) => (e.iaAccessOpenedAt ? 2 : 0) + (e.status === "en_cours" ? 1 : 0);
  const ia = ctx.enrollments
    .filter((e) => e.enrollment.iaOffer)
    .sort((a, b) => rank(b.enrollment) - rank(a.enrollment) || b.enrollment.createdAt.getTime() - a.enrollment.createdAt.getTime())[0];
  if (!ia) return null;
  const dossier = await loadIaDossier(ctx.org.id, ia.enrollment.id);
  return dossier ? syncIaAccess(dossier) : null;
}
