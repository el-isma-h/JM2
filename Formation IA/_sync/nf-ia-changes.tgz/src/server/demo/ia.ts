import "server-only";
import { and, eq, gt, inArray, like } from "drizzle-orm";
import { db, schema } from "@/db";
import { hashPassword } from "@/server/auth";
import { audit } from "@/server/audit";
import { bootstrapOrgDefaults } from "@/server/org-defaults";
import { createDocument } from "@/server/documents/store";
import { recordEvidence } from "@/server/quality/evidence";
import { createTaskOnce } from "@/server/tasks/service";
import { nextEnrollmentReference } from "@/server/enrollments/service";
import { applicablePieces, pieceDueDate } from "@/server/enrollments/rules";
import { randomToken } from "@/lib/crypto";
import { todayParis } from "@/lib/time";
import { ensureIaCatalog } from "@/server/ia/bootstrap";
import { IA_DEMO_SLUG_PREFIX, IA_LEVELS, IA_ORG_NAME, IA_PROGRAM_TITLE, getIaLevel, getIaOffer } from "@/server/ia/catalog";
import { addD, daysAgo, fakeSiret, simplePdf } from "./data/util";

/**
 * Démonstration « Tester en tant que Camille » (contrat `docs/formation-ia-integration.md`).
 * Crée un organisme de démonstration IA (`isDemo = true`, supprimé après 24 h par la tâche demo:cleanup comme
 * les espaces de /demo) contenant le programme NF-IA-150 et ses sessions, puis l'apprenante fictive
 * Camille Fontaine inscrite au parcours N1-N4 : N1 terminé et certifié, N2 en cours (accès e-learning ouvert),
 * N3 et N4 à venir ; dossier de financement CPF fictif « en attente d'enregistrement RS » ; contrat signé fictif ;
 * pièces, tâches et preuves cohérentes. Aucune donnée réelle, aucun e-mail, aucun mot de passe communiqué.
 */

export type IaDemoResult = {
  tenantId: string;
  orgId: string;
  /** Compte de Camille (rôle learner) et sa fiche personne. */
  userId: string;
  personId: string;
  /** Inscriptions par niveau (N1 terminé, N2 en cours, N3 et N4 inscrits). */
  enrollmentIds: Record<"N1" | "N2" | "N3" | "N4", string>;
  /** Identifiants utiles à la recette. */
  staff: { direction: string; admin: string };
  reused: boolean;
};

/** Durée de vie d'un espace de démonstration (même valeur que DEMO_TTL_HOURS de la tâche demo:cleanup, importée ici sans charger les handlers). */
const DEMO_TTL_HOURS = 24;
const DEMO_FOOTER = "Document de démonstration : données fictives, sans valeur contractuelle.";
const CAMILLE = { firstName: "Camille", lastName: "Fontaine" };
const PARCOURS_LEVELS = ["N1", "N2", "N3", "N4"] as const;

/**
 * Espace Camille déjà ouvert pour ce visiteur (même session navigateur) et âgé de moins de 24 h : réutilisé.
 * Le compte doit appartenir à un tenant de démonstration IA encore vivant et porter une affectation apprenante.
 */
async function findReusable(userId: string): Promise<IaDemoResult | null> {
  const cutoff = new Date(Date.now() - DEMO_TTL_HOURS * 3600_000);
  const [row] = await db
    .select({ user: schema.users, tenant: schema.tenants, membership: schema.memberships, org: schema.organismes })
    .from(schema.users)
    .innerJoin(schema.tenants, eq(schema.tenants.id, schema.users.tenantId))
    .innerJoin(schema.memberships, eq(schema.memberships.userId, schema.users.id))
    .innerJoin(schema.organismes, eq(schema.organismes.id, schema.memberships.orgId))
    .where(and(eq(schema.users.id, userId), eq(schema.tenants.isDemo, true), like(schema.tenants.slug, `${IA_DEMO_SLUG_PREFIX}%`), gt(schema.tenants.createdAt, cutoff), eq(schema.memberships.active, true), eq(schema.organismes.isDemo, true)))
    .limit(1);
  if (!row || !row.membership.personId || row.user.firstName !== CAMILLE.firstName) return null;
  const enrollments = await db
    .select({ id: schema.enrollments.id, sessionId: schema.enrollments.sessionId })
    .from(schema.enrollments)
    .where(and(eq(schema.enrollments.orgId, row.org.id), eq(schema.enrollments.personId, row.membership.personId)));
  const sessionIds = enrollments.map((e) => e.sessionId);
  const sessions = sessionIds.length ? await db.select({ id: schema.trainingSessions.id, code: schema.trainingSessions.code }).from(schema.trainingSessions).where(inArray(schema.trainingSessions.id, sessionIds)) : [];
  const enrollmentIds = {} as IaDemoResult["enrollmentIds"];
  for (const l of PARCOURS_LEVELS) {
    const sess = sessions.find((s) => s.code.startsWith(`IA-${l}-`));
    const e = sess ? enrollments.find((x) => x.sessionId === sess.id) : null;
    if (!e) return null;
    enrollmentIds[l] = e.id;
  }
  const staff = await db.select({ userId: schema.memberships.userId, roles: schema.memberships.roles }).from(schema.memberships).where(eq(schema.memberships.orgId, row.org.id));
  const direction = staff.find((s) => (s.roles as string[]).includes("direction"))?.userId ?? row.user.id;
  const admin = staff.find((s) => (s.roles as string[]).includes("admin_staff"))?.userId ?? direction;
  return { tenantId: row.tenant.id, orgId: row.org.id, userId: row.user.id, personId: row.membership.personId, enrollmentIds, staff: { direction, admin }, reused: true };
}

/**
 * Crée (ou réutilise pour le même visiteur) l'organisme de démonstration IA et le dossier de Camille.
 * Retourne les identifiants nécessaires pour ouvrir sa session et vérifier la recette.
 */
export async function seedIaDemo(opts: { reuseUserId?: string | null } = {}): Promise<IaDemoResult> {
  if (opts.reuseUserId) {
    const found = await findReusable(opts.reuseUserId);
    if (found) return found;
  }

  const suffix = randomToken(6).toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 6);
  const domain = `demo-ia-${suffix}.nextformation.local`;
  const passwordHash = await hashPassword(`Demo-${randomToken(12)}`);
  const now = new Date();
  const today = todayParis(now);
  const year = Number(today.slice(0, 4));
  const { siren, siret } = fakeSiret("84421735", "0017");

  /* ---------- Tenant, organisme, comptes ---------- */
  const base = await db.transaction(async (tx) => {
    const [tenant] = await tx.insert(schema.tenants).values({ name: `${IA_ORG_NAME} (démonstration)`, kind: "organisme", slug: `${IA_DEMO_SLUG_PREFIX}${suffix}`, isDemo: true }).returning();
    const [org] = await tx
      .insert(schema.organismes)
      .values({
        tenantId: tenant.id,
        kind: "of",
        legalName: `${IA_ORG_NAME} (démonstration)`,
        tradeName: `${IA_ORG_NAME} (démonstration)`,
        legalForm: "SAS",
        siren,
        siret,
        nda: "84 69 20451 69",
        ndaRegion: "Auvergne-Rhône-Alpes",
        addressLine1: "27 rue de la Fonderie",
        postalCode: "69002",
        city: "Lyon",
        email: `contact@${domain}`,
        phone: "04 72 00 00 00",
        signatoryName: "Hélène Vasseur",
        signatoryTitle: "Directrice",
        documentFooter: `${IA_ORG_NAME} (démonstration), 27 rue de la Fonderie 69002 Lyon. SIRET ${siret} (fictif). Déclaration d'activité n° 84 69 20451 69 (fictif, ne vaut pas agrément de l'État).`,
        onboardingStep: "termine",
        onboardingCompletedAt: now,
        isDemo: true,
      })
      .returning();
    await bootstrapOrgDefaults(tx, org.id);
    await tx.update(schema.sites).set({ name: "Formation à distance (FOAD)", city: "Lyon" }).where(and(eq(schema.sites.orgId, org.id), eq(schema.sites.isMain, true)));

    const people = [
      { key: "direction", firstName: "Hélène", lastName: "Vasseur", roles: ["direction"], title: "Directrice", isOwner: true },
      { key: "admin", firstName: "Rachid", lastName: "Mehdaoui", roles: ["admin_staff", "finance"], title: "Chargé d'administration", isOwner: false },
      { key: "camille", firstName: CAMILLE.firstName, lastName: CAMILLE.lastName, roles: ["learner"], title: "Apprenante", isOwner: false },
    ] as const;
    const users: Record<(typeof people)[number]["key"], string> = { direction: "", admin: "", camille: "" };
    for (const p of people) {
      const [u] = await tx
        .insert(schema.users)
        .values({
          email: `${p.firstName.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase()}.${p.lastName.toLowerCase()}@${domain}`,
          passwordHash,
          firstName: p.firstName,
          lastName: p.lastName,
          tenantId: tenant.id,
          emailVerifiedAt: now,
          termsAcceptedAt: now,
          termsVersion: "demo",
        })
        .returning();
      users[p.key] = u.id;
      await tx.insert(schema.memberships).values({ orgId: org.id, userId: u.id, roles: [...p.roles], title: p.title });
      if (p.isOwner) await tx.update(schema.organismes).set({ ownerUserId: u.id }).where(eq(schema.organismes.id, org.id));
    }
    return { tenant, org, users };
  });
  const { tenant, org, users } = base;
  const orgId = org.id;
  const orgPdf = { name: org.legalName, address: `${org.addressLine1}, ${org.postalCode} ${org.city}`, nda: org.nda ?? "", siret: org.siret ?? "" };

  /* ---------- Catalogue NF-IA-150 (programme, version, modules, sessions, pièces, financeurs, preuve IND_1) ---------- */
  const catalog = await ensureIaCatalog(orgId, { isDemo: true, createdBy: users.direction, year });

  /* ---------- Camille : personne et affectation apprenante ---------- */
  const [person] = await db
    .insert(schema.persons)
    .values({
      orgId,
      civility: "Mme",
      firstName: CAMILLE.firstName,
      lastName: CAMILLE.lastName,
      birthDate: "1994-03-18",
      birthPlace: "Villeurbanne",
      email: `camille.fontaine@${domain}`,
      phone: "06 00 00 00 00",
      addressLine1: "8 rue des Capucins",
      postalCode: "69001",
      city: "Lyon",
      status: "apprenant",
      educationLevel: "Bac + 3",
      situation: "Chargée de communication en reconversion",
      identifiers: { cpf: "fictif" },
      source: "Site Next Formation (page Formation IA)",
      tags: ["formation-ia", "démo"],
      userId: users.camille,
      gdprConsentAt: new Date(`${daysAgo(today, 80)}T09:00:00Z`),
      isDemo: true,
    })
    .returning({ id: schema.persons.id });
  await db.update(schema.memberships).set({ personId: person.id }).where(and(eq(schema.memberships.orgId, orgId), eq(schema.memberships.userId, users.camille)));
  const camilleName = `${CAMILLE.firstName} ${CAMILLE.lastName}`;

  /* ---------- Inscriptions au parcours N1-N4 ---------- */
  const parcours = getIaOffer("PARCOURS")!;
  const perLevelCents = Math.round(parcours.priceCents / PARCOURS_LEVELS.length);
  const contractNumber = `CP-${year}-0001`;
  const signedAt = new Date(`${daysAgo(today, 75)}T14:30:00Z`);
  const accessOpenedAt = new Date(`${daysAgo(today, 70)}T09:15:00Z`);
  const n1Start = daysAgo(today, 70);
  const n1End = daysAgo(today, 35);
  const n2Start = daysAgo(today, 30);
  const plan: Record<(typeof PARCOURS_LEVELS)[number], { status: "termine" | "en_cours" | "inscrit"; progression: "acquise" | "en_cours" | "non_commencee"; fundingState: "solde" | "prevu" | "a_definir"; examState: "admis" | "non_concerne"; startDate: string | null; endDate: string | null; access: boolean }> = {
    N1: { status: "termine", progression: "acquise", fundingState: "solde", examState: "admis", startDate: n1Start, endDate: n1End, access: true },
    N2: { status: "en_cours", progression: "en_cours", fundingState: "prevu", examState: "non_concerne", startDate: n2Start, endDate: addD(n2Start, 60), access: true },
    N3: { status: "inscrit", progression: "non_commencee", fundingState: "a_definir", examState: "non_concerne", startDate: null, endDate: null, access: false },
    N4: { status: "inscrit", progression: "non_commencee", fundingState: "a_definir", examState: "non_concerne", startDate: null, endDate: null, access: false },
  };
  const enrollmentIds = {} as IaDemoResult["enrollmentIds"];
  for (const code of PARCOURS_LEVELS) {
    const level = getIaLevel(code)!;
    const p = plan[code];
    const reference = await nextEnrollmentReference(db, orgId, year);
    const [e] = await db
      .insert(schema.enrollments)
      .values({
        orgId,
        sessionId: catalog.sessionIds[code],
        personId: person.id,
        programVersionId: catalog.versionId,
        reference,
        commercialStatus: "accepte",
        status: p.status,
        progression: p.progression,
        fundingState: p.fundingState,
        examState: p.examState,
        contractKind: "contrat_particulier",
        contractNumber,
        startDate: p.startDate,
        endDate: p.endDate,
        hoursPlanned: level.hours,
        positioning: code === "N1" ? { date: daysAgo(today, 78), level: "débutante", note: "Questionnaire de positionnement en ligne : usage occasionnel de ChatGPT, aucune pratique de l'automatisation." } : {},
        individualPlan: { offer: "PARCOURS", levels: [...PARCOURS_LEVELS], objectives: "Obtenir les quatre certificats Next Formation IA pour piloter des projets IA en communication." },
        priceCents: perLevelCents,
        workflowCode: "ia",
        iaOffer: parcours.code,
        iaAccessOpenedAt: p.access ? accessOpenedAt : null,
        iaAccessOpenedBy: p.access ? users.admin : null,
        closedAt: p.status === "termine" ? new Date(`${addD(n1End, 2)}T15:00:00Z`) : null,
        closedBy: p.status === "termine" ? users.direction : null,
        isDemo: true,
      })
      .returning({ id: schema.enrollments.id });
    enrollmentIds[code] = e.id;

    const created = new Date(`${daysAgo(today, 78)}T10:00:00Z`);
    const events: (typeof schema.enrollmentEvents.$inferInsert)[] = [
      { enrollmentId: e.id, kind: "statut", fromValue: null, toValue: "preinscrit", reason: "Inscription en ligne (parcours N1-N4)", userId: users.camille, at: created },
      { enrollmentId: e.id, kind: "statut", fromValue: "preinscrit", toValue: "inscrit", reason: "Contrat de formation signé, dossier complet", userId: users.admin, at: signedAt },
    ];
    if (p.status === "en_cours" || p.status === "termine") events.push({ enrollmentId: e.id, kind: "statut", fromValue: "inscrit", toValue: "en_cours", reason: "Entrée en formation (accès e-learning ouvert)", userId: users.admin, at: new Date(`${p.startDate}T09:15:00Z`) });
    if (p.status === "termine") events.push({ enrollmentId: e.id, kind: "statut", fromValue: "en_cours", toValue: "termine", reason: "Examen du niveau 1 réussi (87 %), certificat délivré", userId: users.direction, at: new Date(`${addD(n1End, 2)}T15:00:00Z`) });
    await db.insert(schema.enrollmentEvents).values(events);
    if (p.access) {
      await audit({ action: "enrollment.ia_access_open", userId: users.admin, orgId, entityType: "enrollment", entityId: e.id, after: { level: code, offer: parcours.code, openedAt: accessOpenedAt.toISOString(), reason: code === "N2" ? "Ouverture manuelle par l'organisme : contrat signé, financement CPF en attente d'enregistrement RS (dérogation motivée)." : "Contrat signé, financement personnel réglé." } });
      await recordEvidence({ orgId, indicatorCode: "IND_9", level: "individuel", title: `Accès e-learning ouvert : ${camilleName} (niveau ${code.slice(1)})`, note: "Conditions de déroulement communiquées : accès à l'espace e-learning, modalités d'évaluation et d'assistance.", evidenceDate: daysAgo(today, 70), sourceType: "enrollment_ia_access", sourceId: e.id, enrollmentId: e.id, sessionId: catalog.sessionIds[code], createdBy: users.admin });
    }
  }
  await db.insert(schema.dossierNotes).values([
    { orgId, enrollmentId: enrollmentIds.N2, personId: person.id, section: "commentaire", body: "Camille avance vite sur le niveau 2 (n8n, RAG) ; souhaite présenter l'examen avant la fin du mois.", authorId: users.admin, pinned: true },
    { orgId, enrollmentId: enrollmentIds.N2, personId: person.id, section: "administratif", body: "Dossier CPF déposé en attente : la certification est en cours d'enregistrement au Répertoire spécifique. Accès e-learning ouvert sur décision de la direction (contrat signé, niveau 1 réglé).", authorId: users.admin },
    { orgId, enrollmentId: enrollmentIds.N1, personId: person.id, section: "pedagogique", body: "Niveau 1 validé avec 87 % à l'examen final ; missions pratiques toutes rendues.", authorId: users.direction },
  ]);

  /* ---------- Financements : N1 réglé (personnel), N2 CPF fictif en attente d'enregistrement RS ---------- */
  const [cpfFunder] = await db.select({ id: schema.funders.id }).from(schema.funders).where(and(eq(schema.funders.orgId, orgId), eq(schema.funders.kind, "cpf"))).limit(1);
  await db.insert(schema.fundings).values([
    { orgId, enrollmentId: enrollmentIds.N1, funderId: null, kind: "particulier", label: "Financement personnel : niveau 1 (parcours N1-N4)", amountCents: perLevelCents, status: "solde", agreementRef: `REG-${year}-0412`, agreementDate: daysAgo(today, 75), agreementSource: "Règlement par carte bancaire à la signature du contrat (fictif)", validFrom: n1Start, validUntil: n1End, schedule: [{ label: "Règlement à la signature", dueDate: daysAgo(today, 75), amountCents: perLevelCents, invoiceId: null }], notes: "Dossier de démonstration." },
    { orgId, enrollmentId: enrollmentIds.N2, funderId: cpfFunder?.id ?? null, kind: "cpf", label: "Mon compte formation (CPF) : en attente d'enregistrement RS", amountCents: perLevelCents, status: "prevu", agreementRef: null, agreementDate: null, agreementSource: null, validFrom: n2Start, validUntil: addD(n2Start, 60), rateNote: "Plafond CPF Répertoire spécifique : 1 500 € ; participation forfaitaire de l'apprenant selon la réglementation en vigueur.", schedule: [{ label: "Solde après enregistrement RS", dueDate: addD(n2Start, 90), amountCents: perLevelCents, invoiceId: null }], notes: "En attente d'enregistrement RS : certification en cours d'enregistrement au Répertoire spécifique (France Compétences), financement CPF bientôt disponible. Aucune promesse d'accès liée au CPF ; l'accès e-learning a été ouvert manuellement par l'organisme (dérogation motivée, journalisée)." },
  ]);

  /* ---------- Documents : contrat signé, pièce d'identité, certificat N1, certificat de réalisation N1 ---------- */
  const contractPdf = await simplePdf({ org: orgPdf, kicker: "Contrat de formation professionnelle", title: `Contrat n° ${contractNumber} : ${IA_PROGRAM_TITLE}`, paragraphs: [`Entre l'organisme de formation ${org.legalName} et ${camilleName}, née le 18 mars 1994 à Villeurbanne, demeurant 8 rue des Capucins 69001 Lyon, il est conclu le présent contrat de formation professionnelle (art. L6353-3 et suivants du Code du travail).`, `Objet : parcours complet N1 à N4 de la Formation IA (150 h, formation ouverte et à distance), soit : ${IA_LEVELS.filter((l) => !l.specialisation).map((l) => `${l.title} (${l.hours} h)`).join(" ; ")}.`, `Prix : ${(parcours.priceCents / 100).toLocaleString("fr-FR")} € TTC (tarif de lancement). Niveau 1 réglé à la signature ; niveaux suivants selon le financement retenu (CPF bientôt disponible, financement personnel, entreprise ou France Travail).`, "Délai de rétractation de dix jours, modalités d'accès, d'évaluation (quiz, examen par niveau, 70 % requis) et de délivrance des certificats selon les conditions générales annexées.", `Signé électroniquement par ${camilleName} et par Hélène Vasseur, directrice, le ${daysAgo(today, 75)}.`], footer: DEMO_FOOTER });
  const contractDoc = await createDocument({ orgId, enrollmentId: enrollmentIds.N1, personId: person.id, sessionId: catalog.sessionIds.N1, category: "contrat", visibility: "apprenant", status: "signe", title: `Contrat de formation ${contractNumber} : parcours Formation IA N1-N4 (${camilleName})`, fileName: `contrat-${contractNumber.toLowerCase()}.pdf`, mimeType: "application/pdf", data: contractPdf, templateCode: "contrat_particulier_v1", generationData: { enrollmentIds: Object.values(enrollmentIds), offer: parcours.code, contractNumber }, sourceType: "enrollment", sourceId: enrollmentIds.N1, uploadedBy: users.admin, isDemo: true });
  await db.update(schema.documents).set({ transmittedAt: new Date(`${daysAgo(today, 76)}T10:00:00Z`), signedAt }).where(eq(schema.documents.id, contractDoc.id));
  await db.insert(schema.signatureRequests).values({ orgId, documentId: contractDoc.id, provider: "interne", status: "signee", signers: [{ name: camilleName, email: `camille.fontaine@${domain}`, role: "learner", signedAt: new Date(signedAt.getTime() - 3600_000).toISOString(), ip: "92.184.100.21" }, { name: "Hélène Vasseur", email: `helene.vasseur@${domain}`, role: "other", signedAt: signedAt.toISOString(), ip: "10.20.0.4" }], signedDocumentId: contractDoc.id, proof: { signedAt: signedAt.toISOString(), signers: [{ name: camilleName, signedAt: new Date(signedAt.getTime() - 3600_000).toISOString() }, { name: "Hélène Vasseur", signedAt: signedAt.toISOString() }], sha256: contractDoc.sha256 ?? "demo" }, requestedBy: users.admin });
  await recordEvidence({ orgId, indicatorCode: "IND_4", level: "individuel", title: `Contrat de formation signé : ${camilleName} (parcours N1-N4)`, evidenceDate: daysAgo(today, 75), sourceType: "document", sourceId: contractDoc.id, documentId: contractDoc.id, enrollmentId: enrollmentIds.N1, sessionId: catalog.sessionIds.N1, createdBy: users.admin });

  const identityDoc = await createDocument({ orgId, enrollmentId: enrollmentIds.N1, personId: person.id, category: "piece_identite", visibility: "administratif", status: "valide", title: `Pièce d'identité : ${camilleName}`, fileName: `piece-identite-${person.id.slice(0, 8)}.txt`, mimeType: "text/plain", data: Buffer.from(`Pièce d'identité déposée par ${camilleName} (démonstration, contenu fictif).\n`, "utf8"), sourceType: "piece", sourceId: enrollmentIds.N1, uploadedBy: users.camille, isDemo: true });

  const certN1Pdf = await simplePdf({ org: orgPdf, kicker: "Certificat Next Formation IA", title: `${getIaLevel("N1")!.certificate}`, paragraphs: [`Décerné à ${camilleName} pour la validation du niveau 1 « Fondamentaux de l'IA » (25 h) de la Formation IA, examen final réussi le ${n1End} avec un score de 87 % (seuil : 70 %).`, "Compétences certifiées : C1.1 à C1.6 du référentiel de compétences Next Formation IA (expliquer un modèle de langage, choisir un outil, rédiger un prompt structuré, vérifier une production, décrire une automatisation, appliquer les règles RGPD et AI Act).", "Certification en cours d'enregistrement au Répertoire spécifique (France Compétences).", `Fait à Lyon le ${addD(n1End, 2)}. La directrice, Hélène Vasseur.`], footer: DEMO_FOOTER });
  const certN1 = await createDocument({ orgId, enrollmentId: enrollmentIds.N1, personId: person.id, sessionId: catalog.sessionIds.N1, category: "attestation", visibility: "apprenant", status: "valide", title: `Certificat Next Formation IA, niveau 1 : ${camilleName}`, fileName: `certificat-ia-n1-${person.id.slice(0, 8)}.pdf`, mimeType: "application/pdf", data: certN1Pdf, templateCode: "certificat_ia_niveau_v1", generationData: { enrollmentId: enrollmentIds.N1, level: "N1", score: 87 }, sourceType: "enrollment", sourceId: enrollmentIds.N1, uploadedBy: users.direction, isDemo: true });
  await db.update(schema.documents).set({ validatedAt: new Date(`${addD(n1End, 2)}T15:00:00Z`), validatedBy: users.direction }).where(eq(schema.documents.id, certN1.id));
  const realisationPdf = await simplePdf({ org: orgPdf, kicker: "Certificat de réalisation", title: `Certificat de réalisation : ${camilleName}`, paragraphs: [`Action : ${IA_PROGRAM_TITLE}, niveau 1 « Fondamentaux de l'IA ». Nature : action de formation. Modalité : formation ouverte et à distance.`, `Dates : du ${n1Start} au ${n1End}. Durée réalisée : 25 h sur 25 h prévues (relevé de connexion et de progression de l'espace e-learning, validé par l'organisme).`, `Fait à Lyon le ${addD(n1End, 2)}.`], footer: DEMO_FOOTER });
  const realisationN1 = await createDocument({ orgId, enrollmentId: enrollmentIds.N1, personId: person.id, sessionId: catalog.sessionIds.N1, category: "certificat_realisation", visibility: "apprenant", status: "valide", title: `Certificat de réalisation, niveau 1 : ${camilleName}`, fileName: `certificat-realisation-n1-${person.id.slice(0, 8)}.pdf`, mimeType: "application/pdf", data: realisationPdf, templateCode: "certificat_realisation_v1", generationData: { enrollmentId: enrollmentIds.N1, hours: 25 }, sourceType: "enrollment", sourceId: enrollmentIds.N1, uploadedBy: users.direction, isDemo: true });
  await recordEvidence({ orgId, indicatorCode: "IND_11", level: "individuel", title: `Niveau 1 validé et certifié : ${camilleName}`, evidenceDate: addD(n1End, 2), sourceType: "document", sourceId: realisationN1.id, documentId: realisationN1.id, enrollmentId: enrollmentIds.N1, sessionId: catalog.sessionIds.N1, createdBy: users.direction });

  /* ---------- Pièces attendues par inscription (contrat de particulier × financement) ---------- */
  const pieces = await db.select().from(schema.requiredPieces).where(and(eq(schema.requiredPieces.orgId, orgId), eq(schema.requiredPieces.isActive, true)));
  const fundingKindsOf: Record<(typeof PARCOURS_LEVELS)[number], string[]> = { N1: ["particulier"], N2: ["cpf"], N3: [], N4: [] };
  const submissions: (typeof schema.pieceSubmissions.$inferInsert)[] = [];
  for (const code of PARCOURS_LEVELS) {
    const eid = enrollmentIds[code];
    const start = plan[code].startDate ?? `${year}-12-31`;
    for (const p of applicablePieces(pieces, { contractKind: "contrat_particulier", fundingKinds: fundingKindsOf[code], activity: "of" })) {
      const accepted = { status: "acceptee" as const, submittedAt: new Date(`${daysAgo(today, 76)}T11:00:00Z`), submittedBy: users.camille, reviewedBy: users.admin, reviewedAt: new Date(`${daysAgo(today, 75)}T09:00:00Z`) };
      if (p.code === "piece_identite") submissions.push({ orgId, enrollmentId: eid, requiredPieceId: p.id, documentId: identityDoc.id, dueDate: pieceDueDate(p, start), ...accepted });
      else if (p.code === "contrat_formation_signe") submissions.push({ orgId, enrollmentId: eid, requiredPieceId: p.id, documentId: contractDoc.id, dueDate: pieceDueDate(p, start), ...accepted });
      else if (p.code === "reglement_interieur") submissions.push({ orgId, enrollmentId: eid, requiredPieceId: p.id, documentId: null, dueDate: pieceDueDate(p, start), ...accepted });
      else if (p.code === "accord_prise_en_charge") submissions.push({ orgId, enrollmentId: eid, requiredPieceId: p.id, documentId: null, status: "attendue", dueDate: addD(today, 30) });
      else if (!p.isRequired) submissions.push({ orgId, enrollmentId: eid, requiredPieceId: p.id, documentId: null, status: "non_applicable", naReason: "Pièce facultative non demandée pour ce dossier.", dueDate: null });
      else submissions.push({ orgId, enrollmentId: eid, requiredPieceId: p.id, documentId: null, status: "attendue", dueDate: pieceDueDate(p, start) });
    }
  }
  if (submissions.length) await db.insert(schema.pieceSubmissions).values(submissions);

  /* ---------- Tâches de relais (idempotentes) ---------- */
  const href = (eid: string, tab?: string) => `/app/${orgId}/inscriptions/${eid}${tab ? `?onglet=${tab}` : ""}`;
  const rsBlocked = "Certification en cours d'enregistrement au Répertoire spécifique (France Compétences) : financement CPF bientôt disponible.";
  await createTaskOnce({ orgId, title: `Financement CPF en attente d'enregistrement RS : ${camilleName} (niveau 2)`, description: "Dossier CPF fictif déposé en prévision. Aucune promesse d'accès liée au CPF ; informer l'apprenante dès l'enregistrement de la certification.", family: "financement", entityType: "enrollment", entityId: enrollmentIds.N2, entityLabel: camilleName, href: href(enrollmentIds.N2, "financement"), assigneeRole: "finance", priority: "normale", blockedReason: rsBlocked, indicatorCode: null, createdBy: users.admin, isDemo: true, idempotencyKey: `ia:cpf:${enrollmentIds.N2}` });
  const accord = pieces.find((p) => p.code === "accord_prise_en_charge");
  if (accord) await createTaskOnce({ orgId, title: `Pièce manquante : ${accord.label} (${camilleName})`, family: "administratif", entityType: "enrollment", entityId: enrollmentIds.N2, entityLabel: camilleName, href: href(enrollmentIds.N2, "pieces"), assigneeRole: "admin_staff", dueDate: addD(today, 30), blockedReason: rsBlocked, createdBy: users.admin, isDemo: true, idempotencyKey: `piece:${enrollmentIds.N2}:${accord.code}` });
  await createTaskOnce({ orgId, title: `Planifier l'entrée au niveau 3 : ${camilleName}`, description: "Dès la validation du niveau 2 : ouvrir l'accès e-learning du niveau 3 et confirmer le financement des niveaux 3 et 4.", family: "pedagogie", entityType: "enrollment", entityId: enrollmentIds.N3, entityLabel: camilleName, href: href(enrollmentIds.N3), assigneeRole: "pedagogy_manager", dueDate: addD(n2Start, 60), prerequisites: [{ label: "Examen du niveau 2 réussi", done: false }], createdBy: users.direction, isDemo: true, idempotencyKey: `ia:niveau_suivant:${enrollmentIds.N3}` });

  await audit({ action: "demo.ia_seed", orgId, tenantId: tenant.id, userId: users.camille, entityType: "tenant", entityId: tenant.id, after: { slug: tenant.slug, enrollmentIds } });
  return { tenantId: tenant.id, orgId, userId: users.camille, personId: person.id, enrollmentIds, staff: { direction: users.direction, admin: users.admin }, reused: false };
}
