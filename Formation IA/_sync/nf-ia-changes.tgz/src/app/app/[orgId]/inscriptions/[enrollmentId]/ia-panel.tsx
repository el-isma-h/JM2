import Link from "next/link";
import { ActionButton } from "@/components/admin/action-form";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { KeyValue, Notice, Panel, PanelHeader } from "@/components/ui/surface";
import { fmtDateTime } from "@/lib/dates";
import { formatCents } from "@/lib/money";
import { integrationLabels } from "@/lib/env";
import { IA_FUNDING_META, iaIntegrationConfigured, loadIaDossier, syncIaAccess } from "@/server/ia/enrollment";
import { iaOfferPriceNote } from "@/server/ia/catalog";
import { closeIaAccessAction, openIaAccessAction } from "@/server/actions/ia-inscription";

/**
 * Bloc « Formation IA » du dossier central : offre, droits e-learning, financement, contrat, accès.
 * Ouverture et fermeture de l'accès (permission `enrollments.manage`, confirmation, motif journalisé).
 * Affiché uniquement pour une inscription portant une offre IA.
 */
export async function IaDossierPanel({ orgId, enrollmentId, canManage }: { orgId: string; enrollmentId: string; canManage: boolean }) {
  const loaded = await loadIaDossier(orgId, enrollmentId);
  if (!loaded) return null;
  const d = await syncIaAccess(loaded);
  const labels = integrationLabels as unknown as Record<string, { label: string; envVars: string[] } | undefined>;
  const iaLabel = labels.ia ?? { label: "Connexion à l'espace e-learning (SSO)", envVars: ["IA_APP_URL", "IA_SSO_SECRET"] };
  const configured = iaIntegrationConfigured();
  const fundingLabel = d.iaFunding ? IA_FUNDING_META[d.iaFunding].label : d.funding?.label ?? "À définir";
  const priceNote = d.offer ? iaOfferPriceNote(d.offer) : null;
  return (
    <Panel>
      <PanelHeader title="Formation IA" description="Offre achetée en ligne, droits transmis à l'espace e-learning et ouverture de l'accès (signature + financement hors CPF : automatique ; sinon décision de l'organisme)." />
      <div className="space-y-4 p-5">
        <KeyValue
          items={[
            { k: "Offre", v: d.offer ? `${d.offer.label} (${d.offer.hours} h)` : d.enrollment.iaOffer },
            { k: "Prix TTC", v: <span className="num">{formatCents(d.offer?.priceCents ?? d.enrollment.priceCents)}{priceNote ? ` · ${priceNote}` : ""}</span> },
            { k: "Droits e-learning", v: d.entitlements.length ? d.entitlements.map((e) => <Badge key={e} tone="accent" className="mr-1">{e}</Badge>) : "-" },
            { k: "Financement", v: <span className="flex flex-wrap items-center gap-2">{fundingLabel} <StatusBadge status={d.enrollment.fundingState} /></span> },
            { k: "Contrat", v: d.contract ? <span className="flex flex-wrap items-center gap-2"><Link href={`/app/${orgId}/documents/${d.contract.document.id}`} className="hover:underline">{d.contract.document.title}</Link> <StatusBadge status={d.contract.signed ? "signe" : d.contract.document.status} /></span> : d.iaFunding === "cpf" ? "Après enregistrement de la certification (RS)" : "Non généré" },
            { k: "Accès", v: d.enrollment.iaAccessOpenedAt ? <span className="flex flex-wrap items-center gap-2"><StatusBadge status="ouverte" /> <span className="num">{fmtDateTime(d.enrollment.iaAccessOpenedAt)}</span></span> : <span className="flex flex-wrap items-center gap-2"><StatusBadge status="attendue" /> non ouvert</span> },
          ]}
        />
        {d.iaFunding === "cpf" ? (
          <Notice tone="warn" title="Dossier CPF : en attente d'enregistrement RS">
            Certification en cours d&apos;enregistrement au Répertoire spécifique (France Compétences) : financement CPF bientôt disponible. Aucune promesse d&apos;accès n&apos;a été faite à l&apos;apprenant ; l&apos;ouverture relève de votre décision.
          </Notice>
        ) : null}
        {!d.enrollment.iaAccessOpenedAt && d.blockers.length ? <p className="text-[12.5px] text-ink-3">{d.blockers.join(" ")}</p> : null}
        {d.contract?.missing.length ? <p className="text-[12.5px] text-warn-ink">Document généré en ligne avec informations à compléter : {d.contract.missing.join(", ")}.</p> : null}
        {!configured ? (
          <p className="text-[12.5px] text-ink-3">
            {iaLabel.label} non configurée (<span className="num">{iaLabel.envVars.join(", ")}</span>) : l&apos;apprenant verra l&apos;explication dans son espace au lieu du bouton.
          </p>
        ) : null}
        {canManage ? (
          <div className="flex flex-wrap gap-2">
            {d.enrollment.iaAccessOpenedAt ? (
              <ActionButton
                action={closeIaAccessAction}
                fields={{ orgId, enrollmentId }}
                label="Fermer l'accès e-learning"
                variant="danger"
                confirm={{ title: "Fermer l'accès e-learning", description: "L'apprenant ne pourra plus ouvrir son espace depuis l'extranet. Le motif est obligatoire et conservé dans le journal du dossier.", input: { name: "reason", label: "Motif", help: "Obligatoire" }, danger: true, confirmLabel: "Fermer l'accès" }}
              />
            ) : (
              <ActionButton
                action={openIaAccessAction}
                fields={{ orgId, enrollmentId }}
                label="Ouvrir l'accès e-learning"
                variant="primary"
                confirm={{ title: "Ouvrir l'accès e-learning", description: `Niveaux ouverts : ${d.entitlements.join(", ") || "aucun"}. L'ouverture est journalisée (enrollment.ia_access_open), produit une preuve qualité et notifie l'apprenant.`, input: { name: "reason", label: "Motif", help: "Facultatif (ex. : accord OPCO reçu, décision direction)" }, confirmLabel: "Ouvrir l'accès" }}
              />
            )}
          </div>
        ) : (
          <p className="text-[12.5px] text-ink-3">L&apos;ouverture ou la fermeture de l&apos;accès demande le droit « gérer les inscriptions ».</p>
        )}
      </div>
    </Panel>
  );
}
