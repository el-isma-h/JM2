import { NextResponse } from "next/server";
import { and, eq, gt, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { createSession, destroySession, getCurrentUser } from "@/server/auth";
import { audit } from "@/server/audit";
import { seedIaDemo } from "@/server/demo/ia";
import { clientIp, hit, RATE_LIMITS, tooManyMessage } from "@/server/rate-limit";
import { appUrl } from "@/lib/env";

export const dynamic = "force-dynamic";

/** Plafond global de démonstrations créées par heure (même règle que /demo). */
const MAX_DEMOS_PER_HOUR = 300;
const ENTETES = { "cache-control": "no-store", "x-robots-tag": "noindex, nofollow" };

/** Destinations fixes sur l'adresse publique (aucune redirection ouverte). */
function redirectTo(path: "/moi" | "/formation-ia" | `/formation-ia?camille=${string}`) {
  return NextResponse.redirect(new URL(path, appUrl()), { status: 303, headers: ENTETES });
}

/** Un GET (lien direct, robot) renvoie simplement vers la page Formation IA : la démonstration ne s'ouvre que par le bouton (POST). */
export async function GET() {
  return redirectTo("/formation-ia");
}

/**
 * « Tester en tant que Camille » : crée (ou réutilise pour ce visiteur, moins de 24 h) l'organisme de démonstration IA,
 * ouvre la session de Camille Fontaine (aucun mot de passe) et redirige vers son extranet `/moi`.
 * Protection anti-abus identique à /demo : limitation par adresse IP et plafond global horaire.
 */
export async function POST() {
  const rl = await hit("demo:ip", await clientIp(), RATE_LIMITS.demoIp);
  if (!rl.ok) return redirectTo(`/formation-ia?camille=${encodeURIComponent(tooManyMessage(rl))}`);
  const [{ n }] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(schema.tenants)
    .where(and(eq(schema.tenants.isDemo, true), gt(schema.tenants.createdAt, new Date(Date.now() - 3600_000))));
  if (n >= MAX_DEMOS_PER_HOUR) return redirectTo(`/formation-ia?camille=${encodeURIComponent("Trop de démonstrations ont été ouvertes ces dernières minutes. Réessayez dans un moment.")}`);

  try {
    const current = await getCurrentUser();
    const demo = await seedIaDemo({ reuseUserId: current?.id ?? null });
    if (current && current.id !== demo.userId) await destroySession();
    if (!current || current.id !== demo.userId) await createSession(demo.userId);
    await audit({ action: "demo.enter", userId: demo.userId, tenantId: demo.tenantId, orgId: demo.orgId, entityType: "tenant", entityId: demo.tenantId, after: { as: "learner", camille: true, reused: demo.reused } });
    return redirectTo("/moi");
  } catch (e) {
    console.error("demo.camille", e);
    return redirectTo(`/formation-ia?camille=${encodeURIComponent("La démonstration n'a pas pu être préparée. Réessayez dans un instant.")}`);
  }
}
