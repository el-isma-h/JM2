"use client";

import * as React from "react";
import Link from "next/link";
import { useActionState } from "react";
import { Check } from "@phosphor-icons/react";
import { ActionForm, LinkToCopy } from "@/components/admin/action-form";
import { Button } from "@/components/ui/button";
import { Checkbox, Field, Input, Select } from "@/components/ui/field";
import { StatusBadge } from "@/components/ui/badge";
import { Notice } from "@/components/ui/surface";
import { ACCEPT_ATTR, ALLOWED_LABEL } from "@/server/documents/upload-rules";
import { formatCents } from "@/lib/money";
import { cn } from "@/lib/utils";
import { iaContractAction, iaFundingAction, iaIdentityAction, iaOfferAction, iaPieceUploadAction, iaSignNowAction } from "@/server/actions/ia-inscription";
import type { ActionState } from "@/server/actions/auth";

export type StepId = 1 | 2 | 3 | 4 | 5;

export type SerializedDossier = {
  reference: string;
  offer: { code: string; title: string; priceCents: number; hours: number } | null;
  funding: string | null;
  fundingLabel: string;
  person: { fullName: string; email: string; address: string };
  company: { name: string; siret: string | null } | null;
  pieces: { submissionId: string; code: string; label: string; description: string | null; status: string; isRequired: boolean; providedBy: string; refusalReason: string | null; fileName: string | null }[];
  contract: { title: string; status: string; signed: boolean; missing: string[]; requestStatus: string | null; signers: { name: string; email: string; role: string; signedAt: string | null }[]; canSignNow: boolean } | null;
  accessOpen: boolean;
  blockers: string[];
  nextAction: string;
};

/* ---------- Indicateur d'étapes ---------- */

export function Stepper({ steps, current, max, done }: { steps: { id: StepId; label: string }[]; current: StepId; max: StepId; done: boolean }) {
  return (
    <ol className="flex flex-col border-t border-line-strong" aria-label="Étapes de l'inscription">
      {steps.map((s) => {
        const complete = done || s.id < max;
        const active = !done && s.id === current;
        const reachable = s.id <= max && !done;
        const inner = (
          <>
            <span className={cn("num flex h-7 w-7 shrink-0 items-center justify-center border text-[11px]", complete ? "border-accent bg-accent text-accent-ink" : active ? "border-ink bg-ink text-bg" : "border-line-strong text-ink-3")} aria-hidden>
              {complete ? <Check size={13} weight="bold" /> : s.id}
            </span>
            <span className={cn("font-mono text-[10px] uppercase tracking-[0.2em]", active ? "text-ink" : complete ? "text-ink-2" : "text-ink-3")}>{s.label}</span>
          </>
        );
        return (
          <li key={s.id} className="border-b border-line" aria-current={active ? "step" : undefined}>
            {reachable ? (
              <Link href={`/formation-ia/inscription?etape=${s.id}`} className="flex items-center gap-3 py-3 transition-colors hover:text-ink">
                {inner}
              </Link>
            ) : (
              <span className="flex items-center gap-3 py-3">{inner}</span>
            )}
          </li>
        );
      })}
    </ol>
  );
}

function errFor(state: ActionState, field: string): string | null {
  return state.error && state.data?.field === field ? state.error : null;
}

function GlobalError({ state, fields }: { state: ActionState; fields: string[] }) {
  if (!state.error) return null;
  if (state.data?.field && fields.includes(state.data.field)) return null;
  return <Notice tone="danger">{state.error}</Notice>;
}

/* ---------- Étape 1 : identité et compte ---------- */

const IDENTITY_FIELDS = ["civility", "firstName", "lastName", "email", "phone", "birthDate", "birthPlace", "addressLine1", "postalCode", "city", "situation", "employerName", "employerSiret", "employerContactFirstName", "employerContactLastName", "employerContactEmail", "employerContactJobTitle", "password", "consent"];

export function StepIdentity({
  user,
  person,
  company,
}: {
  user: { firstName: string; lastName: string; email: string } | null;
  person: { civility: string | null; phone: string | null; birthDate: string | null; birthPlace: string | null; addressLine1: string | null; postalCode: string | null; city: string | null; situation: string | null } | null;
  company: { name: string; siret: string | null } | null;
}) {
  const [state, action, pending] = useActionState<ActionState, FormData>(iaIdentityAction, {});
  const v = (k: string, fallback = "") => state.data?.[k] ?? fallback;
  return <IdentityForm key={state.data ? JSON.stringify(state.data) : "initial"} state={state} action={action} pending={pending} v={v} user={user} person={person} company={company} />;
}

function IdentityForm({
  state,
  action,
  pending,
  v,
  user,
  person,
  company,
}: {
  state: ActionState;
  action: (formData: FormData) => void;
  pending: boolean;
  v: (k: string, fallback?: string) => string;
  user: { firstName: string; lastName: string; email: string } | null;
  person: { civility: string | null; phone: string | null; birthDate: string | null; birthPlace: string | null; addressLine1: string | null; postalCode: string | null; city: string | null; situation: string | null } | null;
  company: { name: string; siret: string | null } | null;
}) {
  const [situation, setSituation] = React.useState(v("situation", person?.situation ?? "particulier"));
  const salarie = situation === "salarie";
  return (
    <form action={action} className="space-y-6" noValidate>
      <div>
        <p className="etiquette">Étape 1 sur 5</p>
        <h2 className="mt-3 text-[26px]">Identité et compte</h2>
        <p className="mt-2 text-[14px] text-ink-2">
          {user ? (
            <>
              Vous êtes connecté en tant que <strong>{user.firstName} {user.lastName}</strong> ({user.email}). Complétez votre dossier.
            </>
          ) : (
            <>
              Ces informations figurent sur votre contrat ou votre convention. Déjà un compte ?{" "}
              <Link href="/connexion?next=/formation-ia/inscription" className="font-medium text-accent underline-offset-4 hover:underline">
                Se connecter
              </Link>
              .
            </>
          )}
        </p>
      </div>
      <div className="grid gap-5 sm:grid-cols-[120px_1fr_1fr]">
        <Field label="Civilité" htmlFor="ia-civ" required error={errFor(state, "civility")}>
          <Select id="ia-civ" name="civility" defaultValue={v("civility", person?.civility ?? "")} required>
            <option value="">Choisir</option>
            <option value="Mme">Madame</option>
            <option value="M">Monsieur</option>
            <option value="autre">Autre</option>
          </Select>
        </Field>
        <Field label="Prénom" htmlFor="ia-first" required error={errFor(state, "firstName")}>
          <Input id="ia-first" name="firstName" autoComplete="given-name" defaultValue={v("firstName", user?.firstName ?? "")} required />
        </Field>
        <Field label="Nom" htmlFor="ia-last" required error={errFor(state, "lastName")}>
          <Input id="ia-last" name="lastName" autoComplete="family-name" defaultValue={v("lastName", user?.lastName ?? "")} required />
        </Field>
      </div>
      <div className="grid gap-5 sm:grid-cols-2">
        <Field label="Adresse e-mail" htmlFor="ia-email" required error={errFor(state, "email")} help={user ? "Adresse de votre compte." : "Elle sert de identifiant de connexion et reçoit le contrat à signer."}>
          <Input id="ia-email" name="email" type="email" autoComplete="email" defaultValue={v("email", user?.email ?? "")} readOnly={Boolean(user)} required />
          {state.data?.emailExists ? (
            <p className="mt-1.5 text-[12.5px]">
              <Link href="/connexion?next=/formation-ia/inscription" className="font-medium text-accent underline-offset-4 hover:underline">
                Se connecter avec ce compte
              </Link>
            </p>
          ) : null}
        </Field>
        <Field label="Téléphone" htmlFor="ia-phone" required error={errFor(state, "phone")}>
          <Input id="ia-phone" name="phone" type="tel" autoComplete="tel" defaultValue={v("phone", person?.phone ?? "")} required className="num" />
        </Field>
        <Field label="Date de naissance" htmlFor="ia-birth" required error={errFor(state, "birthDate")} help="JJ/MM/AAAA">
          <Input id="ia-birth" name="birthDate" type="date" autoComplete="bday" defaultValue={v("birthDate", person?.birthDate ?? "")} required className="num" />
        </Field>
        <Field label="Lieu de naissance" htmlFor="ia-birthplace" error={errFor(state, "birthPlace")} help="Figure sur le contrat de formation ; facultatif à cette étape.">
          <Input id="ia-birthplace" name="birthPlace" defaultValue={v("birthPlace", person?.birthPlace ?? "")} />
        </Field>
      </div>
      <div className="grid gap-5 sm:grid-cols-[1fr_140px_1fr]">
        <Field label="Adresse postale" htmlFor="ia-addr" required error={errFor(state, "addressLine1")}>
          <Input id="ia-addr" name="addressLine1" autoComplete="street-address" defaultValue={v("addressLine1", person?.addressLine1 ?? "")} required />
        </Field>
        <Field label="Code postal" htmlFor="ia-cp" required error={errFor(state, "postalCode")}>
          <Input id="ia-cp" name="postalCode" autoComplete="postal-code" inputMode="numeric" defaultValue={v("postalCode", person?.postalCode ?? "")} required className="num" />
        </Field>
        <Field label="Ville" htmlFor="ia-city" required error={errFor(state, "city")}>
          <Input id="ia-city" name="city" autoComplete="address-level2" defaultValue={v("city", person?.city ?? "")} required />
        </Field>
      </div>
      <Field label="Votre situation" htmlFor="ia-situation" required error={errFor(state, "situation")} help="Un salarié financé par son entreprise ou son OPCO renseigne son employeur : il signera la convention.">
        <Select id="ia-situation" name="situation" value={situation} onChange={(e) => setSituation(e.target.value)} required>
          <option value="particulier">Particulier (financement personnel ou CPF)</option>
          <option value="salarie">Salarié (entreprise ou OPCO)</option>
          <option value="demandeur_emploi">Demandeur d&apos;emploi (France Travail)</option>
          <option value="independant">Indépendant, dirigeant</option>
        </Select>
      </Field>
      {salarie ? (
        <fieldset className="space-y-5 border border-line p-5">
          <legend className="px-2 font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">Employeur</legend>
          <div className="grid gap-5 sm:grid-cols-2">
            <Field label="Raison sociale" htmlFor="ia-emp" required error={errFor(state, "employerName")}>
              <Input id="ia-emp" name="employerName" autoComplete="organization" defaultValue={v("employerName", company?.name ?? "")} />
            </Field>
            <Field label="SIRET" htmlFor="ia-siret" required error={errFor(state, "employerSiret")} help="14 chiffres, clé vérifiée.">
              <Input id="ia-siret" name="employerSiret" inputMode="numeric" defaultValue={v("employerSiret", company?.siret ?? "")} className="num" />
            </Field>
            <Field label="Prénom du contact" htmlFor="ia-ecf" required error={errFor(state, "employerContactFirstName")}>
              <Input id="ia-ecf" name="employerContactFirstName" defaultValue={v("employerContactFirstName")} />
            </Field>
            <Field label="Nom du contact" htmlFor="ia-ecl" required error={errFor(state, "employerContactLastName")}>
              <Input id="ia-ecl" name="employerContactLastName" defaultValue={v("employerContactLastName")} />
            </Field>
            <Field label="E-mail du contact" htmlFor="ia-ece" required error={errFor(state, "employerContactEmail")} help="Reçoit la convention à signer.">
              <Input id="ia-ece" name="employerContactEmail" type="email" defaultValue={v("employerContactEmail")} />
            </Field>
            <Field label="Fonction du contact" htmlFor="ia-ecj" error={errFor(state, "employerContactJobTitle")}>
              <Input id="ia-ecj" name="employerContactJobTitle" defaultValue={v("employerContactJobTitle")} />
            </Field>
          </div>
        </fieldset>
      ) : null}
      {!user ? (
        <>
          <Field label="Mot de passe" htmlFor="ia-pw" required error={errFor(state, "password")} help="12 caractères minimum, avec majuscule, minuscule et chiffre.">
            <Input id="ia-pw" name="password" type="password" autoComplete="new-password" required minLength={12} />
          </Field>
          <div>
            <Checkbox
              name="consent"
              defaultChecked={state.data?.consent === "on"}
              label={
                <span className="text-[13px] text-ink-2">
                  J&apos;accepte les{" "}
                  <Link href="/cgu" target="_blank" className="text-accent hover:underline">
                    conditions générales
                  </Link>{" "}
                  et la{" "}
                  <Link href="/confidentialite" target="_blank" className="text-accent hover:underline">
                    politique de confidentialité
                  </Link>
                  . Mes données servent uniquement à la gestion de mon dossier de formation.
                </span>
              }
            />
            {errFor(state, "consent") ? (
              <p className="mt-1.5 text-[12.5px] text-danger-ink" role="alert">
                {errFor(state, "consent")}
              </p>
            ) : null}
          </div>
        </>
      ) : null}
      <GlobalError state={state} fields={IDENTITY_FIELDS} />
      <div className="flex flex-wrap items-center gap-4">
        <Button type="submit" size="lg" loading={pending}>
          {user ? "Enregistrer et continuer" : "Créer mon compte et continuer"}
        </Button>
      </div>
    </form>
  );
}

/* ---------- Étape 2 : offre ---------- */

export function StepOffer({ offers, n5Hint, priceNote }: { offers: { code: string; title: string; priceCents: number; hours: number; entitlements: string[] }[]; n5Hint: string; priceNote: string }) {
  const [state, action, pending] = useActionState<ActionState, FormData>(iaOfferAction, {});
  const [offer, setOffer] = React.useState<string>("");
  return (
    <form action={action} className="space-y-6">
      <div>
        <p className="etiquette">Étape 2 sur 5</p>
        <h2 className="mt-3 text-[26px]">Votre offre</h2>
        <p className="mt-2 text-[14px] text-ink-2">Formation ouverte à distance, entrée à tout moment de l&apos;année. {priceNote}</p>
      </div>
      <div role="radiogroup" aria-label="Offres" className="grid gap-3 sm:grid-cols-2">
        {offers.map((o) => {
          const checked = offer === o.code;
          return (
            <label key={o.code} className={cn("flex cursor-pointer flex-col gap-2 border p-5 transition-colors", checked ? "border-accent bg-accent-bright/30" : "border-line hover:border-ink")}>
              <span className="flex items-start justify-between gap-3">
                <span className="flex items-center gap-2.5">
                  <input type="radio" name="offer" value={o.code} checked={checked} onChange={() => setOffer(o.code)} className="h-4 w-4 accent-[var(--accent)]" />
                  <span className="font-medium text-ink">{o.title}</span>
                </span>
                <span className="num text-[15px] text-ink">{formatCents(o.priceCents)}</span>
              </span>
              <span className="num pl-6 text-[12.5px] text-ink-3">
                {o.hours} h · {o.entitlements.length > 1 ? `niveaux ${o.entitlements.join(", ")}` : `niveau ${o.entitlements[0]}`}
              </span>
              {o.code === "N5" ? <span className="pl-6 text-[12.5px] text-ink-2">{n5Hint}</span> : null}
            </label>
          );
        })}
      </div>
      {state.error ? <Notice tone="danger">{state.error}</Notice> : null}
      <div className="flex flex-wrap items-center gap-4">
        <Button type="submit" size="lg" loading={pending} disabled={!offer}>
          Continuer vers le financement
        </Button>
        <Button asChild variant="ghost" size="lg">
          <Link href="/formation-ia/inscription?etape=1">Retour</Link>
        </Button>
      </div>
    </form>
  );
}

/* ---------- Étape 3 : financement ---------- */

const FUNDING_FIELDS = ["funding", "opcoName", "franceTravailId", "employerName", "employerSiret", "employerContactFirstName", "employerContactLastName", "employerContactEmail", "employerContactJobTitle", "employerAddressLine1", "employerPostalCode", "employerCity", "cpfAck"];

export function StepFunding({
  offer,
  fundings,
  company,
}: {
  offer: { code: string; title: string; priceCents: number; hours: number };
  fundings: { code: string; label: string; description: string; needsCompany: boolean; pieces: string[] }[];
  company: { name: string; siret: string | null; addressLine1: string | null; postalCode: string | null; city: string | null } | null;
}) {
  const [state, action, pending] = useActionState<ActionState, FormData>(iaFundingAction, {});
  const v = (k: string, fallback = "") => state.data?.[k] ?? fallback;
  return <FundingForm key={state.data ? JSON.stringify(state.data) : "initial"} state={state} action={action} pending={pending} v={v} offer={offer} fundings={fundings} company={company} />;
}

function FundingForm({
  state,
  action,
  pending,
  v,
  offer,
  fundings,
  company,
}: {
  state: ActionState;
  action: (formData: FormData) => void;
  pending: boolean;
  v: (k: string, fallback?: string) => string;
  offer: { code: string; title: string; priceCents: number; hours: number };
  fundings: { code: string; label: string; description: string; needsCompany: boolean; pieces: string[] }[];
  company: { name: string; siret: string | null; addressLine1: string | null; postalCode: string | null; city: string | null } | null;
}) {
  const [funding, setFunding] = React.useState<string>(v("funding"));
  const meta = fundings.find((f) => f.code === funding) ?? null;
  return (
    <form action={action} className="space-y-6" noValidate>
      <input type="hidden" name="offer" value={offer.code} />
      <div>
        <p className="etiquette">Étape 3 sur 5</p>
        <h2 className="mt-3 text-[26px]">Financement</h2>
        <p className="mt-2 text-[14px] text-ink-2">
          Offre choisie : <strong>{offer.title}</strong>, <span className="num">{offer.hours} h</span>, <span className="num">{formatCents(offer.priceCents)}</span> TTC.{" "}
          <Link href="/formation-ia/inscription?etape=2" className="font-medium text-accent underline-offset-4 hover:underline">
            Changer d&apos;offre
          </Link>
        </p>
      </div>
      <div role="radiogroup" aria-label="Mode de financement" className="flex flex-col divide-y divide-line border border-line">
        {fundings.map((f) => {
          const checked = funding === f.code;
          return (
            <label key={f.code} className={cn("flex cursor-pointer gap-3 p-4 transition-colors", checked ? "bg-accent-bright/30" : "hover:bg-bg-sunken")}>
              <input type="radio" name="funding" value={f.code} checked={checked} onChange={() => setFunding(f.code)} className="mt-1 h-4 w-4 shrink-0 accent-[var(--accent)]" />
              <span className="min-w-0">
                <span className="block font-medium text-ink">{f.label}</span>
                <span className="mt-1 block text-[13px] text-ink-2">{f.description}</span>
                <span className="mt-1.5 block text-[12px] text-ink-3">Pièces attendues : {f.pieces.join(", ")}.</span>
              </span>
            </label>
          );
        })}
      </div>
      {errFor(state, "funding") ? (
        <p className="text-[12.5px] text-danger-ink" role="alert">
          {errFor(state, "funding")}
        </p>
      ) : null}

      {funding === "cpf" ? (
        <div className="space-y-3 border border-warn/70 p-5">
          <Notice tone="warn" title="Pré-réservation CPF">
            {meta?.description}
          </Notice>
          <Checkbox name="cpfAck" defaultChecked={state.data?.cpfAck === "on"} label={<span className="text-[13px]">J&apos;ai compris que le financement CPF n&apos;est pas encore disponible et que mon dossier est enregistré comme pré-réservation, sans ouverture d&apos;accès.</span>} />
          {errFor(state, "cpfAck") ? (
            <p className="text-[12.5px] text-danger-ink" role="alert">
              {errFor(state, "cpfAck")}
            </p>
          ) : null}
        </div>
      ) : null}

      {meta?.needsCompany ? (
        <fieldset className="space-y-5 border border-line p-5">
          <legend className="px-2 font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">Employeur (signataire de la convention)</legend>
          <div className="grid gap-5 sm:grid-cols-2">
            {funding === "opco" ? (
              <Field label="OPCO" htmlFor="ia-opco" required error={errFor(state, "opcoName")} help="Ex. : Atlas, Akto, Opco EP, Afdas, Uniformation, Ocapiat, Constructys, Opco 2i, Opco Mobilités, Opcommerce, Opco Santé." className="sm:col-span-2">
                <Input id="ia-opco" name="opcoName" defaultValue={v("opcoName")} />
              </Field>
            ) : null}
            <Field label="Raison sociale" htmlFor="ia-f-emp" required error={errFor(state, "employerName")}>
              <Input id="ia-f-emp" name="employerName" autoComplete="organization" defaultValue={v("employerName", company?.name ?? "")} />
            </Field>
            <Field label="SIRET" htmlFor="ia-f-siret" required error={errFor(state, "employerSiret")} help="14 chiffres, clé vérifiée.">
              <Input id="ia-f-siret" name="employerSiret" inputMode="numeric" defaultValue={v("employerSiret", company?.siret ?? "")} className="num" />
            </Field>
            <Field label="Adresse de l'entreprise" htmlFor="ia-f-addr" required error={errFor(state, "employerAddressLine1")} className="sm:col-span-2">
              <Input id="ia-f-addr" name="employerAddressLine1" defaultValue={v("employerAddressLine1", company?.addressLine1 ?? "")} />
            </Field>
            <Field label="Code postal" htmlFor="ia-f-cp" required error={errFor(state, "employerPostalCode")}>
              <Input id="ia-f-cp" name="employerPostalCode" inputMode="numeric" defaultValue={v("employerPostalCode", company?.postalCode ?? "")} className="num" />
            </Field>
            <Field label="Ville" htmlFor="ia-f-city" required error={errFor(state, "employerCity")}>
              <Input id="ia-f-city" name="employerCity" defaultValue={v("employerCity", company?.city ?? "")} />
            </Field>
            <Field label="Prénom du contact" htmlFor="ia-f-ecf" required error={errFor(state, "employerContactFirstName")}>
              <Input id="ia-f-ecf" name="employerContactFirstName" defaultValue={v("employerContactFirstName")} />
            </Field>
            <Field label="Nom du contact" htmlFor="ia-f-ecl" required error={errFor(state, "employerContactLastName")}>
              <Input id="ia-f-ecl" name="employerContactLastName" defaultValue={v("employerContactLastName")} />
            </Field>
            <Field label="E-mail du contact" htmlFor="ia-f-ece" required error={errFor(state, "employerContactEmail")} help="Reçoit la convention à signer.">
              <Input id="ia-f-ece" name="employerContactEmail" type="email" defaultValue={v("employerContactEmail")} />
            </Field>
            <Field label="Fonction du signataire" htmlFor="ia-f-ecj" required error={errFor(state, "employerContactJobTitle")} help="Figure sur la convention.">
              <Input id="ia-f-ecj" name="employerContactJobTitle" defaultValue={v("employerContactJobTitle")} />
            </Field>
          </div>
        </fieldset>
      ) : null}

      {funding === "france_travail" ? (
        <Field label="Identifiant France Travail" htmlFor="ia-ft" required error={errFor(state, "franceTravailId")} help="Identifiant figurant sur vos courriers France Travail ; transmis à votre conseiller avec le devis.">
          <Input id="ia-ft" name="franceTravailId" defaultValue={v("franceTravailId")} className="num" />
        </Field>
      ) : null}

      <GlobalError state={state} fields={FUNDING_FIELDS} />
      <div className="flex flex-wrap items-center gap-4">
        <Button type="submit" size="lg" loading={pending} disabled={!funding}>
          Enregistrer mon inscription
        </Button>
        <Button asChild variant="ghost" size="lg">
          <Link href="/formation-ia/inscription?etape=2">Retour</Link>
        </Button>
      </div>
    </form>
  );
}

/* ---------- Étape 4 : pièces ---------- */

export function StepPieces({ dossier }: { dossier: SerializedDossier }) {
  const todo = dossier.pieces.filter((p) => p.status === "attendue" || p.status === "refusee");
  return (
    <div className="space-y-6">
      <div>
        <p className="etiquette">Étape 4 sur 5</p>
        <h2 className="mt-3 text-[26px]">Pièces du dossier</h2>
        <p className="mt-2 text-[14px] text-ink-2">
          Dossier <span className="num">{dossier.reference}</span>, financement : {dossier.fundingLabel}. Déposez les pièces que vous détenez ; les autres peuvent être déposées plus tard depuis votre espace apprenant, l&apos;organisme les suit.
        </p>
      </div>
      {dossier.pieces.length ? (
        <ul className="divide-y divide-line border border-line">
          {dossier.pieces.map((p) => (
            <li key={p.submissionId} className="p-4">
              <PieceRow piece={p} />
            </li>
          ))}
        </ul>
      ) : (
        <Notice tone="info">Aucune pièce n&apos;est attendue pour ce financement.</Notice>
      )}
      <div className="flex flex-wrap items-center gap-4">
        <Button asChild size="lg">
          <Link href="/formation-ia/inscription?etape=5">{todo.length ? "Déposer plus tard et continuer" : "Continuer"}</Link>
        </Button>
        <Button asChild variant="ghost" size="lg">
          <Link href="/formation-ia/inscription?etape=3">Retour</Link>
        </Button>
      </div>
    </div>
  );
}

function PieceRow({ piece }: { piece: SerializedDossier["pieces"][number] }) {
  const [state, action, pending] = useActionState<ActionState, FormData>(iaPieceUploadAction, {});
  const id = `file-${piece.submissionId}`;
  const canUpload = piece.status === "attendue" || piece.status === "refusee" || piece.status === "deposee";
  return (
    <div className="flex flex-col gap-3">
      <div className="min-w-0">
        <p className="flex flex-wrap items-center gap-2">
          <span className="font-medium text-ink">{piece.label}</span>
          <StatusBadge status={piece.status} />
          {!piece.isRequired ? <span className="text-[12px] text-ink-3">facultative</span> : null}
        </p>
        {piece.description ? <p className="mt-1 text-[12.5px] text-ink-3">{piece.description}</p> : null}
        {piece.providedBy !== "apprenant" ? <p className="mt-1 text-[12px] text-ink-3">Attendue de {piece.providedBy === "entreprise" ? "votre employeur" : "votre financeur"} : déposez-la si vous la détenez déjà.</p> : null}
        {piece.status === "refusee" && piece.refusalReason ? <p className="mt-1 text-[12.5px] text-danger-ink">Motif du refus : {piece.refusalReason}</p> : null}
        {piece.fileName ? <p className="num mt-1 text-[12px] text-ink-3">Déposé : {piece.fileName}</p> : null}
        {state.ok && state.message ? <p className="mt-1 text-[12.5px] text-ok-ink">{state.message}</p> : null}
        {state.error ? (
          <p className="mt-1 text-[12.5px] text-danger-ink" role="alert">
            {state.error}
          </p>
        ) : null}
      </div>
      {canUpload ? (
        <form action={action} className="flex flex-wrap items-end gap-3">
          <input type="hidden" name="submissionId" value={piece.submissionId} />
          <Field label="Fichier" htmlFor={id} help={ALLOWED_LABEL} className="min-w-[260px] flex-1">
            <Input id={id} name="file" type="file" accept={ACCEPT_ATTR} className="h-auto py-2 file:mr-3 file:border-0 file:bg-transparent file:font-mono file:text-[10px] file:uppercase file:tracking-[0.18em] file:text-ink" />
          </Field>
          <Button type="submit" variant="secondary" size="md" loading={pending}>
            {piece.status === "deposee" ? "Remplacer" : "Déposer"}
          </Button>
        </form>
      ) : (
        <span className="text-[12.5px] text-ink-3">Rien à faire</span>
      )}
    </div>
  );
}

/* ---------- Étape 5 : récapitulatif et contrat ---------- */

export function StepContract({ dossier, mailOn, finished = false }: { dossier: SerializedDossier; mailOn: boolean; finished?: boolean }) {
  const c = dossier.contract;
  const isCpf = dossier.funding === "cpf";
  return (
    <div className="space-y-6">
      {!finished ? (
        <div>
          <p className="etiquette">Étape 5 sur 5</p>
          <h2 className="mt-3 text-[26px]">Récapitulatif et contrat</h2>
        </div>
      ) : null}
      <dl className="grid grid-cols-[max-content_1fr] gap-x-6 gap-y-2.5 border border-line p-5 text-[13.5px]">
        <Row k="Dossier" v={<span className="num">{dossier.reference}</span>} />
        <Row k="Stagiaire" v={`${dossier.person.fullName}, ${dossier.person.email}`} />
        <Row k="Adresse" v={dossier.person.address || "-"} />
        <Row k="Offre" v={dossier.offer ? `${dossier.offer.title}, ${dossier.offer.hours} h` : "-"} />
        <Row k="Prix TTC" v={<span className="num">{dossier.offer ? formatCents(dossier.offer.priceCents) : "-"}</span>} />
        <Row k="Financement" v={dossier.fundingLabel} />
        {dossier.company ? <Row k="Employeur" v={`${dossier.company.name}${dossier.company.siret ? ` (SIRET ${dossier.company.siret})` : ""}`} /> : null}
        <Row k="Pièces" v={dossier.pieces.length ? dossier.pieces.map((p) => `${p.label} : ${p.status === "attendue" ? "attendue" : p.status === "deposee" ? "déposée" : p.status === "acceptee" ? "acceptée" : p.status === "refusee" ? "refusée" : "non applicable"}`).join(" · ") : "aucune"} />
      </dl>

      {isCpf ? (
        <>
          <Notice tone="warn" title="Pré-réservation CPF enregistrée">
            Certification en cours d&apos;enregistrement au Répertoire spécifique (France Compétences) : financement CPF bientôt disponible. L&apos;organisme vous recontacte dès l&apos;enregistrement ; aucun accès n&apos;est ouvert d&apos;ici là. Vous retrouvez ce dossier dans votre espace apprenant.
          </Notice>
          {!finished ? (
            <div className="flex flex-wrap gap-3">
              <Button asChild size="lg">
                <Link href="/moi/formation-ia">Ouvrir mon espace apprenant</Link>
              </Button>
              <Button asChild variant="ghost" size="lg">
                <Link href="/formation-ia/inscription?etape=4">Retour</Link>
              </Button>
            </div>
          ) : null}
        </>
      ) : c ? (
        <div className="space-y-4 border border-line p-5">
          <p className="flex flex-wrap items-center gap-2">
            <span className="font-medium text-ink">{c.title}</span>
            <StatusBadge status={c.status} />
          </p>
          {c.signed ? (
            <Notice tone="ok" title="Signé par toutes les parties">
              {dossier.accessOpen ? "Votre accès e-learning est ouvert." : dossier.blockers.join(" ")}
            </Notice>
          ) : c.requestStatus === "envoyee" || c.requestStatus === "signee_partiellement" ? (
            <>
              <ul className="flex flex-wrap gap-3 text-[12.5px]">
                {c.signers.map((s) => (
                  <li key={s.email} className="flex items-center gap-2">
                    <span>{s.name}</span>
                    <StatusBadge status={s.signedAt ? "signe" : "attendue"} />
                  </li>
                ))}
              </ul>
              {c.canSignNow ? (
                <ActionForm action={iaSignNowAction} submitLabel="Signer maintenant" submitVariant="primary" submitSize="lg" hideResult={false}>
                  <p className="mb-3 text-[13px] text-ink-2">Lecture du document, code de confirmation reçu par e-mail{mailOn ? "" : " (affiché à l'écran sur cette installation, e-mail non configuré)"}, signature manuscrite et consentement.</p>
                </ActionForm>
              ) : (
                <p className="text-[13px] text-ink-2">{dossier.nextAction}</p>
              )}
            </>
          ) : c.requestStatus === "non_configure" ? (
            <Notice tone="warn" title="Signature électronique non configurée">
              La demande est enregistrée ; l&apos;organisme vous transmettra le document à signer dès que le prestataire sera configuré.
            </Notice>
          ) : (
            <Notice tone="info" title="Contrat en préparation">
              {c.missing.length ? `Informations à compléter par l'organisme avant signature : ${c.missing.join(", ")}.` : "L'organisme vous enverra le lien de signature."}
            </Notice>
          )}
        </div>
      ) : (
        <ContractForm funding={dossier.funding} />
      )}
    </div>
  );
}

function Row({ k, v }: { k: string; v: React.ReactNode }) {
  return (
    <>
      <dt className="pt-0.5 font-mono text-[10px] uppercase tracking-[0.16em] text-ink-3">{k}</dt>
      <dd className="min-w-0 text-ink">{v}</dd>
    </>
  );
}

function ContractForm({ funding }: { funding: string | null }) {
  const [state, action, pending] = useActionState<ActionState, FormData>(iaContractAction, {});
  const convention = funding === "entreprise" || funding === "opco";
  const links = state.data?.links?.split("\n").filter(Boolean) ?? [];
  if (state.ok) {
    return (
      <Notice tone={links.length ? "warn" : "ok"} title={state.message}>
        {links.length ? (
          <div className="mt-2 space-y-2">
            <p className="text-[12.5px]">E-mail non configuré sur cette installation : liens de signature à transmettre.</p>
            {links.map((l) => {
              const url = l.slice(l.indexOf(" : ") + 3);
              return (
                <div key={l}>
                  <p className="text-[12.5px] font-medium">{l.slice(0, l.indexOf(" : "))}</p>
                  <LinkToCopy value={url} />
                </div>
              );
            })}
          </div>
        ) : null}
        <p className="mt-3">
          <Link href="/formation-ia/inscription?etape=5" className="font-medium underline underline-offset-4">
            Afficher l&apos;état de la signature
          </Link>
        </p>
      </Notice>
    );
  }
  return (
    <form action={action} className="space-y-4 border border-line p-5" noValidate>
      <p className="font-medium text-ink">{convention ? "Convention de formation professionnelle" : "Contrat de formation professionnelle"}</p>
      <p className="text-[13px] text-ink-2">
        {convention
          ? "Établie entre l'organisme et votre employeur à partir du modèle de l'organisme ; envoyée pour signature électronique au signataire de l'entreprise. Toute information manquante est complétée par l'organisme avant signature, jamais inventée."
          : "Établi à partir du modèle de l'organisme, avec délai de rétractation de 14 jours ; vous le signez électroniquement (code de confirmation, signature manuscrite, consentement). Toute information manquante est complétée par l'organisme avant signature, jamais inventée."}
      </p>
      <div>
        <Checkbox name="accept" label={<span className="text-[13px]">J&apos;ai lu le récapitulatif, le programme et les conditions de financement ; je demande l&apos;établissement du document.</span>} />
        {state.error && state.data?.field === "accept" ? (
          <p className="mt-1.5 text-[12.5px] text-danger-ink" role="alert">
            {state.error}
          </p>
        ) : null}
      </div>
      {state.error && state.data?.field !== "accept" ? <Notice tone="danger">{state.error}</Notice> : null}
      <div className="flex flex-wrap items-center gap-4">
        <Button type="submit" size="lg" loading={pending}>
          {convention ? "Générer la convention" : "Générer mon contrat"}
        </Button>
        <Button asChild variant="ghost" size="lg">
          <Link href="/formation-ia/inscription?etape=4">Retour</Link>
        </Button>
      </div>
    </form>
  );
}
