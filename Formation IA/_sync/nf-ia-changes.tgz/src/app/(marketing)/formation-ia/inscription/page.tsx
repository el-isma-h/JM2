import type { Metadata } from "next";
import Link from "next/link";
import { PageHero } from "@/components/marketing/site";
import { Notice } from "@/components/ui/surface";
import { Button } from "@/components/ui/button";
import { emailAccessOk, integrations } from "@/lib/env";
import { pageMeta } from "@/lib/seo";
import { getCurrentUser } from "@/server/auth";
import { IA_OFFERS } from "@/server/ia/catalog";
import { loadIaFlow, isIaOffer, IA_FUNDINGS, IA_FUNDING_META, IA_PUBLIC_TEXTS, iaExpectedPieces } from "@/server/ia/enrollment";
import { StepContract, StepFunding, StepIdentity, StepOffer, StepPieces, Stepper, type SerializedDossier, type StepId } from "./steps";

export const metadata: Metadata = pageMeta("/formation-ia/inscription", "Inscription à la Formation IA", "Créez votre compte et votre dossier d'inscription à la Formation IA en cinq étapes : identité, offre, financement, pièces, contrat.");
export const dynamic = "force-dynamic";

const STEPS: { id: StepId; label: string }[] = [
  { id: 1, label: "Identité et compte" },
  { id: 2, label: "Offre" },
  { id: 3, label: "Financement" },
  { id: 4, label: "Pièces" },
  { id: 5, label: "Récapitulatif et contrat" },
];

/**
 * Parcours d'inscription public à la Formation IA. L'étape affichée est celle demandée (`?etape=`), bornée
 * par la première étape non terminée en base : on ne saute jamais une étape, on peut toujours revenir en arrière.
 */
export default async function IaInscriptionPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const user = await getCurrentUser();
  const flow = await loadIaFlow(user);
  const requested = Number(Array.isArray(sp.etape) ? sp.etape[0] : sp.etape) || null;
  const offerParam = Array.isArray(sp.offre) ? sp.offre[0] : sp.offre;
  const offerForFunding = isIaOffer(offerParam) ? offerParam : null;
  // L'offre choisie (étape 2) voyage dans l'URL jusqu'à la création de l'inscription (étape 3) : elle ouvre l'étape 3.
  const maxStep = Math.min(flow.firstIncomplete === 2 && offerForFunding ? 3 : flow.firstIncomplete >= 4 ? 5 : flow.firstIncomplete, 5) as StepId;
  const step = (requested && requested >= 1 && requested <= maxStep ? requested : maxStep) as StepId;
  const done = flow.firstIncomplete === 6;
  const mailOn = integrations.mail();

  return (
    <article>
      <PageHero crumbs={[{ label: "Accueil", href: "/" }, { label: "Formation IA", href: "/formation-ia" }, { label: "Inscription" }]} eyebrow="Inscription en ligne" title="Votre dossier Formation IA en cinq étapes." description="Identité et compte, offre, financement, pièces, puis récapitulatif et contrat. Vous pouvez reprendre à tout moment depuis votre espace apprenant." filigrane="IA" />
      <section className="conteneur grid gap-10 py-14 lg:grid-cols-[0.6fr_1.4fr] lg:gap-16 lg:py-20">
        <aside>
          <Stepper steps={STEPS} current={step} max={maxStep} done={done} />
          <p className="mt-8 text-[13px] text-ink-3">{IA_PUBLIC_TEXTS.qualiopi}</p>
          <p className="mt-2 text-[13px] text-ink-3">{IA_PUBLIC_TEXTS.cpf}</p>
          {!flow.org ? (
            <Notice tone="warn" className="mt-6" title="Organisme vendeur non amorcé">
              L&apos;organisme « Next Formation Académie » n&apos;existe pas encore sur cette installation : exécutez l&apos;amorçage NF-IA-150 (script de bootstrap) avant d&apos;ouvrir les inscriptions.
            </Notice>
          ) : null}
          {user && !emailAccessOk(user) ? (
            <Notice tone="info" className="mt-6" title="Adresse e-mail à vérifier">
              Vous pouvez poursuivre votre inscription. Votre espace apprenant s&apos;ouvrira après vérification de votre adresse :{" "}
              <Link href="/verification" className="font-medium underline underline-offset-4">
                vérifier maintenant
              </Link>
              .
            </Notice>
          ) : null}
        </aside>
        <div className="relative border border-line-strong bg-bg-elev p-6 sm:p-8">
          {done && flow.dossier ? (
            <div className="space-y-5">
              <p className="etiquette">Dossier enregistré</p>
              <h2 className="text-[26px]">Votre inscription est enregistrée.</h2>
              <p className="text-[14px] text-ink-2">
                Référence <span className="num">{flow.dossier.enrollment.reference}</span>. {flow.dossier.nextAction}
              </p>
              <StepContract dossier={serializeDossier(flow)} mailOn={mailOn} finished />
              <div className="flex flex-wrap gap-3">
                <Button asChild size="lg">
                  <Link href="/moi/formation-ia">Ouvrir mon espace apprenant</Link>
                </Button>
                <Button asChild variant="secondary" size="lg">
                  <Link href="/formation-ia">Retour à la Formation IA</Link>
                </Button>
              </div>
            </div>
          ) : step === 1 ? (
            <StepIdentity user={user ? { firstName: user.firstName, lastName: user.lastName, email: user.email } : null} person={flow.person ? { civility: flow.person.civility, phone: flow.person.phone, birthDate: flow.person.birthDate, birthPlace: flow.person.birthPlace, addressLine1: flow.person.addressLine1, postalCode: flow.person.postalCode, city: flow.person.city, situation: flow.person.situation } : null} company={flow.company ? { name: flow.company.name, siret: flow.company.siret } : null} />
          ) : step === 2 ? (
            <StepOffer offers={IA_OFFERS.map((o) => ({ code: o.code, title: o.label, priceCents: o.priceCents, hours: o.hours, entitlements: [...o.entitlements] }))} n5Hint={IA_PUBLIC_TEXTS.n5Hint} priceNote={IA_PUBLIC_TEXTS.price} />
          ) : step === 3 ? (
            offerForFunding ? (
              <StepFunding offer={{ code: offerForFunding, title: IA_OFFERS.find((o) => o.code === offerForFunding)!.label, priceCents: IA_OFFERS.find((o) => o.code === offerForFunding)!.priceCents, hours: IA_OFFERS.find((o) => o.code === offerForFunding)!.hours }} fundings={IA_FUNDINGS.map((f) => ({ code: f, label: IA_FUNDING_META[f].label, description: IA_FUNDING_META[f].description, needsCompany: IA_FUNDING_META[f].needsCompany, pieces: iaExpectedPieces(f).map((p) => p.label) }))} company={flow.company ? { name: flow.company.name, siret: flow.company.siret, addressLine1: flow.company.addressLine1, postalCode: flow.company.postalCode, city: flow.company.city } : null} />
            ) : (
              <Notice tone="info" title="Choisissez d'abord votre offre">
                <Link href="/formation-ia/inscription?etape=2" className="font-medium underline underline-offset-4">
                  Revenir au choix de l&apos;offre
                </Link>
              </Notice>
            )
          ) : step === 4 && flow.dossier ? (
            <StepPieces dossier={serializeDossier(flow)} />
          ) : step === 5 && flow.dossier ? (
            <StepContract dossier={serializeDossier(flow)} mailOn={mailOn} />
          ) : (
            <Notice tone="info">Reprenez votre inscription depuis la première étape.</Notice>
          )}
        </div>
      </section>
    </article>
  );
}

/** Données sérialisables du dossier pour les composants client (jamais d'identifiant d'un autre organisme). */
function serializeDossier(flow: Awaited<ReturnType<typeof loadIaFlow>>): SerializedDossier {
  const d = flow.dossier!;
  return {
    reference: d.enrollment.reference,
    offer: d.offer ? { code: d.offer.code, title: d.offer.label, priceCents: d.offer.priceCents, hours: d.offer.hours } : null,
    funding: d.iaFunding,
    fundingLabel: d.iaFunding ? IA_FUNDING_META[d.iaFunding].label : d.funding?.label ?? "À définir",
    person: { fullName: `${d.person.firstName} ${d.person.lastName}`, email: d.person.email ?? "", address: [d.person.addressLine1, d.person.postalCode, d.person.city].filter(Boolean).join(" ") },
    company: d.company ? { name: d.company.name, siret: d.company.siret } : null,
    pieces: d.pieces.map((p) => ({ submissionId: p.submission.id, code: p.piece.code, label: p.piece.label, description: p.piece.description, status: p.submission.status, isRequired: p.piece.isRequired, providedBy: p.piece.providedBy, refusalReason: p.submission.refusalReason, fileName: p.document?.fileName ?? null })),
    contract: d.contract ? { title: d.contract.document.title, status: d.contract.document.status, signed: d.contract.signed, missing: d.contract.missing, requestStatus: d.contract.request?.status ?? null, signers: d.contract.signers, canSignNow: Boolean(d.contract.request && d.contract.request.provider === "interne" && ["envoyee", "signee_partiellement"].includes(d.contract.request.status) && d.contract.signers.some((s) => s.email.toLowerCase() === (flow.user?.email ?? "").toLowerCase() && !s.signedAt)) } : null,
    accessOpen: d.accessOpen,
    blockers: d.blockers,
    nextAction: d.nextAction,
  };
}
