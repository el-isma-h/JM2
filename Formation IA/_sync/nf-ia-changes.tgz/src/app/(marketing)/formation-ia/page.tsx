import type { Metadata } from "next";
import { FormationIaPage } from "@/components/marketing/formation-ia";
import { formationIaJsonLd, jsonLdScript, pageMeta } from "@/lib/seo";

export const metadata: Metadata = pageMeta(
  "/formation-ia",
  "Formation IA : 4 niveaux certifiants, 150 h à distance",
  "Formation à l'intelligence artificielle 100 % à distance : Fondamentaux, Praticien IA et automatisation, Développeur IA, Expert IA et spécialisation Data engineering. 184 leçons, 525 quiz éclair, tuteur IA, examens de niveau, certificat Next Formation par niveau. Financement OPCO, entreprise, France Travail ou personnel ; 1 490 € TTC par niveau.",
);
export const dynamic = "force-dynamic";

/** Page vitrine de la Formation IA (NF-IA-150) : niveaux, pédagogie, évaluation, certificats, financements, qualité, tarifs, FAQ. */
export default function FormationIaRoute() {
  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={jsonLdScript(formationIaJsonLd())} />
      <FormationIaPage />
    </>
  );
}
