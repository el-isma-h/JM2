import Link from "next/link";
import { guardLearner } from "@/server/extranet/guard";
import { IA_FUNDING_META, iaIntegrationConfigured, learnerIaDossier } from "@/server/ia/enrollment";
import { openIaSpaceAction } from "@/server/actions/ia-inscription";
import { NoAttachment } from "@/components/extranet/shell";
import { ActionForm } from "@/components/admin/action-form";
import { StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { EmptyState, KeyValue, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { fmtDate, fmtDateTime } from "@/lib/dates";
import { formatCents } from "@/lib/money";
import { integrationLabels } from "@/lib/env";
import { enrollmentStatusLabels } from "@/server/extranet/context";

export const dynamic = "force-dynamic";

/** Détail du dossier Formation IA de l'apprenant : offre, financement, pièces, contrat, accès e-learning (SSO). */
export default async function LearnerFormationIa() {
  const ctx = await guardLearner("/moi/formation-ia");
  if (!ctx) return <NoAttachment kind="learner" />;
  const d = await learnerIaDossier(ctx);
  if (!d) {
    return (
      <>
        <PageHeader title="Ma formation IA" breadcrumb={[{ label: "Mon parcours", href: "/moi" }, { label: "Formation IA" }]} />
        <Panel>
          <EmptyState title="Aucun dossier Formation IA" description="Vous n'avez pas de dossier d'inscription à la Formation IA dans cet organisme." action={<Button asChild size="sm"><Link href="/formation-ia/inscription">S&apos;inscrire à la Formation IA</Link></Button>} />
        </Panel>
      </>
    );
  }
  const configured = iaIntegrationConfigured();
  const labels = integrationLabels as unknown as Record<string, { label: string; envVars: string[]; effect: string } | undefined>;
  const iaLabel = labels.ia ?? { label: "Connexion à l'espace e-learning (SSO)", envVars: ["IA_APP_URL", "IA_SSO_SECRET"], effect: "Le bouton « Ouvrir mon espace e-learning » reste inactif tant que ces variables ne sont pas renseignées." };
  const missingPieces = d.pieces.filter((p) => p.submission.status === "attendue" || p.submission.status === "refusee");
  const toSign = d.contract && !d.contract.signed && d.contract.request && ["envoyee", "signee_partiellement"].includes(d.contract.request.status) ? d.contract : null;
  const fundingLabel = d.iaFunding ? IA_FUNDING_META[d.iaFunding].label : d.funding?.label ?? "À définir";

  return (
    <>
      <PageHeader
        title="Ma formation IA"
        breadcrumb={[{ label: "Mon parcours", href: "/moi" }, { label: "Formation IA" }]}
        description={`Dossier ${d.enrollment.reference} : ${enrollmentStatusLabels[d.enrollment.status] ?? d.enrollment.status}. ${d.nextAction}`}
      />
      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <Panel>
            <PanelHeader title="Mon dossier" description="Offre, financement et contrat tels qu'enregistrés par l'organisme." />
            <div className="grid gap-6 p-6 md:grid-cols-2">
              <KeyValue
                items={[
                  { k: "Référence", v: <span className="num">{d.enrollment.reference}</span> },
                  { k: "Offre", v: d.offer ? `${d.offer.label} (${d.offer.hours} h)` : d.enrollment.iaOffer },
                  { k: "Niveaux ouverts", v: d.entitlements.join(", ") || "-" },
                  { k: "Prix TTC", v: <span className="num">{formatCents(d.offer?.priceCents ?? d.enrollment.priceCents)}</span> },
                  { k: "Session", v: `${d.session.title} (${d.session.code})` },
                ]}
              />
              <KeyValue
                items={[
                  { k: "Inscription", v: <StatusBadge status={d.enrollment.status} /> },
                  { k: "Financement", v: <span className="flex flex-wrap items-center gap-2">{fundingLabel} <StatusBadge status={d.enrollment.fundingState} /></span> },
                  { k: "Employeur", v: d.company ? d.company.name : "Aucun (particulier)" },
                  { k: "Contrat", v: d.contract ? <span className="flex flex-wrap items-center gap-2">{d.contract.document.title} <StatusBadge status={d.contract.signed ? "signe" : d.contract.document.status} /></span> : d.iaFunding === "cpf" ? "Établi après l'enregistrement de la certification" : "Non généré" },
                  { k: "Accès e-learning", v: d.enrollment.iaAccessOpenedAt ? <span>Ouvert le <span className="num">{fmtDateTime(d.enrollment.iaAccessOpenedAt)}</span></span> : "Non ouvert" },
                ]}
              />
            </div>
          </Panel>

          {d.iaFunding === "cpf" ? (
            <Notice tone="warn" title="Pré-réservation CPF">
              Certification en cours d&apos;enregistrement au Répertoire spécifique (France Compétences) : financement CPF bientôt disponible. L&apos;organisme vous recontacte dès l&apos;enregistrement ; aucun accès n&apos;est ouvert d&apos;ici là.
            </Notice>
          ) : null}

          <Panel>
            <PanelHeader title="Pièces attendues" description="Déposez vos pièces depuis « Mes pièces à fournir » ; l'organisme les contrôle." actions={<Button asChild variant="secondary" size="sm"><Link href="/moi/pieces">Mes pièces à fournir</Link></Button>} />
            {d.pieces.length ? (
              <ul className="divide-y divide-line">
                {d.pieces.map((p) => (
                  <li key={p.submission.id} className="flex flex-wrap items-center justify-between gap-2 px-5 py-3 text-[13.5px]">
                    <span>
                      {p.piece.label}
                      {p.submission.status === "refusee" && p.submission.refusalReason ? <span className="block text-[12.5px] text-danger-ink">Motif du refus : {p.submission.refusalReason}</span> : null}
                    </span>
                    <span className="flex items-center gap-3">
                      {p.submission.dueDate ? <span className="num text-[12.5px] text-ink-3">échéance {fmtDate(p.submission.dueDate)}</span> : null}
                      <StatusBadge status={p.submission.status} />
                    </span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="px-5 py-4 text-[13px] text-ink-3">Aucune pièce attendue.</p>
            )}
          </Panel>

          <Panel>
            <PanelHeader title="Documents à signer" description="Contrat de formation ou convention : signature électronique depuis le lien reçu par e-mail (code de confirmation, signature manuscrite, consentement)." />
            {toSign ? (
              <div className="space-y-3 px-5 py-4">
                <p className="text-[13.5px] text-ink">{toSign.document.title}</p>
                <ul className="flex flex-wrap gap-3 text-[12.5px]">
                  {toSign.signers.map((s) => (
                    <li key={s.email} className="flex items-center gap-2">
                      <span>{s.name}</span>
                      <StatusBadge status={s.signedAt ? "signe" : "attendue"} />
                    </li>
                  ))}
                </ul>
                {toSign.signers.some((s) => s.email.toLowerCase() === ctx.user.email.toLowerCase() && !s.signedAt) ? (
                  <Button asChild size="sm">
                    <Link href="/formation-ia/inscription?etape=5">Signer maintenant</Link>
                  </Button>
                ) : (
                  <p className="text-[13px] text-ink-2">En attente des autres signataires.</p>
                )}
              </div>
            ) : d.contract?.signed ? (
              <p className="px-5 py-4 text-[13px] text-ink-2">
                {d.contract.document.title} : signé par toutes les parties.{" "}
                <Link href="/moi/documents" className="font-medium text-accent underline-offset-4 hover:underline">
                  Mes documents
                </Link>
              </p>
            ) : d.contract ? (
              <p className="px-5 py-4 text-[13px] text-ink-2">{d.contract.document.title} : {d.contract.missing.length ? `en préparation par l'organisme (à compléter : ${d.contract.missing.join(", ")})` : "en préparation par l'organisme"}.</p>
            ) : (
              <p className="px-5 py-4 text-[13px] text-ink-3">
                Aucun document à signer pour le moment.{" "}
                {d.iaFunding !== "cpf" ? (
                  <Link href="/formation-ia/inscription?etape=5" className="font-medium text-accent underline-offset-4 hover:underline">
                    Terminer la contractualisation
                  </Link>
                ) : null}
              </p>
            )}
          </Panel>
        </div>

        <div className="space-y-6">
          <Panel>
            <PanelHeader title="Espace e-learning" description="Connexion unique vers la plateforme de formation, avec les niveaux inclus dans votre inscription." />
            <div className="space-y-3 p-5">
              {d.enrollment.iaAccessOpenedAt ? (
                configured ? (
                  <ActionForm action={openIaSpaceAction} submitLabel="Ouvrir mon espace e-learning" submitVariant="primary" submitSize="lg" />
                ) : (
                  <Notice tone="warn" title={iaLabel.label}>
                    {iaLabel.effect} Variables : <span className="num">{iaLabel.envVars.join(", ")}</span>.
                  </Notice>
                )
              ) : (
                <>
                  <Button size="lg" disabled aria-disabled className="w-full">
                    Ouvrir mon espace e-learning
                  </Button>
                  <Notice tone="info" title="Accès non ouvert">
                    {d.blockers.length ? d.blockers.join(" ") : "L'organisme ouvre l'accès depuis votre dossier."}
                  </Notice>
                </>
              )}
              {missingPieces.length ? <p className="text-[12.5px] text-ink-3">{missingPieces.length} pièce(s) encore attendue(s) : elles n&apos;empêchent pas l&apos;accès mais sont nécessaires au dossier.</p> : null}
            </div>
          </Panel>
          <Panel>
            <PanelHeader title="Prochaine action" />
            <p className="px-5 py-4 text-[13.5px] text-ink">{d.nextAction}</p>
          </Panel>
        </div>
      </div>
    </>
  );
}
