import Link from "next/link";
import type { IaDossier } from "@/server/ia/enrollment";
import { IA_FUNDING_META, iaIntegrationConfigured } from "@/server/ia/enrollment";
import { openIaSpaceAction } from "@/server/actions/ia-inscription";
import { ActionForm } from "@/components/admin/action-form";
import { StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { KeyValue, Panel, PanelHeader } from "@/components/ui/surface";
import { enrollmentStatusLabels } from "@/server/extranet/context";

/** Carte « Ma formation IA » de l'accueil apprenant : statut du dossier, offre, financement, pièces, documents à signer, prochaine action, accès e-learning. */
export function IaLearnerCard({ d, userEmail }: { d: IaDossier; userEmail: string }) {
  const missingPieces = d.pieces.filter((p) => p.piece.isRequired && (p.submission.status === "attendue" || p.submission.status === "refusee"));
  const toSign = d.contract && !d.contract.signed && d.contract.request && ["envoyee", "signee_partiellement"].includes(d.contract.request.status) && d.contract.signers.some((s) => s.email.toLowerCase() === userEmail.toLowerCase() && !s.signedAt);
  const fundingLabel = d.iaFunding ? IA_FUNDING_META[d.iaFunding].label : d.funding?.label ?? "À définir";
  const canOpen = Boolean(d.enrollment.iaAccessOpenedAt) && iaIntegrationConfigured();
  return (
    <Panel>
      <PanelHeader
        title="Ma formation IA"
        description={`${d.offer?.label ?? d.enrollment.iaOffer} · dossier ${d.enrollment.reference}`}
        actions={
          <Button asChild variant="secondary" size="sm">
            <Link href="/moi/formation-ia">Voir le détail</Link>
          </Button>
        }
      />
      <div className="grid gap-6 p-5 md:grid-cols-[1fr_auto] md:items-start">
        <KeyValue
          items={[
            { k: "Dossier", v: <span className="flex flex-wrap items-center gap-2">{enrollmentStatusLabels[d.enrollment.status] ?? d.enrollment.status} <StatusBadge status={d.enrollment.status} /></span> },
            { k: "Financement", v: <span className="flex flex-wrap items-center gap-2">{fundingLabel} <StatusBadge status={d.enrollment.fundingState} /></span> },
            { k: "Pièces attendues", v: missingPieces.length ? <Link href="/moi/pieces" className="hover:underline">{missingPieces.map((p) => p.piece.label).join(", ")}</Link> : "Aucune" },
            { k: "À signer", v: toSign ? <Link href="/formation-ia/inscription?etape=5" className="font-medium text-accent hover:underline">{d.contract!.document.title}</Link> : d.contract?.signed ? "Contrat signé" : d.iaFunding === "cpf" ? "Après enregistrement de la certification" : d.contract ? "Contrat en préparation" : <Link href="/formation-ia/inscription?etape=5" className="font-medium text-accent hover:underline">Terminer la contractualisation</Link> },
            { k: "Prochaine action", v: d.nextAction },
          ]}
        />
        <div className="min-w-[220px]">
          {canOpen ? (
            <ActionForm action={openIaSpaceAction} submitLabel="Ouvrir mon espace e-learning" submitVariant="primary" submitSize="md" />
          ) : (
            <Button asChild variant="secondary">
              <Link href="/moi/formation-ia">{d.enrollment.iaAccessOpenedAt ? "Espace e-learning : configuration" : "Accès e-learning non ouvert"}</Link>
            </Button>
          )}
        </div>
      </div>
    </Panel>
  );
}
