"use client";

import * as React from "react";
import Link from "next/link";
import { useInView } from "motion/react";
import { ArrowRight, ArrowUpRight, Bank, BookOpen, Books, Briefcase, Buildings, Certificate, ChatCircleDots, Clock, Exam, Headset, Lightning, ListChecks, MagnifyingGlass, Robot, Scales, ShieldCheck, Timer, Trophy, User, Wheelchair } from "@phosphor-icons/react";
import { CountUp, FadeIn, Stagger, StaggerItem } from "@/components/ui/motion";
import { FORMATION_IA_FAQ, FORMATION_IA_PRIX } from "@/lib/seo";
import { BigTitle, FaqList, Reveal, btnContour, btnEncre, btnOsContour, btnPastel } from "./site";

/*
  Vitrine de la Formation IA (NF-IA-150) : section d'accueil et page /formation-ia.
  Textes issus de /home/claude/formation-ia (README v1.1, programme/programme.json, guides/guide-apprenant.md,
  referentiel/dossier-rs-france-competences.md, referentiel/correspondance-certifications.md). Rien d'inventé.
  Règles : pas de tiret cadratin, jamais « éligible CPF », jamais « certifié Qualiopi », jamais « équivalent » à une certification tierce.
*/

const CAMILLE_ACTION = "/formation-ia/camille";
const INSCRIPTION = "/formation-ia/inscription";
const CATALOGUE = "/catalogue-public/next-formation-academie";
const CPF_MENTION = "Certification en cours d'enregistrement au Répertoire spécifique (France Compétences) : financement CPF bientôt disponible.";
const DELAI_ACCES = "Sous 15 jours après validation du dossier, immédiat pour le financement personnel après signature.";

const fmtInt = (n: number) => Math.round(n).toLocaleString("fr-FR");

type Niveau = {
  id: string;
  code: string;
  num: string;
  title: string;
  hours: number;
  lessons: number;
  audience: string;
  prerequisites: string;
  certificate: string;
  couvre: string;
  prepare: string;
  modules: { id: string; title: string; hours: number }[];
  specialisation?: boolean;
};

/** Source : programme/programme.json (v1.0.0, 1er novembre 2026) et correspondance-certifications.md § 13. */
export const NIVEAUX: Niveau[] = [
  {
    id: "N1",
    code: "NF-IA-N1",
    num: "01",
    title: "Fondamentaux de l'IA",
    hours: 25,
    lessons: 31,
    audience: "Tout public : salariés, dirigeants, indépendants, demandeurs d'emploi, sans prérequis technique.",
    prerequisites: "Savoir utiliser un ordinateur et un navigateur web. Aucune compétence en programmation.",
    certificate: "Utilisateur IA certifié",
    couvre: "Anthropic Academy (fondamentaux Claude), n8n Level 1, Google AI Essentials, Microsoft AI-900 (IA générative), Elements of AI, AI Act art. 4 (alphabétisation IA)",
    prepare: "badges Claude Academy, badge OpenAI Academy « AI Foundations », Google AI Essentials, Elements of AI, Microsoft AI-901",
    modules: [
      { id: "M01", title: "Comprendre l'intelligence artificielle", hours: 3.08 },
      { id: "M02", title: "Les grands modèles de langage (LLM) expliqués", hours: 3.92 },
      { id: "M03", title: "Les outils IA du quotidien", hours: 3.67 },
      { id: "M04", title: "Prompt engineering : parler aux modèles", hours: 4.83 },
      { id: "M05", title: "L'IA au travail", hours: 2.42 },
      { id: "M06", title: "Introduction à l'automatisation et aux agents", hours: 3.08 },
      { id: "M07", title: "Éthique, droit et sécurité de l'IA", hours: 3 },
    ],
  },
  {
    id: "N2",
    code: "NF-IA-N2",
    num: "02",
    title: "Praticien IA et automatisation",
    hours: 35,
    lessons: 33,
    audience: "Professionnels voulant automatiser, déployer des assistants et faire tourner des modèles en local, sans être développeurs.",
    prerequisites: "Niveau 1 ou connaissances équivalentes.",
    certificate: "Praticien IA et automatisation",
    couvre: "n8n Level 2, Make Academy, Anthropic Academy (Claude pour les équipes, Claude Code), Microsoft AI-900, AWS Certified AI Practitioner (domaines fondamentaux)",
    prepare: "certificats n8n Foundations (N8N101 à N8N103), badges Make Academy, Google AI Professional Certificate, badges Claude Academy",
    modules: [
      { id: "M08", title: "n8n avancé : automatiser avec l'IA", hours: 6.75 },
      { id: "M09", title: "Make, Zapier et choix d'un outil d'automatisation", hours: 2.25 },
      { id: "M10", title: "LLM locaux : faire tourner l'IA sur sa machine", hours: 6.08 },
      { id: "M11", title: "RAG et bases de connaissances", hours: 4.17 },
      { id: "M12", title: "Assistants et agents sans code", hours: 4.17 },
      { id: "M13", title: "Données et analyse avec l'IA", hours: 4.25 },
      { id: "M14", title: "IA multimédia : image, vidéo, voix", hours: 3.25 },
      { id: "M15", title: "Gouvernance et déploiement de l'IA en entreprise", hours: 3.08 },
    ],
  },
  {
    id: "N3",
    code: "NF-IA-N3",
    num: "03",
    title: "Développeur IA",
    hours: 45,
    lessons: 46,
    audience: "Développeurs, intégrateurs, data analysts, étudiants en informatique.",
    prerequisites: "Bases de programmation (Python ou JavaScript/TypeScript), notions HTTP/JSON. Niveau 2 recommandé.",
    certificate: "Développeur IA",
    couvre: "Anthropic Academy (API et Claude Code), OpenAI Academy et API OpenAI, xAI Grok API, Perplexity Sonar API, Hugging Face Agents Course, DeepLearning.AI (MCP, agents), OWASP Top 10 LLM",
    prepare: "badges Claude Academy « Building with the Claude API », certifications Claude Certified Foundations (réservées au Claude Partner Network), cours Hugging Face Agents et MCP, parcours OpenAI Academy « Build with AI »",
    modules: [
      { id: "M16", title: "Fondations de développement pour l'IA", hours: 3.5 },
      { id: "M17", title: "API Anthropic : construire avec Claude", hours: 8.58 },
      { id: "M18", title: "API OpenAI", hours: 5.75 },
      { id: "M19", title: "xAI Grok, Perplexity, Mistral, Gemini et multi-fournisseur", hours: 4.83 },
      { id: "M20", title: "RAG en code", hours: 5.75 },
      { id: "M21", title: "Agents en code", hours: 5.75 },
      { id: "M22", title: "Applications IA : interface, déploiement, observabilité", hours: 4.83 },
      { id: "M23", title: "Sécurité des applications LLM", hours: 5 },
    ],
  },
  {
    id: "N4",
    code: "NF-IA-N4",
    num: "04",
    title: "Expert IA : du machine learning aux modèles de frontière",
    hours: 45,
    lessons: 40,
    audience: "Développeurs confirmés, ingénieurs, data scientists, étudiants d'écoles d'ingénieurs et de 42.",
    prerequisites: "Niveau 3 ou expérience en développement IA ; bases de mathématiques niveau bac + 1 remises à niveau dans le module 24.",
    certificate: "Expert IA",
    couvre: "MIT 6.S191 et 6.390, Stanford CS229, CS224N, CS324 et CS336, projets IA de l'École 42, Karpathy Zero to Hero, Hugging Face LLM Course, NIST AI RMF, ISO/IEC 42001, OWASP Agentic",
    prepare: "Hugging Face LLM Course et smol course, IBM AI Engineering Professional Certificate, spécialisations DeepLearning.AI, Claude Certified Architect Professional (Claude Partner Network), Harvard CS50 AI",
    modules: [
      { id: "M24", title: "Mathématiques pour l'IA", hours: 5.25 },
      { id: "M25", title: "Machine learning (inspiré Stanford CS229 et MIT 6.390)", hours: 6.58 },
      { id: "M26", title: "Deep learning (inspiré MIT 6.S191)", hours: 7.58 },
      { id: "M27", title: "Transformers et LLM from scratch (inspiré CS224N, CS336, CS25)", hours: 7.42 },
      { id: "M28", title: "Fine-tuning et adaptation de modèles", hours: 6.5 },
      { id: "M29", title: "Inférence, déploiement et MLOps", hours: 5.33 },
      { id: "M30", title: "Sécurité avancée, alignement et frontière de la recherche", hours: 5.33 },
    ],
  },
  {
    id: "N5",
    code: "NF-IA-N5",
    num: "05",
    title: "Data engineering et Big Data pour l'IA",
    hours: 30,
    lessons: 34,
    specialisation: true,
    audience: "Développeurs, data analysts et ingénieurs IA ayant validé le niveau 3 ; profils niveau 4 souhaitant industrialiser les données.",
    prerequisites: "Niveau 3 (Python, API, RAG en code) ; SQL de base ; Docker de base (rappel en M31).",
    certificate: "Data engineer IA",
    couvre: "Google Professional Data Engineer, AWS Certified Data Engineer Associate (DEA-C01), Microsoft Fabric DP-700, Databricks Data Engineer Associate, SnowPro Core, dbt Analytics Engineering, Confluent CCDAK (fondamentaux communs, sans pratique approfondie des services propriétaires)",
    prepare: "dbt Analytics Engineering Certification, Databricks Certified Data Engineer Associate, Google Professional Data Engineer, AWS DEA-C01, Microsoft DP-700, SnowPro Core, Confluent CCDAK",
    modules: [
      { id: "M31", title: "Données, formats et SQL analytique moderne", hours: 4.42 },
      { id: "M32", title: "Stockage, lakehouse et calcul distribué", hours: 4.5 },
      { id: "M33", title: "Pipelines batch : ingestion, ELT avec dbt et orchestration", hours: 4.42 },
      { id: "M34", title: "Streaming et données temps réel", hours: 3.58 },
      { id: "M35", title: "Qualité, gouvernance et observabilité des données", hours: 3.92 },
      { id: "M36", title: "Préparer les données pour l'IA : LLM, ML et RAG", hours: 4.25 },
      { id: "M37", title: "Projet final : pipeline de données de bout en bout pour un RAG d'entreprise", hours: 3.92 },
    ],
  },
];

/** Chiffres clés (README v1.1 du 5 novembre 2026). */
const CHIFFRES: { v: number; suffix?: string; l: string }[] = [
  { v: 4, l: "niveaux certifiants" },
  { v: 150, suffix: " h", l: "à distance, entrées permanentes" },
  { v: 184, l: "leçons avec la spécialisation N5" },
  { v: 525, l: "quiz éclair et 339 missions documentation" },
];

const PEDAGOGIE: { icon: React.ElementType; t: string; d: string }[] = [
  { icon: BookOpen, t: "Leçons vulgarisées", d: "Chaque leçon commence par un encadré « En clair » sans jargon, puis « Autrement dit », « Exemple à la main », « Ce que fait ce code », « Si ça ne marche pas » et « Si vous ne retenez que 3 choses »." },
  { icon: Lightning, t: "525 quiz éclair", d: "Deux à trois questions à la fin des sections importantes, corrigées et expliquées immédiatement. Ils rapportent des XP et alimentent vos révisions, sans jamais bloquer." },
  { icon: MagnifyingGlass, t: "339 missions documentation", d: "Vous ouvrez la page officielle indiquée (Anthropic, OpenAI, n8n, CNIL, Légifrance) et vous y trouvez une information précise, avec un indice. Le réflexe de la source avant celui de la rumeur." },
  { icon: ListChecks, t: "37 fiches mémo", d: "Une page par module, relue en cinq minutes, imprimable : la phrase qui résume, les sept idées à retenir, le schéma, les pièges et un auto-test de trois questions." },
  { icon: Exam, t: "5 examens blancs", d: "Alignés sur des certifications tierces publiques, pour s'entraîner dans leurs conditions, sans aucune équivalence revendiquée." },
  { icon: Books, t: "Lexique de 683 termes", d: "Définition simple, analogie, exemple dans une organisation française, termes voisins et leçons où le terme est traité. Filtrable par niveau et par catégorie." },
  { icon: Robot, t: "Tuteur IA dans chaque leçon", d: "Il réexplique autrement, donne un exemple dans votre métier ou vous pose un mini-quiz, à partir du contenu de la leçon ouverte. Il ne donne jamais les réponses des quiz ni des examens et ne remplace pas le formateur." },
  { icon: Trophy, t: "Badges et XP, sans classement", d: "Leçon terminée, quiz réussi, examen réussi, révisions espacées : chaque effort compte, votre objectif quotidien est réglable. Aucun classement entre apprenants ; les badges n'ont pas valeur de certification." },
];

const EVALUATION: { icon: React.ElementType; t: string; items: string[] }[] = [
  { icon: ListChecks, t: "Quiz de fin de module", items: ["10 questions : QCM, vrai ou faux, « trouvez l'erreur », mises en situation", "Seuil 70 %, tentatives illimitées", "Explication et source pour chaque question", "Réussir le quiz débloque le module suivant"] },
  { icon: Timer, t: "Examen de niveau", items: ["40 questions tirées dans une banque de 80, équilibrées par compétence", "60 minutes chronométrées par le serveur", "Seuil 70 %, 3 tentatives au maximum, 7 jours entre deux", "Résultat détaillé par compétence après soumission"] },
  { icon: Briefcase, t: "Épreuves pratiques", items: ["Projets, ateliers, études de cas, épreuve écrite au niveau 4", "Grille de 5 critères notés de 0 à 3 par un formateur-évaluateur", "Compétence validée à partir de 8/15, sans critère à 0", "Une reprise possible avec retour écrit du correcteur"] },
];

const FINANCEMENTS: { icon: React.ElementType; t: string; d: string }[] = [
  { icon: Bank, t: "OPCO", d: "Prise en charge par l'opérateur de compétences de votre entreprise, sur devis et convention de formation." },
  { icon: Buildings, t: "Entreprise", d: "Plan de développement des compétences : convention, facturation et pièces gérées dans votre dossier Next Formation." },
  { icon: Briefcase, t: "France Travail", d: "Demandeurs d'emploi : dossier de financement préparé avec votre conseiller, devis et programme fournis." },
  { icon: User, t: "Financement personnel", d: "Contrat de formation à distance, droit de rétractation, accès ouvert dès la signature." },
];

const QUALIOPI: { t: string; d: string }[] = [
  { t: "Programme détaillé", d: "Objectifs par leçon et par module, compétences C1.1 à C5.6, durée de chaque leçon." },
  { t: "Prérequis et publics", d: "Annoncés par niveau, vérifiés par un test de positionnement à l'entrée." },
  { t: "Modalités et délais d'accès", d: `100 % à distance, entrées permanentes. ${DELAI_ACCES}` },
  { t: "Accessibilité", d: "Temps majoré d'un tiers aux examens, aménagement des soutenances, référent handicap à contacter avant le début de la formation." },
  { t: "Émargement à distance", d: "Temps passé par leçon (onglet visible, plafonné), dates d'ouverture et de fin, relevé d'activité journalier : preuves de réalisation FOAD." },
  { t: "Suivi et assistance", d: "Formateur-référent sous 24 h ouvrées, classe virtuelle hebdomadaire facultative par niveau, relance après 7 jours sans connexion." },
  { t: "Évaluations", d: "Quiz de module qui jalonnent, examens de niveau et épreuves pratiques qui concluent, résultats conservés par compétence." },
  { t: "Enquêtes et réclamations", d: "Satisfaction recueillie à chaud et à froid, réclamation écrite possible, recours sur une décision de certification sous 30 jours." },
];

const TARIFS: { code: string; t: string; d: string; prix: number; detail: string; primary?: boolean }[] = [
  { code: "N1 à N4", t: "Un niveau", d: "Au choix, selon votre positionnement", prix: FORMATION_IA_PRIX.niveau, detail: "25 à 45 h selon le niveau, examen et certificat inclus" },
  { code: "Parcours", t: "Parcours complet", d: "Les quatre niveaux, 150 h", prix: FORMATION_IA_PRIX.parcours, detail: "Quatre examens, quatre certificats, un seul dossier", primary: true },
  { code: "N5", t: "Spécialisation", d: "Data engineering et Big Data pour l'IA", prix: FORMATION_IA_PRIX.n5, detail: "30 h après le niveau 3, environnement de TP local gratuit" },
];

const fmtPrix = (n: number) => `${n.toLocaleString("fr-FR")} €`;

/** Nombre animé quand il entre dans la fenêtre (CountUp seul compte dès le montage). */
function Chiffre({ value, suffix = "", className }: { value: number; suffix?: string; className?: string }) {
  const ref = React.useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-40px" });
  return (
    <span ref={ref} className={className}>
      {inView ? <CountUp value={value} format={(n) => `${fmtInt(n)}${suffix}`} /> : <span className="num opacity-0">{`${fmtInt(value)}${suffix}`}</span>}
    </span>
  );
}

/** Bouton de démonstration : formulaire POST vers /formation-ia/camille (chantier B1), sans mot de passe. */
export function BoutonCamille({ className, children }: { className: string; children?: React.ReactNode }) {
  return (
    <form method="post" action={CAMILLE_ACTION} className="contents">
      <button type="submit" className={className}>
        {children ?? "Tester en tant que Camille"}
      </button>
    </form>
  );
}

/* ---------------------------------------------------------------------------------------------- */
/* Section de la page d'accueil, insérée juste sous le hero                                        */
/* ---------------------------------------------------------------------------------------------- */

const POINTS_ACCUEIL: { icon: React.ElementType; t: string }[] = [
  { icon: Certificate, t: "Un certificat Next Formation par niveau, vérifiable en ligne" },
  { icon: Clock, t: "150 h à distance, entrées permanentes, à votre rythme" },
  { icon: BookOpen, t: "184 leçons avec la spécialisation N5, 525 quiz éclair, 339 missions documentation" },
  { icon: Robot, t: "Tuteur IA dans chaque leçon, formateur-référent sous 24 h ouvrées" },
  { icon: Bank, t: "Financements OPCO, entreprise, France Travail ou personnel" },
  { icon: ShieldCheck, t: "Conçue selon le référentiel national qualité (Qualiopi)" },
];

export function FormationIaAccueil() {
  return (
    <section id="formation-ia" aria-labelledby="formation-ia-titre" className="relative scroll-mt-14 overflow-hidden border-b border-[#0a0b0d]/15 bg-[#c9b8f0] text-[#0a0b0d]">
      <span className="filigrane absolute -top-8 end-0 hidden text-[26vw] md:block" aria-hidden="true">
        IA
      </span>
      <div className="conteneur relative grid gap-12 py-20 lg:grid-cols-[1.1fr_0.9fr] lg:items-center sm:py-28">
        <div>
          <Reveal>
            <p className="etiquette !text-[#0a0b0d]/70">Nouveau : formation certifiante</p>
          </Reveal>
          <div className="mt-8">
            <BigTitle lines={["Formation IA.", "Quatre niveaux", "certifiants."]} className="text-[12vw] sm:text-[8vw] lg:text-[64px] xl:text-[76px]" />
          </div>
          <Reveal delay={0.12}>
            <p className="mt-8 max-w-xl text-[15.5px] leading-relaxed text-[#0a0b0d]/75 sm:text-[17px]">
              De zéro à expert, 100 % à distance : Fondamentaux, Praticien IA et automatisation, Développeur IA, Expert IA, plus une spécialisation Data engineering et Big Data. Quiz, missions, projets évalués et un certificat Next Formation à chaque niveau.
            </p>
          </Reveal>
          <Reveal delay={0.16}>
            <Stagger className="mt-8 grid gap-x-8 gap-y-3 sm:grid-cols-2">
              {POINTS_ACCUEIL.map((p) => (
                <StaggerItem key={p.t} className="flex items-start gap-3 text-[13.5px] leading-snug">
                  <p.icon size={18} weight="regular" className="mt-0.5 shrink-0 text-[#4b2a7f]" aria-hidden="true" />
                  <span>{p.t}</span>
                </StaggerItem>
              ))}
            </Stagger>
          </Reveal>
          <Reveal delay={0.22} className="mt-10 flex flex-wrap items-center gap-3">
            <Link href="/formation-ia" className="inline-flex min-h-[46px] items-center gap-2 border border-[#0a0b0d] bg-[#0a0b0d] px-6 font-mono text-[11px] font-medium uppercase tracking-[0.18em] text-[#f3f0e8] transition-colors duration-300 hover:bg-[#f3f0e8] hover:text-[#0a0b0d] active:scale-[0.985]">
              Découvrir la formation <ArrowRight size={14} />
            </Link>
            <BoutonCamille className="inline-flex min-h-[46px] items-center gap-2 border border-[#0a0b0d]/40 px-6 font-mono text-[11px] uppercase tracking-[0.18em] text-[#0a0b0d] transition-colors duration-300 hover:border-[#0a0b0d] hover:bg-[#0a0b0d] hover:text-[#f3f0e8] active:scale-[0.985]" />
            <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-[#0a0b0d]/55">Démo sans mot de passe, apprenante fictive</span>
          </Reveal>
          <Reveal delay={0.26}>
            <p className="mt-6 max-w-xl text-[12.5px] leading-relaxed text-[#0a0b0d]/65">{CPF_MENTION}</p>
          </Reveal>
        </div>

        <Reveal delay={0.2} className="relative border border-[#0a0b0d]/25 bg-[#0a0b0d] p-6 text-[#f3f0e8] sm:p-8">
          <p className="etiquette !text-[#f3f0e8]/55">Le parcours, niveau par niveau</p>
          <ol className="mt-5 flex flex-col">
            {NIVEAUX.map((n) => (
              <li key={n.id} className="grid grid-cols-[2.5rem_1fr_auto] items-baseline gap-3 border-b border-[#f3f0e8]/10 py-3 last:border-b-0">
                <span className="num font-mono text-[10.5px] text-[#c9b8f0]">{n.id}</span>
                <span className="font-display text-[14px] font-medium uppercase tracking-[0.04em] leading-tight">
                  {n.title}
                  {n.specialisation ? <span className="ms-2 font-mono text-[9px] font-normal normal-case tracking-[0.16em] text-[#f3f0e8]/50">Spécialisation</span> : null}
                </span>
                <span className="num font-mono text-[11px] text-[#f3f0e8]/70">{n.hours} h</span>
              </li>
            ))}
          </ol>
          <div className="mt-6 grid grid-cols-2 gap-px border border-[#f3f0e8]/15 bg-[#f3f0e8]/15">
            {CHIFFRES.map((c) => (
              <div key={c.l} className="bg-[#0a0b0d] p-4">
                <Chiffre value={c.v} suffix={c.suffix} className="num font-display text-[30px] font-semibold tracking-tight text-[#c9b8f0]" />
                <p className="mt-1 font-mono text-[9.5px] uppercase leading-relaxed tracking-[0.16em] text-[#f3f0e8]/50">{c.l}</p>
              </div>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}

/* ---------------------------------------------------------------------------------------------- */
/* Page /formation-ia                                                                              */
/* ---------------------------------------------------------------------------------------------- */

const MENTIONS_HERO: [string, string][] = [
  ["Durée", "150 h (N1 à N4), + 30 h (N5)"],
  ["Modalité", "100 % à distance, entrées permanentes"],
  ["Délai d'accès", "Sous 15 jours après validation du dossier"],
  ["Accessibilité", "Temps majoré, référent handicap"],
];

export function FormationIaPage() {
  return (
    <article>
      {/* HERO */}
      <section className="sombre relative overflow-hidden bg-[#0a0b0d] text-[#f3f0e8]">
        <span className="filigrane absolute -top-10 end-2 hidden text-[22vw] text-[#f3f0e8] md:block" aria-hidden="true">
          150
        </span>
        <div className="conteneur relative py-16 lg:py-24">
          <nav className="flex flex-wrap gap-2 font-mono text-[10px] uppercase tracking-[0.2em] text-[#f3f0e8]/50" aria-label="Fil d'Ariane">
            <Link href="/" className="transition-colors hover:text-[#f3f0e8]">
              Accueil
            </Link>
            <span aria-hidden="true">/</span>
            <span className="text-[#f3f0e8]">Formation IA</span>
          </nav>
          <FadeIn>
            <p className="etiquette mt-10">Formation IA · NF-IA-150 · 100 % à distance</p>
          </FadeIn>
          <div className="mt-8">
            <BigTitle as="h1" lines={["De zéro à expert.", "Quatre niveaux certifiants."]} className="text-[12vw] sm:text-[8.5vw] lg:text-[6vw] xl:text-[92px] [&>span:last-child]:text-[#c9b8f0]" />
          </div>
          <div className="mt-10 grid gap-10 lg:grid-cols-[1.1fr_0.9fr] lg:items-end">
            <div>
              <FadeIn delay={0.15}>
                <p className="max-w-2xl text-[15.5px] leading-relaxed text-[#f3f0e8]/70 sm:text-[17px]">
                  150 heures en quatre niveaux, de l&apos;utilisateur au concepteur de modèles, plus une spécialisation Data engineering et Big Data de 30 heures. Chaque niveau se termine par un examen et des épreuves pratiques, et donne lieu à un certificat Next Formation vérifiable en ligne. Un tuteur IA dans chaque leçon, un formateur-référent qui répond sous 24 h ouvrées.
                </p>
              </FadeIn>
              <FadeIn delay={0.22} className="mt-8 flex flex-wrap items-center gap-3">
                <Link href={INSCRIPTION} className={btnPastel}>
                  Créer mon compte et m&apos;inscrire <ArrowRight size={14} />
                </Link>
                <BoutonCamille className={btnContour} />
                <Link href={CATALOGUE} className="lien-nav inline-flex min-h-[46px] items-center gap-1 !text-[11px]">
                  Voir la fiche catalogue <ArrowUpRight size={12} />
                </Link>
              </FadeIn>
              <FadeIn delay={0.28}>
                <p className="mt-6 max-w-2xl text-[12.5px] leading-relaxed text-[#f3f0e8]/55">{CPF_MENTION} Financements disponibles dès aujourd&apos;hui : OPCO, entreprise, France Travail, personnel.</p>
              </FadeIn>
            </div>
            <FadeIn delay={0.3}>
              <dl className="grid grid-cols-2 gap-px border border-[#f3f0e8]/15 bg-[#f3f0e8]/15">
                {MENTIONS_HERO.map(([t, d]) => (
                  <div key={t} className="bg-[#0a0b0d] p-4">
                    <dt className="font-mono text-[9.5px] uppercase tracking-[0.18em] text-[#f3f0e8]/45">{t}</dt>
                    <dd className="mt-2 text-[13px] leading-snug text-[#f3f0e8]/85">{d}</dd>
                  </div>
                ))}
              </dl>
            </FadeIn>
          </div>
        </div>
        <div className="relative border-t border-[#f3f0e8]/10">
          <div className="conteneur grid grid-cols-2 md:grid-cols-4">
            {CHIFFRES.map((c, i) => (
              <Reveal key={c.l} delay={i * 0.06} className={`py-8 pe-6 ${i > 0 ? "md:border-s md:border-[#f3f0e8]/10 md:ps-6" : ""}`}>
                <Chiffre value={c.v} suffix={c.suffix} className="num font-display text-4xl font-semibold tracking-tight sm:text-5xl" />
                <p className="mt-2 font-mono text-[10px] uppercase leading-relaxed tracking-[0.18em] text-[#f3f0e8]/45">{c.l}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* NIVEAUX */}
      <section id="niveaux" className="scroll-mt-14 border-b border-line bg-bg-sunken">
        <div className="conteneur py-24 sm:py-32">
          <div className="grid gap-10 lg:grid-cols-[0.9fr_1.1fr] lg:items-end">
            <div>
              <Reveal>
                <p className="etiquette">Les niveaux</p>
              </Reveal>
              <div className="mt-8">
                <BigTitle lines={["Un seul niveau", "ou tout le parcours."]} className="text-[10vw] sm:text-[6.6vw] lg:text-[64px]" />
              </div>
            </div>
            <Reveal delay={0.1}>
              <p className="max-w-xl text-[15px] leading-relaxed text-ink-2">
                Les modules d&apos;un niveau se suivent dans l&apos;ordre : le module suivant s&apos;ouvre quand le quiz est réussi, l&apos;examen quand tous les quiz le sont, le niveau suivant quand l&apos;examen est réussi. Vous entrez au niveau qui correspond à vos acquis, vérifiés par un test de positionnement. La spécialisation N5 s&apos;ajoute aux 150 heures et s&apos;ouvre dès que le niveau 3 est validé.
              </p>
            </Reveal>
          </div>
          <ol className="mt-16 grid gap-px border border-line-strong bg-line-strong lg:grid-cols-2">
            {NIVEAUX.map((n, i) => (
              <Reveal key={n.id} as="li" delay={i * 0.05} className={`flex flex-col bg-bg p-6 sm:p-8 ${n.specialisation ? "lg:col-span-2" : ""}`}>
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div>
                    <p className="flex items-center gap-3 font-mono text-[11px] tracking-[0.2em] text-accent">
                      <span className="num">{n.num}</span>
                      <span className="text-ink-3">{n.code}</span>
                      {n.specialisation ? <span className="border border-accent px-2 py-0.5 text-[9px] uppercase">Spécialisation, hors parcours de 150 h</span> : null}
                    </p>
                    <h3 className="mt-5 text-[22px] sm:text-[26px]">
                      Niveau {i + 1} : {n.title}
                    </h3>
                  </div>
                  <dl className="grid shrink-0 grid-cols-3 gap-px border border-line-strong bg-line-strong text-center">
                    {[
                      [`${n.hours} h`, "durée"],
                      [String(n.modules.length), "modules"],
                      [String(n.lessons), "leçons"],
                    ].map(([v, l]) => (
                      <div key={l} className="bg-bg px-4 py-2">
                        <dd className="num font-display text-[20px] font-semibold tracking-tight text-accent">{v}</dd>
                        <dt className="font-mono text-[9px] uppercase tracking-[0.16em] text-ink-3">{l}</dt>
                      </div>
                    ))}
                  </dl>
                </div>
                <div className={`mt-8 grid gap-8 ${n.specialisation ? "lg:grid-cols-[1fr_1fr]" : ""}`}>
                  <dl className="grid content-start gap-4 text-[13.5px] leading-relaxed">
                    <div>
                      <dt className="font-mono text-[9.5px] uppercase tracking-[0.18em] text-ink-3">Public</dt>
                      <dd className="mt-1 text-ink-2">{n.audience}</dd>
                    </div>
                    <div>
                      <dt className="font-mono text-[9.5px] uppercase tracking-[0.18em] text-ink-3">Prérequis</dt>
                      <dd className="mt-1 text-ink-2">{n.prerequisites}</dd>
                    </div>
                    <div>
                      <dt className="font-mono text-[9.5px] uppercase tracking-[0.18em] text-ink-3">Certificat</dt>
                      <dd className="mt-1 flex items-start gap-2 text-ink">
                        <Certificate size={16} className="mt-0.5 shrink-0 text-accent" aria-hidden="true" />
                        <span>
                          Certificat Next Formation IA, niveau {i + 1} « {n.certificate} »
                        </span>
                      </dd>
                    </div>
                  </dl>
                  <div>
                    <p className="font-mono text-[9.5px] uppercase tracking-[0.18em] text-ink-3">Modules</p>
                    <ul className="mt-2 border-t border-line">
                      {n.modules.map((m) => (
                        <li key={m.id} className="grid grid-cols-[2.6rem_1fr_auto] items-baseline gap-3 border-b border-line py-2 text-[13px]">
                          <span className="num font-mono text-[10.5px] text-accent">{m.id}</span>
                          <span className="leading-snug text-ink">{m.title}</span>
                          <span className="num font-mono text-[10.5px] text-ink-3">{m.hours.toLocaleString("fr-FR", { maximumFractionDigits: 1 })} h</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </Reveal>
            ))}
          </ol>
          <Reveal className="mt-10 flex flex-wrap items-center gap-3">
            <Link href={INSCRIPTION} className={btnEncre}>
              Créer mon compte et m&apos;inscrire <ArrowRight size={14} />
            </Link>
            <Link href={CATALOGUE} className={btnOsContour}>
              Voir la fiche catalogue
            </Link>
          </Reveal>
        </div>
      </section>

      {/* PÉDAGOGIE */}
      <section id="pedagogie" className="sombre relative scroll-mt-14 overflow-hidden bg-[#0a0b0d] text-[#f3f0e8]">
        <span className="filigrane absolute -top-6 end-2 text-[40vw] sm:text-[22vw]" aria-hidden="true">
          525
        </span>
        <div className="conteneur relative py-24 sm:py-32">
          <Reveal className="flex flex-wrap items-end justify-between gap-6">
            <div>
              <p className="etiquette">La pédagogie</p>
              <h2 className="mt-5 max-w-3xl text-[32px] sm:text-[52px]">Comprendre d&apos;abord, pratiquer à chaque leçon, réviser dans le temps.</h2>
            </div>
            <p className="max-w-md text-sm leading-relaxed text-[#f3f0e8]/60">Chaque leçon annonce ce que vous saurez faire, l&apos;explique sans jargon, le fait pratiquer et renvoie à la documentation officielle. Les révisions espacées reprennent ce que vous avez terminé, par boîtes de Leitner.</p>
          </Reveal>
          <div className="mt-14 grid border-s border-t border-[#f3f0e8]/15 sm:grid-cols-2 lg:grid-cols-4">
            {PEDAGOGIE.map((p, i) => (
              <Reveal key={p.t} delay={i * 0.03} className="group flex flex-col border-b border-e border-[#f3f0e8]/15 p-6 transition-colors duration-300 hover:bg-[#f3f0e8] hover:text-[#0a0b0d]">
                <p.icon size={22} className="text-[#c9b8f0] group-hover:text-[#4b2a7f]" aria-hidden="true" />
                <h3 className="mt-6 text-[19px] leading-[1.05]">{p.t}</h3>
                <p className="mt-3 flex-1 text-[13px] leading-relaxed text-[#f3f0e8]/60 group-hover:text-[#0a0b0d]/70">{p.d}</p>
              </Reveal>
            ))}
          </div>
          <Reveal delay={0.1} className="mt-10 grid gap-6 border border-[#f3f0e8]/15 p-6 md:grid-cols-[auto_1fr] md:items-center">
            <Headset size={28} className="text-[#c9b8f0]" aria-hidden="true" />
            <p className="text-[14px] leading-relaxed text-[#f3f0e8]/75">
              <span className="text-[#f3f0e8]">Vous n&apos;êtes pas seul à distance.</span> Un formateur-référent répond sous 24 h ouvrées à toute question pédagogique, une classe virtuelle de 60 minutes par semaine et par niveau est proposée (facultative), et un support technique traite les questions de connexion, de certificat ou de clé API. Sans connexion pendant 7 jours, votre formateur vous contacte pour faire le point.
            </p>
          </Reveal>
        </div>
      </section>

      {/* ÉVALUATION */}
      <section id="evaluation" className="scroll-mt-14 border-b border-line bg-bg">
        <div className="conteneur py-24 sm:py-32">
          <div className="grid gap-10 lg:grid-cols-[0.9fr_1.1fr] lg:items-end">
            <div>
              <Reveal>
                <p className="etiquette">L&apos;évaluation</p>
              </Reveal>
              <div className="mt-8">
                <BigTitle lines={["Trois épreuves,", "aucune compensation."]} className="text-[10vw] sm:text-[6.6vw] lg:text-[60px]" />
              </div>
            </div>
            <Reveal delay={0.1}>
              <p className="max-w-xl text-[15px] leading-relaxed text-ink-2">
                Le certificat d&apos;un niveau est délivré quand toutes ses compétences sont validées : examen réussi et épreuves pratiques validées. Une excellente note sur un projet ne rattrape pas une compétence non atteinte. Une compétence non validée peut être repassée dans un délai de 6 mois.
              </p>
            </Reveal>
          </div>
          <ul className="mt-14 grid gap-px border border-line-strong bg-line-strong md:grid-cols-3">
            {EVALUATION.map((e, i) => (
              <Reveal key={e.t} as="li" delay={i * 0.05} className="bg-bg p-6 sm:p-8">
                <e.icon size={22} className="text-accent" aria-hidden="true" />
                <h3 className="mt-6 text-[20px]">{e.t}</h3>
                <ul className="mt-5 flex flex-col gap-2.5 text-[13.5px] leading-snug text-ink-2">
                  {e.items.map((it) => (
                    <li key={it} className="flex gap-3">
                      <span className="mt-[0.5em] h-1.5 w-1.5 shrink-0 bg-accent" aria-hidden="true" />
                      <span>{it}</span>
                    </li>
                  ))}
                </ul>
              </Reveal>
            ))}
          </ul>
          <Reveal delay={0.1} className="mt-8 grid gap-6 border border-line-strong bg-bg-sunken p-6 md:grid-cols-[auto_1fr] md:items-center">
            <ShieldCheck size={28} className="text-accent" aria-hidden="true" />
            <p className="text-[14px] leading-relaxed text-ink-2">
              Pendant l&apos;examen, questions et réponses sont mélangées, les bonnes réponses ne sont jamais envoyées à votre navigateur avant la soumission, et le chronomètre est tenu par le serveur. L&apos;identité est vérifiée et l&apos;épreuve surveillée à distance. Chaque leçon de projet précise ce qui est autorisé avec l&apos;IA et ce qui doit rester votre travail.
            </p>
          </Reveal>
        </div>
      </section>

      {/* CERTIFICATS */}
      <section id="certificats" className="scroll-mt-14 border-b border-line bg-bg-sunken">
        <div className="conteneur py-24 sm:py-32">
          <Reveal className="flex flex-wrap items-end justify-between gap-6">
            <div>
              <p className="etiquette">Les certificats</p>
              <h2 className="mt-5 max-w-3xl text-[32px] sm:text-[48px]">Un certificat Next Formation par niveau, vérifiable par tout employeur.</h2>
            </div>
            <p className="max-w-md text-sm leading-relaxed text-ink-2">PDF téléchargeable, numéro unique, QR code et page publique de vérification. Vous recevez aussi un certificat de réalisation (heures et résultats) et une attestation de fin de formation, distincts du certificat de niveau.</p>
          </Reveal>
          <ul className="mt-14 grid gap-px border border-line-strong bg-line-strong md:grid-cols-2 xl:grid-cols-5">
            {NIVEAUX.map((n, i) => (
              <Reveal key={n.id} as="li" delay={i * 0.04} className="flex flex-col bg-bg p-6">
                <span className="num font-mono text-[11px] tracking-[0.2em] text-accent">{n.id}</span>
                <h3 className="mt-5 text-[18px] leading-[1.05]">« {n.certificate} »</h3>
                <p className="mt-4 text-[12.5px] leading-relaxed text-ink-2">
                  <span className="text-ink">Couvre les référentiels publics de</span> {n.couvre}.
                </p>
                <p className="mt-3 text-[12.5px] leading-relaxed text-ink-2">
                  <span className="text-ink">Prépare à</span> {n.prepare}.
                </p>
              </Reveal>
            ))}
          </ul>
          <Reveal delay={0.1} className="mt-8 grid gap-6 border border-line-strong bg-bg p-6 md:grid-cols-[auto_1fr] md:items-center">
            <Scales size={28} className="text-accent" aria-hidden="true" />
            <p className="text-[13.5px] leading-relaxed text-ink-2">
              Les certificats Next Formation sont des certificats d&apos;organisme. Ils ne sont ni reconnus, ni délivrés, ni validés par Anthropic, OpenAI, n8n, Make, Microsoft, Google, AWS, Hugging Face, les universités citées ni les éditeurs de données ; ils ne valent pas équivalence de leurs certifications. La formation couvre leurs référentiels publics et vous incite à passer ces certifications en complément, à vos frais et selon leurs propres règles. {CPF_MENTION}
            </p>
          </Reveal>
        </div>
      </section>

      {/* FINANCEMENTS */}
      <section id="financements" className="scroll-mt-14 border-b border-line bg-bg">
        <div className="conteneur py-24 sm:py-32">
          <div className="grid gap-10 lg:grid-cols-[0.9fr_1.1fr] lg:items-end">
            <div>
              <Reveal>
                <p className="etiquette">Les financements</p>
              </Reveal>
              <div className="mt-8">
                <BigTitle lines={["Quatre voies", "ouvertes aujourd'hui."]} className="text-[10vw] sm:text-[6.6vw] lg:text-[60px]" />
              </div>
            </div>
            <Reveal delay={0.1}>
              <p className="max-w-xl text-[15px] leading-relaxed text-ink-2">
                Le dossier d&apos;inscription prépare les pièces attendues par chaque financeur : devis, programme, convention ou contrat, attestations et preuves de réalisation à distance. L&apos;accès à l&apos;espace e-learning s&apos;ouvre quand la convention ou le contrat est signé.
              </p>
            </Reveal>
          </div>
          <ul className="mt-14 grid gap-px border border-line-strong bg-line-strong sm:grid-cols-2 lg:grid-cols-4">
            {FINANCEMENTS.map((f, i) => (
              <Reveal key={f.t} as="li" delay={i * 0.05} className="bg-bg p-6">
                <f.icon size={22} className="text-accent" aria-hidden="true" />
                <h3 className="mt-6 text-[19px]">{f.t}</h3>
                <p className="mt-3 text-[13px] leading-relaxed text-ink-2">{f.d}</p>
              </Reveal>
            ))}
          </ul>
          <Reveal delay={0.1} className="mt-8 grid gap-6 border border-accent bg-bg-sunken p-6 md:grid-cols-[auto_1fr] md:items-center">
            <Bank size={28} className="text-accent" aria-hidden="true" />
            <div>
              <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-accent">CPF</p>
              <p className="mt-2 text-[14px] leading-relaxed text-ink">{CPF_MENTION}</p>
              <p className="mt-2 text-[13px] leading-relaxed text-ink-2">Le prix de chaque niveau est fixé sous le plafond de prise en charge des certifications du Répertoire spécifique. Un dossier CPF ouvert aujourd&apos;hui reste « en attente d&apos;enregistrement RS » dans votre espace, sans promesse d&apos;accès, jusqu&apos;à l&apos;enregistrement.</p>
            </div>
          </Reveal>
        </div>
      </section>

      {/* QUALIOPI */}
      <section id="qualite" className="scroll-mt-14 border-b border-line bg-bg-sunken">
        <div className="conteneur grid gap-12 py-24 lg:grid-cols-[0.8fr_1.2fr] sm:py-32">
          <div>
            <Reveal>
              <p className="etiquette">Qualité</p>
            </Reveal>
            <div className="mt-8">
              <BigTitle lines={["Conçue selon le", "référentiel national", "qualité (Qualiopi)."]} className="text-[10vw] sm:text-[6.4vw] lg:text-[48px]" />
            </div>
            <Reveal delay={0.1}>
              <p className="mt-8 max-w-md text-[14.5px] leading-relaxed text-ink-2">
                L&apos;information, l&apos;inscription, les pièces, la contractualisation, le suivi, l&apos;évaluation et les preuves de la formation passent par les mécanismes qualité de Next Formation, pour les entreprises comme pour les particuliers. Les taux de satisfaction et de réussite seront publiés ici, avec leur méthode de calcul, à l&apos;issue de la première promotion.
              </p>
            </Reveal>
            <Reveal delay={0.15} className="mt-8 flex flex-col gap-3 border border-line-strong bg-bg p-5 text-[13px] leading-relaxed text-ink-2">
              <p className="flex items-start gap-3">
                <Wheelchair size={18} className="mt-0.5 shrink-0 text-accent" aria-hidden="true" />
                <span>
                  <span className="text-ink">Accessibilité et handicap.</span> Temps majoré d&apos;un tiers aux examens (80 min au lieu de 60), aménagement des soutenances, leçons en texte structuré compatibles avec les lecteurs d&apos;écran, mode sombre et respect du réglage « réduire les animations ». Contactez le référent handicap avant le début de la formation, ou au plus tard deux semaines avant un examen, via la{" "}
                  <Link href="/contact" className="text-accent underline underline-offset-4">
                    page contact
                  </Link>
                  .
                </span>
              </p>
              <p className="flex items-start gap-3">
                <ChatCircleDots size={18} className="mt-0.5 shrink-0 text-accent" aria-hidden="true" />
                <span>
                  <span className="text-ink">Méthodes mobilisées.</span> Leçons écrites avec exercice pratique, quiz éclair et missions documentation, fiches mémo, révisions espacées, labs avec tests automatiques, projets évalués, classes virtuelles hebdomadaires facultatives, tuteur IA, formateur-référent.
                </span>
              </p>
            </Reveal>
          </div>
          <Reveal delay={0.1}>
            <dl className="grid gap-px border border-line-strong bg-line-strong sm:grid-cols-2">
              {QUALIOPI.map((q) => (
                <div key={q.t} className="bg-bg p-5">
                  <dt className="font-display text-[15px] font-medium uppercase tracking-[0.04em] text-ink">{q.t}</dt>
                  <dd className="mt-2 text-[13px] leading-relaxed text-ink-2">{q.d}</dd>
                </div>
              ))}
            </dl>
          </Reveal>
        </div>
      </section>

      {/* TARIFS */}
      <section id="tarifs" className="sombre relative scroll-mt-14 overflow-hidden bg-[#0a0b0d] text-[#f3f0e8]">
        <span className="filigrane absolute -top-8 end-2 hidden text-[18vw] md:block" aria-hidden="true">
          TTC
        </span>
        <div className="conteneur relative py-24 sm:py-32">
          <Reveal className="flex flex-wrap items-end justify-between gap-6">
            <div>
              <p className="etiquette">Les tarifs</p>
              <h2 className="mt-5 max-w-3xl text-[32px] sm:text-[48px]">Un prix par niveau, un prix pour tout le parcours.</h2>
            </div>
            <p className="max-w-md text-sm leading-relaxed text-[#f3f0e8]/60">Prix TTC. Examen, épreuves pratiques, certificat, tuteur IA et accompagnement du formateur-référent inclus. Seuls les crédits d&apos;API (niveau 3) et de GPU (niveau 4) restent à votre charge, dans les ordres de grandeur indiqués dans la FAQ.</p>
          </Reveal>
          <ul className="mt-14 grid gap-px border border-[#f3f0e8]/15 bg-[#f3f0e8]/15 md:grid-cols-3">
            {TARIFS.map((t, i) => (
              <Reveal key={t.code} as="li" delay={i * 0.06} className={`flex flex-col p-6 sm:p-8 ${t.primary ? "bg-[#c9b8f0] text-[#0a0b0d]" : "bg-[#0a0b0d]"}`}>
                <span className={`font-mono text-[10.5px] uppercase tracking-[0.2em] ${t.primary ? "text-[#4b2a7f]" : "text-[#c9b8f0]"}`}>{t.code}</span>
                <h3 className="mt-6 text-[24px]">{t.t}</h3>
                <p className={`mt-1 text-[13px] ${t.primary ? "text-[#0a0b0d]/70" : "text-[#f3f0e8]/60"}`}>{t.d}</p>
                <p className="num mt-8 font-display text-[44px] font-semibold tracking-tight">{fmtPrix(t.prix)}</p>
                <p className={`mt-1 font-mono text-[9.5px] uppercase tracking-[0.18em] ${t.primary ? "text-[#0a0b0d]/60" : "text-[#f3f0e8]/45"}`}>TTC</p>
                <p className={`mt-5 flex-1 text-[13px] leading-relaxed ${t.primary ? "text-[#0a0b0d]/75" : "text-[#f3f0e8]/60"}`}>{t.detail}</p>
                <Link href={INSCRIPTION} className={`mt-8 inline-flex min-h-[44px] items-center justify-between gap-2 border px-5 font-mono text-[10.5px] uppercase tracking-[0.18em] transition-colors duration-300 ${t.primary ? "border-[#0a0b0d] bg-[#0a0b0d] text-[#f3f0e8] hover:bg-[#f3f0e8] hover:text-[#0a0b0d]" : "border-[#f3f0e8]/30 text-[#f3f0e8] hover:border-[#f3f0e8] hover:bg-[#f3f0e8] hover:text-[#0a0b0d]"}`}>
                  M&apos;inscrire <ArrowRight size={14} />
                </Link>
              </Reveal>
            ))}
          </ul>
          <Reveal delay={0.1} className="mt-8 flex flex-wrap items-center gap-x-8 gap-y-3 font-mono text-[10px] uppercase tracking-[0.18em] text-[#f3f0e8]/45">
            <span className="inline-flex items-start gap-2">
              <Clock size={14} className="mt-px shrink-0" aria-hidden="true" /> Délai d&apos;accès : {DELAI_ACCES.toLowerCase()}
            </span>
            <span className="inline-flex items-start gap-2">
              <Bank size={14} className="mt-px shrink-0" aria-hidden="true" /> OPCO, entreprise, France Travail, personnel
            </span>
          </Reveal>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="scroll-mt-14 border-b border-line bg-bg">
        <div className="conteneur grid gap-12 py-24 lg:grid-cols-[0.7fr_1.3fr] sm:py-32">
          <div>
            <Reveal>
              <p className="etiquette">Questions fréquentes</p>
            </Reveal>
            <div className="mt-8">
              <BigTitle lines={["Avant de", "vous inscrire."]} className="text-[11vw] sm:text-[7vw] lg:text-[56px]" />
            </div>
            <Reveal delay={0.1}>
              <p className="mt-8 max-w-sm text-sm leading-relaxed text-ink-2">
                Une autre question, un besoin d&apos;aménagement ou un devis pour votre entreprise ?{" "}
                <Link href="/contact" className="text-accent underline underline-offset-4">
                  Écrivez-nous
                </Link>
                , nous répondons sous un jour ouvré.
              </p>
            </Reveal>
          </div>
          <Reveal delay={0.1}>
            <FaqList items={FORMATION_IA_FAQ} />
          </Reveal>
        </div>
      </section>

      {/* APPEL FINAL */}
      <section className="relative overflow-hidden bg-[#c9b8f0] text-[#0a0b0d]">
        <span className="filigrane absolute -top-10 end-0 text-[30vw]" aria-hidden="true">
          IA
        </span>
        <div className="conteneur relative py-24 sm:py-36">
          <BigTitle lines={["Commencez par le niveau", "qui vous ressemble."]} className="text-[9vw] sm:text-[6.6vw] lg:text-[80px]" />
          <div className="mt-12 grid gap-8 md:grid-cols-[1fr_auto] md:items-end">
            <p className="max-w-xl text-base leading-relaxed sm:text-lg">Créez votre compte, choisissez votre niveau ou le parcours complet, votre financement, déposez vos pièces et signez : votre espace e-learning s&apos;ouvre dès la signature. Pour voir la plateforme avant de vous décider, entrez dans l&apos;espace de Camille, apprenante fictive.</p>
            <div className="flex flex-wrap gap-3">
              <Link href={INSCRIPTION} className="inline-flex min-h-[46px] items-center gap-2 border border-[#0a0b0d] bg-[#0a0b0d] px-6 font-mono text-[11px] uppercase tracking-[0.18em] text-[#f3f0e8] transition-colors duration-300 hover:bg-[#f3f0e8] hover:text-[#0a0b0d] active:scale-[0.985]">
                Créer mon compte et m&apos;inscrire <ArrowRight size={14} />
              </Link>
              <BoutonCamille className="inline-flex min-h-[46px] items-center gap-2 border border-[#0a0b0d]/40 px-6 font-mono text-[11px] uppercase tracking-[0.18em] text-[#0a0b0d] transition-colors duration-300 hover:border-[#0a0b0d] hover:bg-[#0a0b0d] hover:text-[#f3f0e8] active:scale-[0.985]" />
              <Link href={CATALOGUE} className="inline-flex min-h-[46px] items-center gap-2 px-2 font-mono text-[11px] uppercase tracking-[0.18em] text-[#0a0b0d]/70 transition-colors hover:text-[#0a0b0d]">
                Voir la fiche catalogue <ArrowUpRight size={12} />
              </Link>
            </div>
          </div>
        </div>
      </section>
    </article>
  );
}
