"use client";

import Link from "next/link";
import { motion, useReducedMotion } from "motion/react";
import { ArrowRight, ArrowUpRight } from "@phosphor-icons/react";
import { FAQ } from "@/lib/seo";
import { CIBLES, FAITS, FEATURES, PARCOURS, SECURITE } from "@/lib/marketing-data";
import { BigTitle, FaqList, Reveal, SiteFooter, SiteHeader, btnContour, btnEncre, btnOsContour, btnPastel } from "./site";
import { PricingGrid, type PricingPlan } from "./pricing";
import { ComparatifTable } from "./comparatif";
import { Ecran } from "./ecran";
import { FormationIaAccueil } from "./formation-ia";

export type { PricingPlan };

/*
  Page d'accueil Next Formation. Même structure que Next Ads / Next Optimisation (direction artistique Next Capital) :
  hero encre à bandes obliques, titre géant Archivo révélé ligne par ligne, bandeau de faits produit,
  sections bordées alternant os / encre, filigranes, grilles à survol inversé. Un seul accent : violet.
*/

const BANDES = ["#c9b8f0", "#d7caf5", "#e4dbf8", "#b9a3ea", "#c9b8f0"];

export function Home({ plans }: { plans: PricingPlan[] }) {
  const reduced = useReducedMotion();
  return (
    <div className="min-h-[100dvh] bg-bg text-ink">
      <SiteHeader />

      {/* HERO : structure Next Ads / Next Optimisation */}
      <section className="sombre relative overflow-hidden bg-[#0a0b0d] text-[#f3f0e8]">
        <div aria-hidden="true" className="pointer-events-none absolute inset-y-[-20%] end-[-30%] hidden w-[60%] opacity-70 lg:flex">
          {BANDES.map((c, i) => (
            <motion.div key={`${c}-${i}`} className="bande h-full flex-1" style={{ background: c, opacity: 0.07 + i * 0.03 }} initial={reduced ? false : { y: "-105%" }} animate={{ y: 0 }} transition={{ duration: 1.2, delay: 0.1 + i * 0.07, ease: [0.76, 0, 0.24, 1] }} />
          ))}
        </div>
        <div className="conteneur relative grid min-h-[calc(100svh-3.5rem)] gap-10 py-14 lg:grid-cols-[1.15fr_0.85fr] lg:py-0">
          <div className="flex flex-col justify-center">
            <Reveal>
              <p className="etiquette">Logiciel pour organismes de formation et CFA</p>
            </Reveal>
            <div className="mt-8">
              <BigTitle as="h1" lines={["Tout le métier,", "un seul dossier."]} className="text-[13vw] sm:text-[9.5vw] lg:text-[6.4vw] xl:text-[104px] [&>span:last-child]:text-[#c9b8f0]" />
            </div>
            <Reveal delay={0.18}>
              <p className="mt-10 max-w-xl text-base leading-relaxed text-[#f3f0e8]/65 sm:text-lg">
                CRM, catalogue, sessions, émargement par demi-journée, documents, financements, facturation, qualité explicable et extranets. Les règles d&apos;heures, le verrouillage et les droits par rôle sont garantis par le serveur, pas par la bonne volonté. À 90 % du prix de référence public.
              </p>
            </Reveal>
            <Reveal delay={0.26} className="mt-10 flex flex-wrap items-center gap-3">
              <Link href="/inscription" className={btnPastel}>
                Essai gratuit 15 jours <ArrowRight size={14} />
              </Link>
              <Link href="/demo" className={btnContour}>
                Explorer la démonstration
              </Link>
              <span className="ms-1 font-mono text-[10px] uppercase tracking-[0.2em] text-[#f3f0e8]/45">Sans compte, données fictives</span>
            </Reveal>
          </div>
          <div className="hidden items-center justify-center lg:flex">
            <Reveal delay={0.3} className="relative w-full max-w-[420px] border border-[#f3f0e8]/15 bg-[#121418] p-6">
              <span className="filigrane absolute -top-6 end-3 text-[160px] text-[#f3f0e8]" aria-hidden="true">
                7
              </span>
              <p className="etiquette">Sept étapes, un seul dossier</p>
              <ol className="relative mt-5 flex flex-col">
                {PARCOURS.map((a, i) => (
                  <motion.li key={a.t} initial={reduced ? false : { opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.5 + i * 0.05 }} className="grid grid-cols-[2rem_7.5rem_1fr] items-baseline gap-3 border-b border-[#f3f0e8]/10 py-2.5 last:border-b-0">
                    <span className="num font-mono text-[10.5px] text-[#c9b8f0]">{String(i + 1).padStart(2, "0")}</span>
                    <span className="font-mono text-[10.5px] uppercase tracking-[0.16em] text-[#f3f0e8]/85">{a.t}</span>
                    <span className="text-[12px] leading-snug text-[#f3f0e8]/50">{a.d}</span>
                  </motion.li>
                ))}
              </ol>
            </Reveal>
          </div>
        </div>
        <div className="relative border-t border-[#f3f0e8]/10">
          <div className="conteneur grid grid-cols-2 md:grid-cols-4">
            {FAITS.map((c, i) => (
              <Reveal key={c.l} delay={i * 0.06} className={`py-8 pe-6 ${i > 0 ? "md:border-s md:border-[#f3f0e8]/10 md:ps-6" : ""}`}>
                <p className="num font-display text-4xl font-semibold tracking-tight sm:text-5xl">{c.v}</p>
                <p className="mt-2 font-mono text-[10px] uppercase leading-relaxed tracking-[0.18em] text-[#f3f0e8]/45">{c.l}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* FORMATION IA : gros bloc juste sous le hero (contrat docs/formation-ia-integration.md) */}
      <FormationIaAccueil />

      {/* CONÇU POUR */}
      <section className="border-b border-line bg-bg">
        <div className="conteneur flex flex-col gap-4 py-8 md:flex-row md:items-center md:gap-10">
          <p className="shrink-0 font-mono text-[10px] uppercase tracking-[0.24em] text-ink-3">Conçu pour</p>
          <ul className="flex flex-wrap gap-x-8 gap-y-2">
            {CIBLES.map((c) => (
              <li key={c.slug}>
                <Link href={`/solutions/${c.slug}`} className="font-display text-[15px] font-medium uppercase tracking-[0.04em] text-ink transition-colors hover:text-accent">
                  {c.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* PARCOURS : tout le métier, un seul dossier */}
      <section id="parcours" className="scroll-mt-14 border-b border-line bg-bg-sunken">
        <div className="conteneur py-24 sm:py-32">
          <div className="grid gap-10 lg:grid-cols-[0.9fr_1.1fr] lg:items-end">
            <div>
              <Reveal>
                <p className="etiquette">Le parcours</p>
              </Reveal>
              <div className="mt-8">
                <BigTitle lines={["Du premier contact", "à la preuve qualité."]} className="text-[10vw] sm:text-[6.6vw] lg:text-[64px]" />
              </div>
            </div>
            <Reveal delay={0.1}>
              <p className="max-w-xl text-[15px] leading-relaxed text-ink-2">
                Le commercial qualifie un besoin et associe un candidat. L&apos;administratif poursuit le même dossier, vérifie les pièces et le financement. Le responsable pédagogique prépare le parcours ; le formateur ne retrouve que ses séances. Les présences alimentent les heures effectuées, la qualité voit les preuves, la direction suit l&apos;ensemble. Aucune ressaisie entre deux métiers.
              </p>
            </Reveal>
          </div>
          <ol className="mt-16 grid gap-px border border-line-strong bg-line-strong sm:grid-cols-2 lg:grid-cols-7">
            {PARCOURS.map((e, i) => (
              <Reveal key={e.t} as="li" delay={i * 0.05} className="relative flex flex-col bg-bg p-5 sm:min-h-[200px]">
                <span className="num font-mono text-[11px] tracking-[0.2em] text-accent">{String(i + 1).padStart(2, "0")}</span>
                <h3 className="mt-6 text-[19px]">{e.t}</h3>
                <p className="mt-3 text-[13px] leading-relaxed text-ink-2">{e.d}</p>
                {i < PARCOURS.length - 1 ? <ArrowRight size={14} className="absolute bottom-5 end-5 hidden text-ink-3 lg:block" aria-hidden="true" /> : null}
              </Reveal>
            ))}
          </ol>
        </div>
      </section>

      {/* FONCTIONNALITÉS : grille encre à survol inversé */}
      <section id="fonctionnalites" className="sombre relative scroll-mt-14 overflow-hidden bg-[#0a0b0d] text-[#f3f0e8]">
        <span className="filigrane absolute -top-6 end-2 text-[40vw] sm:text-[24vw]" aria-hidden="true">
          12
        </span>
        <div className="conteneur relative py-24 sm:py-32">
          <Reveal className="flex flex-wrap items-end justify-between gap-6">
            <div>
              <p className="etiquette">Douze fonctions</p>
              <h2 className="mt-5 max-w-3xl text-[32px] sm:text-[52px]">Le même périmètre que Digiforma, des règles plus strictes.</h2>
            </div>
            <p className="max-w-md text-sm leading-relaxed text-[#f3f0e8]/60">Chaque fonction a sa page : promesse, bénéfices, fonctionnement, règles garanties par le serveur. Rien n&apos;est « bientôt disponible » sans explication.</p>
          </Reveal>
          <div className="mt-14 grid border-s border-t border-[#f3f0e8]/15 sm:grid-cols-2 lg:grid-cols-4">
            {FEATURES.map((f, i) => (
              <Reveal key={f.slug} delay={i * 0.03} className="group relative border-b border-e border-[#f3f0e8]/15 transition-colors duration-300 hover:bg-[#f3f0e8] hover:text-[#0a0b0d]">
                <Link href={`/fonctionnalites/${f.slug}`} className="flex h-full flex-col p-6">
                  <span className="flex items-center justify-between font-mono text-[11px] tracking-[0.2em] text-[#c9b8f0] group-hover:text-[#0a0b0d]">
                    {String(i + 1).padStart(2, "0")}
                    <ArrowUpRight size={14} className="opacity-0 transition-opacity group-hover:opacity-100" />
                  </span>
                  <h3 className="mt-6 text-[20px] leading-[1]">{f.short}</h3>
                  <p className="mt-3 flex-1 text-[13px] leading-relaxed text-[#f3f0e8]/60 group-hover:text-[#0a0b0d]/70">{f.promise}</p>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ÉMARGEMENT : la règle la plus exigeante, montrée */}
      <section id="emargement" className="scroll-mt-14 border-b border-line bg-bg">
        <div className="conteneur grid gap-12 py-24 lg:grid-cols-[0.9fr_1.1fr] lg:items-center sm:py-32">
          <div>
            <Reveal>
              <p className="etiquette">Émargement et heures</p>
            </Reveal>
            <div className="mt-8">
              <BigTitle lines={["Deux périodes.", "Le serveur décide."]} className="text-[10vw] sm:text-[6.6vw] lg:text-[60px]" />
            </div>
            <Reveal delay={0.1}>
              <p className="mt-8 max-w-lg text-[15px] leading-relaxed text-ink-2">
                Matin et après-midi ont leurs propres horaires, présences, signature et clôture. Aucune présence ne peut être saisie avant le début réel de la période, aucune clôture avant sa fin : l&apos;heure de référence est celle du serveur, en Europe/Paris. Une période clôturée ne se modifie plus ; une correction crée une nouvelle ligne et conserve l&apos;originale.
              </p>
            </Reveal>
            <Reveal delay={0.15}>
              <ul className="mt-8 grid gap-px border border-line-strong bg-line-strong sm:grid-cols-3">
                {[
                  ["6 h", "journée 9-12 / 14-17"],
                  ["3 h", "matin seul"],
                  ["0", "durée comptée deux fois"],
                ].map(([v, l]) => (
                  <li key={l} className="bg-bg p-4">
                    <p className="num font-display text-[28px] font-semibold tracking-tight text-accent">{v}</p>
                    <p className="mt-1 font-mono text-[9.5px] uppercase tracking-[0.18em] text-ink-3">{l}</p>
                  </li>
                ))}
              </ul>
            </Reveal>
            <Reveal delay={0.2} className="mt-8">
              <Link href="/fonctionnalites/planning-emargement" className={btnOsContour}>
                Voir les règles d&apos;émargement <ArrowRight size={14} />
              </Link>
            </Reveal>
          </div>
          <Reveal delay={0.15}>
            <Ecran kind="emargement" />
            <p className="mt-3 font-mono text-[9.5px] uppercase tracking-[0.18em] text-ink-3">Aperçu illustratif, données fictives</p>
          </Reveal>
        </div>
      </section>

      {/* COMPARATIF */}
      <section id="comparatif" className="scroll-mt-14 border-b border-line bg-bg-sunken">
        <div className="conteneur py-24 sm:py-32">
          <Reveal>
            <p className="etiquette">Comparatif</p>
          </Reveal>
          <div className="mt-8">
            <BigTitle lines={["Next Formation, Digiforma", "ou logiciel historique."]} className="text-[9vw] sm:text-[6.4vw] lg:text-[72px]" />
          </div>
          <Reveal delay={0.1} className="mt-14">
            <ComparatifTable />
          </Reveal>
          <Reveal delay={0.15} className="mt-8">
            <Link href="/comparatif/digiforma" className={btnOsContour}>
              Lire le comparatif détaillé <ArrowRight size={14} />
            </Link>
          </Reveal>
        </div>
      </section>

      {/* TARIFS */}
      <section id="tarifs" className="scroll-mt-14 border-b border-line bg-bg">
        <div className="conteneur py-24 sm:py-32">
          <div className="grid gap-8 lg:grid-cols-[1fr_auto] lg:items-end">
            <div>
              <Reveal>
                <p className="etiquette">Tarifs</p>
              </Reveal>
              <div className="mt-8">
                <BigTitle lines={["Dix pour cent", "de moins, garanti."]} className="text-[10vw] sm:text-[6.6vw] lg:text-[64px]" />
              </div>
            </div>
            <Reveal delay={0.1}>
              <p className="max-w-md text-[14.5px] leading-relaxed text-ink-2">Chaque offre est calculée à 90 % du prix public de référence relevé sur digiforma.com. Si la référence baisse, nous suivons. Le calculateur de la page tarifs additionne plan et options.</p>
            </Reveal>
          </div>
          <div className="mt-14">
            <PricingGrid plans={plans} />
          </div>
          <Reveal className="mt-10 flex flex-wrap gap-3">
            <Link href="/tarifs" className={btnEncre}>
              Calculer mon tarif <ArrowRight size={14} />
            </Link>
            <Link href="/demo" className={btnOsContour}>
              Démonstration instantanée
            </Link>
          </Reveal>
        </div>
      </section>

      {/* SÉCURITÉ */}
      <section id="securite" className="scroll-mt-14 border-b border-line bg-bg-sunken">
        <div className="conteneur py-24 sm:py-32">
          <Reveal className="flex flex-wrap items-end justify-between gap-6">
            <div>
              <p className="etiquette">Sécurité et conformité</p>
              <h2 className="mt-5 max-w-2xl text-[32px] sm:text-[48px]">Discrète pour l&apos;équipe, réelle sur le serveur.</h2>
            </div>
            <Link href="/securite-conformite" className="lien-nav inline-flex items-center gap-1 !text-[11px]">
              Tout lire <ArrowUpRight size={12} />
            </Link>
          </Reveal>
          <ul className="mt-14 grid gap-px border border-line-strong bg-line-strong sm:grid-cols-2 lg:grid-cols-4">
            {SECURITE.map((s, i) => (
              <Reveal key={s.t} as="li" delay={i * 0.04} className="bg-bg p-6">
                <h3 className="text-[17px]">{s.t}</h3>
                <p className="mt-3 text-[13px] leading-relaxed text-ink-2">{s.d}</p>
              </Reveal>
            ))}
          </ul>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="scroll-mt-14 border-b border-line bg-bg">
        <div className="conteneur grid gap-12 py-24 lg:grid-cols-[0.7fr_1.3fr] sm:py-32">
          <div>
            <Reveal>
              <p className="etiquette">Questions fréquentes</p>
            </Reveal>
            <div className="mt-8">
              <BigTitle lines={["Ce qu'on nous", "demande d'abord."]} className="text-[11vw] sm:text-[7vw] lg:text-[56px]" />
            </div>
            <Reveal delay={0.1}>
              <p className="mt-8 max-w-sm text-sm leading-relaxed text-ink-2">
                Une autre question ?{" "}
                <Link href="/contact" className="text-accent underline underline-offset-4">
                  Écrivez-nous
                </Link>
                , nous répondons sous un jour ouvré.
              </p>
            </Reveal>
          </div>
          <Reveal delay={0.1}>
            <FaqList items={FAQ} />
          </Reveal>
        </div>
      </section>

      {/* APPEL FINAL : aplat pastel violet */}
      <section className="relative overflow-hidden bg-[#c9b8f0] text-[#0a0b0d]">
        <span className="filigrane absolute -top-10 end-0 text-[30vw]" aria-hidden="true">
          N
        </span>
        <div className="conteneur relative py-24 sm:py-36">
          <BigTitle lines={["Quinze jours pour voir", "si le dossier tient."]} className="text-[9vw] sm:text-[6.6vw] lg:text-[84px]" />
          <div className="mt-12 grid gap-8 md:grid-cols-[1fr_auto] md:items-end">
            <p className="max-w-xl text-base leading-relaxed sm:text-lg">Essai gratuit sans carte bancaire, import de vos données guidé, démonstration ouverte sans compte. Vos données restent exportables à tout moment.</p>
            <div className="flex flex-wrap gap-3">
              <Link href="/inscription" className="inline-flex min-h-[46px] items-center gap-2 border border-[#0a0b0d] bg-[#0a0b0d] px-6 font-mono text-[11px] uppercase tracking-[0.18em] text-[#f3f0e8] transition-colors duration-300 hover:bg-[#f3f0e8] hover:text-[#0a0b0d] active:scale-[0.985]">
                Commencer l&apos;essai <ArrowRight size={14} />
              </Link>
              <Link href="/demo" className="inline-flex min-h-[46px] items-center gap-2 border border-[#0a0b0d]/40 px-6 font-mono text-[11px] uppercase tracking-[0.18em] text-[#0a0b0d] transition-colors duration-300 hover:border-[#0a0b0d] hover:bg-[#0a0b0d] hover:text-[#f3f0e8] active:scale-[0.985]">
                Explorer la démonstration
              </Link>
            </div>
          </div>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
