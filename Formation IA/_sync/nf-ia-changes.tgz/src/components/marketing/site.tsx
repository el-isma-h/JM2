"use client";

import * as React from "react";
import Link from "next/link";
import { AnimatePresence, motion, useInView, useReducedMotion } from "motion/react";
import { List, Minus, Moon, Plus, Sparkle, Sun, X } from "@phosphor-icons/react";
import { Logo, FiletMarque } from "@/components/ui/logo";
import { FAMILLE, FEATURES, SOLUTIONS } from "@/lib/marketing-data";
import { cn } from "@/lib/utils";

/*
  Enveloppe du site vitrine Next Formation : même grammaire que Next Ads / Next Optimisation
  (en-tête encre collant, titres géants révélés ligne par ligne, pied de page en colonnes mono).
  Un seul accent : violet (#4b2a7f en texte, pastel #c9b8f0 sur fond encre).
*/

export const EASE: [number, number, number, number] = [0.22, 1, 0.36, 1];
export const OS = "#f3f0e8";
export const ENCRE = "#0a0b0d";
export const PASTEL = "#c9b8f0";

/** Bloc révélé à l'entrée dans la fenêtre (hiérarchie de lecture : le contenu arrive dans l'ordre). */
export function Reveal({ children, delay = 0, className, y = 20, as: Tag = "div" }: { children: React.ReactNode; delay?: number; className?: string; y?: number; as?: "div" | "li" | "section" }) {
  const ref = React.useRef<HTMLElement>(null);
  const inView = useInView(ref, { once: true, margin: "-60px" });
  const reduced = useReducedMotion();
  const props = { initial: reduced ? false : { opacity: 0, y }, animate: reduced || inView ? { opacity: 1, y: 0 } : undefined, transition: { duration: 0.6, delay, ease: EASE }, className };
  if (Tag === "li") return <motion.li ref={ref as unknown as React.RefObject<HTMLLIElement>} {...props}>{children}</motion.li>;
  if (Tag === "section") return <motion.section ref={ref as unknown as React.RefObject<HTMLElement>} {...props}>{children}</motion.section>;
  return <motion.div ref={ref as unknown as React.RefObject<HTMLDivElement>} {...props}>{children}</motion.div>;
}

/** Titre géant révélé ligne par ligne (masque), signature Next Capital. */
export function BigTitle({ lines, className = "", as: Tag = "h2", accentLast = false }: { lines: string[]; className?: string; as?: "h1" | "h2"; accentLast?: boolean }) {
  const reduced = useReducedMotion();
  const ref = React.useRef<HTMLHeadingElement>(null);
  const inView = useInView(ref, { once: true, margin: "-10% 0px" });
  const shown = reduced || inView;
  return (
    <Tag ref={ref} className={cn("titre-geant", className)}>
      {lines.map((l, i) => (
        <span key={i} className={cn("block overflow-hidden pb-[0.08em]", accentLast && i === lines.length - 1 && "text-accent")}>
          <motion.span className="block" initial={reduced ? false : { y: "110%" }} animate={{ y: shown ? 0 : "110%" }} transition={{ duration: 0.9, delay: i * 0.08, ease: [0.76, 0, 0.24, 1] }}>
            {l}
          </motion.span>
        </span>
      ))}
    </Tag>
  );
}

const subscribeTheme = (cb: () => void) => {
  const obs = new MutationObserver(cb);
  obs.observe(document.documentElement, { attributes: true, attributeFilter: ["class"] });
  return () => obs.disconnect();
};
const readTheme = () => document.documentElement.classList.contains("dark");

/** Thème clair / sombre : lu depuis la classe du document (posée par le script du layout racine), persisté dans localStorage. */
function useTheme() {
  const dark = React.useSyncExternalStore(subscribeTheme, readTheme, () => false);
  const toggle = () => {
    const d = !dark;
    document.documentElement.classList.toggle("dark", d);
    try {
      window.localStorage.setItem("nextformation-theme", d ? "dark" : "light");
    } catch {}
  };
  return { dark, toggle };
}

const NAV: [string, string][] = [
  ["/fonctionnalites", "Fonctionnalités"],
  ["/solutions", "Solutions"],
  ["/tarifs", "Tarifs"],
  ["/comparatif/digiforma", "Comparatif"],
  ["/securite-conformite", "Sécurité"],
  ["/contact", "Contact"],
];

const btnOs = "inline-flex min-h-[36px] items-center gap-2 border border-[#f3f0e8] bg-[#f3f0e8] px-4 font-mono text-[10.5px] uppercase tracking-[0.18em] text-[#0a0b0d] transition-colors duration-300 hover:border-[#c9b8f0] hover:bg-[#c9b8f0]";
const btnLigne = "inline-flex min-h-[36px] items-center gap-2 border border-[#f3f0e8]/30 px-4 font-mono text-[10.5px] uppercase tracking-[0.18em] text-[#f3f0e8] transition-colors duration-300 hover:border-[#f3f0e8]";
/** Bouton « Formation IA » de l'en-tête : contour pastel, bien visible sans concurrencer l'essai gratuit. */
const btnIa = "inline-flex min-h-[36px] items-center gap-2 border border-[#c9b8f0]/70 px-4 font-mono text-[10.5px] font-medium uppercase tracking-[0.18em] text-[#c9b8f0] transition-colors duration-300 hover:border-[#c9b8f0] hover:bg-[#c9b8f0] hover:text-[#0a0b0d]";

export function SiteHeader() {
  const { dark, toggle } = useTheme();
  const [open, setOpen] = React.useState(false);
  return (
    <header className="sombre sticky top-0 z-40 border-b border-[#f3f0e8]/10 bg-[#0a0b0d]/90 text-[#f3f0e8] backdrop-blur">
      <div className="conteneur flex h-14 items-center justify-between gap-6">
        <Link href="/" aria-label="Next Formation, accueil" className="shrink-0">
          <Logo clair />
        </Link>
        <nav className="hidden items-center gap-7 lg:flex" aria-label="Pages du site">
          <Link href="/formation-ia" className={cn(btnIa, "min-h-[30px] whitespace-nowrap px-3")}>
            <Sparkle size={12} weight="fill" aria-hidden="true" /> Formation IA
          </Link>
          {NAV.map(([h, l]) => (
            <Link key={h} href={h} className="lien-nav">
              {l}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-3">
          <Link href="/formation-ia" className={cn(btnIa, "hidden whitespace-nowrap md:inline-flex lg:hidden")}>
            <Sparkle size={13} weight="fill" aria-hidden="true" /> Formation IA
          </Link>
          <button type="button" onClick={toggle} className="p-1 text-[#f3f0e8]/70 transition-colors hover:text-[#f3f0e8]" aria-label={dark ? "Passer au thème clair" : "Passer au thème sombre"}>
            {dark ? <Sun size={16} /> : <Moon size={16} />}
          </button>
          <span className="hidden h-4 w-px bg-[#f3f0e8]/20 sm:block" aria-hidden="true" />
          <Link href="/connexion" className="lien-nav hidden sm:block">
            Connexion
          </Link>
          <Link href="/demo" className={cn(btnLigne, "hidden lg:inline-flex")}>
            Démonstration
          </Link>
          <Link href="/inscription" className={cn(btnOs, "hidden sm:inline-flex")}>
            Essai gratuit
          </Link>
          <button type="button" onClick={() => setOpen((o) => !o)} className="grid h-9 w-9 place-items-center border border-[#f3f0e8]/30 lg:hidden" aria-label={open ? "Fermer le menu" : "Ouvrir le menu"} aria-expanded={open} aria-controls="menu-mobile">
            {open ? <X size={16} /> : <List size={16} />}
          </button>
        </div>
      </div>
      <AnimatePresence>
        {open && (
          <motion.nav id="menu-mobile" initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} transition={{ duration: 0.2, ease: EASE }} className="border-t border-[#f3f0e8]/10 bg-[#0a0b0d] lg:hidden" aria-label="Navigation mobile">
            <div className="conteneur flex flex-col py-3">
              <Link href="/formation-ia" onClick={() => setOpen(false)} className="flex items-center gap-2 border-b border-[#f3f0e8]/10 py-3 font-mono text-[11px] font-medium uppercase tracking-[0.2em] text-[#c9b8f0]">
                <Sparkle size={13} weight="fill" aria-hidden="true" /> Formation IA
              </Link>
              {NAV.map(([h, l]) => (
                <Link key={h} href={h} onClick={() => setOpen(false)} className="border-b border-[#f3f0e8]/10 py-3 font-mono text-[11px] uppercase tracking-[0.2em] text-[#f3f0e8]/80">
                  {l}
                </Link>
              ))}
              <Link href="/demo" onClick={() => setOpen(false)} className="border-b border-[#f3f0e8]/10 py-3 font-mono text-[11px] uppercase tracking-[0.2em] text-[#f3f0e8]/80">
                Démonstration
              </Link>
              <div className="flex gap-6 py-3 font-mono text-[11px] uppercase tracking-[0.2em] text-[#c9b8f0]">
                <Link href="/inscription" onClick={() => setOpen(false)}>
                  Essai gratuit
                </Link>
                <Link href="/connexion" onClick={() => setOpen(false)}>
                  Connexion
                </Link>
              </div>
            </div>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
}

export function SiteFooter() {
  const col = "flex flex-col gap-2 font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3";
  return (
    <footer className="border-t border-line bg-bg">
      <div className="conteneur grid gap-10 py-14 md:grid-cols-[1.4fr_1fr_1fr_1fr_1fr]">
        <div className="max-w-md">
          <Logo />
          <p className="mt-4 text-[13px] leading-relaxed text-ink-2">
            Logiciel français de gestion d&apos;organismes de formation et de CFA. Tarifs publiés à 90 % de la grille publique Digiforma, source et date de relevé affichées. Essai gratuit 15 jours, démonstration sans compte.
          </p>
          <p className="mt-5 font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">Un produit de la famille Next Capital</p>
          <ul className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-[12.5px] text-ink-2">
            {FAMILLE.map((f) => (
              <li key={f.name}>
                <span className="text-ink">{f.name}</span> <span className="text-ink-3">({f.d})</span>
              </li>
            ))}
          </ul>
          <FiletMarque className="mt-6" />
        </div>
        <div className={col}>
          <span className="mb-1 text-ink">Fonctionnalités</span>
          {FEATURES.map((f) => (
            <Link key={f.slug} href={`/fonctionnalites/${f.slug}`} className="transition-colors hover:text-ink">
              {f.short}
            </Link>
          ))}
        </div>
        <div className={col}>
          <span className="mb-1 text-ink">Solutions</span>
          {SOLUTIONS.map((s) => (
            <Link key={s.slug} href={`/solutions/${s.slug}`} className="transition-colors hover:text-ink">
              {s.short}
            </Link>
          ))}
        </div>
        <div className={col}>
          <span className="mb-1 text-ink">Next Formation</span>
          <Link href="/tarifs" className="transition-colors hover:text-ink">Tarifs</Link>
          <Link href="/comparatif/digiforma" className="transition-colors hover:text-ink">Comparatif Digiforma</Link>
          <Link href="/securite-conformite" className="transition-colors hover:text-ink">Sécurité</Link>
          <Link href="/demo" className="transition-colors hover:text-ink">Démonstration</Link>
          <Link href="/inscription" className="transition-colors hover:text-ink">Essai gratuit</Link>
          <Link href="/contact" className="transition-colors hover:text-ink">Contact</Link>
          <Link href="/a-propos" className="transition-colors hover:text-ink">À propos</Link>
          <Link href="/connexion" className="transition-colors hover:text-ink">Connexion</Link>
        </div>
        <div className={col}>
          <span className="mb-1 text-ink">Légal</span>
          <Link href="/mentions-legales" className="transition-colors hover:text-ink">Mentions légales</Link>
          <Link href="/cgu" className="transition-colors hover:text-ink">Conditions générales</Link>
          <Link href="/confidentialite" className="transition-colors hover:text-ink">Confidentialité</Link>
          <span className="mt-4 normal-case tracking-normal text-ink-3">© {new Date().getFullYear()} Next Formation</span>
        </div>
      </div>
    </footer>
  );
}

/** Accordéon accessible : bouton avec aria-expanded et aria-controls, contenu animé en hauteur. */
export function FaqList({ items, defaultOpen = 0 }: { items: { q: string; a: string }[]; defaultOpen?: number | null }) {
  const [open, setOpen] = React.useState<number | null>(defaultOpen);
  const id = React.useId();
  return (
    <ul className="border-t border-line-strong">
      {items.map((f, i) => {
        const isOpen = open === i;
        return (
          <li key={f.q} className="border-b border-line">
            <h3 className="normal-case tracking-normal">
              <button type="button" onClick={() => setOpen(isOpen ? null : i)} aria-expanded={isOpen} aria-controls={`${id}-${i}`} className="flex w-full items-center justify-between gap-6 py-5 text-start">
                <span className="font-display text-[16px] font-medium leading-snug sm:text-[18px]">{f.q}</span>
                <span className="grid h-7 w-7 shrink-0 place-items-center border border-line-strong text-ink" aria-hidden="true">
                  {isOpen ? <Minus size={13} /> : <Plus size={13} />}
                </span>
              </button>
            </h3>
            <AnimatePresence initial={false}>
              {isOpen && (
                <motion.div id={`${id}-${i}`} initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.3, ease: EASE }} className="overflow-hidden">
                  <p className="max-w-2xl pb-6 text-[14px] leading-relaxed text-ink-2">{f.a}</p>
                </motion.div>
              )}
            </AnimatePresence>
          </li>
        );
      })}
    </ul>
  );
}

/** Bouton pastel sur fond encre (hero, appel final). */
export const btnPastel = "inline-flex min-h-[46px] items-center gap-2 border border-[#c9b8f0] bg-[#c9b8f0] px-6 font-mono text-[11px] font-medium uppercase tracking-[0.18em] text-[#0a0b0d] transition-colors duration-300 hover:border-[#f3f0e8] hover:bg-[#f3f0e8] active:scale-[0.985]";
export const btnContour = "inline-flex min-h-[46px] items-center gap-2 border border-[#f3f0e8]/30 px-6 font-mono text-[11px] uppercase tracking-[0.18em] text-[#f3f0e8] transition-colors duration-300 hover:border-[#f3f0e8] hover:bg-[#f3f0e8] hover:text-[#0a0b0d] active:scale-[0.985]";
/** Boutons sur fond os. */
export const btnEncre = "inline-flex min-h-[46px] items-center gap-2 border border-ink bg-ink px-6 font-mono text-[11px] font-medium uppercase tracking-[0.18em] text-bg transition-colors duration-300 hover:border-accent hover:bg-accent hover:text-accent-ink active:scale-[0.985]";
export const btnOsContour = "inline-flex min-h-[46px] items-center gap-2 border border-line-strong px-6 font-mono text-[11px] uppercase tracking-[0.18em] text-ink transition-colors duration-300 hover:border-ink hover:bg-ink hover:text-bg active:scale-[0.985]";

/** En-tête de page intérieure : fond encre, fil d'Ariane, titre, description, actions. */
export function PageHero({ crumbs, eyebrow, title, description, children, filigrane }: { crumbs: { label: string; href?: string }[]; eyebrow?: string; title: string; description?: string; children?: React.ReactNode; filigrane?: string }) {
  return (
    <header className="sombre relative overflow-hidden bg-[#0a0b0d] text-[#f3f0e8]">
      {filigrane ? (
        <span className="filigrane absolute -top-8 end-2 hidden text-[18vw] text-[#f3f0e8] md:block" aria-hidden="true">
          {filigrane}
        </span>
      ) : null}
      <div className="conteneur relative py-14 lg:py-20">
        <nav className="flex flex-wrap gap-2 font-mono text-[10px] uppercase tracking-[0.2em] text-[#f3f0e8]/50" aria-label="Fil d'Ariane">
          {crumbs.map((c, i) => (
            <React.Fragment key={c.label}>
              {i > 0 ? <span aria-hidden="true">/</span> : null}
              {c.href ? (
                <Link href={c.href} className="transition-colors hover:text-[#f3f0e8]">
                  {c.label}
                </Link>
              ) : (
                <span className="text-[#f3f0e8]">{c.label}</span>
              )}
            </React.Fragment>
          ))}
        </nav>
        {eyebrow ? <p className="etiquette mt-8">{eyebrow}</p> : null}
        <h1 className="mt-5 max-w-4xl text-[32px] sm:text-[48px] lg:text-[56px]">{title}</h1>
        {description ? <p className="mt-6 max-w-2xl text-[15.5px] leading-relaxed text-[#f3f0e8]/70 sm:text-[16px]">{description}</p> : null}
        {children ? <div className="mt-8 flex flex-wrap items-center gap-3">{children}</div> : null}
      </div>
    </header>
  );
}
