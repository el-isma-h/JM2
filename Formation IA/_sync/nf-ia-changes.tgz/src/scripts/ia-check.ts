/**
 * Recette de l'intégration Formation IA (NF-IA-150) :
 *   npx tsx --conditions=react-server src/scripts/ia-check.ts [--keep] [--no-demo]
 * - affiche l'organisme vendeur réel, le programme, sa version, ses modules et ses sessions de l'année ;
 * - lance `seedIaDemo()` (organisme de démonstration + Camille) et contrôle les invariants du dossier ;
 * - construit un lien `iaSsoLink()` pour Camille et le vérifie avec le même secret.
 * Code de sortie 0 si tous les contrôles passent. Sans --keep, le tenant de démonstration créé est supprimé à la fin.
 */
import path from "node:path";
import { existsSync } from "node:fs";

try {
  if (existsSync(path.resolve(process.cwd(), ".env"))) process.loadEnvFile(path.resolve(process.cwd(), ".env"));
} catch {}

type Check = { label: string; ok: boolean; detail?: string };

async function main() {
  const keep = process.argv.includes("--keep");
  const noDemo = process.argv.includes("--no-demo");
  const { db, pool, schema } = await import("@/db");
  const { and, eq, inArray, sql } = await import("drizzle-orm");
  const { getIaOrg, getIaProgram, getIaSession, IA_LEVELS, IA_OFFERS, IA_ORG_SLUG, entitlementsForOffer } = await import("@/server/ia/catalog");
  const { bootstrapIa } = await import("@/server/ia/bootstrap");
  const { iaSsoLink, verifyIaSsoToken } = await import("@/server/ia/sso");
  const { iaConfig } = await import("@/lib/env");
  const { todayParis } = await import("@/lib/time");
  const checks: Check[] = [];
  const check = (label: string, ok: boolean, detail?: string) => {
    checks.push({ label, ok, detail });
    console.log(`${ok ? "OK      " : "ÉCHEC   "}${label}${detail ? ` : ${detail}` : ""}`);
  };
  const year = Number(todayParis().slice(0, 4));

  /* ---------- Organisme vendeur réel ---------- */
  const boot = await bootstrapIa();
  const ia = await getIaOrg();
  check("Organisme vendeur réel présent", Boolean(ia && !ia.org.isDemo), ia ? `${ia.org.legalName} (tenant ${ia.tenant.slug}, org ${ia.org.id})` : undefined);
  if (boot.toComplete.length) console.log(`        À renseigner dans Paramètres : ${boot.toComplete.join(", ")}`);
  if (!ia) throw new Error("Amorçage incomplet.");
  check("Amorçage idempotent (seconde passe sans création)", (await bootstrapIa()).created.length === 0);

  const prog = await getIaProgram(ia.org.id);
  check("Programme NF-IA-150 actif, publié, certifiante, e-learning, non CPF", Boolean(prog && prog.program.status === "actif" && prog.program.isPublished && prog.program.kind === "certifiante" && !prog.program.cpfEligible && prog.version?.modality === "elearning"), prog ? `${prog.program.title} ; version ${prog.version?.version} (${prog.version?.durationHours} h)` : undefined);
  check("Cinq modules de catalogue N1-N5 avec heures et compétences", Boolean(prog && prog.modules.length === 5 && prog.modules.every((m, i) => m.code === IA_LEVELS[i].code && m.hours === IA_LEVELS[i].hours && (m.skills as unknown[]).length >= 5)), prog?.modules.map((m) => `${m.code} ${m.hours} h`).join(", "));
  for (const l of IA_LEVELS) {
    const s = await getIaSession(ia.org.id, l.code, year);
    check(`Session IA-${l.code}-${year} ouverte, publiée, entrées permanentes`, Boolean(s && s.status === "ouverte" && s.isPublished && s.kind === "individuel" && s.startDate === `${year}-01-01` && s.endDate === `${year}-12-31` && s.priceCents === l.priceCents), s ? `${s.title} ; ${(s.priceCents ?? 0) / 100} €` : "absente");
  }
  const pieces = await db.select({ code: schema.requiredPieces.code }).from(schema.requiredPieces).where(and(eq(schema.requiredPieces.orgId, ia.org.id), eq(schema.requiredPieces.isActive, true)));
  const codes = new Set(pieces.map((p) => p.code));
  check("Pièces requises : identité, accord de prise en charge (OPCO…), convention entreprise, attestation France Travail, contrat particulier", ["piece_identite", "accord_prise_en_charge", "convention_signee", "attestation_france_travail", "contrat_formation_signe"].every((c) => codes.has(c)), [...codes].join(", "));
  const funders = await db.select({ kind: schema.funders.kind }).from(schema.funders).where(eq(schema.funders.orgId, ia.org.id));
  check("Financeurs cpf et france_travail", funders.some((f) => f.kind === "cpf") && funders.some((f) => f.kind === "france_travail"));
  const [ev] = await db.select({ id: schema.qualityEvidences.id }).from(schema.qualityEvidences).where(and(eq(schema.qualityEvidences.orgId, ia.org.id), eq(schema.qualityEvidences.indicatorCode, "IND_1"))).limit(1);
  check("Preuve qualité IND_1 (information du public) enregistrée", Boolean(ev));
  const { loadPublicCatalogue } = await import("@/server/catalog/public");
  const pub = await loadPublicCatalogue(IA_ORG_SLUG);
  check(`Catalogue public /catalogue-public/${IA_ORG_SLUG} affiche la formation`, Boolean(pub && pub.items.some((it) => it.program.code === "NF-IA-150" && it.version)), pub ? `${pub.items.length} formation(s) publiée(s)` : "catalogue introuvable");
  check("Offres : N1-N4 à 1 490 €, PARCOURS 4 990 € (provisoire), N5 1 290 € (provisoire)", IA_OFFERS.filter((o) => ["N1", "N2", "N3", "N4"].includes(o.code)).every((o) => o.priceCents === 149_000 && !o.provisional) && IA_OFFERS.find((o) => o.code === "PARCOURS")?.priceCents === 499_000 && IA_OFFERS.find((o) => o.code === "N5")?.priceCents === 129_000, IA_OFFERS.map((o) => `${o.code} ${o.priceCents / 100} €${o.provisional ? " (provisoire)" : ""} → ${entitlementsForOffer(o.code).join("+")}`).join(" ; "));

  /* ---------- Démonstration Camille ---------- */
  let demoTenantId: string | null = null;
  if (!noDemo) {
    const { seedIaDemo } = await import("@/server/demo/ia");
    const t0 = Date.now();
    const demo = await seedIaDemo();
    demoTenantId = demo.tenantId;
    console.log(`seedIaDemo : ${Date.now() - t0} ms (tenant ${demo.tenantId}, org ${demo.orgId}, Camille ${demo.userId})`);
    const [org] = await db.select().from(schema.organismes).where(eq(schema.organismes.id, demo.orgId)).limit(1);
    check("Organisme de démonstration IA isDemo=true", Boolean(org?.isDemo && org.legalName.includes("démonstration")), org?.legalName);
    const dprog = await getIaProgram(demo.orgId);
    check("Programme NF-IA-150 présent dans la démo (isDemo)", Boolean(dprog?.program.isDemo && dprog.modules.length === 5));
    const enr = await db.select().from(schema.enrollments).where(and(eq(schema.enrollments.orgId, demo.orgId), eq(schema.enrollments.personId, demo.personId)));
    const by = (id: string) => enr.find((e) => e.id === id);
    const n1 = by(demo.enrollmentIds.N1);
    const n2 = by(demo.enrollmentIds.N2);
    check("Camille : 4 inscriptions au parcours (iaOffer = PARCOURS, isDemo)", enr.length === 4 && enr.every((e) => e.iaOffer === "PARCOURS" && e.isDemo));
    check("N1 terminé, acquis, financement soldé, accès ouvert", Boolean(n1 && n1.status === "termine" && n1.progression === "acquise" && n1.fundingState === "solde" && n1.iaAccessOpenedAt && n1.iaAccessOpenedBy));
    check("N2 en cours, financement prévu, accès ouvert", Boolean(n2 && n2.status === "en_cours" && n2.progression === "en_cours" && n2.fundingState === "prevu" && n2.iaAccessOpenedAt));
    check("N3 et N4 inscrits, non commencés, sans accès", ["N3", "N4"].every((k) => { const e = by(demo.enrollmentIds[k as "N3" | "N4"]); return Boolean(e && e.status === "inscrit" && e.progression === "non_commencee" && !e.iaAccessOpenedAt); }));
    const fundings = await db.select().from(schema.fundings).where(inArray(schema.fundings.enrollmentId, enr.map((e) => e.id)));
    const cpf = fundings.find((f) => f.kind === "cpf");
    check("Financement CPF fictif au statut prevu « en attente d'enregistrement RS »", Boolean(cpf && cpf.status === "prevu" && /enregistrement RS/i.test(`${cpf.label} ${cpf.notes}`)), cpf?.label);
    const docs = await db.select({ category: schema.documents.category, status: schema.documents.status, isDemo: schema.documents.isDemo }).from(schema.documents).where(and(eq(schema.documents.orgId, demo.orgId), eq(schema.documents.personId, demo.personId)));
    check("Documents : contrat signé, certificat N1 validé, certificat de réalisation, pièce d'identité (tous isDemo)", docs.some((d) => d.category === "contrat" && d.status === "signe") && docs.some((d) => d.category === "attestation" && d.status === "valide") && docs.some((d) => d.category === "certificat_realisation") && docs.some((d) => d.category === "piece_identite") && docs.every((d) => d.isDemo), docs.map((d) => `${d.category}:${d.status}`).join(", "));
    const subs = await db.select({ status: schema.pieceSubmissions.status, enrollmentId: schema.pieceSubmissions.enrollmentId, requiredPieceId: schema.pieceSubmissions.requiredPieceId }).from(schema.pieceSubmissions).where(inArray(schema.pieceSubmissions.enrollmentId, enr.map((e) => e.id)));
    const identity = await db.select({ id: schema.requiredPieces.id }).from(schema.requiredPieces).where(and(eq(schema.requiredPieces.orgId, demo.orgId), eq(schema.requiredPieces.code, "piece_identite"))).limit(1);
    check("Pièce d'identité acceptée sur chaque inscription", subs.filter((s) => s.requiredPieceId === identity[0]?.id).length === 4 && subs.filter((s) => s.requiredPieceId === identity[0]?.id).every((s) => s.status === "acceptee"), `${subs.length} pièces attendues au total`);
    const tasks = await db.select({ title: schema.tasks.title, status: schema.tasks.status, isDemo: schema.tasks.isDemo }).from(schema.tasks).where(eq(schema.tasks.orgId, demo.orgId));
    check("Tâches de relais (CPF en attente RS bloquée, pièce manquante, niveau suivant), isDemo", tasks.length >= 3 && tasks.some((t) => /CPF/.test(t.title) && t.status === "bloquee") && tasks.every((t) => t.isDemo), tasks.map((t) => `${t.status} : ${t.title}`).join(" ; "));
    const [{ nEv }] = await db.select({ nEv: sql<number>`count(*)::int` }).from(schema.qualityEvidences).where(eq(schema.qualityEvidences.orgId, demo.orgId));
    check("Preuves qualité de la démo (IND_1, IND_4, IND_9, IND_11)", nEv >= 4, `${nEv} preuve(s)`);
    const [{ nAudit }] = await db.select({ nAudit: sql<number>`count(*)::int` }).from(schema.auditLogs).where(and(eq(schema.auditLogs.orgId, demo.orgId), eq(schema.auditLogs.action, "enrollment.ia_access_open")));
    check("Ouvertures d'accès auditées (enrollment.ia_access_open)", nAudit === 2, `${nAudit} entrée(s)`);
    const again = await seedIaDemo({ reuseUserId: demo.userId });
    check("Réutilisation de l'espace pour le même visiteur (moins de 24 h)", again.reused && again.orgId === demo.orgId);

    /* ---------- Lien SSO de Camille ---------- */
    const [user] = await db.select().from(schema.users).where(eq(schema.users.id, demo.userId)).limit(1);
    const cfg = iaConfig();
    const link = iaSsoLink({ userId: user.id, email: user.email, firstName: user.firstName, lastName: user.lastName, entitlements: entitlementsForOffer("PARCOURS"), demo: true, enrollmentId: demo.enrollmentIds.N2, back: `${process.env.APP_URL ?? "http://localhost:3000"}/moi` });
    if (!cfg.ok) check("iaSsoLink : null sans IA_APP_URL / IA_SSO_SECRET (configuration manquante expliquée par integrations.ia)", link === null);
    else {
      const token = link ? new URL(link).searchParams.get("token") : null;
      const v = token ? verifyIaSsoToken(token, cfg.secret) : null;
      check("iaSsoLink : lien signé, vérifiable, demo=true, droits N1-N4", Boolean(link && v?.ok && v.payload.demo && v.payload.entitlements?.join() === "N1,N2,N3,N4" && v.payload.exp - v.payload.iat === 300 && v.payload.nonce.length === 24), link ? `${link.slice(0, 60)}…` : undefined);
    }
  }

  if (demoTenantId && !keep) {
    const { purgeTenant } = await import("@/server/backup/purge");
    await purgeTenant(demoTenantId);
    console.log("Tenant de démonstration supprimé (relancer avec --keep pour le conserver).");
  } else if (demoTenantId) console.log(`Tenant de démonstration conservé : ${demoTenantId} (supprimé automatiquement après 24 h).`);

  await pool.end();
  const failed = checks.filter((c) => !c.ok);
  console.log(`\n${checks.length - failed.length}/${checks.length} contrôle(s) passé(s).`);
  if (failed.length) process.exitCode = 1;
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
