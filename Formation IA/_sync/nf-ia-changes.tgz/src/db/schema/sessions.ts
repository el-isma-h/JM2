import { sql } from "drizzle-orm";
import { boolean, date, index, integer, jsonb, pgEnum, pgTable, text, timestamp, uniqueIndex, uuid } from "drizzle-orm/pg-core";
import { organismes, rooms, sites, timestamps } from "./tenancy";
import { companies, contacts, persons } from "./crm";
import { programVersions } from "./catalog";

/* ---------- Formateurs ---------- */

export const trainerKindEnum = pgEnum("trainer_kind", ["interne", "externe", "sous_traitant"]);

export const trainers = pgTable(
  "trainers",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    orgId: uuid("org_id")
      .notNull()
      .references(() => organismes.id, { onDelete: "cascade" }),
    /** Compte utilisateur (rôle trainer) : périmètre limité aux séances affectées (0045). */
    userId: uuid("user_id"),
    civility: text("civility"),
    firstName: text("first_name").notNull(),
    lastName: text("last_name").notNull(),
    email: text("email"),
    phone: text("phone"),
    kind: trainerKindEnum("kind").notNull().default("interne"),
    companyName: text("company_name"),
    siret: text("siret"),
    nda: text("nda"),
    /** Domaines d'intervention et qualifications (preuves Qualiopi : CV, diplômes, habilitations). */
    skills: jsonb("skills").notNull().default(sql`'[]'::jsonb`),
    qualifications: text("qualifications"),
    hourlyRateCents: integer("hourly_rate_cents"),
    isActive: boolean("is_active").notNull().default(true),
    notes: text("notes"),
    isDemo: boolean("is_demo").notNull().default(false),
    ...timestamps,
  },
  (t) => [index("trainers_org_idx").on(t.orgId), index("trainers_user_idx").on(t.userId)],
);

/* ---------- F03 : sessions, cycles, groupes, inscriptions ---------- */

export const sessionKindEnum = pgEnum("session_kind", ["inter", "intra", "cycle", "individuel"]);
export const sessionStatusEnum = pgEnum("session_status", ["brouillon", "ouverte", "confirmee", "en_cours", "terminee", "annulee"]);

export const trainingSessions = pgTable(
  "sessions_formation",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    orgId: uuid("org_id")
      .notNull()
      .references(() => organismes.id, { onDelete: "cascade" }),
    programVersionId: uuid("program_version_id")
      .notNull()
      .references(() => programVersions.id, { onDelete: "restrict" }),
    code: text("code").notNull(),
    title: text("title").notNull(),
    kind: sessionKindEnum("kind").notNull().default("inter"),
    /** Session d'apprentissage (CFA) ou de formation continue (OF). */
    isApprenticeship: boolean("is_apprenticeship").notNull().default(false),
    startDate: date("start_date").notNull(),
    endDate: date("end_date").notNull(),
    siteId: uuid("site_id").references(() => sites.id, { onDelete: "set null" }),
    roomId: uuid("room_id").references(() => rooms.id, { onDelete: "set null" }),
    modality: text("modality").notNull().default("presentiel"),
    capacity: integer("capacity").notNull().default(12),
    minCapacity: integer("min_capacity").notNull().default(1),
    /** Rythme réellement retenu : {label:"2 jours / 8 jours", centerDays:2, companyDays:8, weekdays:[1,2]} */
    rhythm: jsonb("rhythm").notNull().default(sql`'{}'::jsonb`),
    /** Horaires par défaut de la session (matin / après-midi), sinon ceux de l'organisme. */
    schedule: jsonb("schedule").notNull().default(sql`'{}'::jsonb`),
    status: sessionStatusEnum("status").notNull().default("brouillon"),
    /** Responsables : pédagogique et administratif. */
    pedagogyManagerUserId: uuid("pedagogy_manager_user_id"),
    adminManagerUserId: uuid("admin_manager_user_id"),
    /** Session intra : entreprise cliente. */
    companyId: uuid("company_id").references(() => companies.id, { onDelete: "set null" }),
    priceCents: integer("price_cents"),
    /** Publication sur le catalogue public (dates affichées). */
    isPublished: boolean("is_published").notNull().default(false),
    /** Déclaration Carif-Oref : numéro de session, effectif total, recrutement, publics et financeurs. */
    carifSessionNumber: text("carif_session_number"),
    totalCapacity: integer("total_capacity"),
    recruitment: jsonb("recruitment").notNull().default(sql`'[]'::jsonb`),
    publics: jsonb("publics").notNull().default(sql`'[]'::jsonb`),
    notes: text("notes"),
    closedAt: timestamp("closed_at", { withTimezone: true }),
    isDemo: boolean("is_demo").notNull().default(false),
    ...timestamps,
  },
  (t) => [uniqueIndex("sessions_code_unique").on(t.orgId, t.code), index("sessions_org_idx").on(t.orgId, t.status, t.startDate), index("sessions_version_idx").on(t.programVersionId)],
);

export const groups = pgTable(
  "groups",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    orgId: uuid("org_id")
      .notNull()
      .references(() => organismes.id, { onDelete: "cascade" }),
    sessionId: uuid("session_id")
      .notNull()
      .references(() => trainingSessions.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    capacity: integer("capacity"),
    ...timestamps,
  },
  (t) => [index("groups_session_idx").on(t.sessionId)],
);

export const sessionTrainerRoleEnum = pgEnum("session_trainer_role", ["principal", "intervenant", "jury", "tuteur_pedagogique"]);

/** Affectation d'un formateur à une session (et éventuellement un groupe). */
export const sessionTrainers = pgTable(
  "session_trainers",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    orgId: uuid("org_id")
      .notNull()
      .references(() => organismes.id, { onDelete: "cascade" }),
    sessionId: uuid("session_id")
      .notNull()
      .references(() => trainingSessions.id, { onDelete: "cascade" }),
    groupId: uuid("group_id").references(() => groups.id, { onDelete: "cascade" }),
    trainerId: uuid("trainer_id")
      .notNull()
      .references(() => trainers.id, { onDelete: "cascade" }),
    role: sessionTrainerRoleEnum("role").notNull().default("intervenant"),
    ...timestamps,
  },
  (t) => [uniqueIndex("session_trainers_unique").on(t.sessionId, t.trainerId, t.groupId), index("session_trainers_trainer_idx").on(t.trainerId)],
);

/* Statuts distincts (CDC F03) : commercial, inscription, progression pédagogique, financement, examen. */
export const commercialStatusEnum = pgEnum("commercial_status", ["prospect", "devis_envoye", "accepte", "refuse", "sans_objet"]);
export const enrollmentStatusEnum = pgEnum("enrollment_status", ["preinscrit", "inscrit", "en_cours", "termine", "abandon", "annule", "reporte"]);
export const progressionEnum = pgEnum("progression", ["non_commencee", "en_cours", "acquise", "partielle", "non_acquise"]);
export const fundingStateEnum = pgEnum("funding_state", ["a_definir", "prevu", "accorde", "facture", "solde", "refuse"]);
export const examStateEnum = pgEnum("exam_state", ["non_concerne", "a_inscrire", "inscrit", "admis", "ajourne", "absent", "rattrapage"]);
export const contractKindEnum = pgEnum("contract_kind", ["convention_formation", "contrat_apprentissage", "contrat_professionnalisation", "contrat_particulier", "cpf", "stage", "autre"]);

/** Inscription : une personne × une session (ni une séance, ni une cohorte d'examen). */
export const enrollments = pgTable(
  "enrollments",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    orgId: uuid("org_id")
      .notNull()
      .references(() => organismes.id, { onDelete: "cascade" }),
    sessionId: uuid("session_id")
      .notNull()
      .references(() => trainingSessions.id, { onDelete: "restrict" }),
    personId: uuid("person_id")
      .notNull()
      .references(() => persons.id, { onDelete: "restrict" }),
    groupId: uuid("group_id").references(() => groups.id, { onDelete: "set null" }),
    /** Version de programme contractualisée (figée à l'inscription). */
    programVersionId: uuid("program_version_id").references(() => programVersions.id, { onDelete: "set null" }),
    reference: text("reference").notNull(),
    companyId: uuid("company_id").references(() => companies.id, { onDelete: "set null" }),
    tutorContactId: uuid("tutor_contact_id").references(() => contacts.id, { onDelete: "set null" }),
    commercialStatus: commercialStatusEnum("commercial_status").notNull().default("sans_objet"),
    status: enrollmentStatusEnum("status").notNull().default("preinscrit"),
    progression: progressionEnum("progression").notNull().default("non_commencee"),
    fundingState: fundingStateEnum("funding_state").notNull().default("a_definir"),
    examState: examStateEnum("exam_state").notNull().default("non_concerne"),
    contractKind: contractKindEnum("contract_kind").notNull().default("convention_formation"),
    contractNumber: text("contract_number"),
    /** Dates propres au parcours (peuvent différer de la session : entrée décalée, sortie anticipée). */
    startDate: date("start_date"),
    endDate: date("end_date"),
    exitDate: date("exit_date"),
    exitReason: text("exit_reason"),
    hoursPlanned: integer("hours_planned").notNull().default(0),
    /** Positionnement et plan individuel de formation (F07). */
    positioning: jsonb("positioning").notNull().default(sql`'{}'::jsonb`),
    individualPlan: jsonb("individual_plan").notNull().default(sql`'{}'::jsonb`),
    priceCents: integer("price_cents"),
    /** Solde d'heures historique non réconcilié (anciennes feuilles) : distinct des heures justifiées (F06). */
    legacyHours: integer("legacy_hours").notNull().default(0),
    legacyHoursNote: text("legacy_hours_note"),
    /** Parcours automatique appliqué (cpf, aif, public, entreprise, cfa). */
    workflowCode: text("workflow_code"),
    /** EDOF (CPF) : entrée et sortie de formation déclarées ; Kairos (AIF) : devis et statut. */
    edofStatus: text("edof_status"),
    edofEntryAt: date("edof_entry_at"),
    edofExitAt: date("edof_exit_at"),
    kairosStatus: text("kairos_status"),
    kairosDevisRef: text("kairos_devis_ref"),
    elearningAccessSentAt: timestamp("elearning_access_sent_at", { withTimezone: true }),
    elearningFirstLoginAt: timestamp("elearning_first_login_at", { withTimezone: true }),
    /** Formation IA (NF-IA-150) : offre achetée (N1, N2, N3, N4, PARCOURS, N5) et ouverture de l'accès e-learning (SSO). */
    iaOffer: text("ia_offer"),
    iaAccessOpenedAt: timestamp("ia_access_opened_at", { withTimezone: true }),
    iaAccessOpenedBy: uuid("ia_access_opened_by"),
    placementId: uuid("placement_id"),
    quoteId: uuid("quote_id"),
    closedAt: timestamp("closed_at", { withTimezone: true }),
    closedBy: uuid("closed_by"),
    isDemo: boolean("is_demo").notNull().default(false),
    ...timestamps,
  },
  (t) => [
    uniqueIndex("enrollments_reference_unique").on(t.orgId, t.reference),
    index("enrollments_session_idx").on(t.sessionId, t.status),
    index("enrollments_person_idx").on(t.personId),
    index("enrollments_company_idx").on(t.companyId),
    index("enrollments_org_idx").on(t.orgId, t.status),
  ],
);

/** Historique des changements d'état et de rattachement (groupe, session) : journalisé, jamais effacé. */
export const enrollmentEvents = pgTable(
  "enrollment_events",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    enrollmentId: uuid("enrollment_id")
      .notNull()
      .references(() => enrollments.id, { onDelete: "cascade" }),
    kind: text("kind").notNull(),
    fromValue: text("from_value"),
    toValue: text("to_value"),
    reason: text("reason"),
    userId: uuid("user_id"),
    at: timestamp("at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("enrollment_events_enrollment_idx").on(t.enrollmentId, t.at)],
);

export const noteSectionEnum = pgEnum("note_section", ["commentaire", "interne", "pedagogique", "administratif"]);

/**
 * Notes du dossier central (F04), séparées par section et donc par droit :
 * commentaires/interventions, informations internes (blocs internes), notes pédagogiques, administratif.
 */
export const dossierNotes = pgTable(
  "dossier_notes",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    orgId: uuid("org_id")
      .notNull()
      .references(() => organismes.id, { onDelete: "cascade" }),
    enrollmentId: uuid("enrollment_id").references(() => enrollments.id, { onDelete: "cascade" }),
    personId: uuid("person_id").references(() => persons.id, { onDelete: "cascade" }),
    section: noteSectionEnum("section").notNull().default("commentaire"),
    body: text("body").notNull(),
    authorId: uuid("author_id"),
    pinned: boolean("pinned").notNull().default(false),
    ...timestamps,
  },
  (t) => [index("dossier_notes_enrollment_idx").on(t.enrollmentId, t.section), index("dossier_notes_person_idx").on(t.personId)],
);

/* ---------- Mobilisation des formateurs (proposition de mission, relance, contrat de prestation) ---------- */

export const missionStatusEnum = pgEnum("mission_status", ["proposee", "acceptee", "refusee", "sans_reponse", "annulee", "terminee"]);

export const trainerMissions = pgTable(
  "trainer_missions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    orgId: uuid("org_id")
      .notNull()
      .references(() => organismes.id, { onDelete: "cascade" }),
    trainerId: uuid("trainer_id")
      .notNull()
      .references(() => trainers.id, { onDelete: "cascade" }),
    sessionId: uuid("session_id").references(() => trainingSessions.id, { onDelete: "set null" }),
    enrollmentId: uuid("enrollment_id").references(() => enrollments.id, { onDelete: "set null" }),
    theme: text("theme").notNull(),
    startDate: date("start_date"),
    endDate: date("end_date"),
    /** Heures en visio / présentiel avec formateur (base du contrat). */
    hours: integer("hours").notNull().default(0),
    hourlyRateCents: integer("hourly_rate_cents").notNull().default(0),
    amountCents: integer("amount_cents").notNull().default(0),
    location: text("location"),
    status: missionStatusEnum("status").notNull().default("proposee"),
    proposedAt: timestamp("proposed_at", { withTimezone: true }).notNull().defaultNow(),
    respondedAt: timestamp("responded_at", { withTimezone: true }),
    /** Relance envoyée au formateur après 5 jours ouvrés sans réponse (job missions:remind). */
    reminderSentAt: timestamp("reminder_sent_at", { withTimezone: true }),
    replacedByMissionId: uuid("replaced_by_mission_id"),
    contractDocumentId: uuid("contract_document_id"),
    firstLessonDate: date("first_lesson_date"),
    notes: text("notes"),
    createdBy: uuid("created_by"),
    ...timestamps,
  },
  (t) => [index("trainer_missions_org_idx").on(t.orgId, t.status), index("trainer_missions_trainer_idx").on(t.trainerId)],
);
