# Intégration de la Formation IA (NF-IA-150) dans Next Formation : contrat entre chantiers

Décisions de Nika (5 novembre 2026) :
- Architecture **reliée** : Next Formation (ce dépôt) vend, inscrit, finance et suit ; l'espace e-learning reste une application séparée (`/home/claude/formation-ia/app`, servie sous `https://formation.nikaholding.world/ia`, basePath `/ia`). Les deux sont reliées par une **connexion unique** (SSO signé) et la même identité visuelle.
- Vitrine : bouton « Formation IA » dans le menu, **gros bloc Formation IA juste sous l'écran d'accueil** de la page d'accueil, page dédiée `/formation-ia`.
- CPF : **ne jamais écrire « éligible CPF »**. Formulation : « Certification en cours d'enregistrement au Répertoire spécifique (France Compétences) : financement CPF **bientôt** disponible ». Financements disponibles tout de suite : OPCO, entreprise, France Travail, personnel.
- Qualiopi : tout le parcours (information, inscription, pièces, contractualisation, suivi, évaluation, preuves) doit s'appuyer sur les mécanismes Qualiopi existants de Next Formation, pour les entreprises comme pour les particuliers. Ne jamais afficher « certifié Qualiopi » pour l'organisme tant que `organismes.qualiopiCertified` (ou équivalent) n'est pas vrai : écrire « conçue selon le référentiel national qualité (Qualiopi) ».
- Démo : un bouton « Tester en tant que Camille » (aucun mot de passe) ouvre une apprenante fictive, Camille Fontaine, inscrite à la Formation IA (N1 certifié, N2 en cours, dossier CPF fictif « en attente d'enregistrement RS »), dans un organisme de démonstration, puis son espace e-learning.
- Prix (TTC, TVA non applicable art. 261-4-4° CGI si l'organisme en bénéficie, sinon préciser) : **1 490 € par niveau N1-N4** (dossier RS, sous le plafond CPF RS de 1 500 €) ; parcours complet N1-N4 : 4 990 € (**tarif provisoire à valider**) ; spécialisation N5 : 1 290 € (**tarif provisoire à valider**). Les deux tarifs provisoires portent la mention « tarif de lancement, à confirmer » dans l'admin uniquement (pas sur le site public : afficher le prix, sans mention).
- Déploiement : même serveur Hetzner, Caddy en frontal ; Next Formation à la racine du domaine (port 3060), e-learning sous `/ia` (port 3061).

## Identifiants partagés (ne pas changer sans mettre à jour ce fichier)

| Élément | Valeur |
|---|---|
| Tenant / organisme vendeur (réel, `isDemo=false`) | slug `next-formation-academie`, nom `Next Formation Académie` (nom, SIRET, NDA, adresse remplaçables dans Paramètres ; valeurs d'amorçage marquées « à compléter » via `[À COMPLÉTER]` là où le CDC l'exige, jamais inventées) |
| Organisme de démonstration Camille (`isDemo=true`, supprimé après 24 h comme `/demo`) | créé par `seedIaDemo()` dans `src/server/demo/ia.ts` ; slug `next-formation-academie-demo-<suffixe>` |
| Programme | code `NF-IA-150`, titre « Formation IA : 4 niveaux certifiants (150 h) », kind `certifiante`, modalité `elearning` (FOAD), `cpfEligible=false` |
| Niveaux (modules de catalogue et sessions) | `N1` 25 h, `N2` 35 h, `N3` 45 h, `N4` 45 h, `N5` 30 h (spécialisation, après N3) ; source `/home/claude/formation-ia/export/programme-catalogue.json` et `/home/claude/formation-ia/programme/programme.json` |
| Sessions | une session FOAD « entrées permanentes » par niveau (`kind: individuel`, `status: ouverte`, dates : 1er janvier au 31 décembre de l'année en cours, à renouveler par le bootstrap chaque année) ; code `IA-<niveau>-<année>` |
| Offres achetables | `N1`, `N2`, `N3`, `N4`, `PARCOURS` (N1 à N4), `N5` |
| Droits e-learning (« entitlements ») | tableau de niveaux `["N1","N2"]`… transmis dans le jeton SSO ; `PARCOURS` = N1-N4 |
| Variables d'environnement Next Formation | `IA_APP_URL` (ex. `https://formation.nikaholding.world/ia`, local `http://localhost:3001/ia`), `IA_SSO_SECRET` (32+ caractères, identique des deux côtés) |
| Variables d'environnement app e-learning | `NF_APP_URL` (ex. `https://formation.nikaholding.world`), `NF_SSO_SECRET` (même valeur que `IA_SSO_SECRET`) |

## Jeton SSO (Next Formation → e-learning)

- URL : `${IA_APP_URL}/sso?token=<payload>.<signature>` (GET, puis redirection).
- `payload` = base64url(JSON) ; `signature` = base64url(HMAC-SHA256(payload, secret)).
- JSON : `{ "v": 1, "sub": "<id utilisateur Next Formation>", "email": "...", "firstName": "...", "lastName": "...", "iat": <epoch s>, "exp": <epoch s, iat + 300>, "nonce": "<24 car. aléatoires>", "demo": false, "entitlements": ["N1","N2"], "orgSlug": "next-formation-academie", "enrollmentId": "<uuid ou null>", "back": "https://formation.nikaholding.world/moi" }`.
- Côté e-learning : vérifier signature (comparaison en temps constant), `exp`, nonce jamais vu (table `sso_nonces`), puis :
  - `demo: true` → ouvrir une session sur le compte démo existant (`demo@formation-ia.local`), sans créer de compte ;
  - sinon → trouver ou créer l'utilisateur par e-mail (prénom, nom, `ssoOnly=true`, pas de mot de passe), enregistrer `entitlements` (null = tous les niveaux, comportement des comptes invités existants), ouvrir la session, rediriger vers le tableau de bord. Un niveau hors droits est verrouillé dans le parcours avec le message « Ce niveau n'est pas inclus dans votre inscription » et un lien vers `back`.
- Côté Next Formation : `iaSsoLink({ user, enrollment, demo })` dans `src/server/ia/sso.ts`, utilisé par le bouton « Ouvrir mon espace e-learning » (extranet apprenant) et par la démo Camille.
- Le lien n'est généré que si `IA_APP_URL` et `IA_SSO_SECRET` sont renseignés ; sinon le bouton explique la configuration manquante (`integrations` dans `src/lib/env.ts`).

## Routes publiques (Next Formation)

| Route | Rôle |
|---|---|
| `/formation-ia` | page vitrine : niveaux, programme, pédagogie (quiz, missions, tuteur IA, certificats), financements, Qualiopi, tarifs, FAQ, CTA |
| `/formation-ia/inscription` | création de compte + dossier d'inscription (étapes : identité et compte → offre → financement → pièces → récapitulatif et signature) |
| `/formation-ia/camille` | POST (formulaire) : crée ou réutilise l'organisme de démo IA, ouvre la session de Camille, redirige vers `/moi` |
| `/catalogue-public/next-formation-academie` | fiche catalogue existante (Qualiopi indicateur 1) |

Liens de l'extranet apprenant (`/moi`) : carte « Ma formation IA » (statut du dossier, pièces attendues, documents à signer, financement) et bouton « Ouvrir mon espace e-learning » (actif quand `enrollments.iaAccessOpenedAt` est renseigné).

## Ouverture de l'accès e-learning (règle)

L'accès s'ouvre (`enrollments.iaAccessOpenedAt`) quand : le contrat ou la convention est signé **et** le financement n'est pas CPF ; ou quand un membre de l'organisme ayant `enrollments.manage` clique « Ouvrir l'accès e-learning » dans le dossier. Dossier CPF : statut « en attente d'enregistrement RS », tâche créée pour l'organisme, aucune promesse d'accès. Toute ouverture est auditée (`enrollment.ia_access_open`) et produit une preuve qualité (`IND_9` ou le code adapté).

## Périmètres des chantiers (fichiers)

- **A. Vitrine** : `src/components/marketing/site.tsx` (ajout du bouton de menu uniquement), `src/components/marketing/home.tsx` (ajout d'une section sous le hero uniquement), nouveaux `src/components/marketing/formation-ia.tsx`, `src/app/(marketing)/formation-ia/page.tsx`, `src/lib/seo.ts` (ajouts). Contenu à partir de `/home/claude/formation-ia/README.md`, `programme/programme.json`, `referentiel/dossier-rs.md`, `guides/guide-apprenant.md`.
- **B1. Catalogue, bootstrap, SSO, démo Camille** : `src/server/ia/{catalog.ts,sso.ts,bootstrap.ts}`, `src/server/demo/ia.ts`, `src/scripts/bootstrap.ts` (appel de l'amorçage IA), `src/app/formation-ia/camille/route.ts` ou page, `src/lib/env.ts` (intégration `ia`), `.env.example` (variables), `src/db/schema/*` (colonnes `enrollments.iaAccessOpenedAt`, `enrollments.iaOffer`, `persons`/`users` si besoin).
- **B2. Inscription publique et dossier** : `src/app/(marketing)/formation-ia/inscription/*`, `src/server/actions/ia-inscription.ts`, `src/server/ia/enrollment.ts`, carte extranet `src/app/moi/*` (ajout d'une carte « Ma formation IA » et bouton SSO), action « Ouvrir l'accès e-learning » dans `src/app/app/[orgId]/inscriptions/[enrollmentId]` (ajout d'un bloc), tests vitest des règles (ouverture d'accès, offres → entitlements, prix).
- **C. App e-learning** (`/home/claude/formation-ia/app`) : route `/sso`, table `sso_nonces`, colonnes `users.ssoOnly`, `users.entitlements`, verrouillage des niveaux, lien retour `NF_APP_URL`, migration `drizzle/0005`, tests, `deploy/` (Caddy `/ia`, script de déploiement port 3061), README.

Chaque chantier ne modifie que son périmètre ; les besoins hors périmètre sont signalés dans le rapport final pour l'intégrateur.
