ALTER TABLE "enrollments" ADD COLUMN "ia_offer" text;--> statement-breakpoint
ALTER TABLE "enrollments" ADD COLUMN "ia_access_opened_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "enrollments" ADD COLUMN "ia_access_opened_by" uuid;