/**
 * GET /ia/sso?token=<payload>.<signature> : connexion unique depuis Next Formation (bouton « Ouvrir mon espace
 * e-learning » de l'extranet apprenant, démo Camille). Contrat : next-formation/docs/formation-ia-integration.md.
 *
 * Vérifications, dans l'ordre : secret configuré (NF_SSO_SECRET) → signature HMAC-SHA256 (temps constant), version,
 * dates → nonce jamais vu (table sso_nonces) → compte démo ou compte trouvé / créé par e-mail → session (cookie
 * nfia_session) → redirection vers le tableau de bord.
 *
 * Toute erreur renvoie vers /sso/erreur?code=… (page dans le design de l'app, sans détail exploitable) ; le motif
 * précis n'est écrit que dans les journaux du serveur.
 */
import { createSession, getSession, requestMeta, setNfLinked, SESSION_DAYS } from "@/server/auth";
import { consumeSsoNonce, resolveSsoUser } from "@/server/sso";
import { ssoSecret, verifySsoToken, type SsoFailure } from "@/lib/sso";
import { sharedLimiter } from "@/lib/rate-limit";
import { routes, withBase } from "@/lib/paths";

export const dynamic = "force-dynamic";

const ssoLimiter = sharedLimiter("sso", { limit: 30, windowMs: 60_000 });

export type SsoErrorCode = "config" | "invalide" | "expire" | "rejoue" | "demo" | "compte" | "trop";

function redirectTo(path: string): Response {
  // Location relative (avec /ia) : correcte derrière Caddy quel que soit l'hôte public.
  return new Response(null, { status: 303, headers: { Location: withBase(path), "Cache-Control": "no-store" } });
}

function fail(code: SsoErrorCode, detail: string): Response {
  console.warn(`[sso] refus (${code}) : ${detail}`);
  return redirectTo(`${routes.ssoError}?code=${code}`);
}

const FAILURE_CODES: Record<SsoFailure, SsoErrorCode> = {
  malformed: "invalide",
  signature: "invalide",
  version: "invalide",
  payload: "invalide",
  expired: "expire",
  not_yet_valid: "expire",
};

export async function GET(req: Request): Promise<Response> {
  const secret = ssoSecret();
  if (!secret) return fail("config", "NF_SSO_SECRET absent ou trop court (32 caractères minimum).");
  const { ip } = await requestMeta();
  if (!ssoLimiter.hit(ip ?? "?").allowed) return fail("trop", `limite atteinte pour ${ip ?? "?"}`);

  const token = new URL(req.url).searchParams.get("token") ?? "";
  if (!token) return fail("invalide", "paramètre token absent");
  const now = new Date();
  const v = verifySsoToken(token, secret, now);
  if (!v.ok) return fail(FAILURE_CODES[v.reason], `jeton ${v.reason}`);

  if (!(await consumeSsoNonce(v.payload, now))) return fail("rejoue", `nonce déjà utilisé pour ${v.payload.email}`);

  const r = await resolveSsoUser(v.payload);
  if (!r.ok) return fail(r.reason === "demo_unavailable" ? "demo" : "compte", r.reason);

  // Une session déjà ouverte sur un autre compte est remplacée par celle du jeton (le cookie est réécrit).
  const current = await getSession();
  if (current && current.id !== r.user.id) console.info(`[sso] session ${current.email} remplacée par ${r.user.email}`);
  await createSession(r.user.id);
  // v1.5.1 : tableau de bord unique côté Next Formation : la session est marquée « reliée » et l'apprenant arrive
  // directement dans sa formation (le parcours), pas sur le tableau de bord de l'application.
  await setNfLinked(new Date(now.getTime() + SESSION_DAYS * 86_400_000));
  console.info(`[sso] connexion ${r.user.email}${r.created ? " (compte créé)" : ""}${v.payload.demo ? " (démo)" : ""}`);
  return redirectTo(routes.parcours);
}
